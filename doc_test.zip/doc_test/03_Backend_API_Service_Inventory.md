# Backend API Controller and Service Inventory

ASP.NET Web API inventory from `NPM_API_BackUp/NPMAPI` plus worker/support projects. Default route template is `api/{controller}/{action}/{id}`.

## Dependency Injection Map

| Interface | Implementation |
| --- | --- |
| IRepository | Repository |
| IUserManagementSetup | UserManagementService |
| ICompanyRepository | CompanyService |
| IDashboardRepository | DashboardService |
| IAlertRepository | AlertService |
| IDemographicRepository | DemographicService |
| IInsuranceSetupRepository | InsuranceSetupService |
| IPracticeRepository | PracticeService |
| IReportRepository | ReportService |
| ISetupRepository | SetupService |
| ISubmissionRepository | SubmissionService |
| IEncryption | EncryptionService |
| ISchedulerRepository | SchedulerService |
| IFileHandler | FileHandlerService |
| IEligibility | EligibilityService |
| IERAImport | ERAImportService |
| IFTP | FTPService |
| IPDFRepository | PDFService |
| IPatientAttachment | PatientAttachmentService |
| IClaimsAttachments | ClaimsAttachmentsService |
| IPatientBilling | InboxHealthService |
| IVendorRepository | VendorService |
| IPaymentsRepository | PaymentsService |
| IDeltaSyncRepository | DeltaSyncService |
| IScrubberRepository | ScrubberService |
| IReferralPhysicianRepository | ReferralPhysiciansService |
| IUBClaim | UBClaim |
| IClaimStatusService | ClaimStatusService |
| IClaimService | ClaimStatus |
| IGenerateBatch276Service | GenerateBatch276Service |
| IClaimBatch276 | ClaimBatch276 |
| ITicketTrackerRrepo | TTService |
| ITicketAttachment | TicketAttachmentsService |
| ICredentialingRepository | CredentialingService |
| ICredEDIERASetupRepository | CredEDIERASetupService |
| IExcelFileHandler | ExcelFileHandlerService |
| IImportWizard | ImportWizardService |
| IDemographicRepository | DemographicService |
| IAuditLogService | AuditLogService |
| IMemoryCache | MemoryCache |

## API Controller Actions

| Controller | HTTP | Endpoint | Return | Params | Source |
| --- | --- | --- | --- | --- | --- |
| AlertController | POST | api/Alert/SaveAlert | ResponseModel | NpmAlert model | NPM_API_BackUp/NPMAPI/Controllers/AlertController.cs:31 |
| AlertController | POST | api/Alert/SaveLoginAlert | ResponseModel | NpmAlert model | NPM_API_BackUp/NPMAPI/Controllers/AlertController.cs:38 |
| AlertController | GET | api/Alert/GetAlertForPatient | ResponseModel | long patientaccount | NPM_API_BackUp/NPMAPI/Controllers/AlertController.cs:47 |
| AlertController | GET | api/Alert/GetLoginAlert | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/AlertController.cs:55 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetUsersList | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:20 |
| ClaimAssignmentController | ANY | api/ClaimAssignment/PostAllAssignedClaims | ResponseModel | claimassigneeModel model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:26 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetAssignedClaimData | ResponseModel | long claimnumber | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:32 |
| ClaimAssignmentController | POST | api/ClaimAssignment/EditAssignedClaims | ResponseModel | editassignedclaimModel model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:38 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetAllAssignedClaims | ResponseModel | long practice_code, long assignedByuserid | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:44 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetAllAssignedClaimsForPractice | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:58 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetSpecificAssignedClaimData | ResponseModel | long claimassignee_id | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:64 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetSpecificAssignedClaimNotes | ResponseModel | long ClaimAssignee_notes_ID | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:70 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetAllAssignedClaimsNotifications | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:76 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetAllAssignedAccountsNotifications | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:82 |
| ClaimAssignmentController | POST | api/ClaimAssignment/PostAllAssignedAccounts | ResponseModel | accountassigneeModel model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:90 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetAllAssignedAccounts | ResponseModel | long practice_code, long assignedByuserid | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:98 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetAllAssignedAccountsForPractice | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:112 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetSpecificAssignedAccountNotes | ResponseModel | long AccountAssignee_notes_ID | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:118 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetSpecificAssignedAccountData | ResponseModel | long accountassignee_id | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:124 |
| ClaimAssignmentController | POST | api/ClaimAssignment/EditAssignedAccounts | ResponseModel | editassignedaccountModel model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:130 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetAllActivePractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:137 |
| ClaimAssignmentController | GET | api/ClaimAssignment/CheckClaimAssignment | ResponseModel | long claimno | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:142 |
| ClaimAssignmentController | GET | api/ClaimAssignment/CheckAccountAssignment | ResponseModel | long accnum | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:147 |
| ClaimAssignmentController | POST | api/ClaimAssignment/ClaimTaskAssignment | ResponseModel | TaskAssignmentClaimList model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:152 |
| ClaimAssignmentController | GET | api/ClaimAssignment/GetPracticeAssignUsers | ResponseModel | long userid | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:157 |
| ClaimsAttachmentsController | POST | api/ClaimsAttachments/Attach | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs:34 |
| ClaimsAttachmentsController | GET | api/ClaimsAttachments/GetAll | IHttpActionResult | long Claim_No | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs:99 |
| ClaimsAttachmentsController | GET | api/ClaimsAttachments/GetAttachmentCodeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs:105 |
| ClaimsAttachmentsController | GET | api/ClaimsAttachments/Download | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs:111 |
| CompanyController | ANY | api/Company/GetCompanyList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:20 |
| CompanyController | ANY | api/Company/GetCompanyRecord | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:24 |
| CompanyController | POST | api/Company/SaveCompany | ResponseModel | [FromBody] Company model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:30 |
| CompanyController | GET | api/Company/DeleteCompany | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:43 |
| CompanyController | GET | api/Company/GetCompaniesAndRolesSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:48 |
| CompanyController | ANY | api/Company/GetOfficeList | ResponseModel | long? companyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:56 |
| CompanyController | ANY | api/Company/GetOfficeRecord | ResponseModel | long OfficeId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:60 |
| CompanyController | POST | api/Company/SaveOffice | ResponseModel | [FromBody] Office model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:66 |
| CompanyController | GET | api/Company/DeleteOffice | ResponseModel | long OfficeId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:79 |
| CompanyController | ANY | api/Company/GetShiftList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:88 |
| CompanyController | ANY | api/Company/GetShiftRecord | ResponseModel | long ShiftId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:92 |
| CompanyController | POST | api/Company/SaveShift | ResponseModel | [FromBody] Shift model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:98 |
| CompanyController | GET | api/Company/DeleteShift | ResponseModel | long shiftId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:111 |
| CompanyController | ANY | api/Company/GetAllTeamsList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:119 |
| CompanyController | ANY | api/Company/GetTeamList | ResponseModel | int? companyId, int? officeId, int? departmentId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:123 |
| CompanyController | ANY | api/Company/GetTeamRecord | ResponseModel | long TeamId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:127 |
| CompanyController | POST | api/Company/SaveTeam | ResponseModel | [FromBody] TeamViewModel model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:133 |
| CompanyController | GET | api/Company/DeleteTeam | ResponseModel | long TeamId, int OfficeId, int DepartmentId, int CompanyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:146 |
| CompanyController | ANY | api/Company/GetCompanyOfficenDepartment | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:152 |
| CompanyController | ANY | api/Company/GetOfficeIdFromDept | ResponseModel | long DeptId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:160 |
| CompanyController | ANY | api/Company/GetDepartmentList | ResponseModel | long? officeId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:164 |
| CompanyController | ANY | api/Company/GetDepartmentRecord | ResponseModel | long DepartmentId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:168 |
| CompanyController | POST | api/Company/SaveDepartment | ResponseModel | [FromBody] Department model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:174 |
| CompanyController | GET | api/Company/DeleteDepartment | ResponseModel | long DepartmentId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:187 |
| CompanyController | ANY | api/Company/GetDesignationList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:196 |
| CompanyController | ANY | api/Company/GetDesignationRecord | ResponseModel | long DesignationId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:200 |
| CompanyController | POST | api/Company/SaveDesignation | ResponseModel | [FromBody] DesignationViewModel model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:206 |
| CompanyController | GET | api/Company/DeleteDesignation | ResponseModel | long DesignationId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:219 |
| CredEDIERASetupController | GET | api/CredEDIERASetup/GetLookupLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:27 |
| CredEDIERASetupController | POST | api/CredEDIERASetup/AddEditCredApp | ResponseModel | EDI_ERA_Setup cred_App_ViewModel | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:32 |
| CredEDIERASetupController | GET | api/CredEDIERASetup/GetCredEDIERASetupById | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:37 |
| CredEDIERASetupController | POST | api/CredEDIERASetup/AddEditCred_EDIERA_Note | ResponseModel | EDI_ERA_Notes eDI_ERA_Notes | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:42 |
| CredEDIERASetupController | POST | api/CredEDIERASetup/SearchCredEDIERASetup | ResponseModel | EdiEraSetupSearchViewModel searchViewModel | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:47 |
| CredEDIERASetupController | GET | api/CredEDIERASetup/GetCred_EDIERA_Notes | ResponseModel | long application_Id | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:53 |
| CredEDIERASetupController | POST | api/CredEDIERASetup/UploadCred_EDIERA_Document | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:59 |
| CredEDIERASetupController | GET | api/CredEDIERASetup/GetCred_EDIERA_Documents | ResponseModel | long applicationId | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:116 |
| CredEDIERASetupController | GET | api/CredEDIERASetup/GetCred_EDIERA_DocumentById | IHttpActionResult | long docId | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:125 |
| CredEDIERASetupController | GET | api/CredEDIERASetup/DeleteCred_EDIERA_Document | ResponseModel | long documentId | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:167 |
| CredEDIERASetupController | POST | api/CredEDIERASetup/AddTPAName | ResponseModel | TPA_Name_List tPA_Name_List | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:175 |
| CredEDIERASetupController | GET | api/CredEDIERASetup/GetEDIERAEFTReport | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:180 |
| CredEDIERASetupController | GET | api/CredEDIERASetup/GetEDIERAEFTGridReport | ResponseModel | long practiceCode,long ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:185 |
| CredEDIERASetupController | POST | api/CredEDIERASetup/AddClearingHouse | ResponseModel | Clearing_Houses clearing_Houses | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:190 |
| CredEDIERASetupController | POST | api/CredEDIERASetup/AddSoft | ResponseModel | Practice_Software practice_Software | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:195 |
| CredentialingController | GET | api/Credentialing/GetLookupLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:35 |
| CredentialingController | GET | api/Credentialing/GetObjectiveTypes | ResponseModel | int appTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:40 |
| CredentialingController | POST | api/Credentialing/AddEditCredApp | ResponseModel | Cred_App_ViewModel cred_App_ViewModel | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:45 |
| CredentialingController | POST | api/Credentialing/SearchCredApp | ResponseModel | CredAppSearchViewModel searchViewModel | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:50 |
| CredentialingController | GET | api/Credentialing/GetCredAppById | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:57 |
| CredentialingController | POST | api/Credentialing/AddEditCredAppNote | ResponseModel | Cred_App_Notes cred_App_Notes | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:63 |
| CredentialingController | GET | api/Credentialing/GetCredAppNotes | ResponseModel | long application_Id | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:68 |
| CredentialingController | POST | api/Credentialing/UploadCredAppDocument | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:74 |
| CredentialingController | GET | api/Credentialing/GetCredAppDocuments | ResponseModel | long applicationId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:131 |
| CredentialingController | GET | api/Credentialing/GetCredAppDocumentById | IHttpActionResult | long docId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:140 |
| CredentialingController | GET | api/Credentialing/DeleteCredAppDocument | ResponseModel | long documentId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:182 |
| CredentialingController | GET | api/Credentialing/GetUsersByModuleName | ResponseModel | string moduleName | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:190 |
| CredentialingController | GET | api/Credentialing/GetActivePractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:197 |
| CredentialingController | GET | api/Credentialing/GetCredAppReport | ResponseModel | long practiceCode, int? ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:202 |
| CredentialingController | GET | api/Credentialing/GetCredTasks | ResponseModel | long? PracticeCode, long? UserId, int? Obj_Type_Id | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:207 |
| CredentialingController | GET | api/Credentialing/GetCredUserByRole | ResponseModel | string Role | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:212 |
| CredentialingController | GET | api/Credentialing/GetCredUserListByRole | ResponseModel | string Role, long practiceId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:218 |
| CredentialingController | GET | api/Credentialing/GetHospitalStatusReport | ResponseModel | long practiceCode, long ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:231 |
| CredentialingController | GET | api/Credentialing/GetHospitalGridReport | ResponseModel | long practiceCode,long providercode, long ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:236 |
| CredentialingController | GET | api/Credentialing/GetTaxonomyCode | ResponseModel | string taxonomycode | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:241 |
| CredentialingController | GET | api/Credentialing/GetCredPortals | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:246 |
| CredentialingController | POST | api/Credentialing/AddEditCredPortal | ResponseModel | CredPortal_View cred_portal | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:251 |
| CredentialingController | GET | api/Credentialing/GetCredGridReport | ResponseModel | long practiceCode, long providerCode, int ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:258 |
| CredentialingController | GET | api/Credentialing/GetCredProviderDetails | ResponseModel | string HospitalName , long ProviderCode | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:263 |
| DashboardController | GET | api/Dashboard/GetDashboardData | ResponseModel | long practiceCode,string fromDate,string toDate | NPM_API_BackUp/NPMAPI/Controllers/DashboardController.cs:18 |
| DashboardController | GET | api/Dashboard/GetExternalPractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DashboardController.cs:24 |
| DashboardController | GET | api/Dashboard/GetOpenPaymentBatches | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DashboardController.cs:31 |
| DemographicController | ANY | api/Demographic/GetPatientList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:37 |
| DemographicController | ANY | api/Demographic/GetstateList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:42 |
| DemographicController | POST | api/Demographic/SearchPatient | ResponseModel | [FromBody] PatientSearchModel SearchModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:49 |
| DemographicController | POST | api/Demographic/IsPatientAlreadyExist | ResponseModel | DublicatePatientCheckModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:54 |
| DemographicController | GET | api/Demographic/checkDuplicateDOS | ResponseModel | long patientAccount, DateTime dos | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:65 |
| DemographicController | GET | api/Demographic/GetPatientModel | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:71 |
| DemographicController | GET | api/Demographic/GetPatient | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:76 |
| DemographicController | GET | api/Demographic/DeletePatient | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:81 |
| DemographicController | ANY | api/Demographic/GetFinancialGurantor | ResponseModel | string Name | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:85 |
| DemographicController | ANY | api/Demographic/GetFinancialGurantorSubscriber | ResponseModel | string Name | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:89 |
| DemographicController | ANY | api/Demographic/GetCityState | ResponseModel | string ZipCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:93 |
| DemographicController | POST | api/Demographic/AddEditPatient | ResponseModel | [FromBody] PatientCreateViewModel PatientModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:98 |
| DemographicController | GET | api/Demographic/InquiryByPracPatProvider | ResponseModelForE | long PracticeCode, long PatAcccount, long ProviderCode, long insurance_id | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:148 |
| DemographicController | POST | api/Demographic/SearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:154 |
| DemographicController | POST | api/Demographic/SavePatientInsurance | ResponseModel | [FromBody] Patient_Insurance Model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:159 |
| DemographicController | GET | api/Demographic/DeletePatientInsurance | ResponseModel | long PatientAccount, long PatientInsuranceId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:171 |
| DemographicController | ANY | api/Demographic/GetPatientNotes | ResponseModel | long PatientAccount, int? number | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:175 |
| DemographicController | ANY | api/Demographic/GetPatientNote | ResponseModel | long PatientNotesId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:179 |
| DemographicController | POST | api/Demographic/SavePatientNotes | ResponseModel | [FromBody] Patient_Notes PatientNote | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:184 |
| DemographicController | ANY | api/Demographic/DeletePatientNote | ResponseModel | long PatientAccount, long PatientNotesId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:197 |
| DemographicController | POST | api/Demographic/SaveClaimAttachmentNotes | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:203 |
| DemographicController | POST | api/Demographic/DeleteClaimAttachmentNote | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:218 |
| DemographicController | POST | api/Demographic/UploadImage | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:226 |
| DemographicController | GET | api/Demographic/GetImage | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:246 |
| DemographicController | ANY | api/Demographic/GetAppointments | ResponseModel | long PatientAccount = 0 | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:259 |
| DemographicController | ANY | api/Demographic/GetClaimModel | ResponseModel | long PatientAccount, long ClaimNo = 0 | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:263 |
| DemographicController | ANY | api/Demographic/GetAdmissionType | ResponseModel | long PatientAccount, string ClaimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:267 |
| DemographicController | POST | api/Demographic/SaveClaim | Task<ResponseModel> | ClaimsViewModel ClaimModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:272 |
| DemographicController | ANY | api/Demographic/GetPatientClaims | ResponseModel | long ClaimNo = 0 | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:307 |
| DemographicController | ANY | api/Demographic/DeleteClaim | ResponseModel | long ClaimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:311 |
| DemographicController | ANY | api/Demographic/GetClaimNotes | ResponseModel | long ClaimNo, int? number | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:315 |
| DemographicController | ANY | api/Demographic/GetClaimNote | ResponseModel | long ClaimNotesId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:319 |
| DemographicController | GET | api/Demographic/GetServiceTypeCodesDescription | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:324 |
| DemographicController | GET | api/Demographic/GetModifiers | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:331 |
| DemographicController | POST | api/Demographic/SaveClaimNotes | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:336 |
| DemographicController | ANY | api/Demographic/DeleteClaimNote | ResponseModel | long PatientAccount, long PatientNotesId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:348 |
| DemographicController | ANY | api/Demographic/GetFacilitySelectList | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:353 |
| DemographicController | ANY | api/Demographic/GetFacility | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:357 |
| DemographicController | ANY | api/Demographic/SearchFacilities | ResponseModel | [FromBody] FacilitySearchModel FacilityModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:361 |
| DemographicController | GET | api/Demographic/GetDiagnosis | ResponseModel | string DiagCode, string DiagDesc, long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:366 |
| DemographicController | POST | api/Demographic/AddDxToProvider | ResponseModel | [FromBody] PracticeDxModel PracDxModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:371 |
| DemographicController | ANY | api/Demographic/SavePatientClaimDiagnose | ResponseModel | string DiagCode, long ClaimNo, bool IsEdit, int Sequence | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:386 |
| DemographicController | ANY | api/Demographic/GetPatientClaimsSummary | ResponseModel | long PatientAccount = 0, bool IncludeDeleted = false, bool isAmountDueGreaterThanZero = false | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:397 |
| DemographicController | POST | api/Demographic/GetProcedureCharges | ResponseModel | [FromBody] CPTWiseCharges obj | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:402 |
| DemographicController | POST | api/Demographic/ValidateAddress | ResponseModel | [FromBody] ValidateAddreesRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:407 |
| DemographicController | POST | api/Demographic/GetPracticeClaims | ResponseModel | ClaimSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:418 |
| DemographicController | GET | api/Demographic/GetPatientSelectList | ResponseModel | string searchText, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:429 |
| DemographicController | GET | api/Demographic/GetInsuranceSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:434 |
| DemographicController | GET | api/Demographic/GetProviderSelectList | ResponseModel | string searchText, long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:439 |
| DemographicController | GET | api/Demographic/GetLocationSelectList | ResponseModel | string searchText, long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:444 |
| DemographicController | GET | api/Demographic/GetPanelBillingLocationSelectList | ResponseModel | long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:451 |
| DemographicController | GET | api/Demographic/GetPracticeDefaultLocation | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:456 |
| DemographicController | GET | api/Demographic/GetPatientSummary | ResponseModel | long patientAccount, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:461 |
| DemographicController | GET | api/Demographic/GetClaimSummaryByNo | ResponseModel | long claimNo, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:466 |
| DemographicController | GET | api/Demographic/GetPatientClaimsForStatement | ResponseModel | long patientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:471 |
| DemographicController | POST | api/Demographic/GeneratePatientStatement | ResponseModel | PatientStatementRequest model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:476 |
| DemographicController | POST | api/Demographic/GeneratePatientStatementdn | ResponseModel | PatientStatementRequest model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:487 |
| DemographicController | ANY | api/Demographic/GenItemizedPatientStatement | ResponseModel | Patient_Statement_Itemized model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:502 |
| DemographicController | GET | api/Demographic/GetStatementPatient | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:514 |
| DemographicController | GET | api/Demographic/GetCitiesByZipCode | ResponseModel | string zipCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:520 |
| DemographicController | GET | api/Demographic/GetPAByAccount | ResponseModel | long aCCOUNT_NO | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:527 |
| DemographicController | GET | api/Demographic/GetClaimAndDos | ResponseModel | long patientAcc | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:534 |
| DemographicController | GET | api/Demographic/CheckCollectionStatus | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:540 |
| DemographicController | GET | api/Demographic/getClaimDetails | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:547 |
| DemographicController | POST | api/Demographic/AddOrUpdatePanelCPTCodes | ResponseModel | PanelCPTCodeList panelCPTCodeList | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:555 |
| DemographicController | GET | api/Demographic/getPanelCodeCpt | ResponseModel | long PracticeCode, long ProviderCode, long LocationCode, string cptCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:561 |
| DemographicController | GET | api/Demographic/getPanelCodeCptClaim | ResponseModel | long PracticeCode, long ProviderCode, long LocationCode, string PanelCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:567 |
| DemographicController | GET | api/Demographic/IsAlternateCodeRemoved | ResponseModel | string Cpt_Code, string Cpt_Description, string AlernateCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:576 |
| DemographicController | GET | api/Demographic/GetPanelAlternateCode | ResponseModel | long PracticeCode, long ProviderCode, long LocationCode, string AlternateCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:583 |
| DemographicController | GET | api/Demographic/CheckPanelCodeExists | ResponseModel | long PracticeCode, long ProviderCode, long LocationCode, string PanelCode, long panelBillingCodeId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:589 |
| DemographicController | GET | api/Demographic/GetPanelBillingSummaryByPractice | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:594 |
| DemographicController | POST | api/Demographic/deleteRows | ResponseModel | long[] rowIds | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:599 |
| DemographicController | GET | api/Demographic/GetPanelCodeDetailsForEdits | ResponseModel | long panelBillingCodeId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:605 |
| DemographicController | GET | api/Demographic/PanelCodeStatus | ResponseModel | int panelBillingCodeId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:611 |
| DemographicController | ANY | api/Demographic/ShowPacket277CAClaimReason | ResponseModel | string claimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:622 |
| DemographicController | POST | api/Demographic/AddClaimOverPayment | Task<ResponseModel> | ClaimOverpayment claimOverpayment | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:692 |
| DemographicController | GET | api/Demographic/GetClaimOverPayment | Task<ResponseModel> | long claimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:714 |
| DemographicController | GET | api/Demographic/GetStateDropDownList | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:722 |
| DemographicController | POST | api/Demographic/ProviderPayerSearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:731 |
| DemographicController | GET | api/Demographic/GetClaimsWithPatientDue | ResponseModel | long practicecode, long patientaccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:738 |
| DemographicController | POST | api/Demographic/InsertOrUpdateClaimPayments | ResponseModel | List<Claim_Payments> paymentList | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:743 |
| DemographicController | POST | api/Demographic/SaveUnappliedAmount | ResponseModel | UnappliedPaymentViewModel unappliedPayment | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:748 |
| DemographicController | GET | api/Demographic/GetUnappliedPaymentsByBatchNo | ResponseModel | string batchNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:753 |
| DemographicController | POST | api/Demographic/GetBillingPhysiciansList | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:759 |
| DemographicController | POST | api/Demographic/DeleteUnappliedPayment | ResponseModel | long unappliedPaymentId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:767 |
| DemographicController | GET | api/Demographic/GetUnappliedAmountByPatient | ResponseModel | long patientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:773 |
| DemographicController | GET | api/Demographic/GetClaimsDetailsByPatient | ResponseModel | long Patient_Account | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:778 |
| DemographicController | GET | api/Demographic/GetBatchDetailsByPatient | ResponseModel | long Patient_Account | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:783 |
| DemographicController | GET | api/Demographic/SearchReferringPhysicians | ResponseModel | string firstName, string lastName, string npi, string zip, string city, string state | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:790 |
| DemographicController | ANY | api/Demographic/SaveClaimModel | ResponseModel | ClaimsViewModel ClaimModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:798 |
| DemographicController | ANY | api/Demographic/GetClaimInsurance | ResponseModel | long claimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:803 |
| ERAController | ANY | api/ERA/GetUserId | static long |  | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:37 |
| ERAController | POST | api/ERA/ERAImport | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:50 |
| ERAController | POST | api/ERA/ManualERAFileProcessing | Task<ResponseModel> | ERA_Request ERA | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:102 |
| ERAController | POST | api/ERA/Import | Task<ResponseModel> | ERA_Request ERA | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:272 |
| ERAController | ANY | api/ERA/Import | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:443 |
| ERAController | POST | api/ERA/WeekHistoryOfERA | ResponseModel | CheckPracticeCode Search | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:469 |
| ERAController | GET | api/ERA/LogException | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:478 |
| HCFAController | GET | api/HCFA/GenerateHcfa | HttpResponseMessage | string claimNo, string insuranceType, bool isPrintable = false | NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs:18 |
| HCFAController | GET | api/HCFA/GenerateUB | HttpResponseMessage | string claimNo, bool isPrintable = false | NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs:31 |
| HCFAController | GET | api/HCFA/GenerateBatchHcfa | HttpResponseMessage | string batchIds, string insuranceType, bool isPrintable = false, string status=null | NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs:42 |
| HCFAController | GET | api/HCFA/canPrint | bool | string batchIds | NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs:130 |
| HomeController | ANY | api/Home/Index | ActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/HomeController.cs:8 |
| ImportWizardController | POST | api/ImportWizard/ExcelImport | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:35 |
| ImportWizardController | GET | api/ImportWizard/DownloadImportWizardTemplateFile | HttpResponseMessage |  | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:106 |
| ImportWizardController | GET | api/ImportWizard/GetImportWizard | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:140 |
| ImportWizardController | GET | api/ImportWizard/IssueExcelExport | ResponseModel | long imprtbatchid , long practicecode | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:146 |
| InboxHealthController | POST | api/InboxHealth/Webhook | Task<IHttpActionResult> |  | NPM_API_BackUp/NPMAPI/Controllers/InboxHealthController.cs:24 |
| InsuranceSetupController | ANY | api/InsuranceSetup/GetInsuranceGroupList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:20 |
| InsuranceSetupController | ANY | api/InsuranceSetup/GetInsuranceGroup | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:24 |
| InsuranceSetupController | POST | api/InsuranceSetup/SaveInsuranceGroup | ResponseModel | [FromBody] Insurance_Groups model | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:29 |
| InsuranceSetupController | GET | api/InsuranceSetup/DeleteInsuranceGroup | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:41 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsuranceGroupsSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:46 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetSmartInsuranceGroupsSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:51 |
| InsuranceSetupController | ANY | api/InsuranceSetup/GetInsuranceNameList | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:65 |
| InsuranceSetupController | ANY | api/InsuranceSetup/GetInsuranceName | ResponseModel | long InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:69 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsuranceNameModel | ResponseModel | long? InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:74 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsuranceNameSelectList | ResponseModel | long? InsuranceGroupId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:79 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetSmartInsuranceNameList | ResponseModel | long? InsuranceGroupId, string searchText | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:84 |
| InsuranceSetupController | POST | api/InsuranceSetup/SaveInsuranceName | ResponseModel | [FromBody] InsuranceNameModelViewModel model | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:89 |
| InsuranceSetupController | GET | api/InsuranceSetup/DeleteInsuranceName | ResponseModel | long InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:101 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsurancePayerList | ResponseModel | long InsuranceGroupId, long InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:110 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsurancePayer | ResponseModel | long InsurancePayerId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:115 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsurancePayerModel | ResponseModel | long? InsurancePayerId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:120 |
| InsuranceSetupController | POST | api/InsuranceSetup/SaveInsurancePayer | ResponseModel | [FromBody] InsurancePayerViewModel model | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:125 |
| InsuranceSetupController | GET | api/InsuranceSetup/DeleteInsurancePayer | ResponseModel | long InsurancePayerId, long InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:137 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetSmartInsurancePayersList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:142 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsPayerList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:157 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsPayerById | ResponseModel | string InsurancePayerId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:162 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsPayerByState | ResponseModel | string InsurancePayerState | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:167 |
| InsuranceSetupController | ANY | api/InsuranceSetup/GetInsuranceList | ResponseModel | long? GroupId, string insuranceName, string insurancePayerName | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:171 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsurance | ResponseModel | long InsuranceId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:179 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetInsuranceModel | ResponseModel | long? InsuranceId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:184 |
| InsuranceSetupController | POST | api/InsuranceSetup/SaveInsurance | ResponseModel | [FromBody] Insurance model | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:189 |
| InsuranceSetupController | GET | api/InsuranceSetup/DeleteInsurance | ResponseModel | long InsuranceId, long InsurancePayerId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:201 |
| InsuranceSetupController | GET | api/InsuranceSetup/GetRelationsSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:206 |
| InsuranceSetupController | POST | api/InsuranceSetup/AddInsurance | ResponseModel | [FromBody] AddInsuranceRequest addInsuranceRequest | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:215 |
| ItemizedPatientStatmentController | GET | api/ItemizedPatientStatment/GenerateItemizedPsForPrint | HttpResponseMessage | long patientAccount, long practiceCode, string messageToPrint | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:21 |
| ItemizedPatientStatmentController | POST | api/ItemizedPatientStatment/GenerateItemizedPsForDownload | HttpResponseMessage | StatmentDownloadRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:51 |
| ItemizedPatientStatmentController | GET | api/ItemizedPatientStatment/GeneraterollingForDownload | HttpResponseMessage | string prac_code , string duration | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:81 |
| ItemizedPatientStatmentController | GET | api/ItemizedPatientStatment/GetAllMessages | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:114 |
| ItemizedPatientStatmentController | POST | api/ItemizedPatientStatment/AddMessage | ResponseModel | PatientStatementMessages Model | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:121 |
| ItemizedPatientStatmentController | POST | api/ItemizedPatientStatment/EditMessage | ResponseModel | PatientStatementMessages Model | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:129 |
| ItemizedPatientStatmentController | GET | api/ItemizedPatientStatment/DeleteMessage | ResponseModel | long MessageID | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:136 |
| PatientAttachmentsController | POST | api/PatientAttachments/Attach | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:29 |
| PatientAttachmentsController | GET | api/PatientAttachments/Delete | IHttpActionResult | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:83 |
| PatientAttachmentsController | GET | api/PatientAttachments/GetAll | IHttpActionResult | long patientAccount | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:89 |
| PatientAttachmentsController | GET | api/PatientAttachments/ClaimDelete | IHttpActionResult | long id,long Document_ID | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:94 |
| PatientAttachmentsController | GET | api/PatientAttachments/GetAttachmentCodeList | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:100 |
| PatientAttachmentsController | GET | api/PatientAttachments/Download | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:105 |
| PatientAttachmentsController | ANY | api/PatientAttachments/TicketAttach | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:135 |
| PatientAttachmentsController | POST | api/PatientAttachments/UploadFiles | Task<IHttpActionResult> |  | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:190 |
| PatientAttachmentsController | GET | api/PatientAttachments/DeleteTicketAttachment | IHttpActionResult | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:270 |
| PatientAttachmentsController | GET | api/PatientAttachments/DownloadTicketAttachment | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:276 |
| PatientAttachmentsController | GET | api/PatientAttachments/DownloadStatementPdf | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:306 |
| PaymentsController | POST | api/Payments/SearchPayment | ResponseModel | PaymentsSearchRequestModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:21 |
| PaymentsController | POST | api/Payments/AddInsurancePayment | ResponseModel | [FromBody] InsurancePaymentViewModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:29 |
| PaymentsController | POST | api/Payments/AddPatientPayment | ResponseModel | [FromBody] PatientPayment request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:42 |
| PaymentsController | ANY | api/Payments/GetPaymentList | List<SelectListViewModel> |  | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:54 |
| PaymentsController | GET | api/Payments/GetClaimsSummary | ResponseModel | string ClaimId, string practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:60 |
| PaymentsController | POST | api/Payments/GetClaimBypatient | ResponseModel | patientBasedClaimModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:68 |
| PaymentsController | POST | api/Payments/GetClaimByins | ResponseModel | insBasedClaimModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:76 |
| PaymentsController | POST | api/Payments/PostClaims | ResponseModel | postClaim request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:85 |
| PaymentsController | GET | api/Payments/getClaimsDetails | ResponseModel | long claimNo, long patientaccount | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:93 |
| PaymentsController | POST | api/Payments/SaveClaimsDetails | ResponseModel | ClaimsPaymentDetailModel[] cpd | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:101 |
| PaymentsController | GET | api/Payments/checkPostedClaims | ResponseModel | long batchno, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:109 |
| PaymentsController | POST | api/Payments/CreateUpdateBatch | ResponseModel | [FromBody] BatchCreateModel batchData | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:120 |
| PaymentsController | POST | api/Payments/SearchBatch | ResponseModel | BatchsSearchRequestModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:127 |
| PaymentsController | POST | api/Payments/CloseBatch | ResponseModel | [FromBody] BatchsSearchRequestModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:136 |
| PaymentsController | GET | api/Payments/GetPatientsWithDue | ResponseModel | bool isDueOnly, int practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:146 |
| PaymentsController | GET | api/Payments/GetPatientsClaims | ResponseModel | long patient_account, bool due_only | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:153 |
| PaymentsController | GET | api/Payments/GetClaimDetails | ResponseModel | long claimID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:161 |
| PaymentsController | GET | api/Payments/GetClaimDetailsByClaimNumber | ResponseModel | long claimID, int practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:168 |
| PaymentsController | GET | api/Payments/GetPostedClaims | ResponseModel | string batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:176 |
| PaymentsController | POST | api/Payments/PostPayments | ResponseModel | ClaimsViewModel ClaimModel,long batchID,string batchDate | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:187 |
| PaymentsController | GET | api/Payments/GetBatchPaymentSummary | ResponseModel | string batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:195 |
| PaymentsController | GET | api/Payments/GetBatchType | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:202 |
| PaymentsController | GET | api/Payments/GetBatchCheckDetail | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:209 |
| PaymentsController | GET | api/Payments/DeleteClaimPayment | ResponseModel | string batchID, long claimNo, string Amtdue | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:216 |
| PaymentsController | POST | api/Payments/AutoCloseEligibleBatches | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:225 |
| PaymentsController | POST | api/Payments/ReopenBatch | ResponseModel | long BatchId | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:233 |
| PaymentsController | GET | api/Payments/GetBatchDate | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:239 |
| PaymentsController | GET | api/Payments/ValidateCheckNo | ResponseModel | string CheckNo, long Practice_Code, DateTime BatchOpenDate, string PaymentType, long? BatchID = null | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:246 |
| PaymentsController | POST | api/Payments/CheckIfBatchHasPayments | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:251 |
| PaymentsController | GET | api/Payments/GetCurrentResponsible | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:257 |
| PaymentsController | GET | api/Payments/GetBatchPayments | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:264 |
| PaymentsController | GET | api/Payments/GetPayments | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:270 |
| PaymentsController | GET | api/Payments/GetBatchChequeNoAndDate | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:275 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:24 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticesByUserRights | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:29 |
| PracticeSetupController | GET | api/PracticeSetup/GetPractice | ResponseModel | long? practiceId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:34 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticeWithActiveProviders | ResponseModel | long? practiceId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:39 |
| PracticeSetupController | GET | api/PracticeSetup/ActivateInActivePractice | ResponseModel | long practiceId, bool isActive | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:44 |
| PracticeSetupController | POST | api/PracticeSetup/PostSavePractice | ResponseModel | Practice model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:52 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticeSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:63 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeNotesList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:69 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeNote | ResponseModel | long PracticeNotesId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:73 |
| PracticeSetupController | POST | api/PracticeSetup/SavePracticeNote | ResponseModel | [FromBody] Practice_Notes PracticeNote | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:78 |
| PracticeSetupController | GET | api/PracticeSetup/DeletePracticetNote | ResponseModel | long PracticeId, long PracticeNotesId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:89 |
| PracticeSetupController | ANY | api/PracticeSetup/GetSpecialInstructionList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:95 |
| PracticeSetupController | ANY | api/PracticeSetup/GetSpecialInstruction | ResponseModel | long QuestionId, long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:99 |
| PracticeSetupController | ANY | api/PracticeSetup/GetSpecialInstructionQuestionByCategory | ResponseModel | long CategoryId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:103 |
| PracticeSetupController | POST | api/PracticeSetup/SaveSpecialInstruction | ResponseModel | [FromBody] Practice_Special_Instruction_Answers model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:108 |
| PracticeSetupController | GET | api/PracticeSetup/DeleteSpecialInstruction | ResponseModel | long QuestionId, long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:119 |
| PracticeSetupController | ANY | api/PracticeSetup/GetProviders | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:125 |
| PracticeSetupController | ANY | api/PracticeSetup/GetProvider | ResponseModel | long providerId, long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:129 |
| PracticeSetupController | POST | api/PracticeSetup/SaveProvider | ResponseModel | Provider model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:134 |
| PracticeSetupController | GET | api/PracticeSetup/ActivateInActiveProvider | ResponseModel | long providerId, long PracticeId, bool isActive | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:145 |
| PracticeSetupController | ANY | api/PracticeSetup/GetProviderNotesList | ResponseModel | long ProviderId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:151 |
| PracticeSetupController | ANY | api/PracticeSetup/GetProviderNote | ResponseModel | long ProviderNoteId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:156 |
| PracticeSetupController | POST | api/PracticeSetup/SaveProviderNote | ResponseModel | [FromBody] Provider_Notes ProviderNote | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:161 |
| PracticeSetupController | GET | api/PracticeSetup/DeleteProviderNote | ResponseModel | long ProviderId, long ProviderNotesId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:172 |
| PracticeSetupController | ANY | api/PracticeSetup/GetProviderWorkingHours | ResponseModel | long ProviderId, long LocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:178 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeResources | ResponseModel | long practiceId, long LocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:184 |
| PracticeSetupController | ANY | api/PracticeSetup/GetProviderResources | ResponseModel | long ProviderId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:188 |
| PracticeSetupController | ANY | api/PracticeSetup/GetProviderPayers | ResponseModel | long ProviderId, long LocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:194 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticePayers | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:202 |
| PracticeSetupController | GET | api/PracticeSetup/DeletePracticePayers | ResponseModel | long PracticeId, string ProviderPayerId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:208 |
| PracticeSetupController | POST | api/PracticeSetup/MapPayer | ResponseModel | [FromBody] InsuranceModel model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:214 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeLocationList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:222 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeLocation | ResponseModel | long PracticeId, long PracticeLocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:226 |
| PracticeSetupController | POST | api/PracticeSetup/SavePracticeLocation | ResponseModel | [FromBody] Practice_Locations PracticeLocation | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:231 |
| PracticeSetupController | GET | api/PracticeSetup/DeletePracticeLocation | ResponseModel | long PracticeId, long PracticeLocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:242 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeFacilityList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:248 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeFacility | ResponseModel | long PracticeId, long PracticeFacilityId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:252 |
| PracticeSetupController | POST | api/PracticeSetup/SavePracticeFacility | ResponseModel | PRACTICE_FACILITY model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:257 |
| PracticeSetupController | GET | api/PracticeSetup/DeletePracticeFacility | ResponseModel | long PracticeId, long PracticeFacilityId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:268 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeSpecialityCategoryOne | ResponseModel | long GroupNo | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:274 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeSpecialityCategoryTwo | ResponseModel | long GroupNo, int CatLevel | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:278 |
| PracticeSetupController | POST | api/PracticeSetup/AddPracticeSynchronization | ResponseModel | [FromBody] PracticeSynchronizationModel model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:283 |
| PracticeSetupController | ANY | api/PracticeSetup/GetPracticeSynchronization | ResponseModel | long practiceid | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:287 |
| PracticeSetupController | GET | api/PracticeSetup/GetSpecialityGroups | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:293 |
| PracticeSetupController | GET | api/PracticeSetup/GetSpecializations | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:299 |
| PracticeSetupController | GET | api/PracticeSetup/GetWcbRatings | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:305 |
| PracticeSetupController | GET | api/PracticeSetup/GetActiveUsersForPractice | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:311 |
| PracticeSetupController | GET | api/PracticeSetup/GetDivisionForUser | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:316 |
| PracticeSetupController | GET | api/PracticeSetup/IsAutoFillEnableForPractice | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:322 |
| PracticeSetupController | GET | api/PracticeSetup/GetRecentClaimDetails | ResponseModel | long patientAccount, long practiceCode,string claimType | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:327 |
| PracticeSetupController | POST | api/PracticeSetup/SaveReportingDetails | ResponseModel | Practice_Reporting model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:335 |
| PracticeSetupController | GET | api/PracticeSetup/GetReportingDetailOfPracticeUser | ResponseModel | long userID, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:341 |
| PracticeSetupController | GET | api/PracticeSetup/TaxonomyCode | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:347 |
| PracticeSetupController | GET | api/PracticeSetup/NPICode | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:353 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticeReportingDetail | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:359 |
| PracticeSetupController | POST | api/PracticeSetup/AddOrUpdateProviderResources | ResponseModel | [FromBody] Provider_Resources resource | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:364 |
| PracticeSetupController | GET | api/PracticeSetup/GetAllProviderResources | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:379 |
| PracticeSetupController | GET | api/PracticeSetup/GetExpiredPortalsByTeamLead | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:384 |
| PracticeSetupController | GET | api/PracticeSetup/GetProviderDocTypeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:389 |
| PracticeSetupController | GET | api/PracticeSetup/GetProviderStateList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:394 |
| PracticeSetupController | POST | api/PracticeSetup/SaveProviderDocs | ResponseModel | [FromBody] ProviderDocuments_ViewModel model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:399 |
| PracticeSetupController | POST | api/PracticeSetup/ProviderDocFileUpload | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:404 |
| PracticeSetupController | GET | api/PracticeSetup/GetProviderDocList | ResponseModel | long PracticeCode, long ProviderCode, string Doc_Type | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:409 |
| PracticeSetupController | GET | api/PracticeSetup/Download | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:414 |
| PracticeSetupController | GET | api/PracticeSetup/GetProviderDocBYId | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:457 |
| PracticeSetupController | GET | api/PracticeSetup/DeleteProviderDocBYid | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:462 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticeDocList | ResponseModel | long PracticeCode, string Doc_Type | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:467 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticeDocTypeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:472 |
| PracticeSetupController | POST | api/PracticeSetup/SavePracticeDocs | ResponseModel | [FromBody] PracticeDocuments_ViewModel model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:477 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticeDocBYId | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:482 |
| PracticeSetupController | GET | api/PracticeSetup/DeletePracticeDocBYid | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:487 |
| PracticeSetupController | POST | api/PracticeSetup/PracticeDocFileUpload | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:492 |
| PracticeSetupController | GET | api/PracticeSetup/DownloadPracFile | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:497 |
| PracticeSetupController | GET | api/PracticeSetup/GetPracticeSoftware | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:540 |
| RealTimeClaimStatusController | ANY | api/RealTimeClaimStatus/GenerateBatch276 | Task<IHttpActionResult> | long practice_id, long claim_id,long Insurance_Id, string unique_name | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:27 |
| RealTimeClaimStatusController | POST | api/RealTimeClaimStatus/GetCSIStatus | Task<ResponseModel> | long practiceCode, long ClaimNo | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:42 |
| RealTimeClaimStatusController | ANY | api/RealTimeClaimStatus/GenerateBatch | Task<IHttpActionResult> | long practice_id, long claim_id, long Insurance_Id, string unique_name | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:47 |
| RealTimeClaimStatusController | ANY | api/RealTimeClaimStatus/UploadBatches276 | Task<IHttpActionResult> | BatchUploadRequest model | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:60 |
| RealTimeClaimStatusController | ANY | api/RealTimeClaimStatus/SingleClaimUploadBatches276 | Task<IHttpActionResult> | CSIClaimBatchUploadRequest model, [FromUri] bool? getUpdatedCSI = null | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:90 |
| RealTimeClaimStatusController | ANY | api/RealTimeClaimStatus/SingleClaimUploadBatches276 | Task<IHttpActionResult> | CSIClaimBatchUploadRequest model, [FromUri] bool? getUpdatedCSI = null | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:135 |
| RealTimeClaimStatusController | ANY | api/RealTimeClaimStatus/UploadBatches276 | Task<IHttpActionResult> | BatchUploadRequest model | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:166 |
| RealTimeClaimStatusController | POST | api/RealTimeClaimStatus/RegenerateBatchFile | Task<RegenerateBatchCSIFileModel> | RegenerateBatchCSIFileModel model | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:196 |
| ReferralPhysiciansController | POST | api/ReferralPhysicians/CreateReferralPhysician | Task<ResponseModel> | ReferralPhysicianViewModel model | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:18 |
| ReferralPhysiciansController | POST | api/ReferralPhysicians/UpdateReferralPhysician | Task<ResponseModel> | ReferralPhysicianViewModel model | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:24 |
| ReferralPhysiciansController | GET | api/ReferralPhysicians/GetReferralPhysicianByRefCode | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:30 |
| ReferralPhysiciansController | GET | api/ReferralPhysicians/GetReferralPhysicians | Task<ResponseModel> | int page, int count, string pattern | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:35 |
| ReferralPhysiciansController | POST | api/ReferralPhysicians/ChangeDeleteStatus | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:40 |
| ReferralPhysiciansController | POST | api/ReferralPhysicians/ChangeActiveStatus | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:45 |
| ReferralPhysiciansController | GET | api/ReferralPhysicians/GetActiveReferralPhysicians | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:50 |
| ReferralPhysiciansController | GET | api/ReferralPhysicians/GetActiveInactiveReferralPhysicians | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:56 |
| ReportController | GET | api/Report/AgingSummaryAnalysisReport | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:25 |
| ReportController | GET | api/Report/DormantClaimsReport | Task<ResponseModel> | long PracticeCode, int page, int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:30 |
| ReportController | GET | api/Report/DormantClaimsReports | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:36 |
| ReportController | GET | api/Report/DormantClaimsReportsPagination | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:42 |
| ReportController | GET | api/Report/AgingSummaryPatientAnalysisReport | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:48 |
| ReportController | GET | api/Report/FinancialAnalysisByProviderandProcCodesReport | ResponseModel | long PracticeCode, DateTime DateFrom, DateTime DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:54 |
| ReportController | GET | api/Report/FinancialAnalysisCPTLevelReport | ResponseModel | long PracticeCode, DateTime DateFrom, DateTime DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:60 |
| ReportController | GET | api/Report/PaymentDetail | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, long? PatientAccount | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:66 |
| ReportController | GET | api/Report/PaymentDetailPagination | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, long? PatientAccount, int page, int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:72 |
| ReportController | GET | api/Report/CPTWisePaymentDetail | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:78 |
| ReportController | GET | api/Report/CPTWisePaymentDetailPagination | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, int page, int count | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:83 |
| ReportController | GET | api/Report/AppointmentDetailReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:89 |
| ReportController | GET | api/Report/holdReport | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:95 |
| ReportController | POST | api/Report/ClaimPaymentsDetailReport | ResponseModel | [FromBody] ClaimPaymentsDetailRequest request | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:102 |
| ReportController | GET | api/Report/MissingAppointmentDetailReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:115 |
| ReportController | POST | api/Report/RecallVisits | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:121 |
| ReportController | POST | api/Report/PeriodAnalysisAndClosing | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:127 |
| ReportController | POST | api/Report/PracticeAnalysis | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:133 |
| ReportController | POST | api/Report/PatientBirthDays | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:139 |
| ReportController | POST | api/Report/AgingSummaryRecent | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:145 |
| ReportController | POST | api/Report/ChargesPaymentsRecent | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:151 |
| ReportController | POST | api/Report/GetAgingDashboard | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:157 |
| ReportController | GET | api/Report/GetInsuranceDetailReport | ResponseModel | long? PracCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:162 |
| ReportController | GET | api/Report/GetInsuranceDetailReportPagination | ResponseModel | long? PracCode,int page,int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:168 |
| ReportController | GET | api/Report/GetUserReport | ResponseModel | string PracCode, string userid,string dateFrom,string dateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:174 |
| ReportController | GET | api/Report/GetUserReportPagination | ResponseModel | string PracCode, string userid, string dateFrom, string dateTo,int page,int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:180 |
| ReportController | GET | api/Report/GetRollingSummaryReport | ResponseModel | string PracCode, string duration | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:185 |
| ReportController | GET | api/Report/GetProvidersBYPractice | Task<ResponseModel> | int PracticeId | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:191 |
| ReportController | ANY | api/Report/CollectionAnalysisReport | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:197 |
| ReportController | GET | api/Report/CollectionAnalysisReport | Task<ResponseModel> | long PracticeCode, DateTime? DateFrom, DateTime? DateTo, bool isExport = false, int page = 1, int size = 10 | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:203 |
| ReportController | GET | api/Report/PatientAgingReport | Task<ResponseModel> | long PracticeCode, bool isExport = false, int page=1, int size = 10 | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:210 |
| ReportController | GET | api/Report/PatientAgingAnalysisReport | Task<ResponseModel> | long PracticeCode, bool isExport = false, int page = 1, int size = 10 | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:215 |
| ReportController | GET | api/Report/DenialReportDetailPagination | ResponseModel | long? PracticeCode,string Criteria, DateTime? DateFrom, DateTime? DateTo, int page, int count | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:221 |
| ReportController | GET | api/Report/DenialReportDetail | ResponseModel | long? PracticeCode, string Criteria, DateTime? DateFrom, DateTime? DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:227 |
| ReportController | GET | api/Report/GetNegativeBalanceReport | Task<ResponseModel> | long practiceCode, string responsibleParty, string dateCriteria, DateTime dateFrom, DateTime dateTo, Boolean isExport, int pageSize, int PageNo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:232 |
| ReportController | GET | api/Report/GetEshaCBRDetails | ResponseModel | long? practiceCode, int Page, int Count, bool perPageRecord | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:237 |
| ReportController | ANY | api/Report/GetPatientAgingSummaryDetails | ResponseModel | long? practiceCode, int Page, int Count, bool perPageRecord | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:241 |
| ReportController | ANY | api/Report/GetPlanAgingReportDetails | ResponseModel | long? PracticeCode, int Page, int Count, bool perPageRecord | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:245 |
| ReportController | POST | api/Report/OverAllChargesDos | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:257 |
| ReportController | POST | api/Report/ByCPTDos | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:263 |
| ReportController | POST | api/Report/ByHospitalDos | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:269 |
| ReportController | POST | api/Report/ByPrimaryDXDos | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:275 |
| ReportController | POST | api/Report/ByCarrierDOS | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:281 |
| ReportController | POST | api/Report/CPA | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:287 |
| ReportController | GET | api/Report/ClaimAssignmentReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:295 |
| ReportController | GET | api/Report/ERAUnpostedAdjReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:301 |
| ReportController | GET | api/Report/AccounAssignmentReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:307 |
| ReportController | GET | api/Report/AccounAssignmentReportPagination | ResponseModel | long PracticeCode, string DateFrom, string DateTo,int page, int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:313 |
| ReportController | POST | api/Report/GetVisitClaimActivityReport | Task<ResponseModel> | PatelReportsRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:319 |
| ReportController | POST | api/Report/GetChargesBreakDownReport | Task<ResponseModel> | PatelReportsRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:324 |
| ReportController | ANY | api/Report/PaymentDailyRefresh | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:333 |
| ReportController | POST | api/Report/PaymentMonthWise | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:339 |
| ReportController | POST | api/Report/PaymentByCarrier | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:345 |
| ReportController | POST | api/Report/PaymentPrimaryDX | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:351 |
| ReportController | POST | api/Report/PaymentByPrimaryICD10 | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:357 |
| ReportController | POST | api/Report/GetBatchPaymentReport | ResponseModel | BatchPaymentModel batchpayment | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:362 |
| ReportController | POST | api/Report/GetUnappliedPaymentReport | ResponseModel | UnappliedPaymentReportModel unappliedpayment | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:367 |
| SchedulerController | POST | api/Scheduler/GetAppointments | ResponseModel | AppointmentsSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:34 |
| SchedulerController | POST | api/Scheduler/GetExistingAppointments | ResponseModel | AppointmentCreateModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:47 |
| SchedulerController | GET | api/Scheduler/GetProviderAppointmentSettings | ResponseModel | long providerCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:61 |
| SchedulerController | GET | api/Scheduler/GetAppointmentModel | ResponseModel | long practiceCode, long? id | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:67 |
| SchedulerController | GET | api/Scheduler/GetAppointmentdetail | ResponseModel | long? id, long pataccount, string appDate | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:72 |
| SchedulerController | GET | api/Scheduler/GetReasonsSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:77 |
| SchedulerController | POST | api/Scheduler/Save | ResponseModel | [FromBody] AppointmentCreateModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:82 |
| SchedulerController | GET | api/Scheduler/Delete | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:93 |
| SchedulerController | GET | api/Scheduler/GetProviderSchedules | ResponseModel | long practiceCode, long providerCode, long locationCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:98 |
| SchedulerController | GET | api/Scheduler/GetProviderSchedulesWithLocation | ResponseModel | long practiceCode, string providerCodes, string locationCodes | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:104 |
| SchedulerController | GET | api/Scheduler/GetOfficeTimingForProvidersAndLocations | ResponseModel | long practiceCode, string providerCodes, string locationCodes, DateTime dateFrom, DateTime dateTo | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:113 |
| SchedulerController | ANY | api/Scheduler/GetProviderBlockedSchedules | ResponseModel | long practiceCode, long providerCode, long locationCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:117 |
| SchedulerController | POST | api/Scheduler/Timings | ResponseModel | TimingSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:122 |
| SchedulerController | POST | api/Scheduler/Rules | ResponseModel | ProviderAppointmentRuleViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:135 |
| SchedulerController | POST | api/Scheduler/GetProviderAppointmentRules | ResponseModel | ProviderAppointmentRuleViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:148 |
| SchedulerController | POST | api/Scheduler/SaveOfficeTimings | ResponseModel | OfficeTimingCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:161 |
| SchedulerController | POST | api/Scheduler/SaveAppointmentRules | ResponseModel | ProviderAppointmentRuleViewModel rule | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:172 |
| SchedulerController | GET | api/Scheduler/GetProvidersAndLocations | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:183 |
| SchedulerController | GET | api/Scheduler/GetPaperSubmissionType | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:193 |
| SchedulerController | GET | api/Scheduler/getClaimsTypesInBatch | ResponseModel | string batchIds | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:204 |
| SchedulerController | POST | api/Scheduler/GetMatchingSchedules | ResponseModel | ProviderSchedulesViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:237 |
| SchedulerController | GET | api/Scheduler/Statuses | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:248 |
| SchedulerController | GET | api/Scheduler/GetPracticeAppointmentStatuses | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:253 |
| SchedulerController | GET | api/Scheduler/GetPracticeAppointmentStatuse | ResponseModel | long practiceCode, long id | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:258 |
| SchedulerController | GET | api/Scheduler/DeletePracticeAppointmentStatuse | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:263 |
| SchedulerController | POST | api/Scheduler/SaveStatus | ResponseModel | PracticeAppointmentStatusCreateVM model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:268 |
| SchedulerController | GET | api/Scheduler/GetPracAppointmentReasons | ResponseModel | long practiceCode, long providerCode, long locationCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:280 |
| SchedulerController | GET | api/Scheduler/GetAppointmentReasons | ResponseModel | string searchText = "", bool all = false | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:285 |
| SchedulerController | GET | api/Scheduler/GetUnassignedAppointmentReasons | ResponseModel | long practiceCode, long providerCode, long locationCode, string searchText = "" | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:290 |
| SchedulerController | POST | api/Scheduler/SaveReason | ResponseModel | PracticeAppointmentReasonCreateVM model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:295 |
| SchedulerController | POST | api/Scheduler/ChangeColor | ResponseModel | ColorChangeModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:300 |
| SchedulerController | GET | api/Scheduler/DeletePracticeAppointmentReason | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:312 |
| SchedulerController | POST | api/Scheduler/SlotAvailability | ResponseModel | SlotAvailabilityRequestVM model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:317 |
| SchedulerController | GET | api/Scheduler/InquiryByAppointmentId | ResponseModel | long PracticeCode, long AppointmentId | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:329 |
| SchedulerController | GET | api/Scheduler/CheckDeceasedPatient | ResponseModel | long PatAccount | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:466 |
| ScrubberController | POST | api/Scrubber/getAllCleanClaims | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:23 |
| ScrubberController | POST | api/Scrubber/getViolatedClaims | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:29 |
| ScrubberController | POST | api/Scrubber/getSkippedClaims | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:35 |
| ScrubberController | ANY | api/Scrubber/AddTOScrubber | ResponseModel | ClaimsViewModel claimModel | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:40 |
| ScrubberController | GET | api/Scrubber/GetColumn_Lists_FrontEnd | List<GetColumn_List> |  | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:48 |
| ScrubberController | POST | api/Scrubber/GetColumsList | ResponseModel | GetColumnList GC_L | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:54 |
| ScrubberController | GET | api/Scrubber/GetTableList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:60 |
| ScrubberController | POST | api/Scrubber/AddCustom_Edits_Rules | ResponseModel | CustomEdits_ColumnsList ce | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:67 |
| ScrubberController | POST | api/Scrubber/GetScrubberReport | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:75 |
| ScrubberController | POST | api/Scrubber/GetScrubberReportPagination | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To,int page,int size | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:81 |
| ScrubberController | POST | api/Scrubber/GetScrubberRejectionDetail | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:86 |
| ScrubberController | GET | api/Scrubber/GetAllCustomEdits | List<Custom_Scrubber_Rules> | long Practice_Code | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:91 |
| ScrubberController | GET | api/Scrubber/GetCustomRuleById | ResponseModel | int id | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:97 |
| ScrubberController | GET | api/Scrubber/CustomEditsStatus | ResponseModel | int id | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:103 |
| ScrubberController | POST | api/Scrubber/GetClaimSubmissionReport | ResponseModelForClaimSubmission | long practiceCode, DateTime Date_From, DateTime Date_To, string Status | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:112 |
| ScrubberController | POST | api/Scrubber/GetClaimSubmissionReportPagiantion | ResponseModelForClaimSubmission | long practiceCode, DateTime Date_From, DateTime Date_To, string Status,int page,int size | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:117 |
| ScrubberController | GET | api/Scrubber/GetEdiHistory | ResponseModelForEdiHistory | long claimNo, string Status, string statusLevel, string File277CA | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:122 |
| ScrubberController | GET | api/Scrubber/GetClaimRejections | ResponseModelforClaimRejection | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:127 |
| SetupController | ANY | api/Setup/GetFacilityList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:22 |
| SetupController | ANY | api/Setup/GetFacility | ResponseModel | long FacilityId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:26 |
| SetupController | POST | api/Setup/SaveFacility | ResponseModel | [FromBody] Facility model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:32 |
| SetupController | GET | api/Setup/DeleteFacility | ResponseModel | long FacilityId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:45 |
| SetupController | ANY | api/Setup/GetGurantorsList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:54 |
| SetupController | POST | api/Setup/GetGurantorsList | ResponseModel | Guarantor model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:59 |
| SetupController | POST | api/Setup/GetNDCList | ResponseModel | NDCViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:64 |
| SetupController | POST | api/Setup/GetDXList | ResponseModel | DXViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:70 |
| SetupController | ANY | api/Setup/GetGurantor | ResponseModel | long GurantorId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:74 |
| SetupController | POST | api/Setup/SaveGurantor | ResponseModel | [FromBody] Guarantor model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:80 |
| SetupController | POST | api/Setup/SaveDX | ResponseModel | [FromBody] Diagnosi model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:93 |
| SetupController | POST | api/Setup/UpdateDX | ResponseModel | [FromBody] Diagnosi model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:105 |
| SetupController | POST | api/Setup/SaveNDC | ResponseModel | [FromBody] NDCModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:118 |
| SetupController | GET | api/Setup/DeleteNDC | ResponseModel | long NDC_ID | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:130 |
| SetupController | GET | api/Setup/DeleteDX | ResponseModel | string DX_Code | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:136 |
| SetupController | GET | api/Setup/DeleteGurantor | ResponseModel | long GurantorId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:142 |
| SetupController | ANY | api/Setup/GetStatesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:151 |
| SetupController | ANY | api/Setup/GetPracticeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:156 |
| SetupController | ANY | api/Setup/GetEshaPracticeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:160 |
| SetupController | ANY | api/Setup/GetuserList | ResponseModel | long PracCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:165 |
| SetupController | ANY | api/Setup/GetProviderFeeScheduleDD | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:171 |
| SetupController | ANY | api/Setup/GetStandardCPTFeeSchedule | ResponseModel | string StateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:176 |
| SetupController | POST | api/Setup/GetProviderPlanDetails | ResponseModel | string ProviderCPTPlanId, Pager pager | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:182 |
| SetupController | ANY | api/Setup/GetRevenueCodes | Task<ResponseModel> | string Code | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:187 |
| SetupController | POST | api/Setup/GetProviderFeeSchedule | ResponseModel | ProviderFeeScheduleSearchVM model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:196 |
| SetupController | POST | api/Setup/PostproviderFeeSchedule | ResponseModel | providercptplanModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:209 |
| SetupController | POST | api/Setup/checkproviderFeeinformation | ResponseModel | check_provider_cptplan_existence model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:225 |
| SetupController | GET | api/Setup/getpracticeinformationforcptplan | ResponseModel | long Practicecode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:240 |
| SetupController | GET | api/Setup/GetProviderPlanDetails | ResponseModel | string ProviderCPTPlanId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:254 |
| SetupController | GET | api/Setup/GetProviderFeeSchedule | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:260 |
| SetupController | GET | api/Setup/GetDescriptionByCPT | ResponseModel | string ProviderCPTPCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:266 |
| SetupController | GET | api/Setup/CheckCode | ResponseModel | string Code | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:273 |
| SetupController | GET | api/Setup/GetByAlternateCode | ResponseModel | string AlternateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:280 |
| SetupController | POST | api/Setup/PostProviderCptPlanDetails | ResponseModel | Provider_Cpt_Plan_Details model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:287 |
| SetupController | GET | api/Setup/CheckDuplicateAlternateCode | ResponseModel | string AlternateCode, string ProviderCPTPlainId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:299 |
| SetupController | GET | api/Setup/DuplicateAlternateCodeClaimCharges | ResponseModel | string AlternateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:307 |
| SetupController | GET | api/Setup/CheckDuplicateCPT | ResponseModel | string ProviderCPTCode, string ProviderCPTPlainId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:313 |
| SetupController | POST | api/Setup/InitProviderFeePlan | ResponseModel | ProviderFeeScheduleSearchVM model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:319 |
| SetupController | POST | api/Setup/PaginateStandardCPTFee | ResponseModel | long practiceCode, Pager pager | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:331 |
| SetupController | POST | api/Setup/CreateProviderCPTPlan | ResponseModel | CreateProviderCPTPlanVM model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:337 |
| SetupController | POST | api/Setup/UpdateProviderCPTDetails | ResponseModel | string Id, List<Provider_Cpt_Plan_Details> model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:349 |
| SetupController | GET | api/Setup/DeleteProviderPlanAndCPT | ResponseModel | string planId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:355 |
| SetupController | GET | api/Setup/GetStandardNobilityCPTFeeSchedule | ResponseModel | string StateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:361 |
| SetupController | GET | api/Setup/GetProviderCPTPlanNotes | ResponseModel | string PlanId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:369 |
| SetupController | POST | api/Setup/SaveProviderCPTNote | ResponseModel | ProviderCptPlanNoteCreateVM note | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:375 |
| SetupController | GET | api/Setup/DeleteProviderCPTNote | ResponseModel | long NoteId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:387 |
| SetupController | GET | api/Setup/GetProcedure | ResponseModel | string procedureCode, string alternateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:397 |
| SetupController | GET | api/Setup/GetDropdownsListForProcedures | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:402 |
| SetupController | GET | api/Setup/DuplicateProcAndAlternateCode | ResponseModel | string AlternateCode, string ProcCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:408 |
| SetupController | POST | api/Setup/SaveProcedure | ResponseModel | [FromBody] ProcedureViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:416 |
| SetupController | GET | api/Setup/DeleteProcedure | ResponseModel | string procedureCode, string alternateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:429 |
| SetupController | POST | api/Setup/SearchProcedures | ResponseModel | ProceduresSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:434 |
| SubmissionController | ANY | api/Submission/GenerateBatch_5010_P | ResponseModel | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:29 |
| SubmissionController | GET | api/Submission/GenerateBatch_5010_P | Task<ResponseModel> | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:57 |
| SubmissionController | GET | api/Submission/View837 | Task<ResponseModel> | long batchId, long practice_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:102 |
| SubmissionController | GET | api/Submission/GenerateBatch_5010_I | Task<ResponseModel> | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:107 |
| SubmissionController | POST | api/Submission/SearchClaim | ResponseModel | ClaimSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:113 |
| SubmissionController | ANY | api/Submission/SearchBatchClaims | ResponseModel | BatchClaimsSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:115 |
| SubmissionController | ANY | api/Submission/RemoveClaimBatch | ResponseModel | RemoveClaimBatchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:116 |
| SubmissionController | POST | api/Submission/AddUpdateBatch | ResponseModel | BatchCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:118 |
| SubmissionController | ANY | api/Submission/GetPendingBatchSelectListErrorCom | ResponseModel | long practiceCode, long? providerCode, string practype | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:129 |
| SubmissionController | GET | api/Submission/GetPendingBatchSelectList | ResponseModel | long practiceCode, long? providerCode, string practype, string batch_claim_type | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:135 |
| SubmissionController | GET | api/Submission/GetSentBatchSelectList | ResponseModel | string searchText, long practiceCode, long? providerCode | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:141 |
| SubmissionController | POST | api/Submission/GetBatchesDetail | ResponseModel | BatchListRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:147 |
| SubmissionController | POST | api/Submission/AddInBatch | ResponseModel | AddInBatchRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:159 |
| SubmissionController | POST | api/Submission/LockBatch | ResponseModel | LockBatchRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:171 |
| SubmissionController | POST | api/Submission/HoldBatch | ResponseModel | HoldBatchRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:184 |
| SubmissionController | GET | api/Submission/GetERACheckDetails | ResponseModel | long practice_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:198 |
| SubmissionController | GET | api/Submission/GetBatchPaymentForERA | ResponseModel | string checkNo, long practice_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:209 |
| SubmissionController | ANY | api/Submission/UploadBatches | Task<ResponseModel> | BatchUploadRequest model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:221 |
| SubmissionController | POST | api/Submission/UploadBatches | Task<ResponseModel> | BatchUploadRequest model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:233 |
| SubmissionController | POST | api/Submission/GetBatchFileErrors | ResponseModel | BatchErrorsRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:277 |
| SubmissionController | POST | api/Submission/GetBatchExceptions | ResponseModel | BatchErrorsRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:282 |
| SubmissionController | POST | api/Submission/GetBatchesHistory | ResponseModel | BatchesHistoryRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:287 |
| SubmissionController | GET | api/Submission/Get999Report | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:292 |
| SubmissionController | GET | api/Submission/GetBatcheDetalis | ResponseModel | long batchId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:298 |
| SubmissionController | GET | api/Submission/GetCSIBatcheDetalis | ResponseModel | int batchId, string claimId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:304 |
| SubmissionController | GET | api/Submission/GetCSIBatcheResponseDetalis | ResponseModel | int batchId, long claimId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:309 |
| SubmissionController | GET | api/Submission/GetCSIBatcheDetalisStatus | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:314 |
| SubmissionController | GET | api/Submission/CheckMedicareClaim | ResponseModel | long? claimId,long insurance_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:319 |
| SubmissionController | GET | api/Submission/DownloadEDIFile | HttpResponseMessage | long batchId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:325 |
| SubmissionController | POST | api/Submission/RegenerateBatchFile | Task<ResponseModel> | RegenerateBatchFileRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:356 |
| SubmissionController | GET | api/Submission/Read | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:364 |
| SubmissionController | POST | api/Submission/SearchERA | ResponseModel | ERASearchRequestModel model , string imp_type = null | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:370 |
| SubmissionController | POST | api/Submission/EraSummary | ResponseModel | EraSummaryRequest model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:376 |
| SubmissionController | GET | api/Submission/ViewClaimERA | ResponseModel | long claimno, string check_No | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:381 |
| SubmissionController | POST | api/Submission/ERAClaimSummary | ResponseModel | claimsummaryrequest req, string imp_type = null | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:425 |
| SubmissionController | POST | api/Submission/ApplyERA | ResponseModel | ApplyERARequestModel req | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:431 |
| SubmissionController | POST | api/Submission/AutoPost | ResponseModel | ERAAutoPostRequestModel request | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:437 |
| SubmissionController | POST | api/Submission/ERAClaimsOverPayment | ResponseModel | claimsummaryrequest req | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:443 |
| TicketAttachmentController | ANY | api/TicketAttachment/TicketAttach | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/TicketAttachmentController.cs:26 |
| TicketTrackerController | GET | api/TicketTracker/GetPatientDueAmt | ResponseModel | string patientacc, long claimno | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:21 |
| TicketTrackerController | GET | api/TicketTracker/GetPatientCompleteInfo | ResponseModel | string patientacc, string ticketType | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:37 |
| TicketTrackerController | GET | api/TicketTracker/GetRenderingProvider | ResponseModel | long providercode | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:53 |
| TicketTrackerController | GET | api/TicketTracker/GetClaimInfo | ResponseModel | string claimno | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:69 |
| TicketTrackerController | GET | api/TicketTracker/GetPatientInfo | ResponseModel | string patientacc | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:85 |
| TicketTrackerController | GET | api/TicketTracker/GetPatientAccounts | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:101 |
| TicketTrackerController | GET | api/TicketTracker/GetPracticeInfo | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:117 |
| TicketTrackerController | GET | api/TicketTracker/GetTTDepartmentsList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:133 |
| TicketTrackerController | POST | api/TicketTracker/SaveTicket | ResponseModel | [FromBody] Tickettracker model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:149 |
| TicketTrackerController | POST | api/TicketTracker/SearchTicket | ResponseModel | TicketSearchModel model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:166 |
| TicketTrackerController | ANY | api/TicketTracker/TicketAssignment | ResponseModel | TicketAssignmentRequest model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:183 |
| TicketTrackerController | ANY | api/TicketTracker/GetTicketById | ResponseModel | long ticketid, long tickettrailid | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:199 |
| TicketTrackerController | ANY | api/TicketTracker/GetTicketTrackById | ResponseModel | long ticketid | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:215 |
| TicketTrackerController | GET | api/TicketTracker/GetProviderList | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:232 |
| TicketTrackerController | POST | api/TicketTracker/SaveTrackDetails | ResponseModel | SaveTrackDetails model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:248 |
| TicketTrackerController | ANY | api/TicketTracker/EditTrackDetails | ResponseModel | TicketMessageDetail model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:264 |
| TicketTrackerController | POST | api/TicketTracker/DeleteTrackDetails | ResponseModel | [FromBody] TicketMessageDetail model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:281 |
| TicketTrackerController | ANY | api/TicketTracker/GetAssignedUser | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:297 |
| TicketTrackerController | POST | api/TicketTracker/SendTicketEmail | ResponseModel | [FromBody] Tickettracker model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:314 |
| TicketTrackerController | ANY | api/TicketTracker/SendMultipleTicketEmail | ResponseModel | [FromBody] Tickettracker model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:330 |
| TicketTrackerController | GET | api/TicketTracker/GetTicketTrackerLookUps | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:347 |
| TicketTrackerController | GET | api/TicketTracker/GetUsersByDepartment | ResponseModel | long departmentId | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:364 |
| TicketTrackerController | GET | api/TicketTracker/GetTicketAlerts | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:380 |
| TicketTrackerController | GET | api/TicketTracker/GetLoginTicketPopup | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:396 |
| TicketTrackerController | GET | api/TicketTracker/GetOpenTicketCount | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:412 |
| TokenController | ANY | api/Token/Auth | IHttpActionResult | [FromBody] TokenRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:38 |
| TokenController | ANY | api/Token/AuthCode | IHttpActionResult | [FromBody] CodeRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:57 |
| TokenController | ANY | api/Token/SetAuthCookies | void | HttpResponse response, string accessToken, string refreshToken | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:103 |
| TokenController | GET | api/Token/AuthCodeResend | IHttpActionResult | long userid | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:134 |
| TokenController | GET | api/Token/VerifyPassowrd | IHttpActionResult | string password | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:163 |
| TokenController | ANY | api/Token/myauthmailsender | string | string receiverEmail, string name | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:232 |
| TokenController | ANY | api/Token/maintainlogofOTP | bool | long userid, string Otp | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:287 |
| TokenController | POST | api/Token/Logout | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:424 |
| TokenController | POST | api/Token/sendOTPToResetPassword | IHttpActionResult | TokenRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:445 |
| TokenController | ANY | api/Token/forgetpasswordmailsender | string | string receiverEmail, string name | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:522 |
| TokenController | POST | api/Token/ResetPasswordForOTP | ResponseModel | [FromBody] ResetPasswordViewModel model | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:580 |
| TokenController | ANY | api/Token/GetPracticesClientBased | ResponseModel | long ClientCode, long userId | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:598 |
| TokenController | ANY | api/Token/LoginRateLimitReset | void | string userName | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:609 |
| UBClaimController | GET | api/UBClaim/GetAllCodesData | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/UBClaimController.cs:26 |
| UBClaimController | GET | api/UBClaim/GetallDropdowns | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/UBClaimController.cs:32 |
| UBClaimController | POST | api/UBClaim/ManageOccurenceSpan | Task<ResponseModel> | List<Claims_Occurrence_Code> OSClist | NPM_API_BackUp/NPMAPI/Controllers/UBClaimController.cs:42 |
| UserManagementSetupController | ANY | api/UserManagementSetup/GetModulesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:20 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:25 |
| UserManagementSetupController | GET | api/UserManagementSetup/DeleteModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:30 |
| UserManagementSetupController | POST | api/UserManagementSetup/SaveModule | ResponseModel | [FromBody] ModuleViewModel Model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:35 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetUsersList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:52 |
| UserManagementSetupController | GET | api/UserManagementSetup/verifyEmail | ResponseModel | string vEmail | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:58 |
| UserManagementSetupController | GET | api/UserManagementSetup/empIdExists | ResponseModel | long vEmpId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:66 |
| UserManagementSetupController | POST | api/UserManagementSetup/SaveUser | ResponseModel | [FromBody] UserCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:73 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetUser | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:100 |
| UserManagementSetupController | POST | api/UserManagementSetup/ResetPasswordForOTP | ResponseModel | [FromBody] ResetPasswordViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:110 |
| UserManagementSetupController | POST | api/UserManagementSetup/ResetPassword | ResponseModel | [FromBody] ResetPasswordViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:127 |
| UserManagementSetupController | POST | api/UserManagementSetup/ResetPasswordByUser | ResponseModel | [FromBody] ResetPasswordForuserViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:144 |
| UserManagementSetupController | GET | api/UserManagementSetup/DeleteUser | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:172 |
| UserManagementSetupController | POST | api/UserManagementSetup/ChangeUserStatus | ResponseModel | [FromBody] UserStatusChangeViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:177 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetUsersSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:189 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetPostingUnappliedPaymentUsersList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:196 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetRoleList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:205 |
| UserManagementSetupController | POST | api/UserManagementSetup/SaveRole | ResponseModel | [FromBody] RoleViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:211 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetRole | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:223 |
| UserManagementSetupController | GET | api/UserManagementSetup/DeleteRole | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:229 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetRolesSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:235 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetTemplateByRoleId | ResponseModel | long roleId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:241 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetTemplateByUserId | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:247 |
| UserManagementSetupController | POST | api/UserManagementSetup/SaveRoleModuleProperties | ResponseModel | [FromBody] RoleModulePropertyCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:253 |
| UserManagementSetupController | POST | api/UserManagementSetup/SaveUserModuleProperties | ResponseModel | [FromBody] UserModulePropertyCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:265 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetSubModuleList | ResponseModel | long? moduleId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:279 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetModulesSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:284 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetSubModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:289 |
| UserManagementSetupController | POST | api/UserManagementSetup/SaveSubModule | ResponseModel | [FromBody] SubModuleViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:294 |
| UserManagementSetupController | GET | api/UserManagementSetup/DeleteSubModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:306 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetSubModulePropertiesList | ResponseModel | long? subModuleId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:314 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetSubModuleProperty | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:319 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetSubModulesSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:324 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetSubModulesSelectList | ResponseModel | string searchText, long moduleId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:329 |
| UserManagementSetupController | POST | api/UserManagementSetup/SaveSubModuleProperty | ResponseModel | [FromBody] SubModulePropertiesCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:334 |
| UserManagementSetupController | GET | api/UserManagementSetup/DeleteProperty | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:345 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetEmployeesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:356 |
| UserManagementSetupController | POST | api/UserManagementSetup/SaveEmployee | ResponseModel | [FromBody] EmployeeCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:362 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetEmployee | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:374 |
| UserManagementSetupController | GET | api/UserManagementSetup/GetListsOfSelectLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:380 |
| ValuesController | ANY | api/Values/Get | IEnumerable<string> |  | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:16 |
| ValuesController | ANY | api/Values/Get | string | int id | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:22 |
| ValuesController | ANY | api/Values/Post | void | [FromBody]string value | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:28 |
| ValuesController | ANY | api/Values/Put | void | int id, [FromBody]string value | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:33 |
| ValuesController | ANY | api/Values/Delete | void | int id | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:38 |
| VendorController | GET | api/Vendor/GetVendorList | List<SelectListViewModel> |  | NPM_API_BackUp/NPMAPI/Controllers/VendorController.cs:18 |

## Service Methods

### AlertService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetAlertForPatient | ResponseModel | long patientaccount | NPM_API_BackUp/NPMAPI/Services/AlertService.cs |
| GetLoginAlert | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/AlertService.cs |
| SaveLoginAlert | ResponseModel | NpmAlert model, long userId, string userName | NPM_API_BackUp/NPMAPI/Services/AlertService.cs |
| SaveAlert | ResponseModel | NpmAlert model, long userId, string userName | NPM_API_BackUp/NPMAPI/Services/AlertService.cs |

### AuditLogService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| Log | void | AuditLogEntry entry | NPM_API_BackUp/NPMAPI/Services/AuditLogService.cs |
| Log | void | AuditLogEntry entry | NPM_API_BackUp/NPMAPI/Services/AuditLogService.cs |
| LogBlockedUser | void | AuditLogEntry entry | NPM_API_BackUp/NPMAPI/Services/AuditLogService.cs |
| BlockedLogCount | Audit_Block_Users | long userId | NPM_API_BackUp/NPMAPI/Services/AuditLogService.cs |
| GetUser | User | string username="", long userId = 0 | NPM_API_BackUp/NPMAPI/Services/AuditLogService.cs |
| GetActiveInActiveUser | User | string username = "", long userId = 0 | NPM_API_BackUp/NPMAPI/Services/AuditLogService.cs |
| LoginRateLimitReset | void | string userName | NPM_API_BackUp/NPMAPI/Services/AuditLogService.cs |

### ClaimAssignmentService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetSelectedUserList | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| PostAllAssignedClaimsforUser | ResponseModel | claimassigneeModel model, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetAssignedClaimDataforUser | ResponseModel | long claimnumber | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| EditAssignedClaimsforUser | ResponseModel | editassignedclaimModel model, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetAllAssignedClaimsforspecificuser | ResponseModel | long practice_code, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetAllAssignedClaimsForPracticeuser | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetAllAssignedClaimsNotificationsforuser | ResponseModel | long practice_code, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetAllAssignedAccountsNotificationsforuser | ResponseModel | long practice_code, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetSpecificAssignedClaimDataforuser | ResponseModel | long claimassignee_id | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetSpecificAssignedClaimNotesforuser | ResponseModel | long ClaimAssignee_notes_ID | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| PostAllAssignedAccountforUser | ResponseModel | accountassigneeModel model, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetAllAssignedAccountsforspecificuser | ResponseModel | long practice_code, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetAllAssignedAccountsForPracticeuser | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetSpecificAssignedAccountNotesforuser | ResponseModel | long AccountAssignee_notes_ID | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetSpecificAssignedAccountDataforuser | ResponseModel | long accountassignee_id | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| EditAssignedAccountforUser | ResponseModel | editassignedaccountModel model, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetAllActivePractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| CheckClaimAssignment | ResponseModel | long claimno | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| CheckAccountAssignment | ResponseModel | long accnum | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| ClaimTaskAssignment | ResponseModel | TaskAssignmentClaimList model | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| GetPracticeAssignUsers | ResponseModel | long userid | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |

### ClaimBatch276

| Method | Return | Params | File |
| --- | --- | --- | --- |
| SendRequest | Task<Output277> | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Services/ClaimBatch276.cs |
| Trizetto | Task<Output277> | string request276 | NPM_API_BackUp/NPMAPI/Services/ClaimBatch276.cs |
| UploadBatches | Task<ResponseModel> | BatchUploadRequest model, long v | NPM_API_BackUp/NPMAPI/Services/ClaimBatch276.cs |
| SingleCSIClaimBatchUpload | Task<ResponseModel> | CSIClaimBatchUploadRequest model, long v | NPM_API_BackUp/NPMAPI/Services/ClaimBatch276.cs |

### ClaimStatus

| Method | Return | Params | File |
| --- | --- | --- | --- |
| SendRequest | Task<Output277> | long practice_id, long claim_id, long Insurance_Id, string unique_name | NPM_API_BackUp/NPMAPI/Services/ClaimStatus.cs |
| Trizetto | Task<Output277> | string request276 | NPM_API_BackUp/NPMAPI/Services/ClaimStatus.cs |
| GetCSIReport | Task<ResponseModel> | long practiceCode, long claimNo | NPM_API_BackUp/NPMAPI/Services/ClaimStatus.cs |

### ClaimStatusService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GenerateSerialNumber | ResponseModelForSerialnumber | int length = 8 | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GenerateSerialNumberISA | ResponseModelForSerialnumber | int length = 9 | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GenerateSerialNumberBHTGS | ResponseModelForSerialnumber | int length = 9 | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| SequanceNumber | ResponseModelSerialNumber |  | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| SequanceNumberISA | ResponseModelSequancerNumber |  | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| SequanceNumberBHT | ResponseModelSequancerNumber |  | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GenerateBatch_276 | ResponseModel | long practice_id, long claim_id, long Insurance_Id, string unique_name | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| getSpResult | List<SPDataModel> | string claim_id, string insType | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GetClaimsData | ClaimsDataModel | string id | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| InsertIntoCSIRequestsData | void | string strBatchString, long practice_id, string unique_name | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GenerateSerialNumber | ResponseModelForSerialnumber | int length = 8 | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GenerateSerialNumberISA | ResponseModelForSerialnumber | int length = 9 | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GenerateSerialNumberBHTGS | ResponseModelForSerialnumber | int length = 9 | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| SequanceNumber | ResponseModelSerialNumber |  | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| SequanceNumberISA | ResponseModelSequancerNumber |  | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| SequanceNumberBHT | ResponseModelSequancerNumber |  | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GenerateBatch_276 | ResponseModel | long practice_id, long claim_id, long Insurance_Id, string unique_name | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| getSpResult | List<SPDataModel> | string claim_id, string insType | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| GetClaimsData | ClaimsDataModel | string id | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| InsertIntoCSIRequestsData | void | string strBatchString, long practice_id, string unique_name | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |

### ClaimsAttachmentsService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetAllClaimAttachemnt | ResponseModel | long Claim_No | NPM_API_BackUp/NPMAPI/Services/ClaimsAttachmentsService.cs |
| AttachemntSave | ResponseModel | ClaimAttachmentRequest request, long userId | NPM_API_BackUp/NPMAPI/Services/ClaimsAttachmentsService.cs |
| GetAttachmentTypeCodesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/ClaimsAttachmentsService.cs |
| GetAttachemnt | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Services/ClaimsAttachmentsService.cs |

### ClaimsService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| SaveClaimModel | ResponseModel | [FromBody] ClaimsViewModel ClaimModel | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SaveClaim | Task<ResponseModel> | ClaimsViewModel cr, long userId | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetProcedureCharges | ResponseModel | [FromBody] CPTWiseCharges obj | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetProcedureCharges | ResponseModel | [FromBody] CPTWiseCharges obj | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| CheckModificationAllowed | bool | string Plan_ID | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetPricingModifier | List<string> | string ModifierCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetEFSPractices | List<GETEFSPRACTICES_Result> | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetLocationState | List<string> | string LocationCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetPatientInsuranceInfo | void | string InsId, out string insPayerId, out string insState | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetInsuranceInfo | List<SP_GetInsuranceInfo_Result> | long InsID | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| Is_Participating | string | long InsPayerID, string providerCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| IsFacility | List<GET_ISFACILITY_Result> | long providerCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetCPTCode | string | string provider, string ins, string state, long location, string procedure, string modifier, long facility_code, bool bSelfPay, string practice, string alternate_Code | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetCPTCode | string | string provider, string ins, string state, long location, long facility_code, bool bSelfPay, string practiceCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_ProviderPlan | static List<SP_ProviderPlan_Result> | string provider, string practiceCode, string bSelfPay, string insPayerID, string state, string location, string facilityCode, string modifier, string procCode, string alternate_Code | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsPayer | static List<SP_InsPayer_Result> | string provider, string practiceCode, string insPayerID, string state, string location, string facilityCode, string modifier, string procCode, string alternate_Code | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetInsState | static List<SP_InsStatePlan_Result> | string provider, string practiceCode, string bSelfPay, string insPayerID, string state, string location, string facilityCode, string modifier, string procCode, string alternate_Code | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetInsLocation | static List<SP_InsLocationPlan_Result> | string provider, string practiceCode, string bSelfPay, string insPayerID, string state, string location, string facilityCode, string modifier, string procCode, string alternate_Code | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetInsFacility | static List<SP_InsFacilityPlan_Result> | string provider, string practiceCode, string bSelfPay, string insPayerID, string state, string location, string facilityCode, string modifier, string procCode, string alternate_Code | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetInsFacilityWithOutModifierAndProcedure | static List<SP_InsFacilityInfoWithoutModifierAndProcedure_Result> | string provider, string practiceCode, string bSelfPay, string insPayerID, string state, string location, string facilityCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetInsLocationWithOutModifierAndProcedure | static List<SP_InsLocationWithoutModifierAndProcedure_Result> | string provider, string practiceCode, string bSelfPay, string insPayerID, string state, string location, string facilityCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetProviderInfoWithOutModifierAndProcedure | static List<SP_ProviderWithoutModifierAndProcedure_Result> | string provider, string practiceCode, string bSelfPay, string insPayerID, string state, string location, string facilityCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetInsPayerWithOutModifierAndProcedure | static List<SP_InsPayerWithoutModifierAndProcedure_Result> | string provider, string practiceCode, string insPayerID, string state, string location, string facilityCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetInsStateWithOutModifierAndProcedure | static List<SP_InsStateWithoutModifierAndProcedure_Result> | string provider, string practiceCode, string bSelfPay, string insPayerID, string state, string location, string facilityCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| ListofProviderInfo | static List<SP_ProviderInfo_Result> | bool selfpay, string practice_code, string provider_code, string location_code, string facility_code, string state, string insid | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetProviderCPT_PlanID | string | string provider, string PracticeCode, bool bSelfPay, string modifier, string procCode, string alternate_Code, DateTime Dos, string inspayer, string facilitycode, string Locationcode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| ProviderCPT_Plan | List<SP_GetProviderCPTPlan_Result> | string strPlanID | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| UpdateClaimStatus | void | List<long> claimIds, string status, string typeOfStatus | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| DeleteInboxInvoice | BaseResponse | long invoiceId | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| CheckCode | ResponseModel | string Code | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| InsertOrUpdateClaimPayments | ResponseModel | List<Claim_Payments> paymentList, long userId | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SaveUnappliedAmount | ResponseModel | UnappliedPaymentViewModel unappliedPaymentModel, long userid | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetUnappliedPaymentsByBatchNo | ResponseModel | string batchNo | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| DeleteUnappliedPayment | ResponseModel | long unappliedPaymentId, long userId | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetUnappliedAmountByPatient | ResponseModel | long patientAccount | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetBatchDetailsByPatient | ResponseModel | long Patient_Account | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetClaimsDetailsByPatient | ResponseModel | long Patient_Account | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| GetBillingPhysiciansList | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |

### CompanyService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetCompanyList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetCompanyRecord | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| SaveCompany | ResponseModel | [FromBody] Company model | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| DeleteCompany | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetCompaniesAndRolesSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetOfficeList | ResponseModel | long? companyId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetOfficeRecord | ResponseModel | long OfficeId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| SaveOffice | ResponseModel | [FromBody] Office model | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| DeleteOffice | ResponseModel | long OfficeId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetShiftList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetShiftRecord | ResponseModel | long ShiftId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| SaveShift | ResponseModel | [FromBody] Shift model | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| DeleteShift | ResponseModel | long ShiftId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetTeamList | ResponseModel | int? companyId, int? officeId, int? departmentId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetTeamRecord | ResponseModel | long TeamId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| SaveTeam | ResponseModel | [FromBody] TeamViewModel model | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| DeleteTeam | ResponseModel | long TeamId, int OfficeId, int DepartmentId, int CompanyId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetCompanyOfficenDepartment | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetOfficeIdFromDept | ResponseModel | long DeptId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetDepartmentList | ResponseModel | long? officeId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetDepartmentRecord | ResponseModel | long DepartmentId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| SaveDepartment | ResponseModel | [FromBody] Department model | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| DeleteDepartment | ResponseModel | long DepartmentId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetDesignationList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| GetDesignationRecord | ResponseModel | long DesignationId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| SaveDesignation | ResponseModel | [FromBody] DesignationViewModel model | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| DeleteDesignation | ResponseModel | long DesignationId | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |

### CredEDIERASetupService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetLookupLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| AddEditCredEDIERASetup | ResponseModel | EDI_ERA_Setup eDI_ERA_Setup, long userId | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| GetCredEDIERASetupById | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| SearchCredEDIERASetup | ResponseModel | EdiEraSetupSearchViewModel searchViewModel | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| AddEditCred_EDIERA_Notes | ResponseModel | EDI_ERA_Notes eDI_ERA_Notes, long UserId | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| GetCred_EDIERA_Notes | ResponseModel | long applicationId | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| SaveCred_EDIERA_Document | ResponseModel | CredAppDocumentRequest request | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| GetCred_EDIERA_Documents | ResponseModel | long applicationId | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| GetCred_EDIERA_DocumentByDocId | ResponseModel | long documentId | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| DeleteCred_EDIERA_Document | ResponseModel | long documentId | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| AddTPAName | ResponseModel | TPA_Name_List tPA_Name_List | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| AddClearingHouse | ResponseModel | Clearing_Houses clearing_Houses | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| AddSoft | ResponseModel | Practice_Software practice_Software | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| GetEDIERAEFTReport | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| GetEDIERAEFTGridReport | ResponseModel | long practiceCode, long ObjTypeId | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |

### CredentialingService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetLookupLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetObjectiveTypesByAppType | ResponseModel | int appTypeId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| AddEditCredApp | ResponseModel | Cred_App_ViewModel cred_App_ViewModel, long userId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| SearchCredApp | ResponseModel | CredAppSearchViewModel searchViewModel | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredAppById | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| AddEditCredAppNote | ResponseModel | Cred_App_Notes cred_App_Notes, long UserId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredAppNotes | ResponseModel | long applicationId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| SaveCredAppDocument | ResponseModel | CredAppDocumentRequest request | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredAppDocuments | ResponseModel | long applicationId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredAppDocumentByDocId | ResponseModel | long documentId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| DeleteCredAppDocument | ResponseModel | long documentId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetUsersByModuleName | ResponseModel | string moduleName | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetUserListByRole | ResponseModel | string Role, long practiceId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| CredAppReport | ResponseModel | long practiceCode, int? objTypeId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredPortals | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| AddEditCredPortal | ResponseModel | CredPortal_View cred_portal, long UserId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredGridReport | ResponseModel | long practiceCode, long providerCode, int ObjTypeId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetTaxonomyCode | ResponseModel | string taxonomycode | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredTasks | ResponseModel | long? PracticeCode, long? UserId, int? Obj_Type_Id | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetUserByRole | ResponseModel | string Role, long userId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredentialingDashboard | ResponseModel | int? practiceCode, string dateFilterType, long userId, DateTime? dateFrom, DateTime? dateTo | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetHospitalStatusReport | ResponseModel | long practiceCode, long ObjTypeId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetHospitalGridReport | ResponseModel | long practiceCode, long providercode, long ObjTypeId | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| GetCredProviderDetails | ResponseModel | string HospitalName, long providercode | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |

### DashboardService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetDashboardData | ResponseModel | long practiceCode, string fromDate, string toDate, long userId | NPM_API_BackUp/NPMAPI/Services/DashboardService.cs |
| GetExternalPractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/DashboardService.cs |
| GetOpenPaymentBatches | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/DashboardService.cs |

### DeltaSyncService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetSyncedPractice | SyncedPractice | long pracCode | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| GetSyncedclaim | SyncedClaim | long claimno | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| UpdateClaim | ClaimUpdateResponse | ClaimUpdateRequest request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| CreateClaimCharge | ClaimChargesCreateResponse | ClaimChargesCreateRequest request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| UpdateClaimCharge | ClaimChargesUpdateResponse | ClaimChargesUpdateRequest request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| deleteClaimCharge | ClaimChargesUpdateResponse | long request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| UpdateClaimPayment | ClaimPaymentUpdateResponse | ClaimPaymentUpdateRequest request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| UpdatePatient | PatientUpdateResponse | PatientUpdateRequest request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| UpdatePractice | PracticeUpdateResponse | PracticeUpdateRequest request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| UpdatePracticeLocation | PracticeLocationUpdateResponse | PracticeLocationUpdateRequest request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| UpdateProvider | ProviderUpdateResponse | ProviderUpdateRequest request | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| GetPyments_Invoice | InvoicePaymentsResponse | long InvoiceId | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| DeletePayments | DeleteinvoicepymentResponse | DeleteInvoicepaymentsRequest deleteInvoicepaymentsRequest, long paymentid | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| DeleteInvoice | DeleteInvoiceResponse | long InvoiceId | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |

### DemographicService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| SearchPatient | ResponseModel | [FromBody] PatientSearchModel SearchModel | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| IsPatientAlreadyExist | ResponseModel | DublicatePatientCheckModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| checkDuplicateDOS | ResponseModel | long patientAccount,DateTime dos | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientModel | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatient | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| DeletePatient | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetFinancialGurantor | ResponseModel | string Name | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetFinancialGurantorSubscriber | ResponseModel | string Name | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| AddEditPatient | ResponseModel | [FromBody] PatientCreateViewModel PatientModel, long UserId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetAppointments | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientClaimsSummary | ResponseModel | long PatientAccount, bool IncludeDeleted, bool isAmountDueGreaterThanZero = false | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPracticeClaims | ResponseModel | ClaimSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientClaim | ResponseModel | long ClaimNo | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientReferrals | List<Practice> | long PatientAccount | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| TestFunc | void |  | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientNotes | ResponseModel | long PatientAccount, int? number | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| DeletePatientInsurance | ResponseModel | long PatientAccount, long PatientInsuranceId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| DeletePatientNote | ResponseModel | long PatientAccount, long PatientNotesId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientNote | ResponseModel | long PatientNotesId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SavePatientNotes | ResponseModel | [FromBody] Patient_Notes PatientNote, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SaveClaimAttachmentNotes | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| DeleteClaimAttachmentNote | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetClaimNotes | ResponseModel | long ClaimNo, int? number | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SaveClaimModel | ResponseModel | ClaimsViewModel ClaimModel, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetClaimNote | ResponseModel | long ClaimNotesId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetModifiers | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SaveClaimNotes | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetServiceTypeCodesDescription | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| DeleteClaimNote | ResponseModel | long ClaimNo, long ClaimNotesId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetInsurancePayerName | string | long? insuranceId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetClaimModel | ResponseModel | long PatientAccount, long ClaimNo = 0 | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SaveClaimOld | ResponseModel | [FromBody] ClaimsViewModel ClaimModel | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetFacilitySelectList | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetFacility | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetDiagnosis | ResponseModel | string DiagCode, string DiagDesc, long PracticeCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| AddDxToProvider | ResponseModel | string DiagCode, long PracticeCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetProcedures | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SearchFacilities | ResponseModel | [FromBody] FacilitySearchModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SavePatientClaimDiagnose | ResponseModel | string DiagCode, long ClaimNo, bool IsEdit, int Sequence | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| EditDiagnosis | ResponseModel | string DiagCode, long ClaimNo | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| DeleteClaim | ResponseModel | long ClaimNo | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetState | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetCityState | ResponseModel | string ZipCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientPicture | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SavePatientInsurance | ResponseModel | Patient_Insurance Model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SavePatientInsurance | ResponseModel | PatientInsuranceViewModel Model, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| InquiryByPracPatProvider | ResponseModelForE | long PracticeCode, long PatAcccount, long ProviderCode, long insurance_id | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| ValidateAddress | ResponseModel | ValidateAddreesRequestViewModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientSelectList | ResponseModel | string searchText, long practiceCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetInsuranceSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetProviderSelectList | ResponseModel | string searchText, long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetProviderSelectList | ResponseModel | string searchText, long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetLocationSelectList | ResponseModel | string searchText, long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPanelBillingLocationSelectList | ResponseModel | long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPracticeDefaultLocation | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientSummary | ResponseModel | long patientAccount, long practiceCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetClaimSummaryByNo | ResponseModel | long claimNo, long practiceCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientClaimsForStatement | ResponseModel | long patientAccount | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GeneratePatientStatement | ResponseModel | PatientStatementRequest model, long v | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GeneratePatientStatementdn | ResponseModel | PatientStatementRequest model, long v | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| getstatementpatient | responsemodel | long practicecode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetStatementPatient | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPAByAccount | ResponseModel | long aCCOUNT_NO | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetClaimAndDos | ResponseModel | long patientAcc | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| CheckCollectionStatus | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| getClaimDetails | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| AddOrUpdatePanelCPTCodes | ResponseModel | PanelCPTCodeList panelCPTCodeList, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| getPanelCodeCpt | ResponseModel | long practiceCode, long providerCode, long locationCode, string cptCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| getPanelCodeCpt | ResponseModel | long practiceCode, long providerCode, long locationCode, string cptCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| getPanelCodeCptClaim | ResponseModel | long practiceCode, long providerCode, long locationCode, string panelCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| IsAlternateCodeRemoved | ResponseModel | string Cpt_Code,string Cpt_Description | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| IsAlternateCodeRemoved | ResponseModel | string Cpt_Code, string Cpt_Description, string AlernateCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPanelAlternateCode | ResponseModel | long practiceCode, long providerCode, long locationCode, string alternateCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| CheckPanelCodeExists | ResponseModel | long practiceCode, long providerCode, long locationCode, string PanelCode, long panelBillingCodeId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPanelBillingSummaryByPractice | ResponseModel | long Practice_Code | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPanelCodeDetailsForEdits | ResponseModel | long panelBillingCodeId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| deleteRows | ResponseModel | long[] rowIds | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| PanelCodeStatus | ResponseModel | int panelBillingCodeId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetPatientPicturePath | string | long patientAccount | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetCitiesByZipCode | ResponseModel | string ZipCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| AddPatientStatementNote | ResponseModel | PatientStatementResponse patientStatementResponse, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetAllViolated | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| AddToScrubberQueue | ResponseModel | ClaimsViewModel claimModel | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetAllClaimsInQueue | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| CheckIfAnesthesiaCpt | bool | string procedureCode | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| Show277CAClaimReasons | List<Packet277CAClaimReason_Messages> | string claimNo | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetAdmissionType | ResponseModel | long PatientAccount, string claimNo | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| AddClaimOverPayment | Task<ResponseModel> | ClaimOverpayment claimOverpayment, long userId | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetAllClaimOverPayment | Task<ResponseModel> | long claimNo | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetStateList | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| ProviderPayerSearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| ProviderPayerSearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| ProviderPayerSearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| ProviderPayerSearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetClaimsWithPatientDue | ResponseModel | long practicecode, long patientaccount | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SearchReferringPhysicians | ResponseModel | string firstName, string lastName, string npi, string zip, string city, string state | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| GetClaimInsurance | ResponseModel | long claimNo | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |

### ERAImportService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetUserId | static long |  | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| SaveManualERAFile | ResponseModel | CreateManualERARequest request, long userId | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Manual_Era_User_Request | Task<ReturnERAResult> | ERA_Request ERA | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| ManualERADownloadDumpProcess | Task<ReturnERAResult> | string username, string logs, ERA_Request ERA | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Era_User_Request | Task<ReturnERAResult> | ERA_Request ERA | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| ERA_Download_and_Dump_Process | Task<ReturnERAResult> | string username, string logs, ERA_Request ERA | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| SearchWeeklyHistory | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |

### EligibilityService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| DoInquiryByX12Data | WSX12EligibilityResponse | DoInquiryByX12DataModel model | NPM_API_BackUp/NPMAPI/Services/EligibilityService.cs |
| DoInquiry | WSEligibilityResponse | DoInquiryModel model, long PracticeCode | NPM_API_BackUp/NPMAPI/Services/EligibilityService.cs |
| GetEligibilityModel | ResponseModel | long PracticeCode, long PatientAccount, long ProviderCode, long insurance_id | NPM_API_BackUp/NPMAPI/Services/EligibilityService.cs |

### EncryptionService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| HashPassword | string | string password | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| VerifyHashedPassword | bool | string hashedPassword, string password | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| VerifyUser | LoggedInUserbyCodeViewModel | string username, string password | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| UserInvalidationReason | HttpStatusCode | string username, string password | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| VerifyUserResend | LoggedInUserbyCodeViewModel | long userid | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| VerifyUserCode | LoggedInUserViewModel | string code, long userid | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| VerifyUserForResetPassword | LoggedInUserbyCodeViewModel | string userEmail | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| VerifyPassword | ResponseModel | long userId,string password | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| GetPracticesClientBased | ResponseModel | long ClientCode,long userId | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |

### ExcelFileHandlerService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| InsertExcelData | void | DataTable dt, string tableName, string practiceCode | NPM_API_BackUp/NPMAPI/Services/ExcelFileHandlerService.cs |
| ProcessExcel | ResponseModel | Stream fileStream, string fileName, string practiceCode | NPM_API_BackUp/NPMAPI/Services/ExcelFileHandlerService.cs |
| GetAllowedSheetHeaders | Dictionary<string, List<string>> |  | NPM_API_BackUp/NPMAPI/Services/ExcelFileHandlerService.cs |

### FTPService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| upload | void | string host, int port, string username, string password, string source, string destination | NPM_API_BackUp/NPMAPI/Services/FTPService.cs |

### FileHandlerService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| UploadImage | ResponseModel | HttpPostedFile File, string FilePath, string[] SupportedTypes, string fileNewName, long? MaximumUploadSize | NPM_API_BackUp/NPMAPI/Services/FileHandlerService.cs |
| UploadTicketImage | ResponseModel | HttpPostedFile file, string filePath, string[] supportedTypes, string fileNewName, long? maximumUploadSize | NPM_API_BackUp/NPMAPI/Services/FileHandlerService.cs |
| DownloadFile | ResponseModel | string FilePath | NPM_API_BackUp/NPMAPI/Services/FileHandlerService.cs |

### GenerateBatch276Service

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GenerateSerialNumber | ResponseModelForSerialnumber | int length = 8 | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| GenerateSerialNumberISA | ResponseModelForSerialnumber | int length = 9 | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| GenerateSerialNumberBHTGS | ResponseModelForSerialnumber | int length = 9 | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| SequanceNumber | ResponseModelSerialNumber |  | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| SequanceNumberISA | ResponseModelSequancerNumber |  | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| SequanceNumberBHT | ResponseModelSequancerNumber |  | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| GenerateBatch_276277 | ResponseModel | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| getSpResult | List<SPDataModel> | string claim_id, string insType | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| GetClaimsData | ClaimsDataModel | string id | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| AddUpdateBatch | ResponseModel | BatchCreateViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| UploadBatches | Task<ResponseModel> | BatchUploadRequest model, long v | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| SingleCSIClaimBatchUpload | Task<ResponseModel> | CSIClaimBatchUploadRequest model, long v | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| UploadFileToFTP | string | string source, long practiceCode, long userId, string caller = "" | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| GetBatchFilePath | ResponseModel | long batchId | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| RegenerateBatchCSIFile | ResponseModel | RegenerateBatchCSIFileModel model, long userId | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| AddUpdateClaimBatchError | void | long batchId, long claimNo, long userId, string errorResponse, string patientName, long? patientAccount, DateTime? Dos | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| InsertMultipleClaimsIntoCSIRequestsData | void | List<BatchClaimSubmissionResponse> responsedPerBatch, string batch_name, string filepath, string Username/*, DateTime? Batch837Upload*//*, string BatchStatus*/ | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |

### ImportWizardService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| BulkInsertImportPatient | void | DataTable dt | NPM_API_BackUp/NPMAPI/Services/ImportWizardService.cs |
| GetImportWizard | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Services/ImportWizardService.cs |
| IssueExcelExport | ResponseModel | long importBatchId, long practiceCode | NPM_API_BackUp/NPMAPI/Services/ImportWizardService.cs |

### InboxHealthAPI

| Method | Return | Params | File |
| --- | --- | --- | --- |
| Put | static Task<HttpResponseMessage> | dynamic data, string requestUri | NPM_API_BackUp/NPMAPI/Services/InboxHealthAPI.cs |
| Create | static Task<HttpResponseMessage> | dynamic data, string requestUri | NPM_API_BackUp/NPMAPI/Services/InboxHealthAPI.cs |
| Get | static Task<HttpResponseMessage> | string requestUri | NPM_API_BackUp/NPMAPI/Services/InboxHealthAPI.cs |
| Delete | static Task<HttpResponseMessage> | string requestUri | NPM_API_BackUp/NPMAPI/Services/InboxHealthAPI.cs |

### InboxHealthService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| onPatientPaymentProcessed | int | dynamic eventData | NPM_API_BackUp/NPMAPI/Services/InboxHealthService.cs |

### InsuranceSetupService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| DeleteInsuranceGroup | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceGroup | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceGroupList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| SaveInsuranceGroup | ResponseModel | [FromBody] Insurance_Groups Model, long userId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceGroupsSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetSmartInsuranceGroupsSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| DeleteInsuranceName | ResponseModel | long InsuranceNameId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceName | ResponseModel | long InsuranceNameId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceNameModel | ResponseModel | long? insuranceNameId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceNameSelectList | ResponseModel | long? insuranceGroupId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetSmartInsuranceNameList | ResponseModel | long? insuranceGroupId, string searchText | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceNameList | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| SaveInsuranceName | ResponseModel | [FromBody] InsuranceNameModelViewModel Model, long userId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsurancePayerList | ResponseModel | long InsuranceGroupId, long InsuranceNameId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsPayerById | ResponseModel | string InsurancePayerId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsPayerByState | ResponseModel | string InsurancePayerState | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsurancePayer | ResponseModel | long InsurancePayerId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsurancePayerModel | ResponseModel | long? InsurancePayerId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| SaveInsurancePayer | ResponseModel | [FromBody] InsurancePayerViewModel insPayer, long v | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| DeleteInsurancePayer | ResponseModel | long InsurancePayerId, long InsuranceNameId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetSmartInsurancePayersList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsPayerList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceList | ResponseModel | long? GroupId, string insuranceName, string insurancePayerName | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsurance | ResponseModel | long InsuranceId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| SaveInsurance | ResponseModel | [FromBody] Insurance insurance, long userId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| DeleteInsurance | ResponseModel | long InsuranceId, long InsurancePayerId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetInsuranceModel | ResponseModel | long? insuranceId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| GetRelationsSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| SaveInsuranceGroup | ResponseModel | [FromBody] InsuranceGroupViewModel Model, long userId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| AddInsurance | ResponseModel | AddInsuranceRequest addInsuranceRequest,long userId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| AddInsurance | ResponseModel | AddInsuranceRequest addInsuranceRequest, long userId | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |

### NPMLogger

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetInstance | static NPMLogger |  | NPM_API_BackUp/NPMAPI/Services/NPMLogger.cs |
| Debug | void | string message, string arg = null | NPM_API_BackUp/NPMAPI/Services/NPMLogger.cs |
| Error | void | string message, string arg = null | NPM_API_BackUp/NPMAPI/Services/NPMLogger.cs |
| Info | void | string message, string arg = null | NPM_API_BackUp/NPMAPI/Services/NPMLogger.cs |
| Warning | void | string message, string arg = null | NPM_API_BackUp/NPMAPI/Services/NPMLogger.cs |

### PDFService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GenerateItemizedPatientStatment | byte[] | long patientAccount, long practiceCode, long userId, string messageToPrint | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| GenerateIPsForDownload | byte[] | StatmentDownloadRequestModel model, long userId | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| GenerateItemizedPsForDownload | byte[] | StatmentDownloadRequestModel model, long userId | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| GenerateRollingFordowloadForDownload | byte[] | string prac_code, string duration | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| AddMessage | ResponseModel | PatientStatementMessages Model, long userid | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| EditMessage | ResponseModel | PatientStatementMessages model, long userid | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| DeleteMessage | ResponseModel | long MessageID | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| GetAllMessages | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |

### PatientAttachmentService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| Delete | ResponseModel | long Id, long userId | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| ClaimDelete | ResponseModel | long Id, long userId, long Document_ID | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| GetAll | ResponseModel | long patientAccount | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| Save | ResponseModel | CreateAttachmentRequest request, long userId | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| GetAttachmentTypeCodesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| Get | ResponseModel | long attachmentId | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| GetTicketAttachment | ResponseModel | long attachmentId | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| SaveTicketAttachment | ResponseModel | CreateAttachmentRequest request, long userId | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| DeleteTicketAttachment | ResponseModel | long Id, long userId | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| GetPatientNote | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |

### PaymentsService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| AddInsurancePayment | ResponseModel | InsurancePaymentViewModel request | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| AddPatientPayment | ResponseModel | PatientPayment request | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetPaymentList | List<SelectListViewModel> |  | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SearchPayment | ResponseModel | PaymentsSearchRequestModel SearchModel | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetClaimsSummary | ResponseModel | string ClaimId, string practiceCode | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetClaimBypatientdetials | ResponseModel | patientBasedClaimModel request | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetClaimByinsdetials | ResponseModel | insBasedClaimModel request | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| PostClaims | ResponseModel | postClaim request | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| getClaimsDetails | ResponseModel | long claimNo, long patientaccount | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SaveClaimsDetails | ResponseModel | ClaimsPaymentDetailModel[] cpd | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| checkPostedClaims | ResponseModel | long batchno, long practiceCode | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| CreateUpdateBatch | ResponseModel | BatchCreateModel batchData, long userId | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SearchBatch | ResponseModel | BatchsSearchRequestModel SearchModel | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| CloseBatch | ResponseModel | BatchsSearchRequestModel SearchModel | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetPatientsWithDue | ResponseModel | bool isDueOnly, int practiceCode | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetPatientsClaims | ResponseModel | long patient_account, bool due_only = true | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetClaimDetails | ResponseModel | long claimID | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetClaimDetailsByClaimNumber | ResponseModel | long claimID, int practiceCode | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetPostedClaims | ResponseModel | string batchID | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetBatchPaymentSummary | ResponseModel | string batchID | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| PostPayments | ResponseModel | ClaimsViewModel ClaimModel, long batchID, string batchDate | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetBatchType | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetBatchCheckDetail | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| DeleteClaimPayment | ResponseModel | string batchID, long claimNo | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| DeleteClaimPayment | ResponseModel | string batchID, long claimNo | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| DeleteClaimPayment | ResponseModel | string batchID, long claimNo,string Amtdue, long userId | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| DeleteClaimPayment | ResponseModel | string batchID, long claimNo, string Amtdue, long userId | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| AutoCloseEligibleBatches | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| ReopenBatch | ResponseModel | long BatchId, long userId | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetCurrentResponsible | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| DeleteInboxInvoice | BaseResponse | long invoiceId | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetBatchDate | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| ValidateCheckNo | ResponseModel | string CheckNo, long Practice_Code, DateTime BatchOpenDate, string PaymentType, long? BatchID = null | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| CheckIfBatchHasPayments | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetBatchChequeNoAndDate | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetBatchPayments | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| GetPayments | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |

### PracticeService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetPractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticesByUserRights | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetActivePractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeModel | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPractice | ResponseModel | long? practiceId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeWithActiveProviders | ResponseModel | long? practiceId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| ActivateInActivePractice | ResponseModel | long practiceId, bool isActive, long UserId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| PostSavePractice | ResponseModel | Practice model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeSelectList | ResponseModel | string searchText = "" | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeFTPInfo | PracticeFTPViewModel | long practiceCode, FTPType type | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetBatchCSIPracticeFTPInfo | PracticeFTPViewModel | long practiceCode, FTPType type | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetFTPEnabledPractices | Task<List<PracticeFTPViewModel>> | long? practiceCode | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetManualERAEnabledPractices | Task<List<PracticeFTPViewModel>> | long? practiceCode | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetFTPEnabledPractices | List<PracticeFTPViewModel> |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeNotesList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeNote | ResponseModel | long PracticeNotesId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SavePracticeNote | ResponseModel | [FromBody] Practice_Notes PracticeNote | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeletePracticetNote | ResponseModel | long PracticeId, long PracticeNotesId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeResources | ResponseModel | long practiceId, long LocationId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetSpecialInstructionList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetSpecialInstruction | ResponseModel | long QuestionId, long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetSpecialInstructionQuestionByCategory | ResponseModel | long CategoryId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SaveSpecialInstruction | ResponseModel | Practice_Special_Instruction_Answers model, long uId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeleteSpecialInstruction | ResponseModel | long QuestionId, long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderNotesList | ResponseModel | long ProviderId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderNote | ResponseModel | long ProviderNoteId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SaveProviderNote | ResponseModel | [FromBody] Provider_Notes ProviderNote | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeleteProviderNote | ResponseModel | long ProviderId, long ProviderNotesId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderWorkingHours | ResponseModel | long ProviderId, long LocationId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderResources | ResponseModel | long ProviderId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderPayers | ResponseModel | long ProviderId, long LocationId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticePayers | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeletePracticePayers | ResponseModel | long PracticeId, string ProviderPayerId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| MapPayer | ResponseModel | InsuranceModel model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| MapPayer | ResponseModel | InsuranceModel model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviders | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProvider | ResponseModel | long providerId, long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| ActivateInActiveProvider | ResponseModel | long providerId, long PracticeId, bool isActive | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SaveProvider | ResponseModel | Provider model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeLocationList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeLocation | ResponseModel | long PracticeId, long PracticeLocationId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SavePracticeLocation | ResponseModel | [FromBody] Practice_Locations model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeletePracticeLocation | ResponseModel | long PracticeId, long PracticeLocationId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeletePracticeLocation | ResponseModel | long PracticeId, long PracticeLocationId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeFacilityList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeFacility | ResponseModel | long PracticeId, long PracticeFacilityId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| ConvertId | Int32 | String id | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SavePracticeFacility | ResponseModel | PRACTICE_FACILITY model | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeletePracticeFacility | ResponseModel | long PracticeId, long PracticeFacilityId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetWcbRatings | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetSpecializations | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetSpecialityGroups | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeSpecialityCategoryOne | ResponseModel | long GroupNo | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeSpecialityCategoryTwo | ResponseModel | long GroupNo, int CatLevel | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| AddPracticeSynchronization | ResponseModel | PracticeSynchronizationModel model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeSynchronization | ResponseModel | long practiceid | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetActiveUsersForPractice | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetDivisionForUser | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SaveReportingDetails | ResponseModel | Practice_Reporting model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetReportingDetailOfPracticeUser | ResponseModel | long userID, long practiceCode | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| IsAutoFillEnableForPractice | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetRecentClaimDetails | ResponseModel | string patientAccount, string practiceCode, string claimType | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| TaxonomyCode | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| NPICode | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeReportingDetail | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| AddOrUpdateProviderResources | ResponseModel | Provider_Resources resource, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetAllProviderResources | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetExpiredPortalsByTeamLeadAsync | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderDocTypeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderStateList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SaveProviderDocs | ResponseModel | ProviderDocuments_ViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| ProviderDocFileUpload | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderDocList | ResponseModel | long PracticeCode, long ProviderCode, string Doc_Type | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| Get | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetProviderDocBYId | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeleteProviderDocBYid | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeDocList | ResponseModel | long PracticeCode, string Doc_Type | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeDocTypeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SavePracticeDocs | ResponseModel | PracticeDocuments_ViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeDocBYId | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| DeletePracticeDocBYid | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| PracticeDocFileUpload | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracFile | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| GetPracticeSoftware | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |

### ReferralPhysiciansService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| CreateReferralPhysician | Task<ResponseModel> | ReferralPhysicianViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |
| ChangeDeleteStatus | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |
| ChangeActiveStatus | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |
| GetReferralPhysician | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |
| GetActiveReferralPhysicians | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |
| GetActiveInactiveReferralPhysicians | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |
| GetReferralPhysicians | Task<ResponseModel> | int page, int count, string pattern | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |
| UpdateReferralPhysician | Task<ResponseModel> | ReferralPhysicianViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |

### ReportService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| AgingSummaryAnalysisReport | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| DormantClaimsReport | Task<ResponseModel> | long PracticeCode, int page, int size | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| DormantClaimsReports | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| DormantClaimsReportsPagination | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| AgingSummaryPatientAnalysisReport | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| FinancialAnalysisByProviderandProcCodesReport | ResponseModel | long PracticeCode, DateTime DateFrom, DateTime DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| FinancialAnalysisCPTLevelReport | ResponseModel | long PracticeCode, DateTime DateFrom, DateTime DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PaymentDetail | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, long? PatientAccount | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PaymentDetailPagination | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, long? PatientAccount, int page, int size | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| CPTWisePaymentDetail | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| CPTWisePaymentDetailPagination | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, int Page, int Count | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| DenialReportDetailPagination | ResponseModel | long? PracticeCode, string Criteria, DateTime? DateFrom, DateTime? DateTo, int Page, int Count | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| DenialReportDetail | ResponseModel | long? PracticeCode, string Criteria, DateTime? DateFrom, DateTime? DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetEshaCBRDetails | ResponseModel | long? practicecode, int page, int count, bool perpagerecord | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetPatientAgingSummaryDetails | ResponseModel | long? PracticeCode, int Page, int Count, bool perPageRecord | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetPlanAgingReportDetails | ResponseModel | long? PracticeCode, int Page, int Count, bool perPageRecord | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| AppointmentDetailReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ClaimPaymentsDetailReport | ResponseModel | ClaimPaymentsDetailRequest request | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| MissingAppointmentDetailReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| OverAllChargesDos | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ByCPTDos | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ByHospitalDos | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ByPrimaryDXDos | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ByCarrierDos | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PaymentMonthWise | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PaymentDailyRefresh | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PaymentByCarrier | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PaymentPrimaryDX | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PaymentByPrimaryICD10 | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| RecallVisits | ResponseModel | ReportRequestModel req, long userId | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PeriodAnalysisAndClosing | ResponseModel | ReportRequestModel req, long userId | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PracticeAnalysis | ResponseModel | ReportRequestModel req, long userId | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PatientBirthDays | ResponseModel | ReportRequestModel req, long userId | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| AgingSummaryRecent | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetCPAAnalysis | ResponseModel | long? practiceCode, string fromDate, string toDate, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetInsuranceAging | ResponseModel | long? practiceCode, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetClaimsAndERAs | ResponseModel | long? practiceCode, DateTime? fromDate, DateTime? toDate, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetClaimsAndERAs | ResponseModel | long? practiceCode, string fromDate, string toDate, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetPatientAging | ResponseModel | long? practiceCode, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetPCRatio | ResponseModel | long? practiceCode, string fromDate, string toDate, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetChargesANDPaymentsTrend | ResponseModel | long? practiceCode, string fromDate, string toDate, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ChargesPaymentsRecent | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetAgingDashboard | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetInsuranceDetailReport | ResponseModel | long? PracCode, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetInsuranceDetailReportPagination | ResponseModel | long? PracCode, long v, int page, int size | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetUserReport | ResponseModel | string PracCode, string v, string dateFrom, string dateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetUserReportPagination | ResponseModel | string PracCode, string v, string dateFrom, string dateTo, int page, int size | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetUserReport | ResponseModel | string PracCode, string v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| holdReport | ResponseModel | long? PracCode | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetRollingSummaryReport | ResponseModel | string PracCode, string duration | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| CollectionAnalysisReport | Task<ResponseModel> | long PracticeCode, DateTime? DateFrom, DateTime? DateTo, bool isExport = false, int page = 1, int size = 10 | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PatientAgingReport | Task<ResponseModel> | long PracticeCode, bool isExport = false, int page = 1, int size = 10 | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| PatientAgingAnalysisReport | Task<ResponseModel> | long PracticeCode, bool isExport = false, int page = 1, int size = 10 | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ClaimAssignmentReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| AccounAssignmentReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| AccounAssignmentReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ERAUnpostedAdjReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| AccounAssignmentReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| AccounAssignmentReportPagination | ResponseModel | long PracticeCode, string DateFrom, string DateTo, int page, int size | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| CPA | ResponseModel | ReportRequestModel req, long v | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| CheckPractice | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| findPractice | bool | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| VisitClaimActivityReport | Task<ResponseModel> | PatelReportsRequestModel request | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetProvidersByPractice | Task<ResponseModel> | int PracticeId | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetChargesBreakDownReport | Task<ResponseModel> | PatelReportsRequestModel request | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetNegativeBalanceReport | Task<ResponseModel> | long practiceCode, string responsibleParty, string dateCriteria, DateTime dateFrom, DateTime dateTo, Boolean isExport, int pageSize, int PageNo | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetBatchPaymentReport | ResponseModel | BatchPaymentModel batchpayment | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| GetUnappliedPaymentReport | ResponseModel | UnappliedPaymentReportModel batchpayment | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |

### SchedulerService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetAppointments | ResponseModel | AppointmentsSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetExistingAppointments | ResponseModel | AppointmentCreateModel model | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetProviderAppointmentSettings | ResponseModel | long providerCode | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetAppointmentModel | ResponseModel | long practiceCode, long? id | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetAppointmentdetail | ResponseModel | long? id, long pataccount, string appDate | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetReasonsSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| Save | ResponseModel | AppointmentCreateModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| Save | ResponseModel | AppointmentCreateModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| Delete | ResponseModel | long id, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| Timings | ResponseModel | TimingSearchViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| Rules | ResponseModel | ProviderAppointmentRuleViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetProviderAppointmentRules | ResponseModel | ProviderAppointmentRuleViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| SaveOfficeTimings | ResponseModel | OfficeTimingCreateViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| SaveAppointmentRules | ResponseModel | ProviderAppointmentRuleViewModel rule, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetProviderSchedules | ResponseModel | long practiceCode, long providerCode, long locationCode | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetProviderSchedulesWithLocation | ResponseModel | long practiceCode, List<long> providerCodes, List<long> locationCodes | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetOfficeTimingForProvidersAndLocations | ResponseModel | long practiceCode,string providerCodes, string locationCodes,DateTime dateFrom, DateTime dateTo | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetProviderBlockedSchedules | ResponseModel | long practiceCode, long providerCode, long locationCode | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetMatchingSchedules | ResponseModel | ProviderSchedulesViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| Statuses | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| SaveStatus | ResponseModel | PracticeAppointmentStatusCreateVM model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetPracticeAppointmentStatuses | ResponseModel | long practiceCode, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetPracticeAppointmentStatus | ResponseModel | long practiceCode, long userId, long practiceAppointmentStatusId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| DeletePracticeAppointmentStatus | ResponseModel | long id, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetPracAppointmentReasons | ResponseModel | long practiceCode, long providerCode, long locationCode | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetAppointmentReasons | ResponseModel | string searchText = "", bool all = false | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| GetUnassignedAppointmentReasons | ResponseModel | long practiceCode, long providerCode, long locationCode, string searchText | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| SaveReason | ResponseModel | PracticeAppointmentReasonCreateVM model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| ChangeColor | ResponseModel | long PracAppReasonID, string ReasonColor, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| DeletePracticeAppointmentReason | ResponseModel | long id, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| SlotAvailability | ResponseModel | SlotAvailabilityRequestVM model, long userId | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| CheckDeceasedPatient | ResponseModel | long PatAccount | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |

### ScrubberService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetAllViolated | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetSkippedClaims | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetAllCleanClaims | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| AddToScrubberQueue | ResponseModel | ClaimsViewModel claimModel | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetColumnList_FrontEnd | List<GetColumn_List> |  | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetColumnList | ResponseModel | GetColumnList GC_L | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetTableList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| AddCustom_Edits_Rules | ResponseModel | CustomEdits_ColumnsList ce, string userName | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetAllCustomEdits | List<Custom_Scrubber_Rules> | long Practice_Code | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetCustomRuleById | ResponseModel | int id | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| CustomEditsStatus | ResponseModel | int id | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetScrubberRejection | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetScrubberRejectionPagination | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To,int page,int size | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetScrubberRejectionDetail | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetClaimSubmissionReport | ResponseModelForClaimSubmission | long practiceCode, DateTime Date_From, DateTime Date_To, string Status | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetClaimSubmissionReportPagination | ResponseModelForClaimSubmission | long practiceCode, DateTime Date_From, DateTime Date_To, string Status,int page,int size | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetEdiHistory | ResponseModelForEdiHistory | long ClaimNo, string Status, string statusLevel, string File277CA | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| GetClaimRejections | ResponseModelforClaimRejection | long practiceCode | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |

### SecurityEventService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| PasswordSuccess | void | string username, long userId | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| PasswordFailed | void | string username,string password, string reason = null | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| OtpSent | void | string username, string channel = "Email" | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| OtpSentFailed | void | string username, string reason = null | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| OtpVerifySuccess | void | string username | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| OtpVerifyFailed | void | string username, string reason = null | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| LoginSuccess | void | string username,long userId | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| LoginFailed | void | string username, string reason = null | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| AccessDenied | void | string username, string module | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| PasswordResetSuccess | void | string username, long userId | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
| PasswordResetFailed | void | string username, string reason = null | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |

### SetupService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| DeleteFacility | ResponseModel | long FacilityId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetFacility | ResponseModel | long FacilityId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetFacilityList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SaveFacility | ResponseModel | [FromBody] Facility Model, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SaveGurantor | ResponseModel | [FromBody] Guarantor Model, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SaveNDC | ResponseModel | [FromBody] NDCModel Model, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SaveDX | ResponseModel | [FromBody] Diagnosi Model, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| UpdateDX | ResponseModel | [FromBody] Diagnosi Model, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| DeleteGurantor | ResponseModel | long GurantorId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| DeleteNDC | ResponseModel | long NDC_ID | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| DeleteDX | ResponseModel | string DX_code | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetGurantor | ResponseModel | long GurantorId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetGurantorsList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetGurantorsList | ResponseModel | Guarantor model | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetNDCList | ResponseModel | NDCViewModel model | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetDXList | ResponseModel | DXViewModel model | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetPracticeList | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetEshaPracticeList | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetuserList | ResponseModel | long pracCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetStatesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetProviderFeeScheduleDD | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| PostproviderFeeSchedule | ResponseModel | providercptplanModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| checkproviderFeeinformation | ResponseModel | check_provider_cptplan_existence model | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| getpracticeinformationforcptplan | ResponseModel | long Practicecode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetRevenueCode | Task<ResponseModel> | string Code | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetProviderFeeSchedule | ResponseModel | ProviderFeeScheduleSearchVM model | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetProviderFeeSchedule | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| PostProviderCptPlanDetails | ResponseModel | Provider_Cpt_Plan_Details model, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| CheckDuplicateCPT | ResponseModel | string ProviderCPTCode, string ProviderCPTPlainId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| CheckDuplicateAlternateCode | ResponseModel | string AlternateCode, string ProviderCPTPlainId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| DuplicateAlternateCodeClaimCharges | ResponseModel | string AlternateCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetProviderPlanDetails | ResponseModel | string ProviderCPTPlanId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetDescriptionByCPT | ResponseModel | string ProviderCPTPCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| CheckCode | ResponseModel | string Code | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetByAlternateCode | ResponseModel | string AlternateCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| InitProviderFeePlan | ResponseModel | ProviderFeeScheduleSearchVM model | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetProviderPlanDetails | ResponseModel | string ProviderCPTPlanId, Pager pager | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetStandardCPTFeeSchedule | ResponseModel | string StateCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetStandardNobilityCPTFeeSchedule | ResponseModel | string StateCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| CreateProviderCPTPlan | ResponseModel | CreateProviderCPTPlanVM model, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| UpdateProviderCPTDetails | ResponseModel | string id, List<Provider_Cpt_Plan_Details> model, long v | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| DeleteProviderPlanAndCPT | ResponseModel | string planId, long v | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetStandardCPTFeeSchedule | ResponseModel | long practiceCode, Pager pager | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetProviderCPTPlanNotes | ResponseModel | string planId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SaveProviderCPTNote | ResponseModel | ProviderCptPlanNoteCreateVM note, long v | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| DeleteProviderCPTNote | ResponseModel | long noteId, long v | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetProcedure | ResponseModel | string procedureCode, string alternateCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| GetDropdownsListForProcedures | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| DuplicateProcAndAlternateCode | ResponseModel | string AlternateCode, string ProcCode | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SaveProcedure | ResponseModel | ProcedureViewModel model,long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| DeleteProcedure | ResponseModel | string procedureCode, string alternateCode, long userId | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SearchProcedures | ResponseModel | ProceduresSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |

### SubmissionService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetFormattedDate | string |  | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GenerateSerialNumber | string | int length = 9 | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| InsertSerialNumber | void | string serialNumber, long claim_id | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GenerateBatch_5010_P_P | Task<ResponseModel> | long practice_id, long claim_id, long i, long l, long HL,long SC, long BID, long BP, long SN | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GenerateBatch_5010_P_S | Task<ResponseModel> | long practice_id, long claim_id, long i, long l, long HL, long SC, long BID, long BP, long SN | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| ParseFile | void | string file_Data | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetClaimsSearchModels | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SearchClaim | ResponseModel | ClaimSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SearchBatchClaims | ResponseModel | BatchClaimsSearchViewModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| RemoveClaimBatch | ResponseModel | RemoveClaimBatchViewModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| AddUpdateBatch | ResponseModel | BatchCreateViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetPendingBatchSelectListErrorCom | ResponseModel | long practiceCode, long? providerCode, string practype | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetPendingBatchSelectList | ResponseModel | long practiceCode, long? providerCode, string practype, string batch_claim_type | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetSentBatchSelectList | ResponseModel | string searchText, long practiceCode, long? providerCode | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatchesDetail | ResponseModel | BatchListRequestViewModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| AddInBatch | ResponseModel | AddInBatchRequestViewModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| CanAddClaims | bool | List<string> alreadyAdded, List<string> toAdd | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| LockBatch | ResponseModel | LockBatchRequestViewModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| UploadBatches | Task<ResponseModel> | BatchUploadRequest model, long v | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| UploadBatches | Task<ResponseModel> | BatchUploadRequest model, long v | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatchExceptions | ResponseModel | BatchErrorsRequestModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatchExceptions | ResponseModel | BatchErrorsRequestModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatchFileErrors | ResponseModel | BatchErrorsRequestModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatchesHistory | ResponseModel | BatchesHistoryRequestModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Get999Report | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatcheDetalis | ResponseModel | long batchId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatcheDetalis | ResponseModel | long batchId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| CheckMedicareClaim | ResponseModel | long? claimId, long insurance_id | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetCSIBatcheResponseDetalis | ResponseModel | long batch_id, long claimId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetCSIBatcheDetalisStatus | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetCSIBatcheDetalis | ResponseModel | int batchId, string claimId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| UploadFileToFTP | string | string source, long practiceCode, long userId, string caller = "" | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatchFilePath | ResponseModel | long batchId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| AddUpdateClaimBatchError | void | long batchId, long claimNo, long userId, string errorResponse, string patientName, long? patientAccount, DateTime? Dos | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| AddUpdateClaimBatchError | void | long batchId, long claimNo, long userId, string errorResponse, string patientName, long? patientAccount, DateTime? Dos | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| RegenerateBatchFile | Task<ResponseModel> | RegenerateBatchFileRequestModel model, long userId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Read | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SearchERA | ResponseModel | ERASearchRequestModel model, string imp_type = null | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| EraSummary | ResponseModel | EraSummaryRequest model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| ViewEraSummary | ResponseModel | ViewERASummaryRequest model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| EraSummary | ResponseModel | EraSummaryRequest model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| ERAClaimSummary | ResponseModel | claimsummaryrequest model, string imp_type = null | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| ApplyERA | ResponseModel | ApplyERARequestModel req, long userId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| ERAClaimsOverPayment | ResponseModel | claimsummaryrequest model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| AutoPost | ResponseModel | ERAAutoPostRequestModel request, long userId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GenerateBatch_For_Packet_837i_5010_I | Task<ResponseModel> | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| getSpResult | List<SPDataModel> | string claim_id, string insType | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetClaimsData | ClaimsDataModel | string id | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| View837 | Task<ResponseModel> | long batchId, long practice_id | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| HoldBatch | ResponseModel | HoldBatchRequestViewModel model | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetERACheckDetails | ResponseModel | long practice_id | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GetBatchPaymentForERA | ResponseModel | string checkNo, long practice_id | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| ExtractClaimNumber | static string | string responseString277 | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| UpdateCsiBatchStatus | static void | string claimNumber, string stcStatus | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| ProcessEdiFileAndUpdateStatus | static void | string responseString277, string stcStatus | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| GenerateBatch_5010_P_T | Task<ResponseModel> | long practice_id, long claim_id, long i, long l, long HL, long SC, long BID, long BP, long SN | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |

### TTService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetPatientCompleteInfo | ResponseModel | string patientacc, string ticketType | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetClaimInfo | ResponseModel | string claimno | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetPatientAccounts | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetPatientDueAmt | ResponseModel | string patientacc, long claimno | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetPatientInfo | ResponseModel | string patientacc | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetPracticeInfo | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetRenderingProvider | ResponseModel | long providercode | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetTTDepartmentsList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| SaveTicket | ResponseModel | Tickettracker model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| SaveTicket | ResponseModel | Tickettracker model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| SearchTicket | ResponseModel | TicketSearchModel model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| TicketAssignment | ResponseModel | TicketAssignmentRequest model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetTicketById | ResponseModel | long ticketid, long tickettrailid | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetProviderList | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetTicketTrackById | ResponseModel | long ticketid | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| SaveTrackDetails | ResponseModel | SaveTrackDetails model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| EditTrackDetails | ResponseModel | TicketMessageDetail model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| DeleteTrackDetails | ResponseModel | TicketMessageDetail model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetAssignedUser | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| SendTicketEmail | ResponseModel | Tickettracker model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| CleanValue | static string | string input | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| SendMultipleTicketEmail | ResponseModel | Tickettracker model | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetLookupLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetUsersByDepartment | ResponseModel | long departmentId | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetTicketAlerts | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetLoginTicketPopup | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| GetOpenTicketCount | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/TTService.cs |

### TicketAttachmentsService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| Save | ResponseModel | CreateAttachmentRequest request, long userId | NPM_API_BackUp/NPMAPI/Services/TicketAttachmentsService.cs |

### UBClaim

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetAllCodesData | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| ManageOccurenceSpan | Task<ResponseModel> | List<ClaimsOccurrenceCode> OSClist | NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| ManageOccurenceSpan | Task<ResponseModel> | List<Claims_Occurrence_Code> OSClist, long userid | NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| GetallDropdowns | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| SaveUBClaim | Task<ResponseModel> | ClaimsViewModel cr, long userId | NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |

### UserManagementService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetModulesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SaveModule | ResponseModel | [FromBody] ModuleViewModel Model, long uId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| DeleteModule | ResponseModel | long id, long uId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetModulesSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetUsersList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SaveUser | ResponseModel | UserCreateViewModel model, long uId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetUser | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| ResetPasswordForOTP | ResponseModel | ResetPasswordViewModel model, long uId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| ResetPassword | ResponseModel | ResetPasswordViewModel model, long uId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| ResetPasswordForUser | ResponseModel | ResetPasswordForuserViewModel model, long uId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| DeleteUser | ResponseModel | long id, long uId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| ChangeUserStatus | ResponseModel | UserStatusChangeViewModel model, long uId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetUsersSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetUser | LoggedInUserViewModel | string username, string password | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetUserRoleAndRights | List<SP_GetUserAuthorization_Result> | long userId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| verifyEmail | ResponseModel | string vEmail | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| empIdExists | ResponseModel | long vEmpId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetPostingUnappliedPaymentUsersList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetRoleList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SaveRole | ResponseModel | RoleViewModel model | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetRole | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| DeleteRole | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetRolesSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetTemplateByRoleId | ResponseModel | long roleId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SaveRoleModuleProperties | ResponseModel | RoleModulePropertyCreateViewModel model | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetTemplateByUserId | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SaveUserModuleProperties | ResponseModel | UserModulePropertyCreateViewModel model | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetSubModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetSubModuleList | ResponseModel | long? moduleId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SaveSubModule | ResponseModel | SubModuleViewModel model | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| DeleteSubModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetSubModulePropertiesList | ResponseModel | long? subModuleId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetSubModuleProperty | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetSubModulesSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetSubModulesSelectList | ResponseModel | string searchText, long moduleId | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SaveSubModuleProperty | ResponseModel | SubModulePropertiesCreateViewModel model | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| DeleteProperty | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetEmployeesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetEmployee | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SaveEmployee | ResponseModel | EmployeeCreateViewModel model | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| GetListsOfSelectLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |

### VendorService

| Method | Return | Params | File |
| --- | --- | --- | --- |
| GetVendor | List<SelectListViewModel> |  | NPM_API_BackUp/NPMAPI/Services/VendorService.cs |


## Worker/Support Projects

| Project | Application files counted | Key files |
| --- | --- | --- |
| NPMSyncWorker | 56 | NPM_API_BackUp/NPMSyncWorker/appsettings.Development.json, NPM_API_BackUp/NPMSyncWorker/appsettings.json, NPM_API_BackUp/NPMSyncWorker/NPMSyncWorker.csproj, NPM_API_BackUp/NPMSyncWorker/Procedures.cs, NPM_API_BackUp/NPMSyncWorker/Program.cs, NPM_API_BackUp/NPMSyncWorker/Worker.cs, NPM_API_BackUp/NPMSyncWorker/Entities/Patient.cs, NPM_API_BackUp/NPMSyncWorker/Entities/Practice.cs, NPM_API_BackUp/NPMSyncWorker/Entities/PracticeLocations.cs, NPM_API_BackUp/NPMSyncWorker/Entities/PracticeSynchronization.cs, NPM_API_BackUp/NPMSyncWorker/Entities/PracticeSynchronizationLog.cs, NPM_API_BackUp/NPMSyncWorker/Entities/PracticeVendor.cs |
| NPMWorkers | 15 | NPM_API_BackUp/NPMWorkers/appsettings.Development.json, NPM_API_BackUp/NPMWorkers/appsettings.json, NPM_API_BackUp/NPMWorkers/AutoPostingWorker.cs, NPM_API_BackUp/NPMWorkers/NPMWorkers.csproj, NPM_API_BackUp/NPMWorkers/Program.cs, NPM_API_BackUp/NPMWorkers/Data/ERADBContext.cs, NPM_API_BackUp/NPMWorkers/Data/NPMDBContext.cs, NPM_API_BackUp/NPMWorkers/Entitties/DownloadedFile.cs, NPM_API_BackUp/NPMWorkers/Entitties/Practice.cs, NPM_API_BackUp/NPMWorkers/Models/FTPEnabledPracticeModel.cs, NPM_API_BackUp/NPMWorkers/Properties/launchSettings.json, NPM_API_BackUp/NPMWorkers/Repositories/IERAImportRepository.cs |
| SecretStore | 2 | NPM_API_BackUp/SecretStore/Program.cs, NPM_API_BackUp/SecretStore/SecretStore.csproj |
