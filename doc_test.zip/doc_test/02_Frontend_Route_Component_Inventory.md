# Frontend Route and Component Inventory

Angular PMS UI inventory from `NPM_UI_BackUp/src/app` only.

## Routes

| Path | Component | Lazy module / redirect | Routing file |
| --- | --- | --- | --- |
| login | LoginComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
| forgot-password | ForgotPasswordComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
| otp | OtpComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
|  | LayoutComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
|  | DashBoardComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
| eligblity | EligblityComponent | ./tickettracker/tickettracker.module#TickettrackerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| customEdits/:type/:id | CustomEditsComponent | ./tickettracker/tickettracker.module#TickettrackerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| dashboard | DashBoardComponent | ./tickettracker/tickettracker.module#TickettrackerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ticket-tracker | TicketResponseComponent | ./tickettracker/tickettracker.module#TickettrackerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ticketresponse | TicketResponseComponent | ./patient/patient.module#PatientModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| patient |  | ./patient/patient.module#PatientModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
|  |  | ./practice-setup/practice-setup.module#PracticeSetupModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| claimsubmission |  | ./claim-submission/claim-submission.module#ClaimSubmissionModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| users |  | ./user-management/user-management.module#UserManagementModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| OfficeMGM |  | ./officemanagement/officemanagement.module#OfficemanagementModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ReportSetup |  | ./reports/reports.module#ReportsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| Tasks |  | ./tasks/tasks.module#TasksModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| FeeSchedule |  | ./fee-schedule/fee-schedule.module#FeeScheduleModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| EDISetup |  | ./edisetup/edisetup.module#EDISetupModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| appointments |  | ./appointment-scheduler/appointment-scheduler.module#AppointmentSchedulerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| Facility |  | ./setups/Facility/facility.module#facilityModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| guarantors |  | ./setups/guarantors/guarantors.module#GuarantorsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| procedures |  | ./setups/Procedures/procedures.module#proceduresModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| diagnosis |  | ./setups/dx/dx.module#dxModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ndc |  | ./setups/ndc/ndc.module#ndcModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| DepositSlip |  | ./deposite-slip/deposite-slip.module#DepositeSlipModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| Patient/Demographics |  | ./Claims/claims.module#ClaimsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| InsuranceSetup |  | ./setups/setups.module#SetupsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| reporting |  | ./dynamic-reports/dynamic-reports.module#DynamicReportsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| era |  | ./era/era.module#ERAModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| payment |  | ./payment/payment.module#PaymentModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| referral-physician |  | ./setups/referral-physician/referral-physician.module#ReferralPhysiciansModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| credentialing | ErrorPageComponent | ./credentialing/credentialing.module#CredentialingModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| importwizard | ErrorPageComponent | ./import-wizard/import-wizard.module#ImportWizardModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| 404 | ErrorPageComponent | /404 | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ** |  | /404 | NPM_UI_BackUp/src/app/app-routing.module.ts |
|  | AppointmentSchedulerComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| scheduler | SchedulerComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| officeTiming | OfficeTimingsComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| statuses | AppointmentStatusComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| reasons | AppointmentReasonsComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| block-appointments | BlockAppointmentsComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
|  | ClaimSubmissionComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| scrubber/:type | ComponentScrubberComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| skippedclaims | AutoSubmissionSkippedClaimsComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| claims | ClaimsSubmissionClaimsComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| errors | ClaimSubmissionErrorsComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| claims | ClaimsSubmissionClaimsComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| batchResponse | BatchSubmissionResponseComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| patientStatement | PatientStatementComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| Claimrejection | ClaimRejectionComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| Diagnosis | DiagnosisComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
|  | MainComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| :param | PatientComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| ClaimDetail/:param | ClaimsComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| Detail/:param | PatientComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| New/:param | PatientComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| Edit/:param | PatientComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| ClaimSummary/:param | ClaimSummaryComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| Appoinments/:param | AppoinmentsComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
|  | CredAppListComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| addedit | CredAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| credApp | CredAppListComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| addedit | CredAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| addedit/:id | CredAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| view/:id | CredAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| credEdiEraApp | CredEdiEraAppListComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| addcredEdiEraaddedit | CredEdiEraAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| editcredEdiEraaddedit/:id | CredEdiEraAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| viewcredEdiEraaddedit/:id | CredEdiEraAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| reports | CredReportsComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| credPortal | CredPortalComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| cred-app-report | CredAppReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| hospital-status-report | HospitalStatusReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| hospital-grid-report | HospitalGridReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| edi-era-eft-report | EdiEraEftReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| edi-era-eft-grid-report | EdiEraEftGridReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| cred-grid-report | CredGridReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| credPortal | CredPortalComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| CredTasks | CredTasksComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| CredDashboard | CredDashboardComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
|  | DespositSlipComponent |  | NPM_UI_BackUp/src/app/deposite-slip/depositeSlipRouting.module.ts |
|  | DynamicReportsComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| charges | ChargesComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| overall | OverAllByDosComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-cpt | ByCPTDos |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-hospital | ChargesByHospital |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-primary-dx-dos | ChargesByPrimaryDxDOS |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-carrier | ChargesByCarrierDos |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| cpa | CpaComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| payments | PaymentsComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| monthly | OverallPaymentsByMonth |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| daily | OverallPaymentsByDaily |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-carrier | PaymentByCarrier |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-primary-dx | PaymentByPrimaryDX |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-procedure-code | PaymentByPrimaryICD10 |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
|  | EdiSetupMainComponent |  | NPM_UI_BackUp/src/app/edisetup/edisetupRouting.module.ts |
|  | ERALayout |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| era | ERAImportComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| erahistory | ErahistoryComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| manualeraimport | ManualEraimportComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| batchpayments | BatchPaymentsComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| BatchPaymentAdvisory | BatchPaymentAdvisoryComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| view/:id | ERAViewer |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| claims/:id | ERAClaims |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
|  | FeeScheduleMainComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| Standard | StandardCPTFeeScheduleComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| NobilityCPT | NobilityCPTFeeScheduleComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| ProviderCPT | ProviderCptfeeScheduleTempComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| PanelBilling | PanelBillingComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| AddEditPanelCode | AddEditPanelCodeComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| add-edit-panel-code/:id | AddEditPanelCodeComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
|  | ImportWizardMainComponent |  | NPM_UI_BackUp/src/app/import-wizard/import-wizard-routing.module.ts |
|  | OfficemanagementComponent |  | NPM_UI_BackUp/src/app/officemanagement/officeManagementRouting.module.ts |
| PatientSearch | PatientSearchComponent |  | NPM_UI_BackUp/src/app/patient/patient-routing.module.ts |
|  | PaymentSearchComponent |  | NPM_UI_BackUp/src/app/payment/payment-routing.module.ts |
| PracticeTAB | PracticeTABComponent |  | NPM_UI_BackUp/src/app/practice-setup/practiceSetupRouting.module.ts |
| PracticeList | PracticeListComponent |  | NPM_UI_BackUp/src/app/practice-setup/practiceSetupRouting.module.ts |
| Practice | AddEditPracticeComponent |  | NPM_UI_BackUp/src/app/practice-setup/practiceSetupRouting.module.ts |
| EditPractice/:id/:Type | PracticeTABComponent |  | NPM_UI_BackUp/src/app/practice-setup/practiceSetupRouting.module.ts |
|  | MainReportsComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| AgingSummary | AgingSummaryReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| AgingSummaryPat | AgingSummaryPatientWiseComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| FinancialSummaryProvider | FinancialSummaryProviderWiseComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| FinancialSummaryCPT | FinancialSummaryCPTWiseComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| RecallVisits | RecallVisits |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| practice-analysis-by-facility | PracticeAnalysisComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| practice-analysis-by-provider | PracticeAnalysisByProviderComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| patient-birth-days | PatientBirthDays |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| payment-detail | PaymentDetail |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| ctp-wise-payment-details | CtpWisePaymentDetailsComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| appointment-detail | AppointmentDetailComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| missing-appointment-detail | MissingAppointmentDetailComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| claim-payment-report | ClaimPaymentReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| insurance-detail-report | InsuranceDetailReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| hold-claims-report | HoldclaimsComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| claim-assignmentreport | ClaimAssignmentreportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| acount-assignmentreport | AccountAssignmentreportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| user-report | UserReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| rollingsummary | RollingsummaryreportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| scrubber-rejection-report | ScrubberRejectionReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| claim-submission-report | ClaimSubmissionReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| pending-batch-report | PendingBatchReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| unposted-adjustment-report | UnpostedAdjustmentReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| patient-statement-report | PatientStatementReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| patient-aging-report | PatientAgingReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| collection-analysis-report | CollectionAnalysisReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| patient-aging-analysis-report | PatientAgingAnalysisComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Visit-Claim-Activity-report | VisitClaimActivityReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Charges-BreakDown-report | ChargesBreakDownReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Negative-Balance-Report | NegativeBalanceReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| denial-report | DenialReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| credit-balance-report | CreditBalanceReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| esha-patient-aging | EshaPatientAgingReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| esha-plan-aging | EshaPlanAgingReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| batch-payment-report | BatchPaymentReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| unapplied-payment | UnappliedPaymentReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
|  | DXComponent |  | NPM_UI_BackUp/src/app/setups/dx/dxRouting.module.ts |
|  | FacilitiesComponent |  | NPM_UI_BackUp/src/app/setups/Facility/facilityRouting.module.ts |
|  | GuarantorsListComponent |  | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-routing.module.ts |
| add | GuarantorsAddEditComponent |  | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-routing.module.ts |
| edit/:id | GuarantorsAddEditComponent |  | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-routing.module.ts |
|  | NdcComponent |  | NPM_UI_BackUp/src/app/setups/ndc/ndc-routing.module.ts |
|  | ProceduresComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
|  | ListProceduresComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
| list | ListProceduresComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
| add | AddEditProcedureComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
| edit/:id/:Desc | AddEditProcedureComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
|  | ReferralPhysicianComponent |  | NPM_UI_BackUp/src/app/setups/referral-physician/referral-physician-routing.module.ts |
| :id/:type | AddEditReferralPhysicianComponent |  | NPM_UI_BackUp/src/app/setups/referral-physician/referral-physician-routing.module.ts |
|  | MainInsuranceSetupComponent | insGroup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| insGroup | InsuranceSetupGroupComponent | insGroup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | AddEditInsGroupSetupComponent | insGroup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditInsGroupSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id | AddEditInsGroupSetupComponent | insName | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| detail/:id | InsGroupSetupDetailsComponent | insName | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| insName | InsuranceSetupNameComponent | insName | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | AddEditInsNameSetupComponent | insName | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditInsNameSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id | AddEditInsNameSetupComponent | insPayer | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| detail/:id | InsNameSetupDetailsComponent | insPayer | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| insPayer | InsuranceSetupPayerComponent | insPayer | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | AddEditInsSetupPayerComponent | insPayer | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditInsSetupPayerComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id | AddEditInsSetupPayerComponent | insSetup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| detail/:id | InsSetupPayerDetailComponent | insSetup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| insSetup | InsuranceSetupComponent | insSetup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | AddEditInsSetupComponent | insSetup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditInsSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id/:nameId/:payerid | AddEditInsSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| detail/:id/:nameId/:payerid | AddEditInsSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| Facility | FacilitiesComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| procedures | ProceduresComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | ListProceduresComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| list | ListProceduresComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditProcedureComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id | AddEditProcedureComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| guarantor | GuarantorComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | TasksComponent |  | NPM_UI_BackUp/src/app/tasks/tasks-routing.module.ts |
| claimlevel | ClaimLevelComponent |  | NPM_UI_BackUp/src/app/tasks/tasks-routing.module.ts |
| accountlevel | AccountLevelComponent |  | NPM_UI_BackUp/src/app/tasks/tasks-routing.module.ts |
|  | TicketTrackerComponent |  | NPM_UI_BackUp/src/app/tickettracker/tickettracker-routing.module.ts |
| create-ticket | CreateTicketComponent |  | NPM_UI_BackUp/src/app/tickettracker/tickettracker-routing.module.ts |
| create-ticket/:id/:trailid | CreateTicketComponent |  | NPM_UI_BackUp/src/app/tickettracker/tickettracker-routing.module.ts |
| module | ModuleComponent | module | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditModuleComponent | module | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditModuleComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditModuleComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | ModuleDetailComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| role | RoleComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditRoleComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditRoleComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditRoleComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | RoleDetailComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| submodule | SubModulesComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditSubModuleComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditSubModuleComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditSubModuleComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | SubModuleDetailComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| properties | PropertiesComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditPropertiesComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditPropertiesComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditPropertiesComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | DetailPropertiesComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| users | UsersComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditUserComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditUserComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditUserComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | UserDetailComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| employees | EmployeesComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditEmployeeComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditEmployeeComponent | rights | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | EmployeeDetailComponent | rights | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| rights | RoleRightsComponent | rights | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | RoleWiseRightsComponent | rights | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| rolewise | RoleWiseRightsComponent |  | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| userwise | UsersWiseRightsComponent |  | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |

## Components

| Component | Selector | Folder |
| --- | --- | --- |
| AppComponent | app-root | NPM_UI_BackUp/src/app |
| AddEditAppointmentReasonComponent | add-edit-appointment-reason | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-reasons/add-edit-appointment-reason |
| AppointmentReasonsComponent | app-appointment-reasons | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-reasons |
| AppointmentSchedulerComponent | app-appointment-scheduler | NPM_UI_BackUp/src/app/appointment-scheduler |
| AddEditAppointmentStatusComponent | add-edit-appointment-status | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-status/add-edit-appointment-status |
| AppointmentStatusComponent | app-appointment-status | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-status |
| NgbTimeStringAdapter | app-add-edit-block-appointments | NPM_UI_BackUp/src/app/appointment-scheduler/block-appointments/add-edit-block-appointments/add-edit-block-appointments |
| BlockAppointmentsComponent | app-block-appointments | NPM_UI_BackUp/src/app/appointment-scheduler/block-appointments/block-appointments |
| AddEditOfficeTimingComponent | add-edit-office-timing | NPM_UI_BackUp/src/app/appointment-scheduler/office-timings/add-edit-office-timing |
| OfficeTimingsComponent | app-office-timings | NPM_UI_BackUp/src/app/appointment-scheduler/office-timings |
| SchedulerComponent | app-scheduler | NPM_UI_BackUp/src/app/appointment-scheduler/scheduler |
| ForgotPasswordComponent | app-forgot-password | NPM_UI_BackUp/src/app/auth/forgot-password |
| LoginComponent | app-login | NPM_UI_BackUp/src/app/auth/Login |
| OtpComponent | app-otp | NPM_UI_BackUp/src/app/auth/otp |
| AutoSubmissionSkippedClaimsComponent | app-auto-submission-skipped-claims | NPM_UI_BackUp/src/app/claim-submission/auto-submission-skipped-claims |
| BatchSubmissionResponseComponent | app-batch-submission-response | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response |
| ClaimSubmissionErrorsComponent | app-claim-submission-errors | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors |
| ClaimSubmissionComponent | app-claim-submission | NPM_UI_BackUp/src/app/claim-submission |
| ClaimsSubmissionClaimsComponent | app-claims-submission-claims | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims |
| ComponentScrubberComponent | app-component-scrubber | NPM_UI_BackUp/src/app/claim-submission/component-scrubber |
| ClaimRejectionComponent | app-claim-rejection | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/claim-rejection |
| PatientStatementComponent | app-patient-statement | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/patient-statement |
| PatientStatementClaimsComponent | app-patient-statement-claims | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/patient-statement-claims |
| ClaimAttachmentsComponent | app-claim-attachments | NPM_UI_BackUp/src/app/Claims/Attachments |
| ClaimNotesComponent | app-claim-notes | NPM_UI_BackUp/src/app/Claims/claimNotes |
| ClaimsAssignmentComponent | app-claims-assignment | NPM_UI_BackUp/src/app/Claims/claims-assignment |
| ClaimsComponent | app-claims | NPM_UI_BackUp/src/app/Claims |
| DiagnosisComponent | app-diagnosis | NPM_UI_BackUp/src/app/Claims/Diagnosis |
| ClaimInsurancesComponent | app-claim-insurances | NPM_UI_BackUp/src/app/Claims/Insurances |
| PaymentsComponent | app-payments | NPM_UI_BackUp/src/app/Claims/Payments |
| UB04Component | app-ub04 | NPM_UI_BackUp/src/app/Claims/ub04 |
| BaseComponent | app-base | NPM_UI_BackUp/src/app/core/base |
| ErrorPageComponent | app-error-page | NPM_UI_BackUp/src/app/core/error-page |
| FooterComponent | app-footer | NPM_UI_BackUp/src/app/core/footer |
| LayoutComponent | app-layout | NPM_UI_BackUp/src/app/core/layout |
| NavbarComponent | app-navbar | NPM_UI_BackUp/src/app/core/navbar |
| TopnavbarComponent | app-topnavbar | NPM_UI_BackUp/src/app/core/topnavbar |
| CredAppAddeditComponent | app-cred-app-addedit | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit |
| CredAppAttachmentsComponent | app-cred-app-attachments | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments |
| CredAppListComponent | app-cred-app-list | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-list |
| CredDashboardComponent | app-cred-dashboard | NPM_UI_BackUp/src/app/credentialing/cred-dashboard |
| CredEdiEraAppAddeditComponent | app-cred-edi-era-app-addedit | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit |
| CredEdiEraAppAttachmentsComponent | app-cred-edi-era-app-attachments | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments |
| CredEdiEraAppListComponent | app-cred-edi-era-app-list | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-list |
| CredPortalComponent | app-cred-portal | NPM_UI_BackUp/src/app/credentialing/cred-portal |
| CredAppReportComponent | app-cred-app-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-app-report |
| CredGridReportComponent | app-cred-grid-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report |
| CredReportsComponent | app-cred-reports | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-reports |
| EdiEraEftGridReportComponent | app-edi-era-eft-grid-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/edi-era-eft-grid-report |
| EdiEraEftReportComponent | app-edi-era-eft-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/edi-era-eft-report |
| HospitalGridReportComponent | app-hospital-grid-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/hospital-grid-report |
| HospitalStatusReportComponent | app-hospital-status-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/hospital-status-report |
| CredTasksComponent | app-cred-tasks | NPM_UI_BackUp/src/app/credentialing/cred-tasks |
| CustomEditsComponent | app-custom-edits | NPM_UI_BackUp/src/app/custom-edits |
| DashBoardComponent | app-dash-board | NPM_UI_BackUp/src/app/dashboard |
| DespositSlipComponent | app-desposit-slip | NPM_UI_BackUp/src/app/deposite-slip |
| CpaComponent | app-cpa | NPM_UI_BackUp/src/app/dynamic-reports/charges/by-cpa/cpa |
| ByCPTDos | by-cpt-dos-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/by-cpt-dos |
| ChargesByCarrierDos | charges-by-carrier-dos-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/charges-by-carrier-dos |
| ChargesByHospital | charges-by-hospital-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/charges-by-hospital |
| ChargesByPrimaryDxDOS | charges-by-primary-dx-dos-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/charges-by-primary-dx-dos |
| ChargesComponent | charges-report | NPM_UI_BackUp/src/app/dynamic-reports/charges |
| OverAllByDosComponent | over-all-by-dos-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/overall-by-dos |
| DynamicReportsComponent | dynamic-reports | NPM_UI_BackUp/src/app/dynamic-reports |
| OverallPaymentsByDaily | overall-payments-by-daily-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/overall-payments-by-daily |
| OverallPaymentsByMonth | overall-payments-by-month-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/overall-payments-by-month |
| PaymentByCarrier | payment-by-carrier-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/payment-by-carrier |
| PaymentByPrimaryDX | payment-by-primary-dx-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/payment-by-primary-dx |
| PaymentByPrimaryICD10 | payment-by-primary-icd10-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/payment-by-primary-icd10 |
| PaymentsComponent | payment-report | NPM_UI_BackUp/src/app/dynamic-reports/payments |
| EdiSetupMainComponent | app-edi-setup-main | NPM_UI_BackUp/src/app/edisetup |
| EligblityComponent | app-eligblity | NPM_UI_BackUp/src/app/eligblity |
| BatchPaymentAdvisoryComponent | app-batch-payment-advisory | NPM_UI_BackUp/src/app/era/batch-payment-advisory |
| BatchPaymentsComponent | app-batch-payments | NPM_UI_BackUp/src/app/era/batch-payments |
| ERAClaims | app-era-claims | NPM_UI_BackUp/src/app/era/era-claims |
| ERALayout | app-era-layout | NPM_UI_BackUp/src/app/era/era-layout |
| ERAViewer | app-era-viewer | NPM_UI_BackUp/src/app/era/era-viewer |
| ErahistoryComponent | app-erahistory | NPM_UI_BackUp/src/app/era/erahistory |
| ERAImportComponent | app-eraimport | NPM_UI_BackUp/src/app/era/eraimport |
| ManualEraimportComponent | app-manual-eraimport | NPM_UI_BackUp/src/app/era/manual-eraimport |
| UnappliedPaymentsComponent | app-unapplied-payments | NPM_UI_BackUp/src/app/era/unapplied-payments |
| UnappliedPaymentsPostingComponent | app-unapplied-payments-posting | NPM_UI_BackUp/src/app/era/unapplied-payments-posting |
| AddEditPanelCodeComponent | app-add-edit-panel-code | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code |
| FeeScheduleMainComponent | app-fee-schedule-main | NPM_UI_BackUp/src/app/fee-schedule |
| NobilityCPTFeeScheduleComponent | app-nobility-cptfee-schedule | NPM_UI_BackUp/src/app/fee-schedule/nobility-cptfee-schedule |
| PanelBillingComponent | app-panel-billing | NPM_UI_BackUp/src/app/fee-schedule/panel-billing |
| ProviderCPTFeeScheduleComponent | app-provider-cptfee-schedule | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule |
| ProviderCptfeeScheduleTempComponent | app-provider-cptfee-schedule-temp | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp |
| StandardCPTFeeScheduleComponent | app-standard-cptfee-schedule | NPM_UI_BackUp/src/app/fee-schedule/standard-cptfee-schedule |
| ImportWizardMainComponent | app-import-wizard-main | NPM_UI_BackUp/src/app/import-wizard/import-wizard-main |
| OfficemanagementComponent | app-officemanagement | NPM_UI_BackUp/src/app/officemanagement |
| AccountassignmentComponent | app-accountassignment | NPM_UI_BackUp/src/app/patient/accountassignment |
| AlertAssignmentComponent | app-alertassignment | NPM_UI_BackUp/src/app/patient/alerts |
| AppoinmentsComponent | app-appoinments | NPM_UI_BackUp/src/app/patient/appoinments |
| ClaimSummaryComponent | app-claim-summary | NPM_UI_BackUp/src/app/patient/ClaimSummary |
| MainComponent | app-main | NPM_UI_BackUp/src/app/patient/Main |
| NotesComponent | app-notes | NPM_UI_BackUp/src/app/patient/Patient/Notes |
| PatientNotesComponent | patient-notes | NPM_UI_BackUp/src/app/patient/Patient/patient-notes |
| PatientComponent | app-patient | NPM_UI_BackUp/src/app/patient |
| ReferralComponent | app-referral | NPM_UI_BackUp/src/app/patient/Referrals |
| PatientSearchComponent | app-patient-search | NPM_UI_BackUp/src/app/patient/search |
| PaymentAdvisoryComponent | app-payment-advisory | NPM_UI_BackUp/src/app/payment/payment-advisory/payment-advisory |
| PaymentPostingComponent | app-payment-posting | NPM_UI_BackUp/src/app/payment/payment-posting/payment-posting |
| PaymentSearchComponent | app-payment-search | NPM_UI_BackUp/src/app/payment/payment-search/payment-search |
| AddEditPracticeComponent | app-add-edit-practice | NPM_UI_BackUp/src/app/practice-setup/addeditpractice |
| PracFacilitiesComponent | app-facility | NPM_UI_BackUp/src/app/practice-setup/Facilities |
| LocationsComponent | app-locations | NPM_UI_BackUp/src/app/practice-setup/Locations |
| PracticeListComponent | app-practice-list | NPM_UI_BackUp/src/app/practice-setup/practiceList |
| PracticeTABComponent | app-practice-tab | NPM_UI_BackUp/src/app/practice-setup/practiceTAB |
| ProvidersComponent | app-providers | NPM_UI_BackUp/src/app/practice-setup/providers |
| WebPortalsComponent | app-web-portals | NPM_UI_BackUp/src/app/practice-setup/web-portals |
| AccountAssignmentreportComponent | app-account-assignmentreport | NPM_UI_BackUp/src/app/reports/account-assignmentreport |
| AgingSummaryPatientWiseComponent | app-aging-summary-patient-wise | NPM_UI_BackUp/src/app/reports/aging-summary-patient-wise |
| AgingSummaryReportComponent | app-aging-summary-report | NPM_UI_BackUp/src/app/reports/aging-summary-report |
| AppointmentDetailComponent | app-appointment-detail | NPM_UI_BackUp/src/app/reports/appointment-detail |
| BatchPaymentReportComponent | app-batch-payment-report | NPM_UI_BackUp/src/app/reports/batch-payment-report |
| ChargesBreakDownReportComponent | app-charges-break-down-report | NPM_UI_BackUp/src/app/reports/charges-break-down-report |
| ClaimAssignmentreportComponent | app-claim-assignmentreport | NPM_UI_BackUp/src/app/reports/claim-assignmentreport |
| ClaimPaymentReportComponent | app-claim-payment-report | NPM_UI_BackUp/src/app/reports/claim-payment-report/claim-payment-report |
| ClaimSubmissionReportComponent | app-claim-submission-report | NPM_UI_BackUp/src/app/reports/claim-submission-report |
| CollectionAnalysisReportComponent | app-collection-analysis-report | NPM_UI_BackUp/src/app/reports/collection-analysis-report |
| CreditBalanceReportComponent | app-credit-balance-report | NPM_UI_BackUp/src/app/reports/credit-balance-report |
| CtpWisePaymentDetailsComponent | app-ctp-wise-payment-details | NPM_UI_BackUp/src/app/reports/ctp-wise-payment-details/ctp-wise-payment-details |
| DenialReportComponent | app-denial-report | NPM_UI_BackUp/src/app/reports/denial-report |
| EshaPatientAgingReportComponent | app-esha-patient-aging-report | NPM_UI_BackUp/src/app/reports/esha-patient-aging-report |
| EshaPlanAgingReportComponent | app-esha-plan-aging-report | NPM_UI_BackUp/src/app/reports/esha-plan-aging-report |
| FinancialSummaryCPTWiseComponent | app-financial-summary-cptwise | NPM_UI_BackUp/src/app/reports/financial-summary-cptwise |
| FinancialSummaryProviderWiseComponent | app-financial-summary-provider-wise | NPM_UI_BackUp/src/app/reports/financial-summary-provider-wise |
| HoldclaimsComponent | app-holdclaims | NPM_UI_BackUp/src/app/reports/holdclaims |
| InsuranceDetailReportComponent | app-insurance-detail-report | NPM_UI_BackUp/src/app/reports/Insurance-Detail-Report/insurance-detail-report |
| MainReportsComponent | app-main-reports | NPM_UI_BackUp/src/app/reports |
| MissingAppointmentDetailComponent | app-missing-appointment-detail | NPM_UI_BackUp/src/app/reports/missing-appointment-detail/missing-appointment-detail |
| NegativeBalanceReportComponent | app-negative-balance-report | NPM_UI_BackUp/src/app/reports/negative-balance-report |
| PatientAgingAnalysisComponent | app-patient-aging-analysis | NPM_UI_BackUp/src/app/reports/patient-aging-analysis |
| PatientAgingReportComponent | app-patient-aging-report | NPM_UI_BackUp/src/app/reports/patient-aging-report |
| PatientBirthDays | patient-birth-days-report | NPM_UI_BackUp/src/app/reports/patient-birth-days |
| PatientStatementReportComponent | app-patient-statement-report | NPM_UI_BackUp/src/app/reports/patient-statement-report |
| PaymentDetail | app-payment-detail | NPM_UI_BackUp/src/app/reports/payment-detail |
| PendingBatchReportComponent | app-pending-batch-report | NPM_UI_BackUp/src/app/reports/pending-batch-report |
| PracticeAnalysisComponent | practice-analysis-report | NPM_UI_BackUp/src/app/reports/practice-analysis |
| PracticeAnalysisByProviderComponent | practice-analysis-by-provider-report | NPM_UI_BackUp/src/app/reports/practice-analysis-by-provider |
| RecallVisits | recall-visits-report | NPM_UI_BackUp/src/app/reports/recall-visits |
| RollingsummaryreportComponent | app-rollingsummaryreport | NPM_UI_BackUp/src/app/reports/rollingsummaryreport |
| ScrubberRejectionReportComponent | app-scrubber-rejection-report | NPM_UI_BackUp/src/app/reports/scrubber-rejection-report |
| UnappliedPaymentReportComponent | app-unapplied-payment-report | NPM_UI_BackUp/src/app/reports/unapplied-payment-report |
| UnpostedAdjustmentReportComponent | app-unposted-adjustment-report | NPM_UI_BackUp/src/app/reports/unposted-adjustment-report |
| UserReportComponent | app-user-report | NPM_UI_BackUp/src/app/reports/user-report |
| VisitClaimActivityReportComponent | app-visit-claim-activity-report | NPM_UI_BackUp/src/app/reports/visit-claim-activity-report |
| DXComponent | app-dx | NPM_UI_BackUp/src/app/setups/dx |
| FacilitiesComponent | app-facilities | NPM_UI_BackUp/src/app/setups/Facility |
| GuarantorComponent | app-guarantor | NPM_UI_BackUp/src/app/setups/Guarantor |
| GuarantorsAddEditComponent | app-guarantors-add-edit | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-add-edit |
| GuarantorsListComponent | app-guarantors-list | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-list |
| AddEditInsSetupComponent | app-add-edit-ins-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/add-edit-ins-setup |
| InsSetupDetailComponent | app-ins-setup-detail | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/ins-setup-detail |
| InsuranceSetupComponent | app-insurance-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup |
| ListInsSetupComponent | app-list-ins-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/list-ins-setup |
| AddEditInsGroupSetupComponent | app-add-edit-ins-group-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/add-edit-ins-group-setup |
| InsGroupSetupDetailsComponent | app-ins-group-setup-details | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/ins-group-setup-details |
| InsuranceSetupGroupComponent | app-insurance-setup-group | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group |
| ListInsGroupSetupComponent | app-list-ins-group-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/list-ins-group-setup |
| AddEditInsNameSetupComponent | app-add-edit-ins-name-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/add-edit-ins-name-setup |
| InsNameSetupDetailsComponent | app-ins-name-setup-details | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/ins-name-setup-details |
| InsuranceSetupNameComponent | app-insurance-setup-name | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name |
| ListInsNameSetupComponent | app-list-ins-name-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/list-ins-name-setup |
| AddEditInsSetupPayerComponent | app-add-edit-ins-setup-payer | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/add-edit-ins-setup-payer |
| InsSetupPayerDetailComponent | app-ins-setup-payer-detail | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/ins-setup-payer-detail |
| InsuranceSetupPayerComponent | app-insurance-setup-payer | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer |
| ListInsSetupPayerComponent | app-list-ins-setup-payer | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/list-ins-setup-payer |
| MainInsuranceSetupComponent | app-main-insurance-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup |
| NdcComponent | app-ndc | NPM_UI_BackUp/src/app/setups/ndc |
| AddEditProcedureComponent | app-add-edit-procedure | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure |
| ListProceduresComponent | app-list-procedures | NPM_UI_BackUp/src/app/setups/Procedures/list-procedures |
| ProceduresComponent | app-procedures | NPM_UI_BackUp/src/app/setups/Procedures |
| zipdata | app-add-edit-referral-physician | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician |
| ReferralPhysicianComponent | app-referral-physician | NPM_UI_BackUp/src/app/setups/referral-physician |
| ChangePracticeComponent | app-change-practice | NPM_UI_BackUp/src/app/shared/change-practice |
| ColorPickerComponent | color-picker | NPM_UI_BackUp/src/app/shared/color-picker |
| ZipData | app-add-edit-guarantor-shared | NPM_UI_BackUp/src/app/shared/guarantors/add-edit-guarantor-shared |
| ListGuarantorsSharedComponent | app-list-guarantors-shared | NPM_UI_BackUp/src/app/shared/guarantors/list-guarantors-shared |
| InsuranceSearchComponent | insurance-search | NPM_UI_BackUp/src/app/shared/insurance-search |
| ModalWindow | modal-window | NPM_UI_BackUp/src/app/shared/modal-window |
| PatientAttachmentsComponent | patient-attachments | NPM_UI_BackUp/src/app/shared/patient-attachments |
| PracTabInsuranceSearchComponent | prac-tab-insurance-search | NPM_UI_BackUp/src/app/shared/prac-tab-insurance-search copy |
| ProviderCptPlanNotesComponent | app-provider-cpt-plan-notes | NPM_UI_BackUp/src/app/shared/provider-cpt-plan-notes |
| PhysicianSearchComponent | search-referring-physician | NPM_UI_BackUp/src/app/shared/search-referring-physician |
| AccountLevelComponent | app-account-level | NPM_UI_BackUp/src/app/tasks/account-level |
| ClaimLevelComponent | app-claim-level | NPM_UI_BackUp/src/app/tasks/claim-level |
| TasksComponent | app-tasks | NPM_UI_BackUp/src/app/tasks |
| TicketTrackerComponent | app-ticket-tracker | NPM_UI_BackUp/src/app/ticket-tracker |
| CreateTicketComponent | app-create-ticket | NPM_UI_BackUp/src/app/tickettracker/create-ticket |
| TicketResponseComponent | app-ticket-response | NPM_UI_BackUp/src/app/tickettracker/ticket-response |
| AddEditEmployeeComponent | app-add-edit-employee | NPM_UI_BackUp/src/app/user-management/employees/add-edit-employee |
| EmployeeDetailComponent | app-employee-detail | NPM_UI_BackUp/src/app/user-management/employees/employee-detail |
| EmployeesComponent | app-employees | NPM_UI_BackUp/src/app/user-management/employees |
| ListEmployeesComponent | app-list-employees | NPM_UI_BackUp/src/app/user-management/employees/list-employees |
| AddEditModuleComponent | app-add-edit-module | NPM_UI_BackUp/src/app/user-management/module/add-edit-module |
| ListModuleComponent | app-list-module | NPM_UI_BackUp/src/app/user-management/module/list-module |
| ModuleDetailComponent | app-module-detail | NPM_UI_BackUp/src/app/user-management/module/module-detail |
| ModuleComponent | app-module | NPM_UI_BackUp/src/app/user-management/module |
| AddEditPropertiesComponent | app-add-edit-properties | NPM_UI_BackUp/src/app/user-management/properties/add-edit-properties |
| DetailPropertiesComponent | app-detail-properties | NPM_UI_BackUp/src/app/user-management/properties/detail-properties |
| ListPropertiesComponent | app-list-properties | NPM_UI_BackUp/src/app/user-management/properties/list-properties |
| PropertiesComponent | app-properties | NPM_UI_BackUp/src/app/user-management/properties |
| AddEditRoleComponent | app-add-edit-role | NPM_UI_BackUp/src/app/user-management/role/add-edit-role |
| ListRoleComponent | app-list-role | NPM_UI_BackUp/src/app/user-management/role/list-role |
| RoleDetailComponent | app-role-detail | NPM_UI_BackUp/src/app/user-management/role/role-detail |
| RoleComponent | app-role | NPM_UI_BackUp/src/app/user-management/role |
| RoleRightsComponent | app-role-rights | NPM_UI_BackUp/src/app/user-management/role-rights |
| RoleWiseRightsComponent | app-role-wise-rights | NPM_UI_BackUp/src/app/user-management/role-rights/role-wise-rights |
| UsersWiseRightsComponent | app-users-wise-rights | NPM_UI_BackUp/src/app/user-management/role-rights/users-wise-rights |
| AddEditSubModuleComponent | app-add-edit-sub-module | NPM_UI_BackUp/src/app/user-management/sub-modules/add-edit-sub-module |
| ListSubModuleComponent | app-list-sub-module | NPM_UI_BackUp/src/app/user-management/sub-modules/list-sub-module |
| SubModuleDetailComponent | app-sub-module-detail | NPM_UI_BackUp/src/app/user-management/sub-modules/sub-module-detail |
| SubModulesComponent | app-sub-modules | NPM_UI_BackUp/src/app/user-management/sub-modules |
| UserManagementComponent | app-user-management | NPM_UI_BackUp/src/app/user-management |
| zipdata | app-add-edit-user | NPM_UI_BackUp/src/app/user-management/users/add-edit-user |
| ListUserComponent | app-list-user | NPM_UI_BackUp/src/app/user-management/users/list-user |
| ResetPasswordComponent | app-reset-password | NPM_UI_BackUp/src/app/user-management/users/reset-password |
| UserDetailComponent | app-user-detail | NPM_UI_BackUp/src/app/user-management/users/user-detail |
| UsersComponent | app-users | NPM_UI_BackUp/src/app/user-management/users |

## Angular Services

| Service | File |
| --- | --- |
| AppointmentSchedulerService | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler.service.ts |
| APIService | NPM_UI_BackUp/src/app/components/services/api.service.ts |
| FileHandlerService | NPM_UI_BackUp/src/app/components/services/file-handler/filehandler.service.ts |
| GvarService | NPM_UI_BackUp/src/app/components/services/GVar/gvar.service.ts |
| DataService | NPM_UI_BackUp/src/app/data.service.ts |
| AuthService | NPM_UI_BackUp/src/app/services/auth/auth.service.ts |
| BatchStateService | NPM_UI_BackUp/src/app/services/batch-state-service.service.ts |
| BatchStateService | NPM_UI_BackUp/src/app/services/batch-state.service.ts |
| ClaimService | NPM_UI_BackUp/src/app/services/claim/claim.service.ts |
| ClaimSubmissionService | NPM_UI_BackUp/src/app/services/claim-submission.service.ts |
| AlertService | NPM_UI_BackUp/src/app/services/data/Alert.service.ts |
| DashboardRefreshService | NPM_UI_BackUp/src/app/services/data/dashboard.service.ts |
| DatatableService | NPM_UI_BackUp/src/app/services/data/datatable.service.ts |
| PatientRefreshService | NPM_UI_BackUp/src/app/services/data/patient-refresh.service.ts |
| TableRefreshService | NPM_UI_BackUp/src/app/services/data/table-refresh.service.ts |
| EncryptDecryptService | NPM_UI_BackUp/src/app/services/encrypt-decrypt.service.ts |
| GvarsService | NPM_UI_BackUp/src/app/services/G_vars/gvars.service.ts |
| PaymentServiceService | NPM_UI_BackUp/src/app/services/payment-service.service.ts |
| ModalControllerService | NPM_UI_BackUp/src/app/shared/modal-controller.service.ts |

## HTTP/API Calls Found in UI Source

| Method | File:line | Endpoint/string evidence |
| --- | --- | --- |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:535 | //     const encodedData = params.get('param'); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:550 | // this.formControls['hospitalization'].get('ptlStatus').setValue(this.claimViewModel.ClaimModel.PTL_Status) |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:701 | // this.formControls['hospitalization'].get('ptlStatus').setValue(this.claimViewModel.ClaimModel.PTL_Status) |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:703 | /UBClaim/GetallDropdowns |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:715 | this.ptlSubscription = this.formControls['hospitalization'].get('ptlStatus').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:716 | if (this.formControls['hospitalization'].get('ptlStatus').value) { |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:717 | this.formControls['hospitalization'].get('ptlReason').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:718 | this.formControls['hospitalization'].get('ptlReason').updateValueAndValidity({ onlySelf: true, emitEvent: false }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:721 | this.formControls['hospitalization'].get('ptlReason').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:722 | this.formControls['hospitalization'].get('ptlReason').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:723 | this.formControls['hospitalization'].get('ptlReason').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:733 | this.facilitySubscription = this.formControls['hospitalization'].get('facility').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:734 | if (!Common.isNullOrEmpty(this.claimViewModel.ClaimModel.Facility_Code) && !Common.isNullOrEmpty(this.formControls['hospitalization'].get('facility').value)) { |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:735 | this.formControls['hospitalization'].get('Hospital_From').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:736 | this.formControls['hospitalization'].get('Hospital_From').updateValueAndValidity({ onlySelf: true, emitEvent: false }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:738 | this.formControls['hospitalization'].get('Hospital_From').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:739 | this.formControls['hospitalization'].get('Hospital_From').updateValueAndValidity({ onlySelf: true, emitEvent: false }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:740 | this.formControls['hospitalization'].get('Hospital_From').reset() |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:767 | // this.claimForm.get('hospitalization.Hospital_From').setValue(this.claimViewModel.ClaimModel.Hospital_From); |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:841 | /Demographic/GetClaimModel?PatientAccount= |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1387 | /Demographic/GetModifiers |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1396 | /Demographic/GetstateList |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1558 | /Demographic/GetPAByAccount?aCCOUNT_NO= |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1566 | /Demographic/GetClaimModel?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1709 | let formDos = this.claimForm.get('dos') |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1710 | this.claimForm.get('main.dos').setValue(null) |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1711 | formDos = this.claimForm.get('dos') |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1713 | //       this.claimForm.get('dos').setValue({ month: null, day: null ,year: null}); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1714 | //                       this.claimForm.get('dos').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1715 | //                       this.claimForm.get('dos').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1716 | //                       this.claimForm.get('dos').setValue(''); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1718 | // this.claimForm.get('dos').setValue({}); |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1901 | /Report/DormantClaimsReports?Claim_no= |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1905 | /Demographic/CheckCollectionStatus?Claim_no= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:2616 | this.claimForm.get('hospitalization.ptlStatus').setValue(false) |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:2620 | this.claimForm.get('hospitalization.ptlStatus').setValue(true) |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3426 | /Setup/GetRevenueCodes?Code= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3812 | this.claimForm.get('main.patientStatus').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3813 | this.claimForm.get('main.priStatus').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3814 | this.claimForm.get('main.secStatus').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3815 | this.claimForm.get('main.othStatus').setValue(null); |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:4096 | /Setup/DuplicateAlternateCodeClaimCharges?AlternateCode= |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:4958 | /Demographic/GetAdmissionType?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5715 | this.formControls['hospitalization'].get('facilityDates').patchValue({ myDateRange: '' }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5724 | this.formControls['correctedClaimGroup'].get('ICN_Number').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5725 | this.formControls['correctedClaimGroup'].get('ICN_Number').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5726 | this.formControls['correctedClaimGroup'].get('RSCode').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5727 | this.formControls['correctedClaimGroup'].get('RSCode').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5731 | this.formControls['correctedClaimGroup'].get('ICN_Number').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5732 | this.formControls['correctedClaimGroup'].get('ICN_Number').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5733 | this.formControls['correctedClaimGroup'].get('RSCode').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5734 | this.formControls['correctedClaimGroup'].get('RSCode').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6213 | //     const control = this.paymentResponsibilityForm.get(controlName); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6224 | const control = this.paymentResponsibilityForm.get(controlName); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6274 | this.paymentResponsibilityForm.get('creditbalance').setValue(this.TotaldueAmt); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6277 | this.paymentResponsibilityForm.get('overpaid').setValue(this.TotaldueAmt); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6280 | const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6281 | const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6300 | this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6301 | this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6327 | this.paymentResponsibilityForm.get('creditbalance').setValue(this.TotaldueAmt); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6328 | this.paymentResponsibilityForm.get('overpaid').setValue('') |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6332 | this.paymentResponsibilityForm.get('overpaid').setValue(this.TotaldueAmt) |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6333 | this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6337 | const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6338 | const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6355 | this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6356 | this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value; |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6387 | /Demographic/GetClaimOverPayment?claimNo= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6400 | this.paymentResponsibilityForm.get('overpaid').setValue(overpaid); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6401 | this.paymentResponsibilityForm.get('creditbalance').setValue(creditBalance); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6408 | this.paymentResponsibilityForm.get('overpaid').setValue(overpaid); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6409 | this.paymentResponsibilityForm.get('creditbalance').setValue(creditBalance); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6687 | this.claimForm.get('main.location').setValue(this.recentClaimDetails.Location_Code); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6688 | this.claimForm.get('main.rendPhy').setValue(this.recentClaimDetails.Attending_Physician); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6689 | this.claimForm.get('main.billPhy').setValue(this.recentClaimDetails.Billing_Physician); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6726 | this.claimForm.get('main.autofill').setValue(true); |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:8037 | /InsuranceSetup/GetRelationsSelectList |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:179 | /Scrubber/GetTableList |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:443 | /Scrubber/GetCustomRuleById/ |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:494 | /Scrubber/GetCustomRuleById/ |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:520 | /Scrubber/GetColumn_Lists_FrontEnd |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:535 | /Scrubber/GetAllCustomEdits |
|  | NPM_UI_BackUp/src/app/directives/noSpace.directive.ts:19 | ).trim().replace(/\s/g, |
|  | NPM_UI_BackUp/src/app/directives/noSpace.directive.ts:25 | ).replace(/\s/g, |
|  | NPM_UI_BackUp/src/app/edisetup/edi-setup-main.component.ts:39 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/edisetup/edi-setup-main.component.ts:61 | /Submission/GenerateBatch_5010_P?practice_id= |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:15 | /Common/commonFileuploaddata |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:16 | /Users/UploadProfilePicture |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:17 | /Common/downloadattachedfile |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:18 | /patientattachments/Attach |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:19 | /patientattachments/UploadFiles |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:20 | /patientattachments/GetAll |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:21 | /patientattachments/GetAttachmentCodeList |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:22 | /ERA/Import |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:23 | /ERA/WeekHistoryOfERA |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:24 | /ClaimsAttachments/Attach |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:25 | /ClaimsAttachments/GetAll |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:26 | /ClaimsAttachments/GetAttachmentCodeList |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:27 | /ERA/ERAImport |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:28 | /ERA/ManualERAFileProcessing |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:29 | /Token/ResetPasswordForOTP |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:30 | /PracticeSetup/ProviderDocFileUpload |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:31 | /PracticeSetup/PracticeDocFileUpload |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:32 | /Credentialing/UploadCredAppDocument |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:33 | /Demographic/UploadImage |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:34 | /CredEDIERASetup/UploadCred_EDIERA_Document |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:35 | /ImportWizard/ExcelImport |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:36 | /ImportWizard/DownloadImportWizardTemplateFile |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:163 | /Company/GetCompanyList |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:225 | /Company/DeleteCompany?CompanyId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:237 | /Company/GetDepartmentList?officeId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:325 | /Company/DeleteDepartment?DepartmentId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:337 | /Company/GetDesignationList |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:372 | /Company/GetOfficeIdFromDept?DeptId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:430 | /Company/DeleteDesignation?DesignationId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:440 | /Company/GetOfficeList?companyId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:503 | /Company/DeleteOffice?OfficeId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:517 | /Company/GetShiftList |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:577 | /Company/DeleteShift?ShiftId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:601 | /Company/GetTeamList?companyId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:708 | /Company/DeleteTeam?TeamId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:758 | /Company/GetCompanyList |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:771 | /Company/GetOfficeList?companyId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:783 | /Company/GetDepartmentList?officeId= |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:425 | this.patientInsurancesControl = this.PatientForm.get('patientInsurance') as FormArray; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:455 | let emailCtrl = this.formControls['contact'].get('email'); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:462 | if (this.formControls['death'].get('deceased').value === false) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:468 | if (this.formControls['guarantor'].get('relationship').value === null \|\| this.formControls['guarantor'].get('relationship').value === undefined \|\| this.formControls['guarantor'].get('relationship').value.toString() !== '7') { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:469 | this.formControls['guarantor'].get('name').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:470 | this.formControls['guarantor'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:472 | this.formControls['guarantor'].get('name').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:473 | this.formControls['guarantor'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:474 | this.formControls['guarantor'].get('name').setValue(''); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:481 | if (this.formControls['emergency'].get('relationship').value !== null && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:482 | this.formControls['emergency'].get('relationship').value === '7') { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:484 | this.formControls['emergency'].get('name').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:485 | this.formControls['emergency'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:486 | this.formControls['emergency'].get('phone').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:487 | this.formControls['emergency'].get('phone').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:488 | this.formControls['emergency'].get('relationship').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:489 | this.formControls['emergency'].get('relationship').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:490 | this.formControls['emergency'].get('name').setValue(null); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:491 | this.formControls['emergency'].get('phone').setValue(null); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:492 | } else if (this.formControls['emergency'].get('relationship').value !== null && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:493 | this.formControls['emergency'].get('relationship').value !== '7') { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:495 | this.formControls['emergency'].get('name').setValidators([Validators.required, Validators.maxLength(100)]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:496 | this.formControls['emergency'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:497 | this.formControls['emergency'].get('relationship').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:498 | this.formControls['emergency'].get('relationship').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:499 | this.formControls['emergency'].get('phone').setValidators([Validators.required, Validators.minLength(10), Validators.maxLength(10)]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:500 | this.formControls['emergency'].get('phone').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:501 | } else if (!Common.isNullOrEmpty(this.formControls['emergency'].get('phone').value) \|\| |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:502 | !Common.isNullOrEmpty(this.formControls['emergency'].get('name').value)) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:504 | this.formControls['emergency'].get('name').setValidators([Validators.required, Validators.maxLength(100)]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:505 | this.formControls['emergency'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:506 | this.formControls['emergency'].get('relationship').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:507 | this.formControls['emergency'].get('relationship').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:508 | this.formControls['emergency'].get('phone').setValidators([Validators.required, Validators.minLength(10), Validators.maxLength(10)]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:509 | this.formControls['emergency'].get('phone').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:512 | this.formControls['emergency'].get('name').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:513 | this.formControls['emergency'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:514 | this.formControls['emergency'].get('phone').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:515 | this.formControls['emergency'].get('phone').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:516 | this.formControls['emergency'].get('relationship').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:517 | this.formControls['emergency'].get('relationship').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:524 | this.generalLastNameSub = this.PatientForm.controls['general'].get('lastName').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:529 | this.generalFirstNameSub = this.PatientForm.controls['general'].get('firstName').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:534 | this.generalDobSub = this.PatientForm.controls['general'].get('dob').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:548 | return !(this.formControls['general'].get('firstName').valid && this.formControls['general'].get('lastName').valid && (!this.emergencyGroupRequired \|\| (this.emergencyGroupRequired && this.formControls['emergency'].valid)) && valid); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:554 | this.formControls['contact'].get('email').disable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:556 | this.formControls['contact'].get('email').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:557 | this.formControls['contact'].get('email').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:560 | this.formControls['contact'].get('email').enable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:562 | this.formControls['contact'].get('email').setValidators([Validators.email, Validators.maxLength(256), Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:563 | this.formControls['contact'].get('email').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:570 | this.formControls['death'].get('deceasedDate').enable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:571 | this.formControls['death'].get('deceasedDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:572 | this.formControls['death'].get('deceasedDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:577 | this.formControls['death'].get('deceasedDate').disable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:578 | this.formControls['death'].get('deceasedDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:579 | this.formControls['death'].get('deceasedDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:587 | this.formControls['patientbilling'].get('patientbillingDate').enable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:588 | this.formControls['patientbilling'].get('patientbillingDate'); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:589 | this.formControls['patientbilling'].get('patientbillingDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:594 | this.formControls['patientbilling'].get('patientbillingDate').disable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:595 | this.formControls['patientbilling'].get('patientbillingDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:596 | this.formControls['patientbilling'].get('patientbillingDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:602 | if (this.formControls['contact'].get('email').value) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:603 | this.formControls['contact'].get('emailNotAvailable').setValue(false); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:604 | this.formControls['contact'].get('emailNotAvailable').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:606 | if (this.formControls['contact'].get('emailNotAvailable').value) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:607 | this.formControls['contact'].get('email').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:608 | this.formControls['contact'].get('email').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:611 | this.formControls['contact'].get('email').setValidators([Validators.email, Validators.maxLength(256), Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:612 | this.formControls['contact'].get('email').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:623 | // this.emailNotAvailableSub = this.formControls['contact'].get('emailNotAvailable').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:628 | // this.emailSub = this.formControls['contact'].get('email').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:634 | this.emergencyNameSub = this.formControls['emergency'].get('name').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:639 | this.emergencyRelationshipSub = this.formControls['emergency'].get('relationship').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:644 | this.emergencyPhoneSub = this.formControls['emergency'].get('phone').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:652 | this.deathDeceasedSub = this.formControls['death'].get('deceased').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:660 | this.formControls['guarantor'].get('relationship').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:678 | if (this.formControls['general'].get('lastName').valid && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:679 | this.formControls['general'].get('firstName').valid && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:680 | this.formControls['general'].get('dob').valid && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:681 | this.formControls['contact'].get('zip').valid) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:685 | FirstName: this.formControls['general'].get('firstName').value, |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:686 | LastName: this.formControls['general'].get('lastName').value, |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:687 | zip: this.formControls['contact'].get('zip').value, |
|  | NPM_UI_BackUp/src/app/patient/patient.component.ts:707 | /Demographic/GetCitiesByZipCode?ZipCode= |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:787 | this.PatientForm.get('dob').setValue(event.formatted); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:788 | this.PatientForm.get('dob').markAsTouched(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:789 | this.PatientForm.get('dob').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:793 | this.formControls['death'].get('deceasedDate').setValue(null); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:794 | this.formControls['death'].get('deceasedDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:795 | this.formControls['death'].get('deceasedDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:799 | this.formControls['death'].get('deceasedDate').setValue(this.patient.DeathDate); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:800 | this.formControls['death'].get('deceasedDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:810 | this.formControls['patientbilling'].get('patientbillingDate').setValue(null); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:811 | this.formControls['patientbilling'].get('patientbillingDate'); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:812 | this.formControls['patientbilling'].get('patientbillingDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:816 | this.formControls['patientbilling'].get('patientbillingDate').setValue(this.patient.Hold_pt_until); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:817 | this.formControls['patientbilling'].get('patientbillingDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:995 | this.patient.PatientInsuranceList[i].PayerDescription = group.get('payerDescription').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:996 | this.patient.PatientInsuranceList[i].Pri_Sec_Oth_Type = group.get('insuranceMode').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:997 | this.patient.PatientInsuranceList[i].Policy_Number = group.get('policyNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:998 | if(group.get('IS_Active').value==true){ |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1082 | this.patient.PatientInsuranceList[i].PayerDescription = group.get('payerDescription').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1083 | this.patient.PatientInsuranceList[i].Pri_Sec_Oth_Type = group.get('insuranceMode').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1084 | this.patient.PatientInsuranceList[i].Policy_Number = group.get('policyNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1085 | if(group.get('IS_Active').value==true){ |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1124 | this.patient.PatientInsuranceList[i].PayerDescription = group.get('payerDescription').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1125 | this.patient.PatientInsuranceList[i].Pri_Sec_Oth_Type = group.get('insuranceMode').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1126 | this.patient.PatientInsuranceList[i].Policy_Number = group.get('policyNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1127 | this.patient.PatientInsuranceList[i].Co_Payment = group.get('coPay').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1128 | this.patient.PatientInsuranceList[i].Deductions = group.get('deDuctible').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1129 | this.patient.PatientInsuranceList[i].Co_Payment_Per = group.get('coPaymentPer').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1130 | this.patient.PatientInsuranceList[i].CCN = group.get('ccn').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1131 | this.patient.PatientInsuranceList[i].Group_Number = group.get('groupNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1132 | this.patient.PatientInsuranceList[i].Group_Name = group.get('groupName').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1133 | this.patient.PatientInsuranceList[i].Relationship = group.get('relation').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1134 | this.patient.PatientInsuranceList[i].Access_Carolina_Number = group.get('accCarolinaNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1135 | this.patient.PatientInsuranceList[i].Is_Capitated_Patient = group.get('isCapitated').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1136 | if(group.get('IS_Active').value==true){ |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1161 | // this.PatientForm.get('image').patchValue({profilePic:null |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1294 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').setValue(guarantorName); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1295 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('relation').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1296 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('relation').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1388 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('payerDescription').setValue(Inspayer_Description); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1443 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(index).get('subscriberName').setValue(''); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1446 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1447 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1448 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').disable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1451 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1452 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1453 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').enable(); |
|  | NPM_UI_BackUp/src/app/patient/patient.component.ts:1473 | /Demographic/GetPatient?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1487 | // this.PatientForm.get('additional').patchValue({provider: this.patient.Provider_Code |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1498 | this.formControls['guarantor'].get('name').setValue(this.patient.Financial_Guarantor_Name); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1530 | this.PatientForm.get(['contact', 'email'])[this.patient.emailnotonfile == true ? 'disable' : 'enable'](); |
|  | NPM_UI_BackUp/src/app/patient/patient.component.ts:1543 | /Demographic/GetImage?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/ticket-tracker/ticket-tracker.component.ts:175 | const control = this.SearchForm.get('Patient_Account'); |
|  | NPM_UI_BackUp/src/app/ticket-tracker/ticket-tracker.component.ts:187 | /UserManagementSetup/GetUsersList |
|  | NPM_UI_BackUp/src/app/ticket-tracker/ticket-tracker.component.ts:205 | /TicketTracker/GetTTDepartmentsList |
| GET | NPM_UI_BackUp/src/app/validators/password.validator.ts:4 | let password = group.get('password').value; |
| GET | NPM_UI_BackUp/src/app/validators/password.validator.ts:5 | let confirmPassword = group.get('confirmPassword').value; |
| GET | NPM_UI_BackUp/src/app/validators/password.validator.ts:7 | group.get('confirmPassword').setErrors({ MatchPassword: true }); |
|  | NPM_UI_BackUp/src/app/appointment-scheduler/scheduler/scheduler.component.ts:1269 | /scheduler/CheckDeceasedPatient?PatAccount= |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:120 | this.claimsForm1.get('type').setValue('electronic'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:125 | //         this.claimsForm.get('type').setValue('all'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:129 | //       this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:133 | //       this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:136 | this.submissionType = this.claimsForm1.get('type').value; |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:140 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:146 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:152 | this.claimsForm.get('type').setValue('all'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:158 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:164 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:170 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:176 | this.claimsForm.get('type').setValue('professional'); |
|  | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:377 | /Submission/GetBatcheDetalis?batchId= |
|  | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:466 | /Submission/GetCSIBatcheDetalis?batchId= |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:79 | //             this.claimsForm.get('type').setValue('all'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:83 | //           this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:87 | //           this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:115 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:121 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:127 | this.claimsForm.get('type').setValue('all'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:133 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:139 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:145 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:151 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:274 | //           this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:278 | //           this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:302 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:308 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:314 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:320 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:326 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:332 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:338 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:730 | (<FormControl>this.batchForm.get('type')).setValue('P', { emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:1547 | (<FormControl>this.batchForm.get('type')).setValue('P', { emitEvent: true }); |
|  | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:1578 | /Submission/View837?batchId= |
|  | NPM_UI_BackUp/src/app/claim-submission/component-scrubber/component-scrubber.component.ts:188 | /Scrubber/GetAllCustomEdits/?Practice_Code= |
|  | NPM_UI_BackUp/src/app/claim-submission/component-scrubber/component-scrubber.component.ts:253 | /Scrubber/CustomEditsStatus/ |
|  | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/claim-rejection/claim-rejection.component.ts:58 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/patient-statement/patient-statement.component.ts:60 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/Claims/Attachments/claim-attachments.component.ts:165 | /ClaimsAttachments/GetAttachmentCodeList |
|  | NPM_UI_BackUp/src/app/Claims/Attachments/claim-attachments.component.ts:178 | /ClaimsAttachments/GetAttachmentCodeList |
| GET | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:43 | this.get(this.autochecknumber); |
|  | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:148 | /Demographic/GetClaimNotes?ClaimNo= |
| GET | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:230 | this.get(this.autochecknumber); |
|  | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:234 | /Demographic/GetClaimNote?ClaimNotesId= |
| GET | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:264 | this.get(2); |
| GET | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:282 | this.get(numCheck); |
|  | NPM_UI_BackUp/src/app/Claims/Diagnosis/diagnosis.component.ts:462 | /Demographic/GetDiagnosis?DiagCode= |
|  | NPM_UI_BackUp/src/app/Claims/Diagnosis/diagnosis.component.ts:645 | /Demographic/GetDiagnosis?DiagCode= |
| GET | NPM_UI_BackUp/src/app/Claims/Diagnosis/diagnosis.component.ts:689 | var that = $(this).clone().get(0); |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:143 | /submission/CheckMedicareClaim?claimId= |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:214 | /Submission/GetBatcheDetalis?batchId= |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:230 | /Submission/GetCSIBatcheDetalis?batchId= |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:291 | /Submission/GetCSIBatcheResponseDetalis?batchId= |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:604 | /InsuranceSetup/GetRelationsSelectList |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:1175 | /Submission/GetCSIBatcheDetalisStatus?claimId= |
|  | NPM_UI_BackUp/src/app/Claims/Payments/payments.component.ts:998 | /Submission/ViewClaimERA?claimno= |
|  | NPM_UI_BackUp/src/app/Claims/ub04/ub04.component.ts:450 | /UBClaim/GetAllCodesData |
| GET | NPM_UI_BackUp/src/app/components/services/api.service.ts:30 | return this.httpClient.get(environment.baseUrl + url, options).pipe( |
| GET | NPM_UI_BackUp/src/app/components/services/api.service.ts:43 | return this.httpClient.get(environment.baseUrl + url, { responseType: 'blob' }).pipe( |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:52 | return this.httpClient.post(environment.baseUrl + url, body, { responseType: 'blob' }).pipe( |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:110 | return this.httpClient.post(environment.baseUrl + url, data).subscribe |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:119 | return this.httpClient.post(environment.baseUrl + url, data, options).subscribe |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:138 | return this.httpClient.post(environment.baseUrl + url, data).subscribe |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:148 | return this.httpClient.post(environment.baseUrl + url, data).subscribe |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:241 | return this.httpClient.post(apiUrl, { ids: rowIds }).pipe( |
| GET | NPM_UI_BackUp/src/app/components/services/api.service.ts:251 | return this.httpClient.get(environment.baseUrl + url, { |
| GET | NPM_UI_BackUp/src/app/core/navbar/navbar.component.ts:208 | this.PasswordResetForm.get('pGroup.userName').setValue(this.loggedInUser.unique_name) |
|  | NPM_UI_BackUp/src/app/core/navbar/navbar.component.ts:485 | /Alert/GetLoginAlert |
|  | NPM_UI_BackUp/src/app/credentialing/cred-portal/cred-portal.component.ts:108 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/credentialing/cred-tasks/cred-tasks.component.ts:77 | /Credentialing/GetLookupLists |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:98 | const id = Number(this.route.snapshot.paramMap.get('id')); |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:136 | /Credentialing/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:263 | /PracticeSetup/GetPracticeWithActiveProviders?PracticeId= |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:629 | /UserManagementSetup/GetUsersList |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:1105 | /PracticeSetup/GetPracticeWithActiveProviders?PracticeId= |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments/cred-app-attachments.component.ts:70 | this.form.get('ApplicationId').setValue(this.ApplicationId) |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments/cred-app-attachments.component.ts:194 | if (!this.form.get("DocTypeId").value) { |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments/cred-app-attachments.component.ts:199 | const docTypeId = this.form.get("DocTypeId").value; |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments/cred-app-attachments.component.ts:373 | /Credentialing/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-list/cred-app-list.component.ts:181 | /Credentialing/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-list/cred-app-list.component.ts:191 | /PracticeSetup/GetPracticeWithActiveProviders?PracticeId= |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component.ts:109 | const id = Number(this.route.snapshot.paramMap.get('id')); |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component.ts:150 | /CredEDIERASetup/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component.ts:263 | /PracticeSetup/GetPractice?PracticeId= |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component.ts:520 | /UserManagementSetup/GetUsersList |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component.ts:71 | this.form.get('ApplicationId').setValue(this.ApplicationId) |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component.ts:189 | if (!this.form.get("DocTypeId").value) { |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component.ts:194 | const docTypeId = this.form.get("DocTypeId").value; |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component.ts:343 | /CredEDIERASetup/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-list/cred-edi-era-app-list.component.ts:168 | /CredEDIERASetup/GetLookupLists |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-app-report/cred-app-report.component.ts:161 | //     const payer = payerMap.get(key); |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-app-report/cred-app-report.component.ts:256 | const payer = payerMap.get(key); |
|  | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:64 | /PracticeSetup/GetPractice?PracticeId= |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:348 | payerCount.set(r.Payer_Name, (payerCount.get(r.Payer_Name) \|\| 0) + 1); |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:361 | const start = payerStart.get(payer)!; |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:362 | const count = payerCount.get(payer)!; |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:363 | const serial = payerSerial.get(payer)!; |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:567 | //     const payer = payerMap.get(key); |
|  | NPM_UI_BackUp/src/app/credentialing/cred-reports/edi-era-eft-grid-report/edi-era-eft-grid-report.component.ts:54 | /PracticeSetup/GetPractice?PracticeId= |
|  | NPM_UI_BackUp/src/app/credentialing/cred-reports/edi-era-eft-grid-report/edi-era-eft-grid-report.component.ts:74 | /CredEDIERASetup/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-reports/hospital-grid-report/hospital-grid-report.component.ts:66 | /PracticeSetup/GetPractice?PracticeId= |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:245 | this.searchForm.get('ClaimIds').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:250 | this.searchForm.get('claimValue').valueChanges.subscribe((selectedClaimId: string) => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:255 | this.searchForm.get('claimValue').valueChanges.subscribe((claimID) => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:268 | this.searchForm.get('claimValue').valueChanges.subscribe(claimId => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:270 | this.searchForm.get('ClaimId').setValue(claimId); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:295 | this.patientInfo = this.searchForm.get('selected_Patient').value, |
|  | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:308 | /Demographic/GetClaimModel?PatientAccount= |
|  | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:354 | /Demographic/GetClaimModel?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:966 | this.searchForm.get('selected_Patient').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:967 | this.searchForm.get('claimValue').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1045 | this.searchForm.get('selected_Patient').setValue(this.selectedPatient);  // Set value manually |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1259 | this.searchForm.get('selected_Patient').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1260 | this.searchForm.get('claimValue').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1261 | this.searchForm.get('ClaimIds').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1289 | const accountControl = this.searchForm.get('patientAccount'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1290 | const claimControl = this.searchForm.get('claimValue'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1426 | this.getClaimsByPatient(this.searchForm.get('selected_Patient').value) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1432 | const claimInput = this.searchForm.get('ClaimIds'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1441 | const claimDropdown = this.searchForm.get('claimValue'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2702 | Patient_Account: this.searchForm.get('selected_Patient').value, |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2715 | Patient_Account: this.searchForm.get('selected_Patient').value, |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2914 | this.paymentResponsibilityForm.get('creditbalance').setValue(this.TotaldueAmt); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2915 | this.paymentResponsibilityForm.get('overpaid').setValue('') |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2919 | this.paymentResponsibilityForm.get('overpaid').setValue(this.TotaldueAmt) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2920 | this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2924 | const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2925 | const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2955 | this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2956 | this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3476 | //             this.paymentResponsibilityForm.get('creditbalance').setValue(this.ClaimDueAmt); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3477 | //             this.paymentResponsibilityForm.get('overpaid').setValue('') |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3481 | //             this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3482 | //             this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3486 | //             const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3487 | //             const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3721 | this.paymentResponsibilityForm.get('creditbalance').setValue(this.ClaimDueAmt); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3722 | this.paymentResponsibilityForm.get('overpaid').setValue('') |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3726 | this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3727 | this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3731 | const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3732 | const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4058 | //           this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4059 | //           this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4063 | //           const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4064 | //           const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4208 | this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4209 | this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4364 | const control = this.paymentResponsibilityForm.get(controlName); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:273 | this.batchPaymentForm.get('paymentType').valueChanges.subscribe(value => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:274 | const checkNoControl = this.batchPaymentForm.get('checkNo'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:275 | const checkDateControl = this.batchPaymentForm.get('checkDate'); |
|  | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:361 | /UserManagementSetup/GetUsersList |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:419 | const paymentType = this.batchPaymentForm.get('paymentType').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:423 | this.batchPaymentForm.get('checkNo').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:424 | this.batchPaymentForm.get('checkDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:426 | this.batchPaymentForm.get('checkNo').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:427 | this.batchPaymentForm.get('checkDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:431 | this.batchPaymentForm.get('depositDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:434 | this.batchPaymentForm.get('depositDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:438 | this.batchPaymentForm.get('checkNo').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:439 | this.batchPaymentForm.get('checkDate').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:440 | this.batchPaymentForm.get('depositDate').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:483 | if (control !== 'batchDate') this.batchPaymentForm.get(control).disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:496 | if (control !== 'batchDate') this.batchPaymentForm.get(control).enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:668 | this.batchPaymentForm.get('batchDate').setValue(batchDateValue); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:671 | this.batchPaymentForm.get(field).enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:675 | this.batchPaymentForm.get('paymentType').valueChanges.subscribe((value: string) => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:677 | this.batchPaymentForm.get('batchType').setValue('I'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:678 | this.batchPaymentForm.get('batchType').disable(); // Lock it |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:680 | this.batchPaymentForm.get('batchType').enable(); // Unlock for others |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:771 | // const batchId = this.batchPaymentForm.get('batchId').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1060 | const batchID = this.searchBatchForm.get('BatchID').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1128 | const batchID = this.searchBatchForm.get('BatchID').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1193 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1215 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1216 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1217 | this.batchPaymentForm.get('checkDate').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1218 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1227 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1228 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1229 | this.batchPaymentForm.get('checkDate').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1230 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1247 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1248 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1249 | const paymentType = this.batchPaymentForm.get('paymentType').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1251 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1252 | this.batchPaymentForm.get('checkDate').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1255 | this.batchPaymentForm.get('batchType').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1256 | this.batchPaymentForm.get('paymentType').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1257 | this.batchPaymentForm.get('checkNo').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1258 | this.batchPaymentForm.get('checkDate').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1501 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1502 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1503 | const paymentType = this.batchPaymentForm.get('paymentType').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1506 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1507 | this.batchPaymentForm.get('CheckDate').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1511 | this.batchPaymentForm.get('batchType').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1512 | this.batchPaymentForm.get('paymentType').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1513 | this.batchPaymentForm.get('checkNo').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1514 | this.batchPaymentForm.get('CheckDate').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1556 | if (this.searchBatchForm && this.searchBatchForm.get('BatchDateRange')) { |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:925 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:926 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:928 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:944 | this.batchPaymentForm.get(controlName).setValue(event.formatted \|\| ''); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:954 | const paymentType = this.batchPaymentForm.get('paymentType').value; |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:958 | this.batchPaymentForm.get('checkNo').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:959 | this.batchPaymentForm.get('checkDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:961 | this.batchPaymentForm.get('checkNo').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:962 | this.batchPaymentForm.get('checkDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:966 | this.batchPaymentForm.get('depositDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:968 | this.batchPaymentForm.get('depositDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:971 | this.batchPaymentForm.get('checkNo').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:972 | this.batchPaymentForm.get('checkDate').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:973 | this.batchPaymentForm.get('depositDate').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:72 | this.eraSearchRequest.status = queryParamMap.get('status'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:73 | this.eraSearchRequest.practiceCode = Number(queryParamMap.get('practiceCode')); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:74 | this.eraSearchRequest.patientAccount = queryParamMap.get('patientAccount'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:75 | this.eraSearchRequest.icnNo = queryParamMap.get('icnNo'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:76 | this.eraSearchRequest.checkNo = queryParamMap.get('checkNo'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:77 | this.eraSearchRequest.dateTo = queryParamMap.get('dateTo'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:78 | this.eraSearchRequest.dateFrom = queryParamMap.get('dateFrom'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:79 | this.eraSearchRequest.checkAmount = queryParamMap.get('checkAmount'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:80 | this.eraSearchRequest.dateType = queryParamMap.get('dateType'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:86 | this.eraSearchRequest.status = 'All'// queryParamMap.get('status'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:87 | this.eraSearchRequest.practiceCode = Number(queryParamMap.get('practiceCode')); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:88 | this.eraSearchRequest.patientAccount = queryParamMap.get('patientAccount'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:89 | this.eraSearchRequest.icnNo = queryParamMap.get('icnNo'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:90 | this.eraSearchRequest.checkNo = queryParamMap.get('checkNo'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:91 | this.eraSearchRequest.dateTo = queryParamMap.get('dateTo'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:92 | this.eraSearchRequest.dateFrom = queryParamMap.get('dateFrom'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:93 | this.eraSearchRequest.checkAmount = queryParamMap.get('checkAmount'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:94 | this.eraSearchRequest.dateType = queryParamMap.get('dateType'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:101 | //   this.unappliedPaymentForm.get('checkno').setValue(this.checkNo); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:104 | MM/DD/YYYY |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:109 | const idControl = this.unappliedPaymentForm.get('id'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:110 | const checkNoControl = this.unappliedPaymentForm.get('checkno'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:116 | const checkDateControl = this.unappliedPaymentForm.get('checkDate'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:127 | this.unappliedPaymentForm.get('patient_account').valueChanges.subscribe(val => { |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:128 | const dropdown = this.unappliedPaymentForm.get('selected_Patient'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:129 | const accountControl = this.unappliedPaymentForm.get('patient_account'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:148 | this.unappliedPaymentForm.get('selected_Patient').valueChanges.subscribe(val => { |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:149 | const accountControl = this.unappliedPaymentForm.get('patient_account'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:150 | const dropdown = this.unappliedPaymentForm.get('selected_Patient'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:163 | const idControl = this.unappliedPaymentForm.get('id'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:167 | this.unappliedPaymentForm.get('checkno').setValue(this.checkNo); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:169 | this.unappliedPaymentForm.get('checkno').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:173 | this.unappliedPaymentForm.get('checkDate').setValue(this.formatDateForPicker(this.check_date)); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:175 | this.unappliedPaymentForm.get('checkDate').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:180 | const checkNoControl = this.unappliedPaymentForm.get('checkno'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:181 | const checkDateControl = this.unappliedPaymentForm.get('checkDate'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:243 | this.unappliedPaymentForm.get(controlName).setValue(event.formatted); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:246 | this.unappliedPaymentForm.get(controlName).setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:282 | const selected = this.unappliedPaymentForm.get('checkDate').value; |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:283 | const checkDateControl = this.unappliedPaymentForm.get('checkDate'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:292 | checkDateString =  this.unappliedPaymentForm.get('checkDate').value |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:293 | ? this.unappliedPaymentForm.get('checkDate').value.formatted : null |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:301 | Check_No:  this.unappliedPaymentForm.get('checkno').value, |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:303 | Billing_Physician: this.unappliedPaymentForm.get('billing_physician').value, |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:304 | Resource_Physician: this.unappliedPaymentForm.get('resource_physician').value, |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:305 | Location_Code: this.unappliedPaymentForm.get('location').value, |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:307 | MM/DD/YYYY |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:308 | // CheckDate: this.unappliedPaymentForm.get('checkDate').value |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:309 | //   ? (this.unappliedPaymentForm.get('checkDate').value.formatted |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:310 | //       ? this.unappliedPaymentForm.get('checkDate').value.formatted |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:311 | //       : this.unappliedPaymentForm.get('checkDate').value) |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:326 | this.unappliedPaymentForm.get('patient_account').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:327 | this.unappliedPaymentForm.get('selected_Patient').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:328 | this.unappliedPaymentForm.get('amount').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:330 | this.unappliedPaymentForm.get('billing_physician').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:331 | this.unappliedPaymentForm.get('resource_physician').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:332 | this.unappliedPaymentForm.get('location').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:334 | this.unappliedPaymentForm.get('id').setValue(null); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:400 | const checkNoControl = this.unappliedPaymentForm.get('checkno'); |
| GET | NPM_UI_BackUp/src/app/era/unapplied-payments/unapplied-payments.component.ts:408 | const checkDateControl = this.unappliedPaymentForm.get('checkDate'); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:70 | this.selectedId = +this.route.snapshot.paramMap.get('id')!; |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:148 | this.PanelBilling.get('practice').disable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:149 | this.PanelBilling.get('provideId').disable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:150 | this.PanelBilling.get('Location').disable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:151 | this.PanelBilling.get('PanelCode').disable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:155 | this.PanelBilling.get('practice').disable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:156 | this.PanelBilling.get('provideId').disable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:157 | this.PanelBilling.get('Location').disable(); |
|  | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:176 | /Demographic/GetModifiers |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:186 | this.PanelBilling.get('practice').enable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:187 | this.PanelBilling.get('provideId').enable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:188 | this.PanelBilling.get('Location').enable(); |
|  | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:300 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:352 | return this.PanelBilling.get('practice').valid && |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:353 | this.PanelBilling.get('provideId').valid && |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:354 | this.PanelBilling.get('Location').valid && |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:355 | this.PanelBilling.get('PanelCode').valid; |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:494 | this.PanelBilling.get('PanelCode').enable(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:505 | practiceCode: this.PanelBilling.get('practice').value, |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:506 | providerCode: this.PanelBilling.get('provideId').value, |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:507 | locationCode: this.PanelBilling.get('Location').value, |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:508 | panelCode: this.PanelBilling.get('PanelCode').value, |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:509 | Panel_Billing_Code_Id: +this.route.snapshot.paramMap.get('id')!, |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:535 | if (this.PanelBilling.get(field.control).invalid) { |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:538 | this.PanelBilling.get(field.control).markAsTouched(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:710 | const uniquenessCheckResponse: any = await this.API.getData(`/demographic/CheckPanelCodeExists?PracticeCode=${panelBillingData.practiceCode}&ProviderCode=${panelBillingData.providerCode}&LocationCode=${panelBillingData.locationCode}&PanelCode=${panelBillingDat |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:857 | const control = this.PanelBilling.get(field.control); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:886 | practiceCode: this.PanelBilling.get('practice').value, |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:887 | providerCode: this.PanelBilling.get('provideId').value, |
| GET | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code/add-edit-panel-code.component.ts:888 | locationCode: this.PanelBilling.get('Location').value |
|  | NPM_UI_BackUp/src/app/fee-schedule/nobility-cptfee-schedule/nobility-cptfee-schedule.component.ts:25 | /Setup/GetStandardNobilityCPTFeeSchedule?StateCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/nobility-cptfee-schedule/nobility-cptfee-schedule.component.ts:47 | /Setup/GetStatesList |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule/provider-cptfee-schedule.component.ts:71 | /Setup/GetProviderFeeScheduleDD |
| GET | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule/provider-cptfee-schedule.component.ts:106 | if (this.newProviderFeePlanForm.get('standardOrPercentage').value == "Percentage") { |
| GET | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule/provider-cptfee-schedule.component.ts:107 | this.newProviderFeePlanForm.get('percentageHigher').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule/provider-cptfee-schedule.component.ts:108 | this.newProviderFeePlanForm.get('percentageHigher').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule/provider-cptfee-schedule.component.ts:110 | this.newProviderFeePlanForm.get('percentageHigher').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule/provider-cptfee-schedule.component.ts:111 | this.newProviderFeePlanForm.get('percentageHigher').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:79 | /Setup/GetProviderFeeSchedule?PracticeCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:111 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:158 | /Setup/GetProviderPlanDetails?ProviderCPTPlanId= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:205 | /Setup/getpracticeinformationforcptplan?Practicecode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:317 | /Setup/GetRevenueCodes?Code= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:338 | /Setup/GetDescriptionByCPT?ProviderCPTPCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:364 | /Setup/GetByAlternateCode?AlternateCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:389 | /Setup/CheckDuplicateCPT?ProviderCPTCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:403 | /Setup/CheckDuplicateCPT?ProviderCPTCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:441 | /Setup/CheckDuplicateAlternateCode?AlternateCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp/provider-cptfee-schedule-temp.component.ts:581 | /Setup/GetByAlternateCode?AlternateCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/standard-cptfee-schedule/standard-cptfee-schedule.component.ts:26 | /Setup/GetStandardCPTFeeSchedule?StateCode= |
|  | NPM_UI_BackUp/src/app/fee-schedule/standard-cptfee-schedule/standard-cptfee-schedule.component.ts:48 | /Setup/GetStatesList |
| GET | NPM_UI_BackUp/src/app/import-wizard/import-wizard-main/import-wizard-main.component.ts:260 | this.form.get('attachment').reset(); |
|  | NPM_UI_BackUp/src/app/import-wizard/import-wizard-main/import-wizard-main.component.ts:293 | /ImportWizard/GetImportWizard?practicecode= |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:93 | //       this.NpmAlertModelForm.get('ClaimText').clearValidators(); // Clear validators when checkbox is unchecked |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:95 | //       this.NpmAlertModelForm.get('ClaimText').setValidators(Validators.required); // Set validators when checkbox is checked |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:97 | //     this.NpmAlertModelForm.get('ClaimText').updateValueAndValidity(); // Update validation status |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:100 | //     const claimTextControl = this.NpmAlertModelForm.get('ClaimText'); |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:114 | this.NpmAlertModelForm.get('ClaimText').setValue([]); // Reset the value of ClaimText dropdown to an empty array when the Claim checkbox is unchecked |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:115 | this.NpmAlertModelForm.get('ClaimText').clearValidators(); // Clear validators when checkbox is unchecked |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:117 | this.NpmAlertModelForm.get('ClaimText').setValidators(Validators.required); // Set validators when checkbox is checked |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:120 | this.NpmAlertModelForm.get('ClaimText').updateValueAndValidity(); // Update validation status |
| GET | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:365 | if (this.showClaimDropDownField && this.NpmAlertModelForm.get('ClaimText').value.length === 0) { |
|  | NPM_UI_BackUp/src/app/patient/alerts/alert.component.ts:511 | /Alert/GetAlertForPatient?patientaccount= |
|  | NPM_UI_BackUp/src/app/patient/ClaimSummary/claim-summary.component.ts:198 | /demographic/getClaimDetails?Claim_no= |
|  | NPM_UI_BackUp/src/app/patient/ClaimSummary/claim-summary.component.ts:679 | /Alert/GetAlertForPatient?patientaccount= |
|  | NPM_UI_BackUp/src/app/patient/search/patient-search.component.ts:191 | /Demographic/DeletePatient?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/patient/Patient/Notes/notes.component.ts:31 | //this.get(); |
|  | NPM_UI_BackUp/src/app/patient/Patient/Notes/notes.component.ts:57 | /Demographic/GetPatientNote?PatientNotesId= |
|  | NPM_UI_BackUp/src/app/patient/Patient/Notes/notes.component.ts:70 | /Demographic/GetPatientNotes?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/patient/Patient/Notes/notes.component.ts:96 | this.get(); |
|  | NPM_UI_BackUp/src/app/patient/Patient/patient-notes/patient-notes.component.ts:107 | /Demographic/GetPatientNote?PatientNotesId= |
|  | NPM_UI_BackUp/src/app/practice-setup/addeditpractice/add-edit-practice.component.ts:131 | /CredEDIERASetup/GetLookupLists |
| GET | NPM_UI_BackUp/src/app/practice-setup/addeditpractice/add-edit-practice.component.ts:142 | return !this.rForm.get(field).valid && this.rForm.get(field).touched; |
|  | NPM_UI_BackUp/src/app/practice-setup/addeditpractice/add-edit-practice.component.ts:148 | /PracticeSetup/GetPractice?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/addeditpractice/add-edit-practice.component.ts:220 | /Demographic/GetCitiesByZipCode?ZipCode= |
|  | NPM_UI_BackUp/src/app/practice-setup/Facilities/facilities.component.ts:61 | /PracticeSetup/GetPracticeFacilityList?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/Facilities/facilities.component.ts:114 | /Demographic/GetCityState?ZipCode= |
|  | NPM_UI_BackUp/src/app/practice-setup/Facilities/facilities.component.ts:127 | /PracticeSetup/GetPracticeFacility?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/Facilities/facilities.component.ts:154 | /PracticeSetup/DeletePracticeFacility?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/Facilities/facilities.component.ts:178 | /Setup/GetFacility?FacilityId= |
|  | NPM_UI_BackUp/src/app/practice-setup/Locations/locations.component.ts:67 | /PracticeSetup/GetPracticeLocationList?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/Locations/locations.component.ts:126 | /Demographic/GetCityState?ZipCode= |
|  | NPM_UI_BackUp/src/app/practice-setup/Locations/locations.component.ts:193 | /PracticeSetup/GetPracticeLocation?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/Locations/locations.component.ts:232 | /PracticeSetup/DeletePracticeLocation?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceList/practice-list.component.ts:47 | /PracticeSetup/GetPracticesByUserRights |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceList/practice-list.component.ts:113 | /PracticeSetup/ActivateInActivePractice?practiceId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:251 | /PracticeSetup/GetPracticeNotesList?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:259 | /PracticeSetup/GetPractice?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:280 | /PracticeSetup/GetSpecialInstructionList?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:350 | /PracticeSetup/GetSpecialInstructionQuestionByCategory?CategoryId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:403 | /PracticeSetup/DeleteSpecialInstruction?QuestionId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:452 | /PracticeSetup/GetPracticeNotesList?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:481 | /PracticeSetup/DeletePracticetNote?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:493 | /PracticeSetup/GetPracticeNote?PracticeNotesId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:512 | /PracticeSetup/GetPracticeNotesList?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:528 | /PracticeSetup/GetPracticeLocationList?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:550 | /PracticeSetup/GetProviderWorkingHours?ProviderId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:574 | /PracticeSetup/GetProviderPayers?ProviderId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:593 | /PracticeSetup/GetPracticePayers?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:619 | /PracticeSetup/GetPracticeLocationList?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:672 | /PracticeSetup/GetProviderNotesList?providerId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:689 | /PracticeSetup/DeleteProviderNote?ProviderId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:700 | /PracticeSetup/GetProviderNote?providerNoteId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:718 | /PracticeSetup/GetProviderResources?ProviderId= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:950 | /PracticeSetup/GetActiveUsersForPractice?practiceCode= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:971 | /PracticeSetup/GetDivisionForUser |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:986 | /PracticeSetup/GetActiveUsersForPractice?practiceCode= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:1011 | /PracticeSetup/GetDivisionForUser |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:1033 | /PracticeSetup/GetReportingDetailOfPracticeUser?userID= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:1078 | /PracticeSetup/GetPracticeSoftware?PracticeCode= |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:1199 | /UserManagementSetup/GetUsersList |
|  | NPM_UI_BackUp/src/app/practice-setup/practiceTAB/practice-tab.component.ts:1437 | /PracticeSetup/GetPracticeDocTypeList |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:137 | /PracticeSetup/GetProviders?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:159 | /PracticeSetup/GetSpecilization |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:170 | /PracticeSetup/GetWCBRating |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:235 | /Demographic/GetCitiesByZipCode?ZipCode= |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:319 | /PracticeSetup/ActivateInActiveProvider?providerId= |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:328 | /PracticeSetup/TaxonomyCode?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:341 | /PracticeSetup/NPICode?PracticeId= |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:371 | /PracticeSetup/GetProvider?providerId= |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:699 | /PracticeSetup/GetProviderDocTypeList |
|  | NPM_UI_BackUp/src/app/practice-setup/providers/providers.component.ts:724 | /PracticeSetup/GetProviderStateList |
|  | NPM_UI_BackUp/src/app/reports/account-assignmentreport/account-assignmentreport.component.ts:100 | /Report/AccounAssignmentReport?practiceCode= |
|  | NPM_UI_BackUp/src/app/reports/account-assignmentreport/account-assignmentreport.component.ts:162 | /Report/AccounAssignmentReportPagination?practiceCode= |
|  | NPM_UI_BackUp/src/app/reports/account-assignmentreport/account-assignmentreport.component.ts:234 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/aging-summary-patient-wise/aging-summary-patient-wise.component.ts:40 | /Report/AgingSummaryPatientAnalysisReport?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/aging-summary-patient-wise/aging-summary-patient-wise.component.ts:51 | MM/DD/YYYY |
|  | NPM_UI_BackUp/src/app/reports/aging-summary-patient-wise/aging-summary-patient-wise.component.ts:65 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/aging-summary-report/aging-summary-report.component.ts:41 | /Report/AgingSummaryAnalysisReport?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/aging-summary-report/aging-summary-report.component.ts:68 | MM/DD/YYYY |
|  | NPM_UI_BackUp/src/app/reports/aging-summary-report/aging-summary-report.component.ts:73 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/appointment-detail/appointment-detail.component.ts:63 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/appointment-detail/appointment-detail.component.ts:83 | /Report/AppointmentDetailReport?PracticeCode= |
| GET | NPM_UI_BackUp/src/app/reports/batch-payment-report/batch-payment-report.component.ts:76 | MM/DD/YYYY |
| GET | NPM_UI_BackUp/src/app/reports/batch-payment-report/batch-payment-report.component.ts:77 | MM/DD/YYYY |
|  | NPM_UI_BackUp/src/app/reports/batch-payment-report/batch-payment-report.component.ts:81 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/batch-payment-report/batch-payment-report.component.ts:99 | /UserManagementSetup/GetUsersList |
|  | NPM_UI_BackUp/src/app/reports/charges-break-down-report/charges-break-down-report.component.ts:51 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/claim-assignmentreport/claim-assignmentreport.component.ts:84 | /Report/ClaimAssignmentReport?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/claim-assignmentreport/claim-assignmentreport.component.ts:145 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/claim-submission-report/claim-submission-report.component.ts:94 | let practiceCode=this.SearchForm.get('PracCode').value |
| GET | NPM_UI_BackUp/src/app/reports/claim-submission-report/claim-submission-report.component.ts:152 | let practiceCode=this.SearchForm.get('PracCode').value |
| GET | NPM_UI_BackUp/src/app/reports/claim-submission-report/claim-submission-report.component.ts:202 | let practiceCode=this.SearchForm.get('PracCode').value |
|  | NPM_UI_BackUp/src/app/reports/claim-submission-report/claim-submission-report.component.ts:242 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/collection-analysis-report/collection-analysis-report.component.ts:244 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/credit-balance-report/credit-balance-report.component.ts:49 | /Setup/GetEshaPracticeList |
|  | NPM_UI_BackUp/src/app/reports/denial-report/denial-report.component.ts:102 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/denial-report/denial-report.component.ts:137 | let practiceCode=this.SearchForm.get('PracCode').value |
|  | NPM_UI_BackUp/src/app/reports/denial-report/denial-report.component.ts:142 | /Report/DenialReportDetailPagination?PracticeCode= |
| GET | NPM_UI_BackUp/src/app/reports/denial-report/denial-report.component.ts:163 | let practiceCode=this.SearchForm.get('PracCode').value |
|  | NPM_UI_BackUp/src/app/reports/denial-report/denial-report.component.ts:168 | /Report/DenialReportDetail?PracticeCode= |
| GET | NPM_UI_BackUp/src/app/reports/denial-report/denial-report.component.ts:184 | let practiceCode=this.SearchForm.get('PracCode').value |
| GET | NPM_UI_BackUp/src/app/reports/denial-report/denial-report.component.ts:207 | let practiceCode=this.SearchForm.get('PracCode').value |
|  | NPM_UI_BackUp/src/app/reports/esha-patient-aging-report/esha-patient-aging-report.component.ts:49 | /Setup/GetEshaPracticeList |
|  | NPM_UI_BackUp/src/app/reports/esha-plan-aging-report/esha-plan-aging-report.component.ts:49 | /Setup/GetEshaPracticeList |
|  | NPM_UI_BackUp/src/app/reports/financial-summary-cptwise/financial-summary-cptwise.component.ts:77 | /Report/FinancialAnalysisCPTLevelReport?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/financial-summary-cptwise/financial-summary-cptwise.component.ts:107 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/financial-summary-provider-wise/financial-summary-provider-wise.component.ts:76 | /Report/FinancialAnalysisByProviderandProcCodesReport?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/financial-summary-provider-wise/financial-summary-provider-wise.component.ts:106 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/holdclaims/holdclaims.component.ts:57 | /Report/holdReport?practiceCode= |
|  | NPM_UI_BackUp/src/app/reports/holdclaims/holdclaims.component.ts:94 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/holdclaims/holdclaims.component.ts:128 | // this.CPDForm.value.PracCode=this.CPDForm.get('PracCode').value |
| GET | NPM_UI_BackUp/src/app/reports/negative-balance-report/negative-balance-report.component.ts:55 | MM/DD/YYYY |
| GET | NPM_UI_BackUp/src/app/reports/negative-balance-report/negative-balance-report.component.ts:56 | MM/DD/YYYY |
|  | NPM_UI_BackUp/src/app/reports/negative-balance-report/negative-balance-report.component.ts:70 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/patient-aging-analysis/patient-aging-analysis.component.ts:278 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/patient-aging-report/patient-aging-report.component.ts:301 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/patient-birth-days/patient-birth-days.component.ts:78 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/patient-birth-days/patient-birth-days.component.ts:120 | let practicecodewithname=this.form.get('practiceCode').value |
| GET | NPM_UI_BackUp/src/app/reports/patient-birth-days/patient-birth-days.component.ts:121 | let practiceCode= this.form.get('practiceCode').value |
|  | NPM_UI_BackUp/src/app/reports/patient-statement-report/patient-statement-report.component.ts:310 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/payment-detail/payment-detail.component.ts:106 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/payment-detail/payment-detail.component.ts:142 | /Report/PaymentDetail?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/payment-detail/payment-detail.component.ts:192 | /Report/PaymentDetailPagination?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/pending-batch-report/pending-batch-report.component.ts:58 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/pending-batch-report/pending-batch-report.component.ts:74 | /Submission/Get999Report?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/pending-batch-report/pending-batch-report.component.ts:88 | MM/DD/YYYY |
|  | NPM_UI_BackUp/src/app/reports/practice-analysis/practice-analysis.component.ts:45 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/practice-analysis/practice-analysis.component.ts:77 | let practicecodewithname=this.form.get('practiceCode').value |
| GET | NPM_UI_BackUp/src/app/reports/practice-analysis/practice-analysis.component.ts:78 | let practiceCode= this.form.get('practiceCode').value |
|  | NPM_UI_BackUp/src/app/reports/practice-analysis-by-provider/practice-analysis-by-provider.component.ts:44 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/practice-analysis-by-provider/practice-analysis-by-provider.component.ts:74 | let practicecodewithname=this.form.get('practiceCode').value |
| GET | NPM_UI_BackUp/src/app/reports/practice-analysis-by-provider/practice-analysis-by-provider.component.ts:75 | let practiceCode= this.form.get('practiceCode').value |
|  | NPM_UI_BackUp/src/app/reports/recall-visits/recall-visits.component.ts:43 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/rollingsummaryreport/rollingsummaryreport.component.ts:42 | let practiceCode= this.CPDForm.get('PracCode').value |
| GET | NPM_UI_BackUp/src/app/reports/rollingsummaryreport/rollingsummaryreport.component.ts:66 | let practiceCode= this.CPDForm.get('PracCode').value |
|  | NPM_UI_BackUp/src/app/reports/rollingsummaryreport/rollingsummaryreport.component.ts:72 | /Report/GetRollingSummaryReport?PracCode= |
|  | NPM_UI_BackUp/src/app/reports/rollingsummaryreport/rollingsummaryreport.component.ts:148 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/scrubber-rejection-report/scrubber-rejection-report.component.ts:86 | let practiceCode=this.SearchForm.get('PracCode').value |
|  | NPM_UI_BackUp/src/app/reports/scrubber-rejection-report/scrubber-rejection-report.component.ts:257 | /Setup/GetPracticeList |
| GET | NPM_UI_BackUp/src/app/reports/unapplied-payment-report/unapplied-payment-report.component.ts:79 | MM/DD/YYYY |
| GET | NPM_UI_BackUp/src/app/reports/unapplied-payment-report/unapplied-payment-report.component.ts:80 | MM/DD/YYYY |
|  | NPM_UI_BackUp/src/app/reports/unapplied-payment-report/unapplied-payment-report.component.ts:84 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/unapplied-payment-report/unapplied-payment-report.component.ts:102 | /UserManagementSetup/GetPostingUnappliedPaymentUsersList |
|  | NPM_UI_BackUp/src/app/reports/unposted-adjustment-report/unposted-adjustment-report.component.ts:74 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/unposted-adjustment-report/unposted-adjustment-report.component.ts:107 | /Report/ERAUnpostedAdjReport?practiceCode= |
|  | NPM_UI_BackUp/src/app/reports/unposted-adjustment-report/unposted-adjustment-report.component.ts:124 | MM/DD/YYYY |
|  | NPM_UI_BackUp/src/app/reports/user-report/user-report.component.ts:100 | /Report/GetUserReport?PracCode= |
|  | NPM_UI_BackUp/src/app/reports/user-report/user-report.component.ts:131 | /Report/GetUserReportPagination?PracCode= |
|  | NPM_UI_BackUp/src/app/reports/user-report/user-report.component.ts:160 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/user-report/user-report.component.ts:185 | /Setup/GetuserList?pracCode= |
|  | NPM_UI_BackUp/src/app/reports/visit-claim-activity-report/visit-claim-activity-report.component.ts:60 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/claim-payment-report/claim-payment-report/claim-payment-report.component.ts:68 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/ctp-wise-payment-details/ctp-wise-payment-details/ctp-wise-payment-details.component.ts:86 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/ctp-wise-payment-details/ctp-wise-payment-details/ctp-wise-payment-details.component.ts:122 | /Report/CPTWisePaymentDetail?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/ctp-wise-payment-details/ctp-wise-payment-details/ctp-wise-payment-details.component.ts:175 | /Report/CPTWisePaymentDetailPagination?PracticeCode= |
|  | NPM_UI_BackUp/src/app/reports/Insurance-Detail-Report/insurance-detail-report/insurance-detail-report.component.ts:98 | /Report/GetInsuranceDetailReport?PracCode= |
|  | NPM_UI_BackUp/src/app/reports/Insurance-Detail-Report/insurance-detail-report/insurance-detail-report.component.ts:150 | /Report/GetInsuranceDetailReportPagination?PracCode= |
|  | NPM_UI_BackUp/src/app/reports/Insurance-Detail-Report/insurance-detail-report/insurance-detail-report.component.ts:200 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/missing-appointment-detail/missing-appointment-detail/missing-appointment-detail.component.ts:62 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/reports/missing-appointment-detail/missing-appointment-detail/missing-appointment-detail.component.ts:82 | /Report/MissingAppointmentDetailReport?PracticeCode= |
|  | NPM_UI_BackUp/src/app/services/auth/auth.service.ts:113 | /Token/Logout |
|  | NPM_UI_BackUp/src/app/services/auth/auth.service.ts:252 | /Token/VerifyForgotPasswordOtp |
|  | NPM_UI_BackUp/src/app/services/auth/auth.service.ts:256 | /Token/ResendForgotPasswordOtp |
|  | NPM_UI_BackUp/src/app/services/auth/auth.service.ts:261 | /Token/UpdatePassword |
|  | NPM_UI_BackUp/src/app/services/data/Alert.service.ts:30 | /Alert/GetAlertForPatient?patientaccount= |
|  | NPM_UI_BackUp/src/app/services/data/Alert.service.ts:38 | /Alert/GetAlertForPatient?patientaccount= |
|  | NPM_UI_BackUp/src/app/services/data/Alert.service.ts:48 | /Alert/GetLoginAlert |
|  | NPM_UI_BackUp/src/app/setups/Facility/facilities.component.ts:415 | /Demographic/GetCitiesByZipCode?ZipCode= |
|  | NPM_UI_BackUp/src/app/setups/Facility/facilities.component.ts:573 | /Setup/DeleteFacility?FacilityId= |
|  | NPM_UI_BackUp/src/app/setups/Guarantor/guarantor.component.ts:33 | mm/dd/yyyy |
|  | NPM_UI_BackUp/src/app/setups/Guarantor/guarantor.component.ts:190 | /Demographic/GetCityState?ZipCode= |
|  | NPM_UI_BackUp/src/app/setups/ndc/ndc.component.ts:62 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/setups/referral-physician/referral-physician.component.ts:35 | /ReferralPhysicians/GetReferralPhysicians?page= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/add-edit-ins-setup/add-edit-ins-setup.component.ts:208 | /InsuranceSetup/GetInsPayerList |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/add-edit-ins-setup/add-edit-ins-setup.component.ts:220 | /Demographic/GetStateDropDownList |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/add-edit-ins-setup/add-edit-ins-setup.component.ts:239 | /Demographic/GetCityState?ZipCode= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/add-edit-ins-setup/add-edit-ins-setup.component.ts:400 | /InsuranceSetup/GetInsurancePayerModel?InsurancePayerId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/ins-setup-detail/ins-setup-detail.component.ts:33 | /InsuranceSetup/GetInsurance?InsuranceId= |
| GET | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/list-ins-setup/list-ins-setup.component.ts:64 | this.searchForm.get('groupId').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/list-ins-setup/list-ins-setup.component.ts:66 | this.searchForm.get('groupId').setValidators(Validators.required); |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/list-ins-setup/list-ins-setup.component.ts:106 | /InsuranceSetup/GetInsuranceList?GroupId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/list-ins-setup/list-ins-setup.component.ts:241 | /InsuranceSetup/DeleteInsurance?InsuranceId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/ins-group-setup-details/ins-group-setup-details.component.ts:30 | /InsuranceSetup/GetInsuranceGroup?InsuranceGroupId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/list-ins-group-setup/list-ins-group-setup.component.ts:47 | /InsuranceSetup/GetInsuranceGroupList |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/list-ins-group-setup/list-ins-group-setup.component.ts:90 | /InsuranceSetup/DeleteInsuranceGroup?InsuranceGroupId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/ins-name-setup-details/ins-name-setup-details.component.ts:31 | /InsuranceSetup/GetInsuranceName?InsuranceNameId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/list-ins-name-setup/list-ins-name-setup.component.ts:50 | /InsuranceSetup/GetInsuranceNameList?InsuranceGroupId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/list-ins-name-setup/list-ins-name-setup.component.ts:94 | /InsuranceSetup/DeleteInsuranceName?InsuranceNameId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/add-edit-ins-setup-payer/add-edit-ins-setup-payer.component.ts:78 | /InsuranceSetup/GetInsurancePayerModel?InsurancePayerId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/ins-setup-payer-detail/ins-setup-payer-detail.component.ts:28 | /InsuranceSetup/GetInsurancePayer?InsurancePayerId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/list-ins-setup-payer/list-ins-setup-payer.component.ts:61 | /InsuranceSetup/GetInsurancePayerList?InsuranceGroupId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/list-ins-setup-payer/list-ins-setup-payer.component.ts:108 | /InsuranceSetup/DeleteInsurancePayer?InsurancePayerId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/list-ins-setup-payer/list-ins-setup-payer.component.ts:201 | /InsuranceSetup/GetInsPayerById?InsurancePayerId= |
|  | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/list-ins-setup-payer/list-ins-setup-payer.component.ts:250 | /InsuranceSetup/GetInsPayerByState?InsurancePayerState= |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:81 | // this.ProcedureForm.get('proCode').disable({ emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:225 | const ageRange = this.ProcedureForm.get('ageRange').value; |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:226 | let ageFrom = this.ProcedureForm.get('ageFrom').value; |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:227 | let ageTo = this.ProcedureForm.get('ageTo').value; |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:228 | const alterCode = this.ProcedureForm.get('alternateCode').value; |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:229 | const proceCode = this.ProcedureForm.get('proCode').value; |
|  | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:284 | /Setup/DuplicateProcAndAlternateCode?AlternateCode= |
|  | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:328 | /Setup/DuplicateProcAndAlternateCode?AlternateCode= |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:360 | this.ProcedureForm.get('ageCategory').reset(); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:361 | this.ProcedureForm.get('ageCategory').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:369 | this.ProcedureForm.get('ageFrom').reset(); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:370 | this.ProcedureForm.get('ageTo').reset(); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:375 | //   this.ProcedureForm.get('ageFrom').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:376 | //   this.ProcedureForm.get('ageFrom').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:377 | //   this.ProcedureForm.get('ageTo').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:378 | //   this.ProcedureForm.get('ageTo').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:381 | //   this.ProcedureForm.get('ageFrom').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:382 | //   this.ProcedureForm.get('ageTo').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:383 | //   this.ProcedureForm.get('ageFrom').setValidators([Validators.maxLength(4)]); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:384 | //   this.ProcedureForm.get('ageFrom').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:385 | //   this.ProcedureForm.get('ageTo').setValidators([Validators.maxLength(4)]); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure/add-edit-procedure.component.ts:386 | //   this.ProcedureForm.get('ageTo').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/setups/Procedures/list-procedures/list-procedures.component.ts:41 | if (this.searchForm.get('procedureCode').valid \|\| this.searchForm.get('description').valid) { |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:57 | this.refCode = this.activatedRoute.snapshot.paramMap.get('id'); |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:58 | this.type = this.activatedRoute.snapshot.paramMap.get('type'); |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:82 | if (this.UserForm.get(field).touched){ |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:83 | if (this.UserForm.get(field).invalid){ |
|  | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:92 | /PracticeSetup/GetSpecializations |
|  | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:108 | /PracticeSetup/GetSpecialityGroups |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:210 | this.UserForm.get("Referral_Taxonomy_Code").setValue(""); |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:224 | this.UserForm.get('DEA_Expiry_Date').setValue(event.formatted); |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:228 | this.UserForm.get('Date_Of_Birth').setValue(event.formatted); |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:235 | let control = this.UserForm.get(fieldname); // Replace 'form' with your actual form instance |
|  | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:243 | /ReferralPhysicians/GetReferralPhysicianByRefCode?refCode= |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:249 | this.UserForm.get('Title').setValue(data.Response.Title.toUpperCase()) |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:250 | this.UserForm.get('Referral_Lname').setValue(data.Response.Referral_Lname.toUpperCase()) |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:251 | this.UserForm.get('Referral_Fname').setValue(data.Response.Referral_Fname.toUpperCase()) |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:252 | this.UserForm.get('Referral_Mi').setValue(data.Response.Referral_Mi.toUpperCase()) |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:253 | this.UserForm.get('Referral_Address').setValue(data.Response.Referral_Address.toUpperCase()) |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:261 | this.UserForm.get('specialityGroupNumber').setValue(data.Response.SpecialityGroupNo) |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:265 | this.UserForm.get('Referral_Taxonomy_Code').setValue(data.Response.Referral_Taxonomy_Code) |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:279 | const referralZip = this.UserForm.get('Referral_Zip').value; |
|  | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:288 | /Demographic/GetCitiesByZipCode?ZipCode= |
| GET | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician/add-edit-referral-physician.component.ts:308 | this.UserForm.get('Referral_City').value; |
|  | NPM_UI_BackUp/src/app/shared/patient-attachments/patient-attachments.component.ts:109 | /patientattachments/GetAttachmentCodeList |
|  | NPM_UI_BackUp/src/app/shared/prac-tab-insurance-search copy/prac-tab-insurance-search.component.ts:175 | /PracticeSetup/GetPracticeLocationList?PracticeId= |
|  | NPM_UI_BackUp/src/app/shared/search-referring-physician/search-referring-physician.component.ts:77 | /Demographic/SearchReferringPhysicians |
|  | NPM_UI_BackUp/src/app/shared/search-referring-physician/search-referring-physician.component.ts:148 | /Demographic/GetCitiesByZipCode?ZipCode= |
|  | NPM_UI_BackUp/src/app/shared/guarantors/add-edit-guarantor-shared/add-edit-guarantor-shared.component.ts:138 | /Demographic/GetCitiesByZipCode?ZipCode= |
|  | NPM_UI_BackUp/src/app/tasks/account-level/account-level.component.ts:39 | /ClaimAssignment/GetAllAssignedAccounts?practice_code= |
|  | NPM_UI_BackUp/src/app/tasks/account-level/account-level.component.ts:83 | /ClaimAssignment/GetAllAssignedAccounts?practice_code= |
|  | NPM_UI_BackUp/src/app/tasks/account-level/account-level.component.ts:164 | /ClaimAssignment/GetAllActivePractices |
|  | NPM_UI_BackUp/src/app/tasks/claim-level/claim-level.component.ts:41 | /ClaimAssignment/GetAllAssignedClaims?practice_code= |
|  | NPM_UI_BackUp/src/app/tasks/claim-level/claim-level.component.ts:89 | /ClaimAssignment/GetAllAssignedClaims?practice_code= |
|  | NPM_UI_BackUp/src/app/tasks/claim-level/claim-level.component.ts:153 | /ClaimAssignment/GetAllActivePractices |
| GET | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:115 | const ticketId = Number(this.route.snapshot.paramMap.get('id')); |
| GET | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:116 | const ticketTrailId = Number(this.route.snapshot.paramMap.get('trailid')); |
|  | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:232 | /TicketTracker/GetTTDepartmentsList |
| GET | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:284 | const currentValue = this.createForm.get('Practice_Code').value; |
| GET | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:696 | const selectedInsurance = this.createForm.get('Ins_Type').value; |
| GET | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:1693 | const currentValue = this.createForm.get('Ticket_Type_Id').value; |
| GET | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:1708 | this.createForm.get('Ticket_Type_Id').setValue( |
| GET | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:1779 | this.createForm.get('Assigned_User').setValue(pocUser.UserId); |
| GET | NPM_UI_BackUp/src/app/tickettracker/create-ticket/create-ticket.component.ts:2001 | const ticketType = this.createForm.get('Ticket_Type_Id').value; |
| GET | NPM_UI_BackUp/src/app/tickettracker/ticket-response/ticket-response.component.ts:207 | this.trackerForm.get('Ticket_Status')!.setValue(status); |
|  | NPM_UI_BackUp/src/app/tickettracker/ticket-response/ticket-response.component.ts:403 | /TicketTracker/GetTTDepartmentsList |
|  | NPM_UI_BackUp/src/app/user-management/employees/list-employees/list-employees.component.ts:42 | /UserManagementSetup/GetEmployeesList |
|  | NPM_UI_BackUp/src/app/user-management/module/list-module/list-module.component.ts:39 | /UserManagementSetup/GetModulesList |
|  | NPM_UI_BackUp/src/app/user-management/role/list-role/list-role.component.ts:40 | /UserManagementSetup/GetRoleList |
|  | NPM_UI_BackUp/src/app/user-management/role-rights/role-wise-rights/role-wise-rights.component.ts:42 | /UserManagementSetup/GetRolesSelectList |
|  | NPM_UI_BackUp/src/app/user-management/role-rights/users-wise-rights/users-wise-rights.component.ts:51 | /UserManagementSetup/GetUsersSelectList |
| GET | NPM_UI_BackUp/src/app/user-management/users/add-edit-user/add-edit-user.component.ts:97 | this.UserForm.get('Empid').disable(); |
| GET | NPM_UI_BackUp/src/app/user-management/users/add-edit-user/add-edit-user.component.ts:308 | if (this.UserForm.get('email').valid) { |
| GET | NPM_UI_BackUp/src/app/user-management/users/add-edit-user/add-edit-user.component.ts:329 | if (this.UserForm.get('Empid').valid) { |
| GET | NPM_UI_BackUp/src/app/user-management/users/add-edit-user/add-edit-user.component.ts:346 | this.UserForm.get('Empid').setValue(''); |
| GET | NPM_UI_BackUp/src/app/user-management/users/add-edit-user/add-edit-user.component.ts:355 | const isEmployeeChecked = this.UserForm.get('isEmployee').value; |
| GET | NPM_UI_BackUp/src/app/user-management/users/add-edit-user/add-edit-user.component.ts:359 | this.UserForm.get('Empid').setErrors(null); |
| GET | NPM_UI_BackUp/src/app/user-management/users/add-edit-user/add-edit-user.component.ts:365 | this.UserForm.get('Empid').enable(); |
| GET | NPM_UI_BackUp/src/app/user-management/users/add-edit-user/add-edit-user.component.ts:374 | this.UserForm.get('Empid').disable(); |
|  | NPM_UI_BackUp/src/app/user-management/users/list-user/list-user.component.ts:46 | /UserManagementSetup/GetUsersList |
