# Database Dependency Inventory

This is an initial code-derived dependency map. Exact columns, keys, constraints, trigger behavior, and procedure internals are pending until database schema scripts are supplied.

## EF/Table Model Candidates

| Model/table candidate | Kind | Source |
| --- | --- | --- |
| a | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/a.cs |
| AccountAssignee_AL | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AccountAssignee_AL.cs |
| AccountAssignee_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AccountAssignee_Notes.cs |
| accountassigneeModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/accountassigneeModel.cs |
| AddressType | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AddressType.cs |
| Components | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AddressValidationViewModel.cs |
| Admission_Details | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Admission_Details.cs |
| AdvEligibilityReqRe | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AdvEligibilityReqRe.cs |
| aging_populated_record | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/aging_populated_record.cs |
| Aging_Summary_Analysis_Report_Patient_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_Analysis_Report_Patient_Result.cs |
| Aging_Summary_Analysis_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_Analysis_Report_Result.cs |
| Aging_Summary_Analysis_Reporting_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_Analysis_Reporting_Result.cs |
| AGING_SUMMARY_PATIENT_REPORT | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AGING_SUMMARY_PATIENT_REPORT.cs |
| AGING_SUMMARY_REPORT | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AGING_SUMMARY_REPORT.cs |
| Aging_Summary_report_Top_5_Payers_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_report_Top_5_Payers_Result.cs |
| Aging_Summary_Top_5_Payers_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_Top_5_Payers_Result.cs |
| AlertModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AlertModel.cs |
| Amt | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Amt.cs |
| AppealAttachment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AppealAttachment.cs |
| Appointment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Appointment.cs |
| appointment_reasons | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/appointment_reasons.cs |
| Appointment_Status | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Appointment_Status.cs |
| AssigneeusersList | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/AssigneeusersList.cs |
| Attachment_TypeCode | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Attachment_TypeCode.cs |
| Audit_Block_Users | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Audit_Block_Users.cs |
| BALANCE | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/BALANCE.cs |
| Batch_WisePayments | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Batch_WisePayments.cs |
| BatchClaimsDetail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/BatchClaimsDetail.cs |
| BatchCSIResponse | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/BatchClaimSubmissionResponse.cs |
| BatchPatientClaim | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/BatchPatientClaim.cs |
| BATCHPAYMENT | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/BATCHPAYMENT.cs |
| BatchPaymentModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/BatchPaymentModel.cs |
| BatchPaymentResponse | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/BatchPaymentResponse.cs |
| BatchStatusModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/BatchStatusModel.cs |
| By_Cpt_DOS_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/By_Cpt_DOS_Result.cs |
| C__EFMigrationsHistory | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/C__EFMigrationsHistory.cs |
| Category | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Category.cs |
| Central_Audit_Logs | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Central_Audit_Logs.cs |
| Charges_at_CPT_Level_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Charges_at_CPT_Level_Result.cs |
| check_CPtPlan_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/check_CPtPlan_Result.cs |
| Check_Duplicate_Blocking_Rule_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Check_Duplicate_Blocking_Rule_Result.cs |
| Check_Office_Timing_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Check_Office_Timing_Result.cs |
| check_provider_cptplan_existence | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/check_provider_cptplan_existence.cs |
| checkdetail_impt | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/checkdetail_impt.cs |
| CheckPracticeCode | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CheckPracticeCode.cs |
| City | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/City.cs |
| Claim | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim.cs |
| claim_batch | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_batch.cs |
| claim_batch_detail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_batch_detail.cs |
| claim_batch_detail_test | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_batch_detail_test.cs |
| claim_batch_error | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_batch_error.cs |
| Claim_Batch_Exceptions | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Batch_Exceptions.cs |
| claim_batchbkp | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_batchbkp.cs |
| claim_bkp | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_bkp.cs |
| Claim_Charges | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Charges.cs |
| claim_charges_06092023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_charges_06092023.cs |
| CLAIM_CHARGES_BKP20230817 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CLAIM_CHARGES_BKP20230817.cs |
| Claim_Charges | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Charges_No_Mapped_Prop.cs |
| Claim_Charges_Summary | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Charges_Summary.cs |
| Claim_Document | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Document.cs |
| claim_info_worker_injurycase | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_info_worker_injurycase.cs |
| Claim_Insurance | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Insurance.cs |
| claim_insurance_06092023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_insurance_06092023.cs |
| CLAIM_NOTES | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CLAIM_NOTES.cs |
| Claim_Overpayment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Overpayment.cs |
| Claim_Payments | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Payments.cs |
| CLAIM_PAYMENTSBKP20230817 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CLAIM_PAYMENTSBKP20230817.cs |
| claim_paymentsbkp20230818 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_paymentsbkp20230818.cs |
| claim_paymenttets | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_paymenttets.cs |
| Claim_Provider_Diagnosis_Proc_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Provider_Diagnosis_Proc_Result.cs |
| claim_reject_type_CO | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claim_reject_type_CO.cs |
| Claim_Status_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Status_Codes.cs |
| Claim_Worker_Injurycase | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claim_Worker_Injurycase.cs |
| ClaimAssignee_CL | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_CL.cs |
| ClaimAssignee_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_Notes.cs |
| claimassigneeModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs |
| ClaimAttachmentRequest | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimAttachmentRequest.cs |
| BatchCreateViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimBatchViewModels.cs |
| Claim_Charges | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimChargesAdditionalFields.cs |
| ClaimErrorMessage | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimErrorMessage.cs |
| claimerrormessageRejection | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claimerrormessageRejection.cs |
| ClaimOverpayment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimOverpayment.cs |
| claimReason | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claimReason.cs |
| Claims_06082023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_06082023.cs |
| Claims_06092023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_06092023.cs |
| claims_bkp20230925 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claims_bkp20230925.cs |
| claims_bkp_10012019 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claims_bkp_10012019.cs |
| Claims_Condition_Code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_Condition_Code.cs |
| Claims_filling_limit | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_filling_limit.cs |
| Claims_ICD10DX | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_ICD10DX.cs |
| Claim | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_Not_Mapped_Prop.cs |
| Claims_Occurence_Span_Code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_Occurence_Span_Code.cs |
| Claims_Occurrence_Code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_Occurrence_Code.cs |
| Claims_Ptl_Feedback | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_Ptl_Feedback.cs |
| CLAIMS_SUBMITTED | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CLAIMS_SUBMITTED.cs |
| claims_testUbaid | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claims_testUbaid.cs |
| Claims_Value_Code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Claims_Value_Code.cs |
| claimsbkp | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/claimsbkp.cs |
| ClaimsDataModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimsDataModel.cs |
| ClaimsDetail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimsDetail.cs |
| ClaimsPayments_06082023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06082023.cs |
| ClaimsPayments_06092023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06092023.cs |
| ClaimStatus_Search_Criteria | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimStatus_Search_Criteria.cs |
| ClaimSubmission | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimSubmission.cs |
| ClaimSubmissionModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimSubmissionModel.cs |
| ClaimSummaryViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimSummaryViewModel.cs |
| ClaimsViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ClaimsViewModel.cs |
| CLC_Assigned_Roles | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CLC_Assigned_Roles.cs |
| CLC_Roles | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CLC_Roles.cs |
| Clearing_Houses | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Clearing_Houses.cs |
| CombinedCodeModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CombinedCodeModel.cs |
| Company | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Company.cs |
| Condition_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Condition_Codes.cs |
| consortium_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/consortium_lookup.cs |
| contractor | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/contractor.cs |
| contractor_jurisdiction | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/contractor_jurisdiction.cs |
| contractor_type_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/contractor_type_lookup.cs |
| coverage_topic_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/coverage_topic_lookup.cs |
| CPADASHBOARD | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CPADASHBOARD.cs |
| CPT | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CPT.cs |
| Cpt_Current_Status | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cpt_Current_Status.cs |
| CPT_Fee_Charge | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CPT_Fee_Charge.cs |
| CPT_FEE_STRUCTURE | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CPT_FEE_STRUCTURE.cs |
| CPT_HOSPBILLS | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CPT_HOSPBILLS.cs |
| cpt_pricing_modifier | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/cpt_pricing_modifier.cs |
| Cpt_ShortCodes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cpt_ShortCodes.cs |
| CPTChargesViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CPTChargesViewModel.cs |
| Cptplan_MD | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cptplan_MD.cs |
| CPTs_Ana_by_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CPTs_Ana_by_Report_Result.cs |
| CPTs_Analysis_by_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CPTs_Analysis_by_Report_Result.cs |
| Cred_App_Docs | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cred_App_Docs.cs |
| Cred_App_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cred_App_Notes.cs |
| Cred_Application_Status | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cred_Application_Status.cs |
| Cred_Application_Type | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cred_Application_Type.cs |
| Cred_Contract_Type | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cred_Contract_Type.cs |
| Cred_Document_Type | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cred_Document_Type.cs |
| Cred_Objective_Type | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cred_Objective_Type.cs |
| Cred_Portals | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cred_Portals.cs |
| Credentialing_Application | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Credentialing_Application.cs |
| CredPortal_View | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CredPortal_View.cs |
| Cruduser | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Cruduser.cs |
| CSI_Batch | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CSI_Batch.cs |
| CSI_Batch_Error | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CSI_Batch_Error.cs |
| CSI_Batch_Response | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CSI_Batch_Response.cs |
| CSIReportModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CSIReportModel.cs |
| Custom_Edits | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Custom_Edits.cs |
| Custom_Scrubber_Rules | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Custom_Scrubber_Rules.cs |
| CustomEdit | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomEdit.cs |
| CustomEdit_Mapping | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomEdit_Mapping.cs |
| CustomEdits_ClearClaims | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomEdits_ClearClaims.cs |
| CustomEdits_Columns | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomEdits_Columns.cs |
| CustomEdits_FrontEnd | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomEdits_FrontEnd.cs |
| CustomEdits_Test | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomEdits_Test.cs |
| CustomEditsError | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomEditsError.cs |
| CustomEditsErrors_jinnah | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomEditsErrors_jinnah.cs |
| CustomField | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomField.cs |
| Customised_diagnosis_Description | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Customised_diagnosis_Description.cs |
| Customised_Procedure_Description | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Customised_Procedure_Description.cs |
| CustomValue | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomValue.cs |
| CustomValue1 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomValue1.cs |
| CustomValues_Column | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/CustomValues_Column.cs |
| DashboardViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DashboardViewModel.cs |
| Data12356 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Data12356.cs |
| DataModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DataModel.cs |
| Datet | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Datet.cs |
| Days_Of_Week | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Days_Of_Week.cs |
| default_group_IDs | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/default_group_IDs.cs |
| Default_Setting_Practice | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Default_Setting_Practice.cs |
| DelayClaimReports_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DelayClaimReports_Result.cs |
| DelayReason1 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DelayReason1.cs |
| DelayReasonsNew | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DelayReasonsNew.cs |
| Deleted_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Deleted_Codes.cs |
| DeleteInvoicepaymentsRequest | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DeleteInvoicepaymentsRequest.cs |
| DeleteinvoicepymentResponse | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DeleteinvoicepymentResponse.cs |
| DeleteInvoiceResponse | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DeleteInvoiceResponse.cs |
| Delivery_Zone | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Delivery_Zone.cs |
| DemoERADBModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DemoERADBModel.cs |
| Department | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Department.cs |
| Department_practice | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Department_practice.cs |
| DepartmentViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DepartmentViewModel.cs |
| deposit | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/deposit.cs |
| deposit1 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/deposit1.cs |
| Deposit_Bank | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Deposit_Bank.cs |
| Deposit_Bank_Detail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Deposit_Bank_Detail.cs |
| DEPOSIT_SLIPS | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DEPOSIT_SLIPS.cs |
| DeptShiftTiming | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DeptShiftTiming.cs |
| Designation | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Designation.cs |
| DesignationViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DesignationViewModel.cs |
| Diagnosi | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Diagnosi.cs |
| DIAGNOSIS_PAYER | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DIAGNOSIS_PAYER.cs |
| DiagnosisAccDel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DiagnosisAccDel.cs |
| Discharge_Status | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Discharge_Status.cs |
| Division | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Division.cs |
| dmerc_region_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/dmerc_region_lookup.cs |
| DO | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DO.cs |
| Doc_Type_Lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Doc_Type_Lookup.cs |
| DOCUMENT_CATEGORIES | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DOCUMENT_CATEGORIES.cs |
| DOSAGE_UNITS | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DOSAGE_UNITS.cs |
| DownloadedFile | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DownloadedFile.cs |
| Dtp | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Dtp.cs |
| DublicatePatientCheckModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DublicatePatientCheckModel.cs |
| Dummy | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Dummy.cs |
| DXSearchCriteria_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/DXSearchCriteria_Result.cs |
| EDI_ERA_Doc_Type | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EDI_ERA_Doc_Type.cs |
| EDI_ERA_Documents | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EDI_ERA_Documents.cs |
| EDI_ERA_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EDI_ERA_Notes.cs |
| EDI_ERA_Obj_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EDI_ERA_Obj_Types.cs |
| EDI_ERA_Setup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EDI_ERA_Setup.cs |
| EDI_ERA_Statuses | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EDI_ERA_Statuses.cs |
| edit | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/edit.cs |
| editassignedaccountModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/editassignedaccountModel.cs |
| editassignedclaimModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs |
| Edits_jinnah | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Edits_jinnah.cs |
| EFS_ImpactSummary | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs |
| EFS_Practices | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EFS_Practices.cs |
| EFS_Suggested | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EFS_Suggested.cs |
| EligRequest_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EligRequest_Result.cs |
| EligRequests_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EligRequests_Result.cs |
| EligRequestTEST_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EligRequestTEST_Result.cs |
| Employee | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Employee.cs |
| Employee_Practice | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Employee_Practice.cs |
| EmployeeInformation | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| ENROLLMENT_TRACKER | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ENROLLMENT_TRACKER.cs |
| EOB_Adjustment_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EOB_Adjustment_Codes.cs |
| EPSDTWORKERINFO | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EPSDTWORKERINFO.cs |
| epssdataoriginal | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/epssdataoriginal.cs |
| era | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/era.cs |
| era_adjustment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/era_adjustment.cs |
| ERA_Adjustment_Mapping | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERA_Adjustment_Mapping.cs |
| ERA_ADJUSTMENT_MAPPING_BKP_012721 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERA_ADJUSTMENT_MAPPING_BKP_012721.cs |
| era_claim | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/era_claim.cs |
| era_claim_service | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/era_claim_service.cs |
| ERA_PLB_CODE | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERA_PLB_CODE.cs |
| era_provider_adjustment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/era_provider_adjustment.cs |
| ERA_Request | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERA_Request.cs |
| Era_Summary_Impt | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Era_Summary_Impt.cs |
| ERA_UNPOSTED_PAYMENTS_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERA_UNPOSTED_PAYMENTS_EDI_Result.cs |
| ERACHECKDETAIL | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERACHECKDETAIL.cs |
| ERACHECKDETAIL_bkp20232607 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERACHECKDETAIL_bkp20232607.cs |
| eracheckdetail_EDI | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/eracheckdetail_EDI.cs |
| ERACLAIMINFO | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERACLAIMINFO.cs |
| ERACLAIMINFO_EDI | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERACLAIMINFO_EDI.cs |
| eraclaiminfo_impt | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/eraclaiminfo_impt.cs |
| EraDbModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/EraDbModel.cs |
| ERASUMMARY | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERASUMMARY.cs |
| ERASUMMARY_EDI | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ERASUMMARY_EDI.cs |
| ethnicity | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ethnicity.cs |
| ExternalPractices_Reporting | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ExternalPractices_Reporting.cs |
| Facility | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Facility.cs |
| Facility_Insurance_Id | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Facility_Insurance_Id.cs |
| Facility_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Facility_Notes.cs |
| FacilitySearchModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/FacilitySearchModel.cs |
| Fee_Plan_Update | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Fee_Plan_Update.cs |
| fetchFailedClaims_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/fetchFailedClaims_Result.cs |
| Fiancial_Summary | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Fiancial_Summary.cs |
| File277CA | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/File277CA.cs |
| File999 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/File999.cs |
| FileSegmentValue | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/FileSegmentValue.cs |
| FINAL2 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/FINAL2.cs |
| Financial_Analysis_At_CPT_Level_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Financial_Analysis_At_CPT_Level_Result.cs |
| Financial_Analysis_by_Provider_and_Procedure_Codes_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Financial_Analysis_by_Provider_and_Procedure_Codes_Result.cs |
| FINANCIAL_SUMMARY_REPORT | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/FINANCIAL_SUMMARY_REPORT.cs |
| Functional_Group_Rejection_Response | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Functional_Group_Rejection_Response.cs |
| Gender | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Gender.cs |
| Get_CustomEdits_Colums | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Get_CustomEdits_Colums.cs |
| GET_ISFACILITY_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GET_ISFACILITY_Result.cs |
| GetAppointment_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetAppointment_Result.cs |
| GetAppointmentById_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetAppointmentById_Result.cs |
| GetAppointmentEvents_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetAppointmentEvents_Result.cs |
| GetBatchClaims_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetBatchClaims_Result.cs |
| GetBatchClaimsDetails_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetBatchClaimsDetails_Result.cs |
| GetClaimChargesByClaimNo_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetClaimChargesByClaimNo_Result.cs |
| GetClaimsForStatement_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetClaimsForStatement_Result.cs |
| GetColumn_List | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetColumn_List.cs |
| GetColumnList | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetColumnList.cs |
| GetCPTPlanByProviderPlanId_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetCPTPlanByProviderPlanId_Result.cs |
| GetCPTPlanByProviderPlanId_Temp_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetCPTPlanByProviderPlanId_Temp_Result.cs |
| GetCPTPlanByProviderPlanId_Umer_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetCPTPlanByProviderPlanId_Umer_Result.cs |
| GetCSI_BatchDetails_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetCSI_BatchDetails_Result.cs |
| GETEFSPRACTICES_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GETEFSPRACTICES_Result.cs |
| GetExistingAppointmentData_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetExistingAppointmentData_Result.cs |
| GetInsuranceNamesByGroup_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetInsuranceNamesByGroup_Result.cs |
| GetInsurancePayersByInsPayerId_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetInsurancePayersByInsPayerId_Result.cs |
| GetInsurancePayersByInsPayerState_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetInsurancePayersByInsPayerState_Result.cs |
| GetInsurancePayersByName_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetInsurancePayersByName_Result.cs |
| GetInsurancesByPayers_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetInsurancesByPayers_Result.cs |
| GetOfficeTiming_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetOfficeTiming_Result.cs |
| GetPanelALternateCodeDetails_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPanelALternateCodeDetails_Result.cs |
| GetPanelBillingSummaryByPractice_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPanelBillingSummaryByPractice_Result.cs |
| GetPanelCodeCPTDetailsClaim_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPanelCodeCPTDetailsClaim_Result.cs |
| GetPatientForStatement_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPatientForStatement_Result.cs |
| GetPatientWithClaimsForItemizedStatement_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPatientWithClaimsForItemizedStatement_Result.cs |
| GetPatientWithClaimsForStatement_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPatientWithClaimsForStatement_Result.cs |
| GetPracticeActiveUsers_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPracticeActiveUsers_Result.cs |
| GetPracticeFacilites_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPracticeFacilites_Result.cs |
| GETPRACTICES_WITHDETAILS_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GETPRACTICES_WITHDETAILS_Result.cs |
| GetPracticeUserReportingDetail_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetPracticeUserReportingDetail_Result.cs |
| GetRecentClaimDetailsWithDiagnosis_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetRecentClaimDetailsWithDiagnosis_Result.cs |
| GetTeamsByOffice_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetTeamsByOffice_Result.cs |
| GetTicketTrackDetail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetTicketTrackDetail.cs |
| GetUnassignedAppointmemtReasons_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GetUnassignedAppointmemtReasons_Result.cs |
| Group_Location | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Group_Location.cs |
| Group_Provider | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Group_Provider.cs |
| Guarantor | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Guarantor.cs |
| GUARANTORS_MAPPING_1011004 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GUARANTORS_MAPPING_1011004.cs |
| GUARANTORSRAW_1011004 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/GUARANTORSRAW_1011004.cs |
| Hard_Coded_Value | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Hard_Coded_Value.cs |
| Hard_Coded_Valuenew | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Hard_Coded_Valuenew.cs |
| HASHHASHA | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/HASHHASHA.cs |
| HCFA_Attachment_Type | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/HCFA_Attachment_Type.cs |
| Hcfa_fields | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Hcfa_fields.cs |
| HCFA_Notes_List | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/HCFA_Notes_List.cs |
| HCFAImage | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/HCFAImage.cs |
| HCFAImagesType | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/HCFAImagesType.cs |
| HCFAResponseModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/HCFAResponseModel.cs |
| hcpc_code_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/hcpc_code_lookup.cs |
| Hierarchy | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Hierarchy.cs |
| HIPAA_278_PAYER_INFORMATION | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/HIPAA_278_PAYER_INFORMATION.cs |
| hospital_affilation | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/hospital_affilation.cs |
| icd9_code_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/icd9_code_lookup.cs |
| BaseResponse | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/BaseResponse.cs |
| ClaimChargesUpdateRequest | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/ClaimChargesUpdateRequest.cs |
| ClaimPaymentUpdateRequest | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/ClaimPaymentUpdateRequest.cs |
| ClaimUpdateRequest | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/ClaimUpdateRequest.cs |
| InboxHealthEvent | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/InboxHealthEvent.cs |
| InboxHealthEventBaseEntity | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/InboxHealthEventBaseEntity.cs |
| PatientCreatedEventData | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/PatientCreatedEventData.cs |
| PatientPaymentDetailResponse | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/PatientPaymentDetailResponse.cs |
| PatientPaymentProcessedModel | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/PatientPaymentProcessedModel.cs |
| PatientUpdateRequest | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/PatientUpdateRequest.cs |
| PracticeLocationUpdateRequest | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/PracticeLocationUpdateRequest.cs |
| PracticeUpdateRequest | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/PracticeUpdateRequest.cs |
| ProviderUpdateRequest | Integration model | NPM_API_BackUp/NPMAPI/Models/InboxHealth/ProviderUpdateRequest.cs |
| include_in_edi | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/include_in_edi.cs |
| ins_provider_no | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ins_provider_no.cs |
| InsCardCategory | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsCardCategory.cs |
| instruction_history_New | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/instruction_history_New.cs |
| Insurance | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance.cs |
| Insurance_Denials | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Denials.cs |
| Insurance_Departments | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Departments.cs |
| INSURANCE_FILING_LIMIT | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/INSURANCE_FILING_LIMIT.cs |
| Insurance_filing_limit2 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_filing_limit2.cs |
| Insurance_Groups | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Groups.cs |
| Insurance_Names | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Names.cs |
| Insurance_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Notes.cs |
| Insurance_Payers | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Payers.cs |
| Insurance_Payers_07092023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Payers_07092023.cs |
| Insurance_Payers_Bkp_08232020 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Payers_Bkp_08232020.cs |
| Insurance_payers_formats | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_payers_formats.cs |
| INSURANCE_PAYERS_PLAN | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/INSURANCE_PAYERS_PLAN.cs |
| Insurance_Payers_Plan_Group | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Payers_Plan_Group.cs |
| Insurance_Phone_Directory | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurance_Phone_Directory.cs |
| insurance_role_engine | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/insurance_role_engine.cs |
| insurancelist | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/insurancelist.cs |
| InsuranceModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsuranceModel.cs |
| InsuranceNameViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsuranceNameViewModel.cs |
| InsurancePayerViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsurancePayerViewModel.cs |
| InsurancePayerVM | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsurancePayerVM.cs |
| InsurancePaymentViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsurancePaymentViewModel.cs |
| insurances_11252021 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/insurances_11252021.cs |
| Insurances_Bkp_08232020 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurances_Bkp_08232020.cs |
| Insurancesbkp_07092023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurancesbkp_07092023.cs |
| InsurancesByPayersViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsurancesByPayersViewModel.cs |
| InsuranceSearchViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsuranceSearchViewModel.cs |
| InsurancesByPayersViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InsuranceViewModel.cs |
| Insurnace_Names_Bkp_08232020 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Insurnace_Names_Bkp_08232020.cs |
| InvoicePayment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/InvoicePayments.cs |
| ISA_Identifier | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ISA_Identifier.cs |
| Issue_test | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Issue_test.cs |
| Language | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Language.cs |
| lcd | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd.cs |
| lcd_future_retire | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_future_retire.cs |
| lcd_related_documents | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_related_documents.cs |
| lcd_x_bill_code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_bill_code.cs |
| lcd_x_contractor | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_contractor.cs |
| lcd_x_coverage_topic | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_coverage_topic.cs |
| lcd_x_hcpc_code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_hcpc_code.cs |
| lcd_x_hcpc_code_group | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_hcpc_code_group.cs |
| lcd_x_icd9_dont_support | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_icd9_dont_support.cs |
| lcd_x_icd9_support | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_icd9_support.cs |
| lcd_x_icd9_support_group | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_icd9_support_group.cs |
| lcd_x_primary_jurisdiction | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_primary_jurisdiction.cs |
| lcd_x_revenue_code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_revenue_code.cs |
| lcd_x_secondary_jurisdiction | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lcd_x_secondary_jurisdiction.cs |
| lkup_location_ids | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/lkup_location_ids.cs |
| mainfacility | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/mainfacility.cs |
| Maintenance | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Maintenance.cs |
| maintenance_counter | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/maintenance_counter.cs |
| Manual_ERA_Files | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Manual_ERA_Files.cs |
| MaritalStatu | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MaritalStatu.cs |
| MEDICINE | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MEDICINE.cs |
| MEDICINE_FORMULATION | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MEDICINE_FORMULATION.cs |
| Medigap_Insurances | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Medigap_Insurances.cs |
| MEMO_MAPPING | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MEMO_MAPPING.cs |
| MEMO_MAPPING_PRACTICE_PLAN | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MEMO_MAPPING_PRACTICE_PLAN.cs |
| mis_tbl_AttachmentType_Setup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/mis_tbl_AttachmentType_Setup.cs |
| MIS_TBL_Corrected_Claim_Reason | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_Corrected_Claim_Reason.cs |
| MIS_TBL_CPT_Reason | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_CPT_Reason.cs |
| mis_tbl_fillcombo | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/mis_tbl_fillcombo.cs |
| MIS_TBL_Institution_Condition_Code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_Institution_Condition_Code.cs |
| MIS_TBL_Insurance_Resources_Remarks | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_Insurance_Resources_Remarks.cs |
| Modifier | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Modifier.cs |
| Module | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Module.cs |
| Module_Properties | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Module_Properties.cs |
| Module_Properties_bkp20230821 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Module_Properties_bkp20230821.cs |
| Module_Properties_bkp2023_08_21 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Module_Properties_bkp2023_08_21.cs |
| MONTH_END_AGING | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MONTH_END_AGING.cs |
| MONTH_END_FINANCIAL | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MONTH_END_FINANCIAL.cs |
| MONTH_END_FINANCIAL_PROVIDE_LOCATION | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/MONTH_END_FINANCIAL_PROVIDE_LOCATION.cs |
| Month_end_payments_adjustments | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Month_end_payments_adjustments.cs |
| Myalldata | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Myalldata.cs |
| NAME | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NAME.cs |
| NDC_CrossWalk | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NDC_CrossWalk.cs |
| NDC_CrossWalk_bkp_02192024 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NDC_CrossWalk_bkp_02192024.cs |
| NDC_List_Update | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NDC_List_Update.cs |
| NDC_List_Updated | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NDC_List_Updated.cs |
| NDCSearchCriteria_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NDCSearchCriteria_Result.cs |
| NEW_CATEGORY | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NEW_CATEGORY.cs |
| New_Code | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/New_Code.cs |
| New_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/New_Codes.cs |
| NEW_GCODE | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NEW_GCODE.cs |
| NEW_PATIENTLETTER_FIELDS | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NEW_PATIENTLETTER_FIELDS.cs |
| Nobility_standardcptfee | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Nobility_standardcptfee.cs |
| Notes_Description | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Notes_Description.cs |
| Notes_Description_Category | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Notes_Description_Category.cs |
| NPMDBEntities | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| and | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NPM.Designer.cs |
| NpmAlert | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NpmAlert.cs |
| NPMDBEntities | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/NPMDBEntities.Audit.cs |
| Occurrence_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Occurrence_Codes.cs |
| Occurrence_Span_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Occurrence_Span_Codes.cs |
| Office | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Office.cs |
| office_employees | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/office_employees.cs |
| Office_Test_Detail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Office_Test_Detail.cs |
| Office_tests | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Office_tests.cs |
| OfficeViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/OfficeViewModel.cs |
| Operating_Test | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Operating_Test.cs |
| Output277 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Output277.cs |
| Packet277CA_ClaimStatusCategoryCodes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Packet277CA_ClaimStatusCategoryCodes.cs |
| Packet277CA_ClaimStatusCodes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Packet277CA_ClaimStatusCodes.cs |
| Packet277CA_Data | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Packet277CA_Data.cs |
| Packet277CA_EntityIdentifierCodes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Packet277CA_EntityIdentifierCodes.cs |
| Packet277CAClaimReason_Messages | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Packet277CAClaimReason_Messages.cs |
| Packet277CAClaims | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Packet277CAClaims.cs |
| Packet999_Data | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Packet999_Data.cs |
| PacketFileVital | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PacketFileVital.cs |
| PacketFileVitals_Tets | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PacketFileVitals_Tets.cs |
| PacketFileVitals_Tets1 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PacketFileVitals_Tets1.cs |
| PacketFileVitals_Tets2 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PacketFileVitals_Tets2.cs |
| Panel_Billing_Code_Cptdetail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Panel_Billing_Code_Cptdetail.cs |
| Panel_Billing_Code_detail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Panel_Billing_Code_detail.cs |
| DemoERADBModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Partials/DemoERADBModel.Partial.cs |
| NPMDBEntities | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Partials/NPMDBEntities.Partial.cs |
| Patient | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patient.cs |
| PATIENT_35510209 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PATIENT_35510209.cs |
| Patient_Attachments | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patient_Attachments.cs |
| patient_bkp11282018 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/patient_bkp11282018.cs |
| PaTIENT_BKP_01142022 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PaTIENT_BKP_01142022.cs |
| patient_bkp_11282018 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/patient_bkp_11282018.cs |
| Patient_Insurance | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patient_Insurance.cs |
| Patient_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patient_Notes.cs |
| Patient_Ptl_Feedback | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patient_Ptl_Feedback.cs |
| patient_statement_itemized_tets | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/patient_statement_itemized_tets.cs |
| patient_statement_itemized_tets_ | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/patient_statement_itemized_tets_.cs |
| patient_statement_itemized_tets_bkp | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/patient_statement_itemized_tets_bkp.cs |
| Patient_Statement_Messages | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patient_Statement_Messages.cs |
| Patient_Statement_Messages3 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patient_Statement_Messages3.cs |
| Patient_Updated | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patient_Updated.cs |
| PatientDemographicViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientDemographicViewModel.cs |
| PatientImageModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientImageModel.cs |
| PatientInsuranceViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientInsuranceViewModel.cs |
| PatientInsuranceViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientInsuranceViewModel_Not_Mapped_Prop.cs |
| PatientPayment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientPayment.cs |
| PatientPaymentProcessed | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientPaymentProcessed.cs |
| Patients_Data | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Patients_Data.cs |
| PatientSearchModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientSearchModel.cs |
| PatientSearchResultModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientSearchResultModel.cs |
| PatientSearchViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientSearchViewModel.cs |
| PatientStatementMessages | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientStatementMessages.cs |
| PatientStatementRequest | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PatientStatementRequest.cs |
| PAYER | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PAYER.cs |
| Payer_Facility_Id | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Payer_Facility_Id.cs |
| payer_not_450 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/payer_not_450.cs |
| Payer_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Payer_Notes.cs |
| PayerMappedInsuranceSearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PayerMappedInsuranceSearch_Result.cs |
| PayerPortal_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PayerPortal_Notes.cs |
| PayerWise_Analysis_by_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PayerWise_Analysis_by_Report_Result.cs |
| payment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/payment.cs |
| Payment_By_Carrier_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Payment_By_Carrier_Result.cs |
| Payment_Daily_Refresh_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Payment_Daily_Refresh_Result.cs |
| Payment_detail_Proc_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Payment_detail_Proc_Result.cs |
| Payment_detail_Proctest_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Payment_detail_Proctest_Result.cs |
| Payment_Detail_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Payment_Detail_Result.cs |
| Payments_at_CPT_Level_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Payments_at_CPT_Level_Result.cs |
| PaymentType | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PaymentType.cs |
| PHARMACy | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PHARMACy.cs |
| Phone_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Phone_Types.cs |
| PHY_BA_AGREEMENT | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PHY_BA_AGREEMENT.cs |
| physcian_information | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/physcian_information.cs |
| PhysicianSearchModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PhysicianSearchModel.cs |
| Place_Of_Services | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Place_Of_Services.cs |
| place_of_services_bkp_11082018 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/place_of_services_bkp_11082018.cs |
| Plan_setup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Plan_setup.cs |
| Possible_Options | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Possible_Options.cs |
| Post | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Post.cs |
| PP_BillingSoftware | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PP_BillingSoftware.cs |
| PQRI_INDIVIDUAL_MEASURES | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PQRI_INDIVIDUAL_MEASURES.cs |
| Prac_MeetingSchedule | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Prac_MeetingSchedule.cs |
| Prac_Term_Date_Steps | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Prac_Term_Date_Steps.cs |
| Prac_TermDate_Process | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Prac_TermDate_Process.cs |
| Practice | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice.cs |
| Practice101100205152023_BKP | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice101100205152023_BKP.cs |
| Practice2 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice2.cs |
| Practice_Bank_Statement | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Bank_Statement.cs |
| PRACTICE_CALLING_DAY_CRITERIA | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICE_CALLING_DAY_CRITERIA.cs |
| Practice_Contract | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Contract.cs |
| Practice_CPT_Plan | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_CPT_Plan.cs |
| PRACTICE_CPT_PLAN_GROUP | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICE_CPT_PLAN_GROUP.cs |
| Practice_Daily_Missing_Work | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Daily_Missing_Work.cs |
| PRACTICE_DIAGNOSIS1 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICE_DIAGNOSIS1.cs |
| PRACTICE_DIVISION | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICE_DIVISION.cs |
| Practice_Doc_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Doc_Types.cs |
| Practice_Docs | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Docs.cs |
| PRACTICE_FACILITY | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICE_FACILITY.cs |
| practice_gender | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/practice_gender.cs |
| Practice_Groups | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Groups.cs |
| practice_information | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/practice_information.cs |
| Practice_Locations | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Locations.cs |
| PRACTICE_LOCATIONS_PLAN | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICE_LOCATIONS_PLAN.cs |
| Practice_Locations_Plan_Group | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Locations_Plan_Group.cs |
| Practice_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Notes.cs |
| Practice_NPI_confirmation | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_NPI_confirmation.cs |
| PRACTICE_PROCEDURE1 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICE_PROCEDURE1.cs |
| Practice_Providers_Plan | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Providers_Plan.cs |
| Practice_Providers_Plan_Group | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Providers_Plan_Group.cs |
| Practice_Reporting | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Reporting.cs |
| PRACTICE_SERVER | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICE_SERVER.cs |
| Practice_SignUp_Contact_Information | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_SignUp_Contact_Information.cs |
| Practice_SignUp_Daily_Office_Hours | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_SignUp_Daily_Office_Hours.cs |
| Practice_SignUp_Insurance_Information | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_SignUp_Insurance_Information.cs |
| Practice_SignUp_Physician_Capitation | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_SignUp_Physician_Capitation.cs |
| Practice_SignUp_Physician_Facilities_Info | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_SignUp_Physician_Facilities_Info.cs |
| Practice_SignUp_Referring_Physician | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_SignUp_Referring_Physician.cs |
| Practice_SMS_Settings | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_SMS_Settings.cs |
| Practice_Software | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Software.cs |
| Practice_Special_Instruction_Answers | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Special_Instruction_Answers.cs |
| Practice_Special_Instruction_AnswersReview | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Special_Instruction_AnswersReview.cs |
| Practice_Special_Instruction_Category | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Special_Instruction_Category.cs |
| Practice_Special_Instruction_Questions | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Special_Instruction_Questions.cs |
| Practice_Specialty | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Specialty.cs |
| Practice_Termination | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Termination.cs |
| Practice_Termination_Steps | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Termination_Steps.cs |
| Practice_Transcription_Amount | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Transcription_Amount.cs |
| Practice_Transcription_Rate | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Transcription_Rate.cs |
| Practice_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practice_Types.cs |
| PracticeAppointmentReason | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PracticeAppointmentReason.cs |
| PracticeAppointmentStatu | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PracticeAppointmentStatu.cs |
| PracticeFacilitesViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PracticeFacilitesViewModel.cs |
| PracticeFacilityEditViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PracticeFacilityViewModel.cs |
| PracticeViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PracticeModel.cs |
| PRACTICES_BKP_021619 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PRACTICES_BKP_021619.cs |
| Practices_Techincal_Information | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practices_Techincal_Information.cs |
| Practices_VAS_Other | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Practices_VAS_Other.cs |
| PracticeSynchronization | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PracticeSynchronization.cs |
| PracticeSynchronizationLog | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PracticeSynchronizationLog.cs |
| PracticeVendor | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PracticeVendor.cs |
| Procedure | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Procedure.cs |
| Procedure_Category | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Procedure_Category.cs |
| Procedure_tets | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Procedure_tets.cs |
| PROCEDURES_ALERTS | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PROCEDURES_ALERTS.cs |
| Procedures_Payer | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Procedures_Payer.cs |
| procedures_tets | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/procedures_tets.cs |
| proceduresbkp | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/proceduresbkp.cs |
| ProcedureViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ProcedureViewModel.cs |
| procItemized_Statement_Claim_Due_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/procItemized_Statement_Claim_Due_Result.cs |
| Product | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Product.cs |
| Provider | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider.cs |
| Provider_Appointment_Rules | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Appointment_Rules.cs |
| Provider_Attachments | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Attachments.cs |
| Provider_Cpt_Contractual_Plan | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Cpt_Contractual_Plan.cs |
| Provider_Cpt_Contractual_Plan_Details | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Cpt_Contractual_Plan_Details.cs |
| Provider_Cpt_Contractual_Plan_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Cpt_Contractual_Plan_Notes.cs |
| Provider_Cpt_Plan | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Cpt_Plan.cs |
| Provider_Cpt_Plan_bkp_1_10_2023_ | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Cpt_Plan_bkp_1_10_2023_.cs |
| Provider_Cpt_Plan_Details | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Cpt_Plan_Details.cs |
| Provider_Cpt_Plan_Details_bkp01122023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Cpt_Plan_Details_bkp01122023.cs |
| Provider_Cpt_Plan_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Cpt_Plan_Notes.cs |
| Provider_Diagnosis | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Diagnosis.cs |
| Provider_Doc_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Doc_Types.cs |
| Provider_Docs | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Docs.cs |
| Provider_Initial_Settings | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Initial_Settings.cs |
| Provider_Notes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Notes.cs |
| Provider_Oncall | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Oncall.cs |
| PROVIDER_PAYER_PRINTCENTER | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PROVIDER_PAYER_PRINTCENTER.cs |
| Provider_Payers | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Payers.cs |
| provider_payerTEST | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/provider_payerTEST.cs |
| PROVIDER_PROCEDURES | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PROVIDER_PROCEDURES.cs |
| Provider_Resource_Mapping | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Resource_Mapping.cs |
| Provider_Resources | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Resources.cs |
| Provider_US_Holidays | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_US_Holidays.cs |
| Provider_Working_Days_Time | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Working_Days_Time.cs |
| Provider_Working_Days_Time_Temp | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Working_Days_Time_Temp.cs |
| Provider_Year_Holidays | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Provider_Year_Holidays.cs |
| providercptplanModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/providercptplanModel.cs |
| providercptplanModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/providercptplanModels.cs |
| ProviderFeeScheduleSearchVM | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ProviderFeeScheduleSearchVM.cs |
| ProviderCptPlanNotesVM | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ProviderPlanNotesViewModel.cs |
| Providers_Plan | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Providers_Plan.cs |
| Providers_Plan_Group | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Providers_Plan_Group.cs |
| providers_reasons_timeunits | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/providers_reasons_timeunits.cs |
| ProviderWise_Financials_by_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ProviderWise_Financials_by_Report_Result.cs |
| PtientInsurance_06082023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PtientInsurance_06082023.cs |
| PtientInsurance_06092023 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PtientInsurance_06092023.cs |
| Ptl_Description | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ptl_Description.cs |
| ptl_filing_limit | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ptl_filing_limit.cs |
| PTLReason | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PTLReason.cs |
| PutCustomEdits_values | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PutCustomEdits_values.cs |
| PutCustomEdits_values_Array | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/PutCustomEdits_values_Array.cs |
| Qty | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Qty.cs |
| Race | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Race.cs |
| Ref | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ref.cs |
| Referral_Physicians | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Referral_Physicians.cs |
| ReferralPhysicianViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ReferralPhysicianViewModel.cs |
| RefreshToken | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/RefreshToken.cs |
| RegenerateBatchCSIFileModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/RegenerateBatchCSIFileModel.cs |
| region_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/region_lookup.cs |
| Registeration | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Registeration.cs |
| REJECT_TYPE_DESCRIPTION | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/REJECT_TYPE_DESCRIPTION.cs |
| Relationship | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/relationship.cs |
| REPORT_Sami_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/REPORT_Sami_Result.cs |
| Resource | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Resource.cs |
| resource_settings | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/resource_settings.cs |
| ResponseModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ResponseModel.cs |
| ResponseModel277 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ResponseModel277.cs |
| ClaimStatusTRNNumberModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ResponseModelForSerialnumber.cs |
| ResubmissionCode | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ResubmissionCode.cs |
| revenue_code_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/revenue_code_lookup.cs |
| Revenue_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Revenue_Codes.cs |
| RevenueF | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/RevenueF.cs |
| RevenueT | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/RevenueT.cs |
| Role | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Role.cs |
| Roles_Module_Properties | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Roles_Module_Properties.cs |
| rolesss | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/rolesss.cs |
| room_booking_appointment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/room_booking_appointment.cs |
| room_location | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/room_location.cs |
| room_status | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/room_status.cs |
| ROUTE | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ROUTE.cs |
| sample_data | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sample_data.cs |
| sampledata | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sampledata.cs |
| SaveTrackDetails | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SaveTrackDetails.cs |
| Sceduler_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Sceduler_Types.cs |
| Scheduler_customization | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Scheduler_customization.cs |
| Scheduler_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Scheduler_Types.cs |
| AppointmentViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SchedulerAppointmentsViewModel.cs |
| Scheduling_Workday_Options | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Scheduling_Workday_Options.cs |
| Scrcubber | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Scrcubber.cs |
| Scrubber_Rejection | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Scrubber_Rejection.cs |
| Scrubber_Rejections | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Scrubber_Rejections.cs |
| ScrubberClaim | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ScrubberClaim.cs |
| ScrubberQueue | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ScrubberQueue.cs |
| ScrubberQueuetest | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ScrubberQueuetest.cs |
| Second_level_rejection | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Second_level_rejection.cs |
| Section | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Section.cs |
| SegmentType | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SegmentType.cs |
| SelectListViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SelectListViewModel.cs |
| sequence_of_care | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sequence_of_care.cs |
| Service_Logs | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Service_Logs.cs |
| Service_Type_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Service_Type_Codes.cs |
| Service_Type_Codes_Description | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Service_Type_Codes_Description.cs |
| Shift | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Shift.cs |
| showprovidercptplan | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/showprovidercptplan.cs |
| Source_of_Admission | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Source_of_Admission.cs |
| SP_AGINGCOMPDEMO_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_AGINGCOMPDEMO_Result.cs |
| SP_AGINGDEMO_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_AGINGDEMO_Result.cs |
| SP_AllPaymentSearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_AllPaymentSearch_Result.cs |
| SP_Appointment_Detail_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_Appointment_Detail_Report_Result.cs |
| SP_Claim_Batch_Exception_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_Claim_Batch_Exception_EDI_Result.cs |
| SP_Claim_Insurancebysearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_Claim_Insurancebysearch_Result.cs |
| SP_Claim_patientbysearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_Claim_patientbysearch_Result.cs |
| SP_ClaimInsuranceSearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ClaimInsuranceSearch_Result.cs |
| SP_ClaimPatientSearchnew_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ClaimPatientSearchnew_Result.cs |
| SP_ClaimsSearch_EDI_bkp_04112025_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ClaimsSearch_EDI_bkp_04112025_Result.cs |
| SP_ClaimsSearch_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ClaimsSearch_EDI_Result.cs |
| SP_CLAIMSUMMARYAMOUNTS_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_CLAIMSUMMARYAMOUNTS_Result.cs |
| SP_CountAssignedAccounts_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_CountAssignedAccounts_Result.cs |
| SP_CountAssignedclaims_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_CountAssignedclaims_Result.cs |
| SP_CPADEMO_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_CPADEMO_Result.cs |
| SP_ERAADJCODEGLOSSARY_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ERAADJCODEGLOSSARY_Result.cs |
| SP_ERAADJCODEGLOSSARY_VIEW_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ERAADJCODEGLOSSARY_VIEW_EDI_Result.cs |
| SP_ERACHECKDETAIL_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ERACHECKDETAIL_Result.cs |
| SP_ERAClaimCrossOver_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ERAClaimCrossOver_Result.cs |
| SP_ERACLAIMDETAIL_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ERACLAIMDETAIL_Result.cs |
| SP_ERACLAIMDETAIL_VIEW_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ERACLAIMDETAIL_VIEW_EDI_Result.cs |
| SP_ERASEARCH_MAN_IMP_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ERASEARCH_MAN_IMP_Result.cs |
| SP_ERASEARCH_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ERASEARCH_Result.cs |
| SP_FacilitiesSearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_FacilitiesSearch_Result.cs |
| sp_get999Report_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sp_get999Report_EDI_Result.cs |
| SP_GETAGINGDASHBOARD_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GETAGINGDASHBOARD_Result.cs |
| SP_GETAGINGDASHBOARD_Tets_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GETAGINGDASHBOARD_Tets_Result.cs |
| SP_GetAllAssignedClaimForusers_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetAllAssignedClaimForusers_Result.cs |
| SP_GetBatchDetail1_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetBatchDetail1_Result.cs |
| SP_GetBatchDetail_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetBatchDetail_EDI_Result.cs |
| SP_GetBatchDetail_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetBatchDetail_Result.cs |
| sp_getBatchHistory_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sp_getBatchHistory_EDI_Result.cs |
| sp_getBatchHistory_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sp_getBatchHistory_Result.cs |
| SP_GetClaimById_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetClaimById_Result.cs |
| SP_GetClaimPaymentDetail_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetClaimPaymentDetail_Result.cs |
| SP_GetClaimPaymentDetail_Updated_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetClaimPaymentDetail_Updated_Result.cs |
| SP_GetClaimsListByDOS1_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetClaimsListByDOS1_Result.cs |
| SP_getcptplanlist_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_getcptplanlist_Result.cs |
| Sp_GetCSIBatchStatusMedicare_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Sp_GetCSIBatchStatusMedicare_Result.cs |
| SP_GetInsuranceInfo_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetInsuranceInfo_Result.cs |
| SP_GETPATIENTBDAYS_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GETPATIENTBDAYS_Result.cs |
| SP_GETPERIODANALYSISANDCLOSING_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GETPERIODANALYSISANDCLOSING_Result.cs |
| SP_GETPRACTICEANALYSIS_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GETPRACTICEANALYSIS_Result.cs |
| SP_getpraticedataforCPTPlan_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_getpraticedataforCPTPlan_Result.cs |
| SP_GetProviderCPTPlan_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetProviderCPTPlan_Result.cs |
| SP_GetProviderCPTPlanID_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetProviderCPTPlanID_Result.cs |
| SP_GETRECALLVISITS_EGD_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GETRECALLVISITS_EGD_Result.cs |
| sp_GetScrubberRejectionReportDetailes_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sp_GetScrubberRejectionReportDetailes_Result.cs |
| sp_GetScrubberRejectionReports_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sp_GetScrubberRejectionReports_Result.cs |
| SP_GetSpecificClaiminfo_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetSpecificClaiminfo_Result.cs |
| SP_GetStandardCPTs_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetStandardCPTs_Result.cs |
| SP_GetStandardCPTSByPracticeState_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetStandardCPTSByPracticeState_Result.cs |
| SP_GetUserAuthorization_Hamza_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetUserAuthorization_Hamza_Result.cs |
| SP_GetUserAuthorization_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GetUserAuthorization_Result.cs |
| SP_getuserDailyReport_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_getuserDailyReport_Result.cs |
| SP_GUARANTORSEARCH_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_GUARANTORSEARCH_Result.cs |
| SP_InsFacilityInfoWithoutModifierAndProcedure_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsFacilityInfoWithoutModifierAndProcedure_Result.cs |
| SP_InsFacilityPlan_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsFacilityPlan_Result.cs |
| SP_InsLocationPlan_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsLocationPlan_Result.cs |
| SP_InsLocationWithoutModifierAndProcedure_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsLocationWithoutModifierAndProcedure_Result.cs |
| SP_InsPayer_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsPayer_Result.cs |
| SP_InsPayerWithoutModifierAndProcedure_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsPayerWithoutModifierAndProcedure_Result.cs |
| SP_InsStatePlan_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsStatePlan_Result.cs |
| SP_InsStateWithoutModifierAndProcedure_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsStateWithoutModifierAndProcedure_Result.cs |
| sp_insuranceardetailreport_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sp_insuranceardetailreport_Result.cs |
| SP_InsuranceSearch_BK_11082018_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsuranceSearch_BK_11082018_Result.cs |
| SP_InsuranceSearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_InsuranceSearch_Result.cs |
| SP_Missing_Appointment_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_Missing_Appointment_Report_Result.cs |
| SP_NDCSEARCH_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_NDCSEARCH_Result.cs |
| SP_NDCSEARCHBySearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_NDCSEARCHBySearch_Result.cs |
| SP_NDCSEARCHBySearchCriteria_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_NDCSEARCHBySearchCriteria_Result.cs |
| SP_PassedClaimsSearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PassedClaimsSearch_Result.cs |
| SP_PassedClaimsSearch_Result1 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PassedClaimsSearch_Result1.cs |
| SP_PATIENTAPPSEARCH_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PATIENTAPPSEARCH_Result.cs |
| SP_PatientDueForTicketTracker_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PatientDueForTicketTracker_Result.cs |
| SP_PATIENTINSSERACH_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PATIENTINSSERACH_Result.cs |
| SP_PatientSearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PatientSearch_Result.cs |
| SP_PATIENTSTATEMENTCOUNT_BYCLAIM_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PATIENTSTATEMENTCOUNT_BYCLAIM_Result.cs |
| SP_PATIENTSTATEMENTCOUNT_PIRUBAID_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PATIENTSTATEMENTCOUNT_PIRUBAID_Result.cs |
| SP_PATIENTSTATEMENTCOUNT_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PATIENTSTATEMENTCOUNT_Result.cs |
| SP_PATSTATEMENT_CLAIMSUMMARY_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PATSTATEMENT_CLAIMSUMMARY_Result.cs |
| SP_PaymentCreatiaForSreach_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PaymentCreatiaForSreach_Result.cs |
| SP_PaymentSearchlistfinal_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PaymentSearchlistfinal_Result.cs |
| SP_PaymentSearchlistnew_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PaymentSearchlistnew_Result.cs |
| SP_PRACTICEPROVIDERPAYERSEARCH_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PRACTICEPROVIDERPAYERSEARCH_Result.cs |
| SP_ProcedureSearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ProcedureSearch_Result.cs |
| sp_provider_working_times_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/sp_provider_working_times_Result.cs |
| SP_ProviderInfo_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ProviderInfo_Result.cs |
| SP_PROVIDERPAYERSEARCH_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_PROVIDERPAYERSEARCH_Result.cs |
| SP_ProviderPlan_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ProviderPlan_Result.cs |
| SP_ProviderWithoutModifierAndProcedure_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_ProviderWithoutModifierAndProcedure_Result.cs |
| SP_Search_Claim_Batch_Error_EDI_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_Search_Claim_Batch_Error_EDI_Result.cs |
| SP_Search_Claim_Batch_Error_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_Search_Claim_Batch_Error_Result.cs |
| SP_SearchCredApp_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_SearchCredApp_Result.cs |
| SP_SearchCredEdiEraApp_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_SearchCredEdiEraApp_Result.cs |
| SP_SearchProviderCPTFeePlan_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_SearchProviderCPTFeePlan_Result.cs |
| SP_SelectAllPracticeUsers_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_SelectAllPracticeUsers_Result.cs |
| SP_userReportCharges_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_userReportCharges_Result.cs |
| SP_userReportChargesNewPMOSB_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SP_userReportChargesNewPMOSB_Result.cs |
| SPAppChkEligibility_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SPAppChkEligibility_Result.cs |
| SPDataModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SPDataModel.cs |
| SpecialInstructionViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SpecialInstructionViewModel.cs |
| Specialization | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Specialization.cs |
| Specialty_Category | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Specialty_Category.cs |
| Specialty_Groups | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Specialty_Groups.cs |
| spGetAllClaimsInQueue_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetAllClaimsInQueue_Result.cs |
| spGetAllCleanClaims_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetAllCleanClaims_Result.cs |
| spGetAllViolations_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetAllViolations_Result.cs |
| spGetBatchClaimsDiagnosis_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsDiagnosis_Result.cs |
| spGetBatchClaimsInfo_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsInfo_Result.cs |
| spGetBatchClaimsInsurancesInfo_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsInsurancesInfo_Result.cs |
| spGetBatchClaimsProcedures_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsProcedures_Result.cs |
| spGetBatchClaimsProcedurestest_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsProcedurestest_Result.cs |
| spGetBatchClaimsProviderPayers_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsProviderPayers_Result.cs |
| spGetBatchCompanyDetails_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetBatchCompanyDetails_Result.cs |
| spGetCleanClaims_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetCleanClaims_Result.cs |
| spGetFailedClaims_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetFailedClaims_Result.cs |
| spGetFailedClaimsFromScrubber_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/spGetFailedClaimsFromScrubber_Result.cs |
| SPS_Reason | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SPS_Reason.cs |
| SS_abn_codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SS_abn_codes.cs |
| STANDARD_CPT_FEE | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/STANDARD_CPT_FEE.cs |
| State | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/State.cs |
| state_lookup | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/state_lookup.cs |
| state_x_consortium | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/state_x_consortium.cs |
| state_x_region | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/state_x_region.cs |
| StatementMessage | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/StatementMessage.cs |
| StatmentDownloadRequestModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/StatmentDownloadRequestModel.cs |
| Stc | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Stc.cs |
| student | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/student.cs |
| Sub_Module | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Sub_Module.cs |
| Submission_plan | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Submission_plan.cs |
| submission_Plan_bkp | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/submission_Plan_bkp.cs |
| Submission_Schedual | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Submission_Schedual.cs |
| submission_servers | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/submission_servers.cs |
| SUBMISSION_SETUP | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SUBMISSION_SETUP.cs |
| SubmissionMethod | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SubmissionMethod.cs |
| submissionPlan | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/submissionPlan.cs |
| Superbill_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Superbill_Types.cs |
| SyncedClaim | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SyncedClaim.cs |
| SyncedClaimCharge | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SyncedClaimCharge.cs |
| SyncedClaimPayment | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SyncedClaimPayment.cs |
| SyncedPatient | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SyncedPatient.cs |
| SyncedPractice | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SyncedPractice.cs |
| SyncedPracticeLocation | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SyncedPracticeLocation.cs |
| SyncedProvider | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SyncedProvider.cs |
| SyncExcludedPractice | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/SyncExcludedPractice.cs |
| Table_test | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Table_test.cs |
| TableIdCounter | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TableIdCounter.cs |
| Tableidcounter_bkp_03212024 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Tableidcounter_bkp_03212024.cs |
| TASK | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TASK.cs |
| TASK_CATEGORIES | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TASK_CATEGORIES.cs |
| task_data_dump_cpt | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/task_data_dump_cpt.cs |
| Taxonomy_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Taxonomy_Codes.cs |
| Taxonomy_CodesUpdat | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Taxonomy_CodesUpdat.cs |
| Team | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Team.cs |
| TEAM_SUPERVISORS | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TEAM_SUPERVISORS.cs |
| TeamViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TeamViewModel.cs |
| tem | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/tem.cs |
| tem1 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/tem1.cs |
| TESTEDIT_03 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TESTEDIT_03.cs |
| Ticket | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ticket.cs |
| Ticket_attachments | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ticket_attachments.cs |
| Ticket_Patient_Claims_Info | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ticket_Patient_Claims_Info.cs |
| Ticket_Priority | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ticket_Priority.cs |
| Ticket_Reason | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ticket_Reason.cs |
| Ticket_Tracking | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ticket_Tracking.cs |
| Ticket_Type | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Ticket_Type.cs |
| TicketAssignmentDetails | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TicketAssignmentDetails.cs |
| TicketAssignmentRequest | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TicketAssignmentRequest.cs |
| TicketMessageDetail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TicketMessageDetail.cs |
| TicketSearchModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TicketSearchModel.cs |
| Tickettracker | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Tickettracker.cs |
| TIME_SLOT_ASSIGNED_REASONS | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TIME_SLOT_ASSIGNED_REASONS.cs |
| todoItem | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/todoItem.cs |
| TokenRequestModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TokenViewModel.cs |
| TPA_Name_List | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TPA_Name_List.cs |
| Transact | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Transact.cs |
| Transaction_Set_Rejected_Response | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Transaction_Set_Rejected_Response.cs |
| TreeViewItem | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TreeViewItem.cs |
| TWO_FACTOR_AUTHORAZITION | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/TWO_FACTOR_AUTHORAZITION.cs |
| Type_Of_Admission | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Type_Of_Admission.cs |
| Type_of_Care | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Type_of_Care.cs |
| Type_of_facility | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Type_of_facility.cs |
| Type_Of_Services | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Type_Of_Services.cs |
| Unapplied_Payments | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Unapplied_Payments.cs |
| UnappliedPaymentReportModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/UnappliedPaymentReportModel.cs |
| UnappliedReportResponse | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/UnappliedReportResponse.cs |
| ClaimDetails | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/unpostedModel.cs |
| UrduStatements2 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/UrduStatements2.cs |
| US_Holidays | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/US_Holidays.cs |
| User | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/User.cs |
| User_era_request | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/User_era_request.cs |
| User_Group | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/User_Group.cs |
| UserCrud | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/UserCrud.cs |
| userdetail | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/userdetail.cs |
| ModuleViewModel | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/UserManagementViewModel.cs |
| Users_Module_Properties | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Users_Module_Properties.cs |
| Users_Module_Properties_bkp20230821 | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Users_Module_Properties_bkp20230821.cs |
| Users_Practice_Provider | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Users_Practice_Provider.cs |
| Users_Roles | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Users_Roles.cs |
| Users_RS2F_OTP | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Users_RS2F_OTP.cs |
| Users_Settings | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Users_Settings.cs |
| UsersLog | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/UsersLog.cs |
| UsertaskAssigned | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/UsertaskAssigned.cs |
| USP | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP.cs |
| USP_Batch_Payment_Details_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Batch_Payment_Details_Report_Result.cs |
| USP_Charge_Breakdown_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Charge_Breakdown_Result.cs |
| USP_CheckMedicareClaim_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_CheckMedicareClaim_Result.cs |
| USP_COLLECTION_ANALYSIS_REPORT_NPM_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_COLLECTION_ANALYSIS_REPORT_NPM_Result.cs |
| USP_Denial_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Denial_Report_Result.cs |
| USP_ERAClaimOverPayment_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_ERAClaimOverPayment_Result.cs |
| USP_Get_Batch_ClaimDetails_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Get_Batch_ClaimDetails_Result.cs |
| USP_Get_ImportWizard_Log_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| USP_Get_Practice_Docs_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Get_Practice_Docs_Result.cs |
| USP_Get_Provider_Docs_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Get_Provider_Docs_Result.cs |
| usp_GetAutoBatchSkippedClaims_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/usp_GetAutoBatchSkippedClaims_Result.cs |
| USP_GetBatchPayments_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_GetBatchPayments_Result.cs |
| USP_GetCredPortal_By_PracticeCode_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_GetCredPortal_By_PracticeCode_Result.cs |
| USP_GetOfficeTimeForProvidersAndLocations_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_GetOfficeTimeForProvidersAndLocations_Result.cs |
| usp_GetPracticeReportingDetails_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/usp_GetPracticeReportingDetails_Result.cs |
| USP_GetTickets_WithFilters_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_GetTickets_WithFilters_Result.cs |
| usp_GetTicketsWithFilters_Anum_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/usp_GetTicketsWithFilters_Anum_Result.cs |
| USP_NEGATIVE_BALANCE_REPORT_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_NEGATIVE_BALANCE_REPORT_Result.cs |
| USP_NPM_CREDIT_BALANCE_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_NPM_CREDIT_BALANCE_Result.cs |
| USP_NPM_PLAN_AGING_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_NPM_PLAN_AGING_Result.cs |
| USP_PATIENT_AGING_REPORT_NPM_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_PATIENT_AGING_REPORT_NPM_Result.cs |
| USP_Patient_Wise_Aging_Summary_Report_NPM_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Patient_Wise_Aging_Summary_Report_NPM_Result.cs |
| USP_Search_Insurances_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Search_Insurances_Result.cs |
| USP_Unapplied_Payment_Details_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Unapplied_Payment_Details_Report_Result.cs |
| USP_Visit_Claim_Activity_Report_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USP_Visit_Claim_Activity_Report_Result.cs |
| USPGetAlertAgainst_PAT_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/USPGetAlertAgainst_PAT_Result.cs |
| uspGetAllPaymentbySearch_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/uspGetAllPaymentbySearch_Result.cs |
| uspGetBatchClaimsProviderPayers_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/uspGetBatchClaimsProviderPayers_Result.cs |
| uspGetBatchClaimsProviderPayersDataFromUSP_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/uspGetBatchClaimsProviderPayersDataFromUSP_Result.cs |
| uspGetClaimAttachments_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/uspGetClaimAttachments_Result.cs |
| uspGetPatientAttachments_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/uspGetPatientAttachments_Result.cs |
| UTBL_EnrollmentTracker | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/UTBL_EnrollmentTracker.cs |
| ValidateInsGroupDeletion_Result | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/ValidateInsGroupDeletion_Result.cs |
| Value_Added_Services | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Value_Added_Services.cs |
| Value_Codes | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Value_Codes.cs |
| VAS_Types | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/VAS_Types.cs |
| Vendor | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Vendor.cs |
| AccountAssigneeResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/AccountAssigneeResponse.cs |
| AddInsuranceRequest | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/AddInsuranceRequest.cs |
| AppointmentsSearchViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/AppointmentsSearchViewModel.cs |
| PracticeAppointmentStatusCreateVM | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/AppointmentStatusCreateViewModel.cs |
| AuditLogEntry | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/AuditLogEntry.cs |
| BatchErrorsRequestModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/BatchErrorsRequestModel.cs |
| BatchesHistoryRequestModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/BatchesHistoryRequestModel.cs |
| ChargesBreakdownReportResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ChargesBreakdownReportResponse.cs |
| ClaimPaymentsDetailRequest | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ClaimPaymentsDetailRequest.cs |
| ClaimsDetail | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ClaimsDetail.cs |
| ClaimSubmissionResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ClaimSubmissionResponse.cs |
| ColorChangeModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ColorChangeModel.cs |
| CreateAttachmentRequest | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CreateAttachmentRequest.cs |
| CreateManualERARequest | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CreateManvalERARequest.cs |
| Cred_App_ViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Cred_App_ViewModel.cs |
| Cred_Hospital_Status_Report | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Cred_Hospital_Status_Report.cs |
| CredAppDocumentRequest | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CredAppDocumentRequest.cs |
| CredAppDocumentViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CredAppDocumentViewModel.cs |
| CredAppNoteViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CredAppNoteViewModel.cs |
| CredAppSearchViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CredAppSearchViewModel.cs |
| CredEDIERALookupLists | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CredEDIERALookupLists.cs |
| CredentialingLookupLists | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CredentialingLookupLists.cs |
| CredentialingTasksViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/CredentialingTasksViewModel.cs |
| Credit_BR_Response | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Credit_BR_Response.cs |
| Denial_Report_Response | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Denial_Report_Response.cs |
| DXViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/DXViewModel.cs |
| EDI_ERA_EFT_Grid_Report | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/EDI_ERA_EFT_Grid_Report.cs |
| EDI_ERA_EFT_Report | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/EDI_ERA_EFT_Report.cs |
| EDIERANotesViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/EDIERANotesViewModel.cs |
| EdiEraSetupSearchViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/EdiEraSetupSearchViewModel.cs |
| DoInquiryByX12DataModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/EligibilityModels.cs |
| ERASearchRequestModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ERASearchRequestModel.cs |
| EraSummaryRequest | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/EraSummaryRequest.cs |
| ExcelFieldsViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ExcelFieldsViewModel.cs |
| GetTicketsWithFiltersResult | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/GetTicketsWithFiltersResult.cs |
| Hospital_Grid_Report | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Hospital_Grid_Report.cs |
| InsuranceDetailReportResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/InsuranceDetailReportResponse.cs |
| InsurancePaymentRequestModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/InsurancePaymentRequestModel.cs |
| NDCModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/NDCModel.cs |
| NDCViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/NDCViewModel.cs |
| NegativeBalanceReportResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/NegativeBalanceReportResponse.cs |
| ObjTypeViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ObjTypeViewModel.cs |
| Patient_ASR_Response | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Pateint_ASR_Responsecs.cs |
| PatientBirthDaysReportResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PatientBirthDaysReportResponse.cs |
| PatientBirthDaysResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PatientBirthDaysResponse.cs |
| PatientNoteViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PatientNoteViewModel.cs |
| Payment_detail_Proc_Response | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Payment_detail_Proc_Response.cs |
| PaymentDetailResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PaymentDetailResponse.cs |
| PaymentsSearchRequestModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PaymentsSearchRequestModel.cs |
| Plan_Aging_Response | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Plan_Aging_Response.cs |
| PracticeAppointmentReasonCreateVM | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PracticeAppointmentReasonCreateVM.cs |
| PracticeAppointmentStatusViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PracticeAppointmentStatusViewModel.cs |
| PracticeDocuments_ViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PracticeDocuments_ViewModel.cs |
| PracticeDxModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PracticeDxModel.cs |
| PracticeFTPViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PracticeFTPViewModel.cs |
| PracticeSynchronizationModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/PracticeSynchronizationModel.cs |
| ProviderAppointmentRuleViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ProviderAppointmentRuleViewModel.cs |
| ProviderDocuments_ViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ProviderDocuments_ViewModel.cs |
| ProvidersByPracticeResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ProvidersByPracticeResponse.cs |
| ProviderSchedulesViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ProviderSchedulesViewModel.cs |
| ProviderWorkingDayTimeViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ProviderWorkingDayTimeViewModel.cs |
| RegenerateBatchFileRequestModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/RegenerateBatchFileRequestModel.cs |
| ReportRequestModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ReportRequestModel.cs |
| ScrubberReportResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ScrubberReportResponse.cs |
| SlotAvailabilityRequestVM | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/SlotAvailabilityCheckVM.cs |
| SMTPConfigModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/SMTPConfigModel.cs |
| SP_Cred_App_Report_Result | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/SP_Cred_App_Report_Result.cs |
| TaskAssignmentClaimList | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/TaskAssignmentClaimList.cs |
| Ticket_Patient_Claims_Info_ViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/Ticket_Patient_Claims_Info_ViewModel.cs |
| TicketTrackerLookups | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/TicketTrackerLookups.cs |
| TimingSearchViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/TimingSearchViewModel.cs |
| UnappliedPaymentViewModel | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/UnappliedPaymentViewModel.cs |
| userDailyReportResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/userDailyReportResponse.cs |
| UserEmailOptions | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/UserEmailOptions.cs |
| UserList | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/UserList.cs |
| UserViewDto | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/UserViewDto.cs |
| USP_Credentialing_Grid_Report_Result | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/USP_Credentialing_Grid_Report_Result.cs |
| usp_GetTicketsWithFilters_Result | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/usp_GetTicketsWithFilters_Result.cs |
| USP_NPM_PATIENT_AGING_Result | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/USP_NPM_PATIENT_AGING_Result.cs |
| ViewERASummaryRequest | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/ViewERASummaryRequest.cs |
| VisitClaimActivityReportResponse | ViewModel/SP result DTO | NPM_API_BackUp/NPMAPI/Models/ViewModels/VisitClaimActivityReportResponse.cs |
| WCBRating | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/WCBRating.cs |
| WeekDay | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/WeekDay.cs |
| workerservice | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/workerservice.cs |
| XMLDOC | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/XMLDOC.cs |
| YourTableName | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/YourTableName.cs |
| Zip_City_State | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/Zip_City_State.cs |
| zip_state | EF/table model or DTO | NPM_API_BackUp/NPMAPI/Models/zip_state.cs |

## Stored Procedure / Function References

| Procedure/function token | Referenced in files |
| --- | --- |
| Aging_Comparison | NPM_API_BackUp/NPMAPI/Models/SP_AGINGCOMPDEMO_Result.cs |
| Aging_Payer | NPM_API_BackUp/NPMAPI/Models/ViewModels/NegativeBalanceReportResponse.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Aging_Payer_Type | NPM_API_BackUp/NPMAPI/Models/ViewModels/NegativeBalanceReportResponse.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Aging_Summary_Analysis_Report | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Aging_Summary_Analysis_Report_Patient | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Aging_Summary_Analysis_Report_Patient_Result | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_Analysis_Report_Patient_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Aging_Summary_Analysis_Report_Result | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_Analysis_Report_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Aging_Summary_Analysis_Reporting | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Aging_Summary_Analysis_Reporting_Result | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_Analysis_Reporting_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Aging_Summary_Top_5_Payers | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Aging_Summary_Top_5_Payers_Result | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_Top_5_Payers_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Aging_Summary_report_Top_5_Payers | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Aging_Summary_report_Top_5_Payers_Result | NPM_API_BackUp/NPMAPI/Models/Aging_Summary_report_Top_5_Payers_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Aging_from_Last_submission | NPM_API_BackUp/NPMAPI/Models/Claims_filling_limit.cs |
| Charges_Per_Unit | NPM_API_BackUp/NPMAPI/Models/CPTs_Ana_by_Report_Result.cs, NPM_API_BackUp/NPMAPI/Models/CPTs_Analysis_by_Report_Result.cs |
| Charges___ | NPM_API_BackUp/NPMAPI/Models/SP_CPADEMO_Result.cs |
| Charges_at_CPT_Level | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Charges_at_CPT_Level_Result | NPM_API_BackUp/NPMAPI/Models/Charges_at_CPT_Level_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Check_Bounce_Penalty | NPM_API_BackUp/NPMAPI/Models/PRACTICES_BKP_021619.cs, NPM_API_BackUp/NPMAPI/Models/Practice.cs, NPM_API_BackUp/NPMAPI/Models/Practice101100205152023_BKP.cs, NPM_API_BackUp/NPMAPI/Models/Practice2.cs, NPM_API_BackUp/NPMSyncWorker/Entities/Practice.cs, NPM_API_BackUp/NPMWorkers/Entitties/Practice.cs |
| Check_Date | NPM_API_BackUp/NPMAPI/Models/USP_Unapplied_Payment_Details_Report_Result.cs, NPM_API_BackUp/NPMAPI/Models/Unapplied_Payments.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Check_Duplicate_Blocking_Rule | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| Check_Duplicate_Blocking_Rule_Result | NPM_API_BackUp/NPMAPI/Models/Check_Duplicate_Blocking_Rule_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/ViewModels/SlotAvailabilityCheckVM.cs |
| Check_No | NPM_API_BackUp/NPMAPI/Models/BatchPaymentModel.cs, NPM_API_BackUp/NPMAPI/Models/CLAIM_PAYMENTSBKP20230817.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Payments.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06082023.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06092023.cs, NPM_API_BackUp/NPMAPI/Models/Payment_detail_Proc_Result.cs, NPM_API_BackUp/NPMAPI/Models/Payment_detail_Proctest_Result.cs, NPM_API_BackUp/NPMAPI/Models/UnappliedPaymentReportModel.cs |
| Check_Office_Timing | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| Check_Office_Timing_Result | NPM_API_BackUp/NPMAPI/Models/Check_Office_Timing_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Check_Requested_Practice_According_to_User_request | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Check_if_the_Maximum_Retry_Count_has_been_Reached_AND_ALSO_SMTP | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Claim_Amount | NPM_API_BackUp/NPMAPI/Models/usp_GetAutoBatchSkippedClaims_Result.cs |
| Claim_AmtDue | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_CL.cs, NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs, NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| Claim_AmtPaid | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_CL.cs, NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs, NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| Claim_AssigneeID | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_CL.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetAllAssignedClaimForusers_Result.cs, NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs, NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| Claim_AttendingPhysician | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_CL.cs, NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs, NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| Claim_Batch_Exceptions | NPM_API_BackUp/NPMAPI/Models/Claim_Batch_Exceptions.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Claim_BillingPhysician | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_CL.cs, NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs, NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| Claim_CSI_Status | NPM_API_BackUp/NPMAPI/Models/GetBatchClaimsDetails_Result.cs, NPM_API_BackUp/NPMAPI/Models/claim_batch_detail.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Claim_Charges | NPM_API_BackUp/NPMAPI/Models/ClaimChargesAdditionalFields.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Charges.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Charges_No_Mapped_Prop.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsViewModel.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| Claim_Charges_Id | NPM_API_BackUp/NPMAPI/Models/Fee_Plan_Update.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| Claim_Charges_Imported | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| Claim_Charges_Issues | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| Claim_Charges_Summary | NPM_API_BackUp/NPMAPI/Models/Claim_Charges_Summary.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Claim_Charges_Total | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| Claim_Claimtotal | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_CL.cs, NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs, NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| Claim_Count | NPM_API_BackUp/NPMAPI/Models/sp_getBatchHistory_EDI_Result.cs |
| Claim_DOS | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_CL.cs, NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs, NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs, NPM_API_BackUp/NPMAPI/Models/usp_GetAutoBatchSkippedClaims_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| Claim_Date | NPM_API_BackUp/NPMAPI/Models/Charges_at_CPT_Level_Result.cs, NPM_API_BackUp/NPMAPI/Models/Payments_at_CPT_Level_Result.cs |
| Claim_Document | NPM_API_BackUp/NPMAPI/Models/Claim_Document.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsAttachmentsService.cs, NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| Claim_Due | NPM_API_BackUp/NPMAPI/Models/GetTicketTrackDetail.cs, NPM_API_BackUp/NPMAPI/Models/Ticket_Patient_Claims_Info.cs, NPM_API_BackUp/NPMAPI/Models/Tickettracker.cs, NPM_API_BackUp/NPMAPI/Models/ViewModels/Ticket_Patient_Claims_Info_ViewModel.cs, NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| Claim_ID | NPM_API_BackUp/NPMAPI/Models/Charges_at_CPT_Level_Result.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Batch_Exceptions.cs, NPM_API_BackUp/NPMAPI/Models/Payments_at_CPT_Level_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Claim_Imported | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| Claim_Ins_Imported | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| Claim_Ins_Issues | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| Claim_Ins_Total | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| Claim_Insurance | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Insurance.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsViewModel.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| Claim_Insurance_Id | NPM_API_BackUp/NPMAPI/Models/Claim_Insurance.cs, NPM_API_BackUp/NPMAPI/Models/claim_insurance_06092023.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs, NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| Claim_Issues | NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| Claim_Last_Submission | NPM_API_BackUp/NPMAPI/Models/Claims_filling_limit.cs |
| Claim_NO | NPM_API_BackUp/NPMAPI/Models/CustomEditsError.cs, NPM_API_BackUp/NPMAPI/Models/CustomEditsErrors_jinnah.cs |
| Claim_No | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs, NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs, NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs, NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs, NPM_API_BackUp/NPMAPI/Models/AddressValidationViewModel.cs, NPM_API_BackUp/NPMAPI/Models/Admission_Details.cs, NPM_API_BackUp/NPMAPI/Models/BatchClaimsDetail.cs, NPM_API_BackUp/NPMAPI/Models/BatchPaymentResponse.cs |
| Claim_Notes_Id | NPM_API_BackUp/NPMAPI/Models/CLAIM_NOTES.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs, NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| Claim_Number | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs, NPM_API_BackUp/NPMAPI/Models/CSI_Batch.cs, NPM_API_BackUp/NPMAPI/Models/CSI_Batch_Response.cs, NPM_API_BackUp/NPMAPI/Models/GetCSI_BatchDetails_Result.cs, NPM_API_BackUp/NPMAPI/Models/ViewModels/ScrubberReportResponse.cs, NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsInfo_Result.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
| Claim_Numbers | NPM_API_BackUp/NPMAPI/Models/USP_GetTickets_WithFilters_Result.cs, NPM_API_BackUp/NPMAPI/Models/usp_GetTicketsWithFilters_Anum_Result.cs, NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| Claim_Overpayment | NPM_API_BackUp/NPMAPI/Models/Claim_Overpayment.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| Claim_Payments | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Payments.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsViewModel.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Repositories/IDemographicRepository.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| Claim_Payments_Id | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs, NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| Claim_Pos | NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsInfo_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Claim_Procedures_Id | NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsProcedures_Result.cs, NPM_API_BackUp/NPMAPI/Models/spGetBatchClaimsProcedurestest_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Claim_Provider_Diagnosis_Proc | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| Claim_Provider_Diagnosis_Proc_Result | NPM_API_BackUp/NPMAPI/Models/Claim_Provider_Diagnosis_Proc_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| Claim_RMK_code | NPM_API_BackUp/NPMAPI/Models/ERACLAIMINFO.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERACLAIMDETAIL_Result.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERACLAIMDETAIL_VIEW_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Claim_Reasons | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| Claim_Rsn | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| Claim_Status | NPM_API_BackUp/NPMAPI/Models/CLAIMS_SUBMITTED.cs, NPM_API_BackUp/NPMAPI/Models/Claim.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsDetail.cs, NPM_API_BackUp/NPMAPI/Models/Claims_06082023.cs, NPM_API_BackUp/NPMAPI/Models/Claims_06092023.cs, NPM_API_BackUp/NPMAPI/Models/ViewModels/ClaimsDetail.cs, NPM_API_BackUp/NPMAPI/Models/claim_bkp.cs, NPM_API_BackUp/NPMAPI/Models/claims_bkp20230925.cs |
| Claim_Status_Category_Code | NPM_API_BackUp/NPMAPI/Models/Patients_Data.cs |
| Claim_Status_Code | NPM_API_BackUp/NPMAPI/Models/Patients_Data.cs |
| Claim_Status_Codes | NPM_API_BackUp/NPMAPI/Models/Claim_Status_Codes.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Claim_Status_Date | NPM_API_BackUp/NPMAPI/Models/Claim.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsDetail.cs, NPM_API_BackUp/NPMAPI/Models/Claims_06082023.cs, NPM_API_BackUp/NPMAPI/Models/Claims_06092023.cs, NPM_API_BackUp/NPMAPI/Models/ViewModels/ClaimsDetail.cs, NPM_API_BackUp/NPMAPI/Models/claim_bkp.cs, NPM_API_BackUp/NPMAPI/Models/claims_bkp20230925.cs, NPM_API_BackUp/NPMAPI/Models/claims_bkp_10012019.cs |
| Claim_Status_Request | NPM_API_BackUp/NPMAPI/Models/Claim_Insurance.cs, NPM_API_BackUp/NPMAPI/Models/claim_insurance_06092023.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| Claim_Total | NPM_API_BackUp/NPMAPI/Models/AddressValidationViewModel.cs, NPM_API_BackUp/NPMAPI/Models/CLAIMS_SUBMITTED.cs, NPM_API_BackUp/NPMAPI/Models/Claim.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsDetail.cs, NPM_API_BackUp/NPMAPI/Models/Claims_06082023.cs, NPM_API_BackUp/NPMAPI/Models/Claims_06092023.cs, NPM_API_BackUp/NPMAPI/Models/Claims_filling_limit.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetAllAssignedClaimForusers_Result.cs |
| Claim_Type | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs, NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs, NPM_API_BackUp/NPMAPI/Models/Claim.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsDetail.cs, NPM_API_BackUp/NPMAPI/Models/GetRecentClaimDetailsWithDiagnosis_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/ViewModels/ClaimsDetail.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| Claim_Worker_Injurycase | NPM_API_BackUp/NPMAPI/Models/Claim_Worker_Injurycase.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Claim_id | NPM_API_BackUp/NPMAPI/Models/ISA_Identifier.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| Claim_no | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs, NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsViewModel.cs, NPM_API_BackUp/NPMAPI/Models/Claims_ICD10DX.cs, NPM_API_BackUp/NPMAPI/Models/Claims_Occurrence_Code.cs, NPM_API_BackUp/NPMAPI/Models/Claims_filling_limit.cs, NPM_API_BackUp/NPMAPI/Models/MIS_TBL_Corrected_Claim_Reason.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetAllAssignedClaimForusers_Result.cs |
| Claim_notes | NPM_API_BackUp/NPMAPI/Models/ClaimAssignee_Notes.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetAllAssignedClaimForusers_Result.cs, NPM_API_BackUp/NPMAPI/Models/claimassigneeModel.cs, NPM_API_BackUp/NPMAPI/Models/editassignedclaimModel.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| Claim_payment_Id | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_CPT_Reason.cs |
| Claim_total | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| Claim_type | NPM_API_BackUp/NPMAPI/Models/ClaimBatchViewModels.cs, NPM_API_BackUp/NPMAPI/Models/SP_ClaimsSearch_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Models/SP_ClaimsSearch_EDI_bkp_04112025_Result.cs, NPM_API_BackUp/NPMAPI/Models/USP_Get_Batch_ClaimDetails_Result.cs, NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| EFS_AC_Ratio | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs |
| EFS_Adjusted | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs |
| EFS_Approved | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs |
| EFS_BeqApp_Ratio | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs |
| EFS_BillEqApp | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs |
| EFS_Billed | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs |
| EFS_ImpactSummary | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| EFS_PC_Ratio | NPM_API_BackUp/NPMAPI/Models/EFS_ImpactSummary.cs |
| EFS_PracID | NPM_API_BackUp/NPMAPI/Models/EFS_Practices.cs |
| EFS_Practices | NPM_API_BackUp/NPMAPI/Models/EFS_Practices.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| EFS_Suggested | NPM_API_BackUp/NPMAPI/Models/EFS_Suggested.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| ERA_ADJUSTMENT_CODE | NPM_API_BackUp/NPMAPI/Models/CLAIM_PAYMENTSBKP20230817.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Payments.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06082023.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06092023.cs, NPM_API_BackUp/NPMAPI/Models/DataModel.cs, NPM_API_BackUp/NPMAPI/Models/FINAL2.cs, NPM_API_BackUp/NPMAPI/Models/claim_paymentsbkp20230818.cs, NPM_API_BackUp/NPMAPI/Models/claim_paymenttets.cs |
| ERA_ADJUSTMENT_MAPPING_BKP_012721 | NPM_API_BackUp/NPMAPI/Models/ERA_ADJUSTMENT_MAPPING_BKP_012721.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| ERA_Adjustment_Mapping | NPM_API_BackUp/NPMAPI/Models/ERA_Adjustment_Mapping.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| ERA_AppDate | NPM_API_BackUp/NPMAPI/Models/ViewModels/EDI_ERA_EFT_Report.cs |
| ERA_CATEGORY_CODE | NPM_API_BackUp/NPMAPI/Models/CLAIM_PAYMENTSBKP20230817.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Payments.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06082023.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06092023.cs, NPM_API_BackUp/NPMAPI/Models/DataModel.cs, NPM_API_BackUp/NPMAPI/Models/FINAL2.cs, NPM_API_BackUp/NPMAPI/Models/claim_paymentsbkp20230818.cs, NPM_API_BackUp/NPMAPI/Models/claim_paymenttets.cs |
| ERA_Download_and_Dump_Process | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs, NPM_API_BackUp/NPMAPI/Repositories/IERAImport.cs, NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| ERA_EFT_STATUS | NPM_API_BackUp/NPMAPI/Models/Provider_Payers.cs, NPM_API_BackUp/NPMAPI/Models/provider_payerTEST.cs |
| ERA_EffDate | NPM_API_BackUp/NPMAPI/Models/ViewModels/EDI_ERA_EFT_Report.cs |
| ERA_NextFollowUp | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| ERA_PLB_CODE | NPM_API_BackUp/NPMAPI/Models/ERA_PLB_CODE.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| ERA_Payment | NPM_API_BackUp/NPMAPI/Models/USP_GetBatchPayments_Result.cs |
| ERA_Rejection_CATEGORY_CODE | NPM_API_BackUp/NPMAPI/Models/CLAIM_PAYMENTSBKP20230817.cs, NPM_API_BackUp/NPMAPI/Models/Claim_Payments.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06082023.cs, NPM_API_BackUp/NPMAPI/Models/ClaimsPayments_06092023.cs, NPM_API_BackUp/NPMAPI/Models/DataModel.cs, NPM_API_BackUp/NPMAPI/Models/claim_paymentsbkp20230818.cs, NPM_API_BackUp/NPMAPI/Models/claim_paymenttets.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| ERA_Request | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs, NPM_API_BackUp/NPMAPI/Models/ERA_Request.cs, NPM_API_BackUp/NPMAPI/Repositories/IERAImport.cs, NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| ERA_Status | NPM_API_BackUp/NPMAPI/Models/ViewModels/EDI_ERA_EFT_Report.cs |
| ERA_UNPOSTED_PAYMENTS_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| ERA_UNPOSTED_PAYMENTS_EDI_Result | NPM_API_BackUp/NPMAPI/Models/ERA_UNPOSTED_PAYMENTS_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Financial_Analysis_At_CPT_Level | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Financial_Analysis_At_CPT_Level_Result | NPM_API_BackUp/NPMAPI/Models/Financial_Analysis_At_CPT_Level_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Financial_Analysis_by_Provider_and_Procedure_Codes | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Financial_Analysis_by_Provider_and_Procedure_Codes_Result | NPM_API_BackUp/NPMAPI/Models/Financial_Analysis_by_Provider_and_Procedure_Codes_Result.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| Financial_Guarantor | NPM_API_BackUp/NPMAPI/Models/PaTIENT_BKP_01142022.cs, NPM_API_BackUp/NPMAPI/Models/Patient.cs, NPM_API_BackUp/NPMAPI/Models/PatientDemographicViewModel.cs, NPM_API_BackUp/NPMAPI/Models/Patient_Updated.cs, NPM_API_BackUp/NPMAPI/Models/patient_bkp11282018.cs, NPM_API_BackUp/NPMAPI/Models/patient_bkp_11282018.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| Financial_Guarantor_Name | NPM_API_BackUp/NPMAPI/Models/PaTIENT_BKP_01142022.cs, NPM_API_BackUp/NPMAPI/Models/Patient.cs, NPM_API_BackUp/NPMAPI/Models/PatientDemographicViewModel.cs, NPM_API_BackUp/NPMAPI/Models/Patient_Updated.cs, NPM_API_BackUp/NPMAPI/Models/patient_bkp11282018.cs, NPM_API_BackUp/NPMAPI/Models/patient_bkp_11282018.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| Financial_Summary | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| Get_Current_Request | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Get_Current_Request_which_is_Inserted | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Get_CustomEdits_Colums | NPM_API_BackUp/NPMAPI/Models/Get_CustomEdits_Colums.cs |
| Get_FTP_According_requested_Practice_Code | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Get_List_Of_requests_which_are_in_process_And_with_Same_Practice_as_requested_user | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Get_Mail_stats | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Get_StatOfRequest_AND_Maintain_LOGS_If_no_new_Files_Found | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Get_StatsRequest_AND_Maintain_STATS | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Get_Stats_for_UI_if_no_PRacticeCodeFound | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| Get_UserERARequest | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| MIS_TBL_CPT_Reason | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_CPT_Reason.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| MIS_TBL_Corrected_Claim_Reason | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_Corrected_Claim_Reason.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| MIS_TBL_Institution_Condition_Code | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_Institution_Condition_Code.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| MIS_TBL_Insurance_Resources_Remarks | NPM_API_BackUp/NPMAPI/Models/MIS_TBL_Insurance_Resources_Remarks.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| NPM_API | NPM_API_BackUp/NPMAPI/Models/NPM.Designer.cs |
| SP_277CA_LinkingMessage | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_AGINGCOMPDEMO | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_AGINGCOMPDEMO_Result | NPM_API_BackUp/NPMAPI/Models/DashboardViewModel.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_AGINGCOMPDEMO_Result.cs |
| SP_AGINGDEMO | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_AGINGDEMO_Result | NPM_API_BackUp/NPMAPI/Models/DashboardViewModel.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_AGINGDEMO_Result.cs |
| SP_Aging_Papulated | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_AllPaymentSearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_AllPaymentSearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_AllPaymentSearch_Result.cs |
| SP_Appointment_Detail_Report | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_Appointment_Detail_Report_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_Appointment_Detail_Report_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_CLAIMSUMMARYAMOUNTS | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_CLAIMSUMMARYAMOUNTS_Hamza | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_CLAIMSUMMARYAMOUNTS_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_CLAIMSUMMARYAMOUNTS_Result.cs |
| SP_COSSCPABYADDCRT | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_CPADEMO | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_CPADEMO_Result | NPM_API_BackUp/NPMAPI/Models/DashboardViewModel.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_CPADEMO_Result.cs |
| SP_ChargesANDPaymentsTrend | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_ClaimInsuranceSearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_ClaimInsuranceSearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ClaimInsuranceSearch_Result.cs |
| SP_ClaimPatientSearchnew | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_ClaimPatientSearchnew_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ClaimPatientSearchnew_Result.cs |
| SP_Claim_Batch_Exception_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_Claim_Batch_Exception_EDI_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_Claim_Batch_Exception_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_Claim_Insurancebysearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SP_Claim_Insurancebysearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_Claim_Insurancebysearch_Result.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SP_Claim_patientbysearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SP_Claim_patientbysearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_Claim_patientbysearch_Result.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SP_ClaimsSearch | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ClaimsSearch_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ClaimsSearch_EDI_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ClaimsSearch_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ClaimsSearch_EDI_bkp_04112025 | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_ClaimsSearch_EDI_bkp_04112025_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ClaimsSearch_EDI_bkp_04112025_Result.cs |
| SP_ClaimsSearch_Result | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_CountAssignedAccounts | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| SP_CountAssignedAccounts_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_CountAssignedAccounts_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| SP_CountAssignedclaims | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| SP_CountAssignedclaims_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_CountAssignedclaims_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| SP_CreateProviderCPTPlanDetails | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_Cred_App_Report_Result | NPM_API_BackUp/NPMAPI/Models/ViewModels/SP_Cred_App_Report_Result.cs, NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| SP_Credentialing_Report | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| SP_Date_Of_Birth | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| SP_DeleteProviderPlainWithCPTS | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_EDIHistory | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| SP_ERAADJCODEGLOSSARY | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERAADJCODEGLOSSARY_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERAADJCODEGLOSSARY_Result.cs |
| SP_ERAADJCODEGLOSSARY_VIEW_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERAADJCODEGLOSSARY_VIEW_EDI_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERAADJCODEGLOSSARY_VIEW_EDI_Result.cs |
| SP_ERAAUTOPOST | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERACHECKDETAIL | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_ERACHECKDETAIL_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERACHECKDETAIL_Result.cs |
| SP_ERACLAIMDETAIL | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERACLAIMDETAIL_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERACLAIMDETAIL_Result.cs |
| SP_ERACLAIMDETAIL_VIEW_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERACLAIMDETAIL_VIEW_EDI_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERACLAIMDETAIL_VIEW_EDI_Result.cs |
| SP_ERACLAIMSAUTOPOST | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERAClaimCrossOver | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERAClaimCrossOver_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERAClaimCrossOver_Result.cs |
| SP_ERASEARCH | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERASEARCH_MAN_IMP | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_ERASEARCH_MAN_IMP_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERASEARCH_MAN_IMP_Result.cs |
| SP_ERASEARCH_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ERASEARCH_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_Employee_Id | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| SP_FacilitiesSearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_FacilitiesSearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_FacilitiesSearch_Result.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_First_Name | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| SP_GENERATEPATIENTSTATEMENT | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| SP_GENERATEPATIENTSTATEMENT_XML | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_GENERATEPATIENTSTATEMENT_bkp_091619 | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GETAGINGDASHBOARD | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GETAGINGDASHBOARD_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GETAGINGDASHBOARD_Result.cs |
| SP_GETAGINGDASHBOARD_Tets | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_GETAGINGDASHBOARD_Tets_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GETAGINGDASHBOARD_Tets_Result.cs |
| SP_GETChargesPaymentsLastMonthsTets | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_GETPATIENTBDAYS | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_GETPATIENTBDAYS_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GETPATIENTBDAYS_Result.cs |
| SP_GETPERIODANALYSISANDCLOSING | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_GETPERIODANALYSISANDCLOSING_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GETPERIODANALYSISANDCLOSING_Result.cs |
| SP_GETPRACTICEANALYSIS | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_GETPRACTICEANALYSIS_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GETPRACTICEANALYSIS_Result.cs |
| SP_GETRECALLVISITS_EGD | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_GETRECALLVISITS_EGD_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GETRECALLVISITS_EGD_Result.cs |
| SP_GUARANTORSEARCH | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_GUARANTORSEARCH_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GUARANTORSEARCH_Result.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_Gender | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| SP_GetAllAssignedClaimForusers | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetAllAssignedClaimForusers_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetAllAssignedClaimForusers_Result.cs |
| SP_GetBatchDetail | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_GetBatchDetail1 | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetBatchDetail1_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetBatchDetail1_Result.cs |
| SP_GetBatchDetail_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_GetBatchDetail_EDI_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetBatchDetail_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_GetBatchDetail_Paper | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_GetBatchDetail_Paper_Result | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_GetBatchDetail_Result | NPM_API_BackUp/NPMAPI/Models/ClaimBatchViewModels.cs, NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetBatchDetail_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_GetCPAAnalysis | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_GetClaimById | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetClaimById_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetClaimById_Result.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SP_GetClaimPaymentDetail | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetClaimPaymentDetail_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetClaimPaymentDetail_Result.cs |
| SP_GetClaimPaymentDetail_Updated | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetClaimPaymentDetail_Updated_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetClaimPaymentDetail_Updated_Result.cs |
| SP_GetClaimsListByDOS | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_GetClaimsListByDOS1 | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetClaimsListByDOS1_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetClaimsListByDOS1_Result.cs |
| SP_GetClaimsListByDOS_Result | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_GetInsuranceInfo | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_GetInsuranceInfo_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetInsuranceInfo_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_GetLocationState | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_GetParticipating | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_GetPricingModifier | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetProviderCPTPlan | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_GetProviderCPTPlanID | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_GetProviderCPTPlanID_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetProviderCPTPlanID_Result.cs |
| SP_GetProviderCPTPlanIDtemp | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetProviderCPTPlan_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetProviderCPTPlan_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_GetSpecificClaiminfo | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| SP_GetSpecificClaiminfo_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetSpecificClaiminfo_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| SP_GetStandardCPTSByPracticeState | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_GetStandardCPTSByPracticeState_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetStandardCPTSByPracticeState_Result.cs |
| SP_GetStandardCPTs | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_GetStandardCPTs_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetStandardCPTs_Result.cs |
| SP_GetUserAuthorization | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SP_GetUserAuthorization_Hamza_Result | NPM_API_BackUp/NPMAPI/Models/SP_GetUserAuthorization_Hamza_Result.cs |
| SP_GetUserAuthorization_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_GetUserAuthorization_Result.cs, NPM_API_BackUp/NPMAPI/Models/TokenViewModel.cs, NPM_API_BackUp/NPMAPI/Repositories/IUserManagementSetup.cs, NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
| SP_GetclaimbymultiIDS | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SP_GetclaimbymultiIDSforchecking | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| SP_Global277CAReport | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| SP_InsFacilityInfoWithoutModifierAndProcedure | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsFacilityInfoWithoutModifierAndProcedure_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsFacilityInfoWithoutModifierAndProcedure_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsFacilityPlan | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsFacilityPlan_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsFacilityPlan_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsLocationPlan | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsLocationPlan_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsLocationPlan_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsLocationWithoutModifierAndProcedure | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsLocationWithoutModifierAndProcedure_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsLocationWithoutModifierAndProcedure_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsPayer | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsPayerWithoutModifierAndProcedure | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsPayerWithoutModifierAndProcedure_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsPayerWithoutModifierAndProcedure_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsPayer_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsPayer_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsStatePlan | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsStatePlan_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsStatePlan_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsStateWithoutModifierAndProcedure | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsStateWithoutModifierAndProcedure_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsStateWithoutModifierAndProcedure_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_InsuranceSearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_InsuranceSearch_AfzalBahi | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_InsuranceSearch_BK_11082018 | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_InsuranceSearch_BK_11082018_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsuranceSearch_BK_11082018_Result.cs |
| SP_InsuranceSearch_N | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_InsuranceSearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_InsuranceSearch_Result.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_Last_Name | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| SP_Manual_ERS_MigrateDataToLiveServer | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| SP_Middle_Initial | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| SP_MigrateDataToLiveServer | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| SP_MigrateStats | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| SP_MigrateStats_same_prac | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| SP_Missing_Appointment_Report | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_Missing_Appointment_Report_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_Missing_Appointment_Report_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_NDCSEARCH | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_NDCSEARCHBySearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_NDCSEARCHBySearchCriteria | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_NDCSEARCHBySearchCriteria_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_NDCSEARCHBySearchCriteria_Result.cs |
| SP_NDCSEARCHBySearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_NDCSEARCHBySearch_Result.cs |
| SP_NDCSEARCH_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_NDCSEARCH_Result.cs |
| SP_Nic_Number | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| SP_PATIENTAPPSEARCH | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
| SP_PATIENTAPPSEARCH_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PATIENTAPPSEARCH_Result.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_PATIENTINSSERACH | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_PATIENTINSSERACH_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PATIENTINSSERACH_Result.cs |
| SP_PATIENTSEARCHDUP | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_PATIENTSTATEMENTCOUNT | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_PATIENTSTATEMENTCOUNT_BYCLAIM | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_PATIENTSTATEMENTCOUNT_BYCLAIM_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PATIENTSTATEMENTCOUNT_BYCLAIM_Result.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_PATIENTSTATEMENTCOUNT_PIRUBAID_Result | NPM_API_BackUp/NPMAPI/Models/SP_PATIENTSTATEMENTCOUNT_PIRUBAID_Result.cs |
| SP_PATIENTSTATEMENTCOUNT_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PATIENTSTATEMENTCOUNT_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_PATSTATEMENT_CLAIMSUMMARY | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_PATSTATEMENT_CLAIMSUMMARY_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PATSTATEMENT_CLAIMSUMMARY_Result.cs |
| SP_PCRatio | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_PRACTICEPROVIDERPAYERSEARCH | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SP_PRACTICEPROVIDERPAYERSEARCH_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PRACTICEPROVIDERPAYERSEARCH_Result.cs, NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SP_PROVIDERPAYERSEARCH | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SP_PROVIDERPAYERSEARCH_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PROVIDERPAYERSEARCH_Result.cs, NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| SP_PassedClaimsSearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_PassedClaimsSearch_Result | NPM_API_BackUp/NPMAPI/Models/SP_PassedClaimsSearch_Result.cs |
| SP_PassedClaimsSearch_Result1 | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PassedClaimsSearch_Result1.cs |
| SP_PatientDueForTicketTracker | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| SP_PatientDueForTicketTracker_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PatientDueForTicketTracker_Result.cs |
| SP_PatientSearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_PatientSearchNew | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_PatientSearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PatientSearch_Result.cs, NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_PatientSearch_bkp12262018 | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_PaymentCreatiaForSreach | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_PaymentCreatiaForSreach_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PaymentCreatiaForSreach_Result.cs |
| SP_PaymentSearchlistfinal | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_PaymentSearchlistfinal_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PaymentSearchlistfinal_Result.cs |
| SP_PaymentSearchlistnew | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_PaymentSearchlistnew_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_PaymentSearchlistnew_Result.cs |
| SP_ProcedureSearch | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_ProcedureSearch_BKP_Afzl | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_ProcedureSearch_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ProcedureSearch_Result.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_ProviderInfo | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_ProviderInfo_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ProviderInfo_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_ProviderPlan | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_ProviderPlan_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ProviderPlan_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_ProviderWithoutModifierAndProcedure | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_ProviderWithoutModifierAndProcedure_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_ProviderWithoutModifierAndProcedure_Result.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| SP_Relation | NPM_API_BackUp/NPMAPI/Models/EmployeeInformation.cs |
| SP_SearchCredApp | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| SP_SearchCredApp_Result | NPM_API_BackUp/NPMAPI/Models/SP_SearchCredApp_Result.cs, NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| SP_SearchCredEdiEraApp | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| SP_SearchCredEdiEraApp_Result | NPM_API_BackUp/NPMAPI/Models/SP_SearchCredEdiEraApp_Result.cs, NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| SP_SearchProviderCPTFeePlan | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_SearchProviderCPTFeePlan_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_SearchProviderCPTFeePlan_Result.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_Search_Claim_Batch_Error | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_Search_Claim_Batch_Error_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_Search_Claim_Batch_Error_EDI_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_Search_Claim_Batch_Error_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_Search_Claim_Batch_Error_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_Search_Claim_Batch_Error_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_SelectAllPracticeUsers | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| SP_SelectAllPracticeUsers_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_SelectAllPracticeUsers_Result.cs |
| SP_TableIdGenerator | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/AlertService.cs, NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsAttachmentsService.cs, NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/CompanyService.cs, NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs, NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| SP_TableIdGenerator_Test | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| SP_getcptplanlist | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_getcptplanlist_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_getcptplanlist_Result.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_getpraticedataforCPTPlan | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_getpraticedataforCPTPlan_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_getpraticedataforCPTPlan_Result.cs, NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| SP_getuserDailyReport | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_getuserDailyReport_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_getuserDailyReport_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_laim_Charges_Summary | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_rollingReport | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PDFService.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_showEDIHistory | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_showEDIHistory_bkp2 | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| SP_userReportCharges | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| SP_userReportChargesNewPMOSB | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| SP_userReportChargesNewPMOSB_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_userReportChargesNewPMOSB_Result.cs |
| SP_userReportCharges_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/SP_userReportCharges_Result.cs |
| UPDATE_TYPE | NPM_API_BackUp/NPMAPI/Models/Fee_Plan_Update.cs |
| USP_Batch_Payment_Details_Report | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Batch_Payment_Details_Report_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Batch_Payment_Details_Report_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_COLLECTION_ANALYSIS_REPORT_NPM | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_COLLECTION_ANALYSIS_REPORT_NPM_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_COLLECTION_ANALYSIS_REPORT_NPM_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Charge_Breakdown | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Charge_Breakdown_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Charge_Breakdown_Result.cs |
| USP_CheckMedicareClaim | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_CheckMedicareClaim_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_CheckMedicareClaim_Result.cs |
| USP_Credentialing_Grid_Report | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_Credentialing_Grid_Report_Result | NPM_API_BackUp/NPMAPI/Models/ViewModels/USP_Credentialing_Grid_Report_Result.cs, NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_Credentialing_Hospital_Status_Report | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_Credentialing_Tasks | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_Denial_Report | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Denial_Report_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Denial_Report_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_ERAClaimOverPayment | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_ERAClaimOverPayment_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_ERAClaimOverPayment_Result.cs |
| USP_GETCredUsersByRole | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_GETUsersListByRole | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_GET_EDI_ERA_EFT_Grid_Report | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| USP_GetBatchPayments | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| USP_GetBatchPayments_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_GetBatchPayments_Result.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| USP_GetCredPortal_By_PracticeCode | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_GetCredPortal_By_PracticeCode_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_GetCredPortal_By_PracticeCode_Result.cs, NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_GetCustomEditTable | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| USP_GetIssues_Excel_Export | NPM_API_BackUp/NPMAPI/Services/ImportWizardService.cs |
| USP_GetLatestSerialNumber | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_GetOfficeTimeForProvidersAndLocations | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| USP_GetOfficeTimeForProvidersAndLocations_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_GetOfficeTimeForProvidersAndLocations_Result.cs, NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| USP_GetPatientsWithDue | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
| USP_GetReasonId | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_GetReasonId_Result | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs, NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_GetTickets_WithFilters | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| USP_GetTickets_WithFilters_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_GetTickets_WithFilters_Result.cs, NPM_API_BackUp/NPMAPI/Services/TTService.cs |
| USP_Get_Batch_ClaimDetails | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_Get_Batch_ClaimDetails_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Get_Batch_ClaimDetails_Result.cs |
| USP_Get_Credentialing_Dashboard_Data | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_Get_EDI_ERA_EFT_Status_Report | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| USP_Get_ImportWizard_Log | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ImportWizardService.cs |
| USP_Get_ImportWizard_Log_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Get_ImportWizard_Log_Result.cs |
| USP_Get_ObjTypes_ByAppType | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_Get_Practice_Docs | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| USP_Get_Practice_Docs_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Get_Practice_Docs_Result.cs |
| USP_Get_Provider_Docs | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| USP_Get_Provider_Docs_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Get_Provider_Docs_Result.cs |
| USP_Hospital_Grid_Report | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
| USP_Import_Wizard | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs |
| USP_InsertSerialNumber | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_NEGATIVE_BALANCE_REPORT | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NEGATIVE_BALANCE_REPORT_Result | NPM_API_BackUp/NPMAPI/Models/USP_NEGATIVE_BALANCE_REPORT_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_By_Carrier_DOS | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_By_Cpt_DOS | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_By_Hospital | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_By_Primary_DX_Payment | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_By_Primary_Dx_DOS | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_COSSCPABYADDCRT | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_CREDIT_BALANCE | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_CREDIT_BALANCE_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_NPM_CREDIT_BALANCE_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_OVER_ALL_CHARGES | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_PATIENT_AGING | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_PATIENT_AGING_Result | NPM_API_BackUp/NPMAPI/Models/ViewModels/USP_NPM_PATIENT_AGING_Result.cs |
| USP_NPM_PAYER_MAPPING | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| USP_NPM_PAYER_MAPPING_LOCATION | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| USP_NPM_PAYER_MAPPING_PROVIDER | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| USP_NPM_PLAN_AGING | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_PLAN_AGING_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_NPM_PLAN_AGING_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_Payment_By_Carrier | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_Payment_By_Primary_ICD10 | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_Payment_Daily_Refresh | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_NPM_Payment_Month_Wise | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_PATIENT_AGING_REPORT_NPM | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_PATIENT_AGING_REPORT_NPM_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_PATIENT_AGING_REPORT_NPM_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Patient_Wise_Aging_Summary_Report_NPM | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Patient_Wise_Aging_Summary_Report_NPM_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Patient_Wise_Aging_Summary_Report_NPM_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Practice_Assign_Users | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| USP_SUMPOSTEDAMOUNT | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs, NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_Search_Insurances | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| USP_Search_Insurances_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Search_Insurances_Result.cs, NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
| USP_Search_ReferringPhysicians | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| USP_Unapplied_Payment_Details_Report | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Unapplied_Payment_Details_Report_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Unapplied_Payment_Details_Report_Result.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_UpdateSyncedClaim_ERA | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| USP_Visit_Claim_Activity_Report | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| USP_Visit_Claim_Activity_Report_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/USP_Visit_Claim_Activity_Report_Result.cs |
| sp_FindErorrClaims | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| sp_GetInsuranceAging_Ubaid | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| sp_GetPatientAging_Ubaid | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| sp_GetScrubberRejectionReportDetailes | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| sp_GetScrubberRejectionReportDetailes_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/sp_GetScrubberRejectionReportDetailes_Result.cs |
| sp_GetScrubberRejectionReports | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| sp_GetScrubberRejectionReports_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/sp_GetScrubberRejectionReports_Result.cs |
| sp_ScrubberProcess | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |
| sp_deleteFromScrubberQueue | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| sp_get999Report_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| sp_get999Report_EDI_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/sp_get999Report_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| sp_getBatchHistory | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| sp_getBatchHistory_EDI | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| sp_getBatchHistory_EDI_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/sp_getBatchHistory_EDI_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| sp_getBatchHistory_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/sp_getBatchHistory_Result.cs, NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| sp_insuranceardetailreport | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| sp_insuranceardetailreport_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/sp_insuranceardetailreport_Result.cs |
| sp_name | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
| sp_provider_working_times | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
| sp_provider_working_times_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/sp_provider_working_times_Result.cs |
| sp_result | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| usp_GetAutoBatchSkippedClaims | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| usp_GetAutoBatchSkippedClaims_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/usp_GetAutoBatchSkippedClaims_Result.cs |
| usp_GetPracticeReportingDetails | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| usp_GetPracticeReportingDetails_Result | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs, NPM_API_BackUp/NPMAPI/Models/usp_GetPracticeReportingDetails_Result.cs |
| usp_GetTicketsWithFilters_Anum_Result | NPM_API_BackUp/NPMAPI/Models/usp_GetTicketsWithFilters_Anum_Result.cs |
| usp_GetTicketsWithFilters_Result | NPM_API_BackUp/NPMAPI/Models/ViewModels/usp_GetTicketsWithFilters_Result.cs |
| usp_update_claims_totals_new | NPM_API_BackUp/NPMAPI/Models/NPM.Context1.cs |

## Raw SQL / Stored Procedure Call Evidence

| File:line | Evidence |
| --- | --- |
| NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:86 | spCmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs:860 | var results = ctx.Database.SqlQuery<UserList>( |
| NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs:861 | "EXEC USP_Practice_Assign_Users " + |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:376 | bool? isCLIA = db.Database.SqlQuery<bool>("select CONVERT(BIT,ISNULL(Clia_Number,'False')) from procedures where ProcedureCode='" + cr.claimCharges[x].claimCharges.Procedure_Code + "'").FirstOrDefault(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1044 | string clia = db.Database.SqlQuery<string>(getClia).FirstOrDefault(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1091 | //var chargesres= db.Database.ExecuteSqlCommand(chargesque, new SqlParameter("@id", UpdateClaim.ClaimModel.Claim_No)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1314 | //var paymentres = db.Database.ExecuteSqlCommand(paymnetque, new SqlParameter("@id", UpdateClaim.ClaimModel.Claim_No)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1338 | var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", UpdateClaim.ClaimModel.Claim_No)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1351 | db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1362 | db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payment.claim_payments_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1399 | var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", UpdateClaim.ClaimModel.Claim_No)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1413 | db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:1424 | db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payment.claim_payments_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:2849 | var results = db.Database.SqlQuery<bool>(Query, new SqlParameter("plan_id", Plan_ID)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:2859 | var results = db.Database.SqlQuery<string>(Query, new SqlParameter("ModifierCode", ModifierCode)).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:2927 | IEnumerable<decimal?> results = db.Database.SqlQuery<decimal?>("SELECT " + Column + " FROM standard_cpt_fee WHERE state =@state and cpt_code=@ProcCode and isnull(cpt_modifier,'')=@Modifier and isnull(deleted,0)<>1", new |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3465 | var results = db.Database.SqlQuery<decimal?>(Query, new SqlParameter("PlanId", PlanId), new SqlParameter("procCode", procCode), new SqlParameter("modifierCode", modifierCode), new SqlParameter("Alternate_Code", Alternate |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3537 | var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", ClaimNumber)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3551 | db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3562 | db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payment.claim_payments_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3808 | var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", payment.Claim_No)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3821 | db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3832 | db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payments.claim_payments_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3867 | var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", payment.Claim_No)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3881 | db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:3892 | db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payments.claim_payments_id)); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:4337 | db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:4444 | db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo", param); |
| NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs:4545 | db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo); |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatus.cs:720 | var violatedClaims = await ctx.Database.SqlQuery<CSIReportModel>( |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs:273 | claimStatusTRNNumbers = connection.Query<ClaimStatusTRNNumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs:299 | claimStatusTRNNumbers = connection.Query<ClaimStatusISAIEANumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs:325 | claimStatusTRNNumbers = connection.Query<ClaimStatusISAIEANumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs:1537 | resultList = connection.Query<SPDataModel>(storedProcedureName, parameters, commandType: System.Data.CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs:2080 | //                        claimStatusTRNNumbers = connection.Query<ClaimStatusTRNNumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs:2106 | //                        claimStatusTRNNumbers = connection.Query<ClaimStatusISAIEANumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs:2132 | //                        claimStatusTRNNumbers = connection.Query<ClaimStatusISAIEANumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs:2903 | //                        resultList = connection.Query<SPDataModel>(storedProcedureName, parameters, commandType: System.Data.CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/CompanyService.cs:891 | var res = ctx.Database.ExecuteSqlCommand(sql, model.DepartmentName, model.CompanyId, model.OfficeId, model.ModifiedDate, model.DepartmentId); |
| NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs:209 | var results = ctx.Database.SqlQuery<SP_SearchCredEdiEraApp_Result>( |
| NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs:210 | "EXEC SP_SearchCredEdiEraApp " + |
| NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs:628 | var results = ctx.Database.SqlQuery<EDI_ERA_EFT_Report>( |
| NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs:629 | "EXEC USP_Get_EDI_ERA_EFT_Status_Report " + |
| NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs:658 | var results = ctx.Database.SqlQuery<EDI_ERA_EFT_Grid_Report>( |
| NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs:659 | "EXEC USP_GET_EDI_ERA_EFT_Grid_Report "  + |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:54 | .SqlQuery<ObjTypeViewModel>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:55 | "EXEC USP_Get_ObjTypes_ByAppType @p0", appTypeId) |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:215 | var results = ctx.Database.SqlQuery<SP_SearchCredApp_Result>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:216 | "EXEC SP_SearchCredApp " + |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:631 | var results = ctx.Database.SqlQuery<UserViewDto>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:632 | "EXEC USP_GETUsersListByRole @RoleName, @PracticeCode", |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:663 | var results = ctx.Database.SqlQuery<SP_Cred_App_Report_Result>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:664 | "EXEC SP_Credentialing_Report " + |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:694 | var credportallist = ctx.Database.SqlQuery<USP_GetCredPortal_By_PracticeCode_Result>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:695 | "EXEC USP_GetCredPortal_By_PracticeCode " + |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:791 | var results = ctx.Database.SqlQuery<USP_Credentialing_Grid_Report_Result>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:792 | "EXEC USP_Credentialing_Grid_Report " + |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:880 | var results = ctx.Database.SqlQuery<CredentialingTasksViewModel>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:881 | "EXEC USP_Credentialing_Tasks " + |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:907 | var results = ctx.Database.SqlQuery<UserViewDto>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:908 | "EXEC USP_GETCredUsersByRole " + |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:948 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:1031 | var results = ctx.Database.SqlQuery<Cred_Hospital_Status_Report>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:1032 | "EXEC USP_Credentialing_Hospital_Status_Report " + |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:1063 | var results = ctx.Database.SqlQuery<Hospital_Grid_Report>( |
| NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs:1064 | "EXEC USP_Hospital_Grid_Report " + |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:2382 | var facilityList = db.Database.SqlQuery<FacilityResult>("exec UPS_GET_FACILITIES @PRACTICE_CODE", new SqlParameter("@PRACTICE_CODE", practice_code)).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:3693 | ctx.Database.SqlQuery<PatientStatementViewModelFromSpXML>("SP_GENERATEPATIENTSTATEMENT_XML @PATACCT,@PRAC,@CLMNO", parameters: new[] { |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:3814 | //        //        statementsList.AddRange(ctx.Database.SqlQuery<PatientStatementViewModelFromSp>("SP_GENERATEPATIENTSTATEMENT @PATACCT,@PRAC,@CLMNO", parameters: new[] { new SqlParameter("@PATACCT", model.PatientAccoun |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:3913 | //    //            statementsList.AddRange(ctx.Database.SqlQuery<PatientStatementViewModelFromSp>("SP_GENERATEPATIENTSTATEMENT @PATACCT,@PRAC,@CLMNO", parameters: new[] { new SqlParameter("@PATACCT", model.PatientAccoun |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:4053 | var result = ctx.Database.SqlQuery<StatementPatientModel>( |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:4054 | "EXEC GetPatientForStatement @PracticeCode", |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:4353 | var objCPTDetails = ctx.Database.SqlQuery<GetPanelCptDetails_Result>( |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:4354 | "EXEC GetPanelCptDetails @PracticeCode, @ProviderCode, @LocationCode, @CptCode", |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:5026 | cmd.CommandType = System.Data.CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:5524 | var result = ctx.Database.SqlQuery<PhysicianSearchModel>( |
| NPM_API_BackUp/NPMAPI/Services/DemographicService.cs:5526 | "EXEC USP_Search_ReferringPhysicians @FirstName, @LastName, @NPI, @Zip, @City, @State", |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:202 | //var user = eraDbModel.Database.SqlQuery<User_era_request>(query, ERA.UserID, ERA.PracticeCde).FirstOrDefault(); |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:241 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:326 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:504 | //var Requests = eraDbModel.Database.SqlQuery<User_era_request>(query, "In_processing", ERA.UserID, ERA.PracticeCde, ERA.UserName).FirstOrDefault(); |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:634 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:765 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:913 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:1612 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:2199 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:2373 | //var user = eraDbModel.Database.SqlQuery<User_era_request>(query, ERA.UserID, ERA.PracticeCde).FirstOrDefault(); |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:2412 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:2497 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:2675 | //var Requests = eraDbModel.Database.SqlQuery<User_era_request>(query, "In_processing", ERA.UserID, ERA.PracticeCde, ERA.UserName).FirstOrDefault(); |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:2804 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:2933 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:3081 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs:3358 | //    cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs:259 | claimStatusTRNNumbers = connection.Query<ClaimStatusTRNNumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs:285 | claimStatusTRNNumbers = connection.Query<ClaimStatusISAIEANumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs:311 | claimStatusTRNNumbers = connection.Query<ClaimStatusISAIEANumberModel>(storedProcedureName, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs:1149 | resultList = connection.Query<SPDataModel>(storedProcedureName, parameters, commandType: System.Data.CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ImportWizardService.cs:85 | cmd.CommandType = CommandType.StoredProcedure; |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:534 | //////////var result = db.Database.SqlQuery<string>("select top 1 call_status from calls where call_claim_no='" + UpdateClaim.claimNo + "'   and Call_Insurance_Id='" + cp.Insurance_Id + "'   and Call_Status in('IP','WT') |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:539 | //////////        db.Database.ExecuteSqlCommand("update calls set call_status='DP' where call_claim_no='" + UpdateClaim.claimNo + "'  and Call_Status in('IP','WT') "); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:545 | //var k = db.Database.SqlQuery<int>(count).Single(); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:549 | //    db.Database.ExecuteSqlCommand(dropCall); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:780 | db.Database.SqlQuery<SP_GetClaimById_Result>("SP_GetclaimbymultiIDS @ClaimId,@practiceCode", parameters: new[] { |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:809 | db.Database.SqlQuery<SP_GetClaimById_Result>("SP_GetclaimbymultiIDSforchecking @ClaimId,@practiceCode", parameters: new[] { |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:911 | db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1075 | var patientList = db.Database.SqlQuery<PatientResult>("exec USP_GetPatientsWithDue @IsDueOnly, @PracticeCode", parameters).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1697 | //                        var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", claimNo)); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1710 | //                                        db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id)); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1721 | //                                    db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payments.claim_payments_id)); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1836 | //                    db.Database.ExecuteSqlCommand( |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1837 | //                        "EXEC USP_GetBatchPayments @PracticeCode, @BatchID, @FileName, @BatchStatus, @BatchType, @PostedBy, @PaymentStatus, @BatchDateFrom, @BatchDateTo, @PaymentType, @CheckNo", |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1858 | //                    db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1910 | var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", claimNo)); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1923 | db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id)); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:1934 | db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payments.claim_payments_id)); |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:2049 | db.Database.ExecuteSqlCommand( |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:2050 | "EXEC USP_GetBatchPayments @PracticeCode, @BatchID, @FileName, @BatchStatus, @BatchType, @PostedBy, @PaymentStatus, @BatchDateFrom, @BatchDateTo, @PaymentType, @CheckNo", |
| NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs:2097 | db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo); |
| NPM_API_BackUp/NPMAPI/Services/PDFService.cs:2988 | ctx.Database.SqlQuery<PatientStatementViewModelFromSpforprint>("SP_GENERATEPATIENTSTATEMENT @PATACCT,@PRAC,@CLMNO", parameters: new[] { |
| NPM_API_BackUp/NPMAPI/Services/PDFService.cs:3024 | ctx.Database.SqlQuery<PatientStatementViewModelFromSp>("SP_GENERATEPATIENTSTATEMENT @PATACCT,@PRAC,@CLMNO", parameters: new[] { |
| NPM_API_BackUp/NPMAPI/Services/PDFService.cs:3056 | db.Database.SqlQuery<rollingReportforSP>("SP_rollingReport @PracticeCode,@duration", parameters: new[] { |
| NPM_API_BackUp/NPMAPI/Services/PracticeService.cs:416 | ctx.Database.ExecuteSqlCommand( |
| NPM_API_BackUp/NPMAPI/Services/PracticeService.cs:419 | ctx.Database.ExecuteSqlCommand( |
| NPM_API_BackUp/NPMAPI/Services/PracticeService.cs:426 | ctx.Database.ExecuteSqlCommand( |
| NPM_API_BackUp/NPMAPI/Services/PracticeService.cs:1401 | var result = ctx.Database.SqlQuery<int>( |
| NPM_API_BackUp/NPMAPI/Services/PracticeService.cs:1402 | "EXEC USP_NPM_PAYER_MAPPING @PracticeId, @InsuranceId, @UserId", |
| NPM_API_BackUp/NPMAPI/Services/PracticeService.cs:1552 | ctx.Database.ExecuteSqlCommand("EXEC [USP_NPM_PAYER_MAPPING_PROVIDER] @PROVIDER_CODE, @CREATED_BY", |
| NPM_API_BackUp/NPMAPI/Services/PracticeService.cs:1615 | ctx.Database.ExecuteSqlCommand( |
| NPM_API_BackUp/NPMAPI/Services/PracticeService.cs:1783 | ctx.Database.ExecuteSqlCommand("EXEC [USP_NPM_PAYER_MAPPING_LOCATION] @LOCATION_CODE, @CREATED_BY", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:661 | detailList = ctx.Database.SqlQuery<Patient_ASR_Response> |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:662 | ("EXEC USP_NPM_PATIENT_AGING @PRACTICE_CODE", new SqlParameter("@PRACTICE_CODE", PracticeCode)).Skip((Page - 1) * Count).Take(Count).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:663 | pagingResponse.TotalRecords = ctx.Database.SqlQuery<Patient_ASR_Response> |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:664 | ("EXEC USP_NPM_PATIENT_AGING @PRACTICE_CODE", new SqlParameter("@PRACTICE_CODE", PracticeCode)).Count(); |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:671 | detailList = ctx.Database.SqlQuery<Patient_ASR_Response> |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:672 | ("EXEC USP_NPM_PATIENT_AGING @PRACTICE_CODE", new SqlParameter("@PRACTICE_CODE", PracticeCode)).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:886 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:934 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:982 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1030 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1078 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1125 | //cmd.CommandText = "exec Payment_Month_Wise @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1127 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1174 | //cmd.CommandText = "exec Payment_Daily_Refresh @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1176 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1223 | //cmd.CommandText = "exec Payment_By_Carrier @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1225 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1272 | //cmd.CommandText = "exec By_Primary_DX_Payment @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1274 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1321 | //cmd.CommandText = "exec Payment_By_Primary_ICD10 @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1323 | cmd.CommandText = "exec " + sp_name + " @PracticeCode, @DATEFROM, @DATETO, @locationcode, @DateType"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1514 | cmd.CommandText = "exec SP_GetCPAAnalysis @PracticeCode, @FromDate, @ToDate"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1551 | cmd.CommandText = "exec sp_GetInsuranceAging_Ubaid @PracticeCode"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1589 | //            cmd.CommandText = "exec uspGetClaimsAndERAs_PirUbaid @PracticeCode, @FromDate, @ToDate"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1629 | cmd.CommandText = "exec uspGetClaimsAndERAs_PirUbaid @PracticeCode, @FromDate, @ToDate"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1711 | cmd.CommandText = "exec sp_GetPatientAging_Ubaid @PracticeCode"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1749 | cmd.CommandText = "exec SP_PCRatio @PracticeCode, @FromDate, @ToDate"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1808 | cmd.CommandText = "exec SP_ChargesANDPaymentsTrend @PracticeCode, @FromDate, @ToDate"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:1846 | cmd.CommandText = "exec SP_GETChargesPaymentsLastMonthsTets @PRAC"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:2207 | //            cmd.CommandText = "exec [SP_userReportCharges] @practice_code, @userid"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:2277 | cmd.CommandText = "exec SP_rollingReport @PracticeCode,@duration"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:2727 | cmd.CommandText = "exec SP_COSSCPABYADDCRT @datecriteria,@datacriteria,@Fromdate,@Todate,@facname"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:2732 | cmd.CommandText = "exec USP_NPM_COSSCPABYADDCRT @datecriteria,@datacriteria,@PracticeCode,@Fromdate,@Todate,@locationcode"; |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:2987 | var results = ctx.Database.SqlQuery<USP_NEGATIVE_BALANCE_REPORT_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:2988 | "EXEC USP_NEGATIVE_BALANCE_REPORT @practiceCode, @responsibleParty, @dateCriteria, @dateFrom, @dateTo", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3040 | var results = ctx.Database.SqlQuery<USP_NEGATIVE_BALANCE_REPORT_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3041 | "EXEC USP_NEGATIVE_BALANCE_REPORT @practiceCode, @responsibleParty, @dateCriteria, @dateFrom, @dateTo", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3049 | pagingResponse.TotalRecords = ctx.Database.SqlQuery<USP_NEGATIVE_BALANCE_REPORT_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3050 | "EXEC USP_NEGATIVE_BALANCE_REPORT @practiceCode, @responsibleParty, @dateCriteria, @dateFrom, @dateTo", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3122 | var results = ctx.Database.SqlQuery<USP_Batch_Payment_Details_Report_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3123 | "EXEC USP_Batch_Payment_Details_Report @PracticeCode, @Batch_Type, @Batch_Status, @Batch_CheckNo, @Created_By, @DateCriteria, @DateFrom, @DateTo", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3183 | var results = ctx.Database.SqlQuery<USP_Batch_Payment_Details_Report_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3184 | "EXEC USP_Batch_Payment_Details_Report @PracticeCode, @Batch_Type, @Batch_Status, @Batch_CheckNo, @Created_By, @DateCriteria, @DateFrom, @DateTo", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3197 | pagingResponse.TotalRecords = ctx.Database.SqlQuery<USP_Batch_Payment_Details_Report_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3198 | "EXEC USP_Batch_Payment_Details_Report @PracticeCode, @Batch_Type, @Batch_Status, @Batch_CheckNo, @Created_By, @DateCriteria, @DateFrom, @DateTo", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3290 | var results = ctx.Database.SqlQuery<USP_Unapplied_Payment_Details_Report_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3291 | "EXEC USP_Unapplied_Payment_Details_Report @PracticeCode, @Batch_Status, @Batch_CheckNo, @Created_By, @DateCriteria, @DateFrom, @DateTo", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3342 | var results = ctx.Database.SqlQuery<USP_Unapplied_Payment_Details_Report_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3343 | "EXEC USP_Unapplied_Payment_Details_Report @PracticeCode, @Batch_Status, @Batch_CheckNo, @Created_By, @DateCriteria, @DateFrom, @DateTo", |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3355 | pagingResponse.TotalRecords = ctx.Database.SqlQuery<USP_Unapplied_Payment_Details_Report_Result>( |
| NPM_API_BackUp/NPMAPI/Services/ReportService.cs:3356 | "EXEC USP_Unapplied_Payment_Details_Report @PracticeCode, @Batch_Status, @Batch_CheckNo, @Created_By, @DateCriteria, @DateFrom, @DateTo", |
| NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs:1141 | objResponse.obj = connection.Query<ClaimSubmission>(storedProcedureName, parameters, commandTimeout: 120, commandType: CommandType.StoredProcedure).OrderByDescending(c => c.DOS).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs:1197 | objResponse.obj = connection.Query<ClaimSubmission>(storedProcedureName, parameters, commandTimeout: 120, commandType: CommandType.StoredProcedure). |
| NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs:1200 | pagingResponse.TotalRecords = connection.Query<ClaimSubmission>(storedProcedureName, parameters, commandTimeout: 120, commandType: CommandType.StoredProcedure).Count(); |
| NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs:1267 | objResponse.obj = connection.Query<EdiHistoryModel>(storedProcedureName, parameters, commandType: System.Data.CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs:1293 | obj = connection.Query<ClaimRejectionModel>(storedProcedureName, parameters, commandType: System.Data.CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/SetupService.cs:2192 | int rowsAffected = ctx.Database.ExecuteSqlCommand( |
| NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs:69 | latestSerialNumber = ctx.Database.SqlQuery<string>("EXEC USP_GetLatestSerialNumber") |
| NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs:87 | ctx.Database.ExecuteSqlCommand( |
| NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs:88 | "EXEC USP_InsertSerialNumber @Seq_Number,@Claim_id,@Created_At", |
| NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs:10320 | ctx2.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo); |
| NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs:10386 | ctx2.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo); |
| NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs:13528 | resultList = connection.Query<SPDataModel>(storedProcedureName, parameters, commandType: System.Data.CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs:13869 | var result = ctx.Database.SqlQuery<BatchPaymentDto>( |
| NPM_API_BackUp/NPMAPI/Services/TTService.cs:1195 | var result = ctx.Database.SqlQuery<USP_GetTickets_WithFilters_Result>( |
| NPM_API_BackUp/NPMAPI/Services/TTService.cs:1196 | @"EXEC USP_GetTickets_WithFilters |
| NPM_API_BackUp/NPMAPI/Services/UBClaim.cs:503 | bool? isCLIA = db.Database.SqlQuery<bool>("select CONVERT(BIT,ISNULL(Clia_Number,'False')) from procedures where ProcedureCode='" + cr.claimCharges[x].claimCharges.Procedure_Code + "'").FirstOrDefault(); |
| NPM_API_BackUp/NPMAPI/Services/UBClaim.cs:1282 | string clia = db.Database.SqlQuery<string>(getClia).FirstOrDefault(); |
| NPM_API_BackUp/NPMSyncWorker/Repositories/PatientReposiroty.cs:21 | commandType: CommandType.StoredProcedure).AsList(); |
| NPM_API_BackUp/NPMSyncWorker/Repositories/PracticeRepository.cs:19 | return Connection.Query<PracticeToSync>(Procedures.GetPracticesForSync, new { }, transaction: Transaction, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMSyncWorker/Repositories/PracticeRepository.cs:24 | return Connection.Query<PracticeLocations>(Procedures.GetPracticeLocationsForSync, new { pPracticeCode = practice_Code }, transaction: Transaction, commandType: CommandType.StoredProcedure).ToList(); |
| NPM_API_BackUp/NPMSyncWorker/Repositories/ProviderRepository.cs:23 | commandType: CommandType.StoredProcedure |
| NPM_API_BackUp/NPMSyncWorker/Repositories/RepositoryBase.cs:33 | commandType: CommandType.StoredProcedure |
| NPM_API_BackUp/NPMSyncWorker/Repositories/RepositoryBase.cs:50 | commandType: CommandType.StoredProcedure |
| NPM_API_BackUp/NPMSyncWorker/Repositories/RepositoryBase.cs:66 | commandType: CommandType.StoredProcedure |
