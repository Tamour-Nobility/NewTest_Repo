# Application Flow Document

## Scope

This first-pass flow document covers only `NPM_UI_BackUp` and `NPM_API_BackUp`. Database table/procedure internals will be expanded after schema scripts are provided.

## Global Application Flow

1. User opens Angular hash route.
2. Unauthenticated paths allow login, OTP, forgot password, and 404. Authenticated paths render `LayoutComponent` and are protected by `AuthGuard`.
3. UI pages call APIs under `environment.baseUrl` using Angular services/components. JWT and credential/encryption interceptors modify requests.
4. ASP.NET Web API receives `api/{controller}/{action}/{id}` calls. Message handlers validate tokens and process encryption.
5. Controllers call Unity-injected services/repositories.
6. Services query/update EF entities and stored procedures, then return JSON, file streams, EDI artifacts, PDFs, or status responses.
7. UI components update tables, forms, modals, calendars, reports, downloads, or navigation based on success/error responses.

## Error and Exception Flow

- Client validation errors are blocked in Angular forms and custom validators where implemented.
- API errors flow through controller/service return handling and global `NLogExceptionLogger`; route/audit filters record user/API activity.
- Authentication failures should redirect to login or block guarded routes.
- Migration target should normalize all API errors into RFC 9457 ProblemDetails with correlation IDs and domain-specific validation codes.

## Feature Flows

### Authentication and Security

- Feature name: Authentication and Security.
- Business purpose: Supports the PMS authentication and security workflow.
- Frontend route/page/component: login, forgot-password, otp; components include ForgotPasswordComponent, LoginComponent, OtpComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Alert/SaveLoginAlert, api/Alert/GetLoginAlert, api/TicketTracker/GetLoginTicketPopup, api/Token/Auth, api/Token/AuthCode, api/Token/SetAuthCookies, api/Token/AuthCodeResend, api/Token/VerifyPassowrd, api/Token/myauthmailsender, api/Token/maintainlogofOTP, api/Token/Logout, api/Token/sendOTPToResetPassword, api/Token/forgetpasswordmailsender, api/Token/ResetPasswordForOTP, api/Token/GetPracticesClientBased, api/Token/LoginRateLimitReset, api/UserManagementSetup/ResetPasswordForOTP.
- Service/repository/business logic: AuditLogService, EncryptionService, SecurityEventService.
- Database tables used: AuditLogEntry, Audit_Block_Users, Central_Audit_Logs, NPMDBEntities, RefreshToken, SP_GetUserAuthorization_Hamza_Result, SP_GetUserAuthorization_Result, TWO_FACTOR_AUTHORAZITION, TokenRequestModel, Users_RS2F_OTP.
- Stored procedures/functions used: SP_GetUserAuthorization, SP_GetUserAuthorization_Hamza_Result, SP_GetUserAuthorization_Result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Claims and UB04

- Feature name: Claims and UB04.
- Business purpose: Supports the PMS claims and ub04 workflow.
- Frontend route/page/component: claimsubmission, scrubber/:type, skippedclaims, claims, errors, claims, batchResponse, Claimrejection, Diagnosis, ClaimDetail/:param, ClaimSummary/:param, Appoinments/:param, claims/:id, claim-payment-report, hold-claims-report, claim-assignmentreport, scrubber-rejection-report, claim-submission-report; components include AutoSubmissionSkippedClaimsComponent, BatchSubmissionResponseComponent, ClaimSubmissionErrorsComponent, ClaimSubmissionComponent, ClaimsSubmissionClaimsComponent, ComponentScrubberComponent, ClaimAttachmentsComponent, ClaimNotesComponent, ClaimsAssignmentComponent, ClaimsComponent, DiagnosisComponent, ClaimInsurancesComponent, PaymentsComponent, UB04Component, ERAClaims, ClaimAssignmentreportComponent, ClaimPaymentReportComponent, ClaimSubmissionReportComponent, HoldclaimsComponent, ScrubberRejectionReportComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/ClaimAssignment/GetUsersList, api/ClaimAssignment/PostAllAssignedClaims, api/ClaimAssignment/GetAssignedClaimData, api/ClaimAssignment/EditAssignedClaims, api/ClaimAssignment/GetAllAssignedClaims, api/ClaimAssignment/GetSpecificAssignedClaimData, api/ClaimAssignment/GetSpecificAssignedClaimNotes, api/ClaimAssignment/GetAllAssignedClaimsNotifications, api/ClaimAssignment/GetAllAssignedAccountsNotifications, api/ClaimAssignment/PostAllAssignedAccounts, api/ClaimAssignment/GetAllAssignedAccounts, api/ClaimAssignment/GetSpecificAssignedAccountNotes, api/ClaimAssignment/GetSpecificAssignedAccountData, api/ClaimAssignment/EditAssignedAccounts, api/ClaimAssignment/CheckClaimAssignment, api/ClaimAssignment/CheckAccountAssignment, api/ClaimAssignment/ClaimTaskAssignment, api/ClaimsAttachments/Attach, api/ClaimsAttachments/GetAll, api/ClaimsAttachments/GetAttachmentCodeList, api/ClaimsAttachments/Download, api/HCFA/GenerateHcfa, api/HCFA/GenerateUB, api/HCFA/GenerateBatchHcfa, api/HCFA/canPrint, api/Payments/GetClaimsSummary, api/Payments/GetClaimByins, api/Payments/PostClaims, api/Payments/getClaimsDetails, api/Payments/SaveClaimsDetails.
- Service/repository/business logic: ClaimAssignmentService, ClaimBatch276, ClaimsAttachmentsService, ClaimsService, ClaimStatus, ClaimStatusService, ScrubberService, SubmissionService, UBClaim.
- Database tables used: BatchCSIResponse, BatchClaimsDetail, BatchCreateViewModel, CLAIMS_SUBMITTED, CLAIM_CHARGES_BKP20230817, CLAIM_NOTES, CLAIM_PAYMENTSBKP20230817, Claim, ClaimAssignee_CL, ClaimAssignee_Notes, ClaimAttachmentRequest, ClaimChargesUpdateRequest, ClaimDetails, ClaimErrorMessage, ClaimOverpayment, ClaimPaymentUpdateRequest, ClaimPaymentsDetailRequest, ClaimStatusTRNNumberModel, ClaimStatus_Search_Criteria, ClaimSubmission, ClaimSubmissionModel, ClaimSubmissionResponse, ClaimSummaryViewModel, ClaimUpdateRequest, Claim_Batch_Exceptions, Claim_Charges, Claim_Charges_Summary, Claim_Document, Claim_Insurance, Claim_Overpayment, Claim_Payments, Claim_Status_Codes, Claim_Worker_Injurycase, ClaimsDataModel, ClaimsDetail, ClaimsPayments_06082023, ClaimsPayments_06092023, ClaimsViewModel, Claims_06082023, Claims_06092023, Claims_Condition_Code, Claims_ICD10DX, Claims_Occurence_Span_Code, Claims_Occurrence_Code, Claims_Ptl_Feedback, Claims_Value_Code, Claims_filling_limit, CustomEdits_ClearClaims, Custom_Scrubber_Rules, DelayClaimReports_Result, ERACLAIMINFO, ERACLAIMINFO_EDI, GetBatchClaimsDetails_Result, GetBatchClaims_Result, GetClaimChargesByClaimNo_Result, GetClaimsForStatement_Result, GetPanelCodeCPTDetailsClaim_Result, GetRecentClaimDetailsWithDiagnosis_Result, HCFAImage, HCFAImagesType, HCFAResponseModel, HCFA_Attachment_Type, HCFA_Notes_List, Hcfa_fields, MIS_TBL_Corrected_Claim_Reason, Packet277CAClaimReason_Messages, Packet277CAClaims, Packet277CA_ClaimStatusCategoryCodes, Packet277CA_ClaimStatusCodes, ResubmissionCode, SP_CLAIMSUMMARYAMOUNTS_Result, SP_ClaimInsuranceSearch_Result, SP_Claim_Batch_Exception_EDI_Result, SP_Claim_Insurancebysearch_Result, SP_ClaimsSearch_EDI_Result, SP_ClaimsSearch_EDI_bkp_04112025_Result, SP_CountAssignedclaims_Result, SP_ERACLAIMDETAIL_Result, SP_ERACLAIMDETAIL_VIEW_EDI_Result, SP_ERAClaimCrossOver_Result.
- Stored procedures/functions used: Aging_from_Last_submission, Check_Date, Check_No, Claim_Amount, Claim_AmtDue, Claim_AmtPaid, Claim_AssigneeID, Claim_AttendingPhysician, Claim_Batch_Exceptions, Claim_BillingPhysician, Claim_CSI_Status, Claim_Charges_Id, Claim_Charges_Imported, Claim_Charges_Issues, Claim_Charges_Summary, Claim_Charges_Total, Claim_Claimtotal, Claim_Count, Claim_DOS, Claim_Date, Claim_ID, Claim_Imported, Claim_Ins_Imported, Claim_Ins_Issues, Claim_Ins_Total, Claim_Issues, Claim_Last_Submission, Claim_NO, Claim_Numbers, Claim_Payments_Id, Claim_Pos, Claim_Procedures_Id, Claim_RMK_code, Claim_Status_Codes, Claim_Status_Request, Claim_Worker_Injurycase, Claim_id, Claim_notes, Claim_payment_Id, Claim_total, Claim_type, ERA_ADJUSTMENT_CODE, ERA_CATEGORY_CODE, ERA_Rejection_CATEGORY_CODE, MIS_TBL_Corrected_Claim_Reason, SP_CLAIMSUMMARYAMOUNTS_Result, SP_ClaimInsuranceSearch, SP_ClaimInsuranceSearch_Result, SP_Claim_Batch_Exception_EDI, SP_Claim_Batch_Exception_EDI_Result, SP_Claim_Insurancebysearch, SP_Claim_Insurancebysearch_Result, SP_ClaimsSearch, SP_ClaimsSearch_EDI, SP_ClaimsSearch_EDI_Result, SP_ClaimsSearch_EDI_bkp_04112025, SP_ClaimsSearch_EDI_bkp_04112025_Result, SP_ClaimsSearch_Result, SP_CountAssignedAccounts, SP_CountAssignedAccounts_Result, SP_CountAssignedclaims, SP_CountAssignedclaims_Result, SP_EDIHistory, SP_ERAADJCODEGLOSSARY, SP_ERAADJCODEGLOSSARY_VIEW_EDI, SP_ERAAUTOPOST, SP_ERACLAIMDETAIL, SP_ERACLAIMDETAIL_Result, SP_ERACLAIMDETAIL_VIEW_EDI, SP_ERACLAIMDETAIL_VIEW_EDI_Result, SP_ERACLAIMSAUTOPOST, SP_ERAClaimCrossOver, SP_ERAClaimCrossOver_Result, SP_ERASEARCH, SP_ERASEARCH_MAN_IMP, SP_ERASEARCH_Result, SP_GetAllAssignedClaimForusers, SP_GetAllAssignedClaimForusers_Result, SP_GetBatchDetail, SP_GetBatchDetail_EDI.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Credentialing

- Feature name: Credentialing.
- Business purpose: Supports the PMS credentialing workflow.
- Frontend route/page/component: No direct route found; shared/component-level surface; components include CredAppAttachmentsComponent, CredAppListComponent, CredPortalComponent, CredTasksComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Credentialing/GetLookupLists, api/Credentialing/GetObjectiveTypes, api/Credentialing/SearchCredApp, api/Credentialing/GetCredAppById, api/Credentialing/GetCredAppNotes, api/Credentialing/UploadCredAppDocument, api/Credentialing/GetCredAppDocuments, api/Credentialing/GetCredAppDocumentById, api/Credentialing/DeleteCredAppDocument, api/Credentialing/GetCredTasks, api/Credentialing/GetTaxonomyCode, api/Credentialing/GetCredPortals.
- Service/repository/business logic: CredentialingService.
- Database tables used: CredAppDocumentRequest, CredAppDocumentViewModel, CredAppNoteViewModel, CredAppSearchViewModel, CredPortal_View, Cred_App_Docs, Cred_App_Notes, Cred_App_ViewModel, Cred_Application_Status, Cred_Application_Type, Cred_Contract_Type, Cred_Document_Type, Cred_Objective_Type, Cred_Portals, CredentialingLookupLists, CredentialingTasksViewModel, Credentialing_Application, SP_SearchCredApp_Result.
- Stored procedures/functions used: SP_SearchCredApp, SP_SearchCredApp_Result, USP_Credentialing_Tasks, USP_Get_ObjTypes_ByAppType.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Dashboard and Alerts

- Feature name: Dashboard and Alerts.
- Business purpose: Supports the PMS dashboard and alerts workflow.
- Frontend route/page/component: dashboard, CredDashboard; components include CredDashboardComponent, DashBoardComponent, AlertAssignmentComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Alert/SaveAlert, api/Alert/GetAlertForPatient, api/Dashboard/GetDashboardData, api/Dashboard/GetExternalPractices, api/Dashboard/GetOpenPaymentBatches, api/Report/GetAgingDashboard, api/TicketTracker/GetTicketAlerts.
- Service/repository/business logic: AlertService, DashboardService.
- Database tables used: AlertModel, CPADASHBOARD, DashboardViewModel, NpmAlert, PROCEDURES_ALERTS, SP_GETAGINGDASHBOARD_Result, SP_GETAGINGDASHBOARD_Tets_Result, USPGetAlertAgainst_PAT_Result.
- Stored procedures/functions used: SP_AGINGCOMPDEMO_Result, SP_AGINGDEMO_Result, SP_CPADEMO_Result, SP_GETAGINGDASHBOARD, SP_GETAGINGDASHBOARD_Result, SP_GETAGINGDASHBOARD_Tets, SP_GETAGINGDASHBOARD_Tets_Result, SP_TableIdGenerator, USP_Get_Credentialing_Dashboard_Data.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### ERA and EDI

- Feature name: ERA and EDI.
- Business purpose: Supports the PMS era and edi workflow.
- Frontend route/page/component: customEdits/:type/:id, EDISetup, era, addedit, addedit, addedit/:id, view/:id, credEdiEraApp, addcredEdiEraaddedit, editcredEdiEraaddedit/:id, viewcredEdiEraaddedit/:id, edi-era-eft-report, edi-era-eft-grid-report, overall, era, erahistory, manualeraimport, view/:id; components include AddEditAppointmentReasonComponent, AddEditAppointmentStatusComponent, NgbTimeStringAdapter, AddEditOfficeTimingComponent, CredAppAddeditComponent, CredEdiEraAppAddeditComponent, CredEdiEraAppAttachmentsComponent, CredEdiEraAppListComponent, EdiEraEftGridReportComponent, EdiEraEftReportComponent, CustomEditsComponent, OverAllByDosComponent, EdiSetupMainComponent, ERALayout, ERAViewer, ErahistoryComponent, ERAImportComponent, ManualEraimportComponent, AddEditPanelCodeComponent, CreditBalanceReportComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/CredEDIERASetup/GetLookupLists, api/CredEDIERASetup/AddEditCredApp, api/CredEDIERASetup/GetCredEDIERASetupById, api/CredEDIERASetup/AddEditCred_EDIERA_Note, api/CredEDIERASetup/SearchCredEDIERASetup, api/CredEDIERASetup/GetCred_EDIERA_Notes, api/CredEDIERASetup/UploadCred_EDIERA_Document, api/CredEDIERASetup/GetCred_EDIERA_Documents, api/CredEDIERASetup/GetCred_EDIERA_DocumentById, api/CredEDIERASetup/DeleteCred_EDIERA_Document, api/CredEDIERASetup/AddTPAName, api/CredEDIERASetup/GetEDIERAEFTReport, api/CredEDIERASetup/GetEDIERAEFTGridReport, api/CredEDIERASetup/AddClearingHouse, api/CredEDIERASetup/AddSoft, api/Credentialing/AddEditCredApp, api/Credentialing/AddEditCredAppNote, api/Credentialing/AddEditCredPortal, api/ERA/GetUserId, api/ERA/ERAImport, api/ERA/ManualERAFileProcessing, api/ERA/Import, api/ERA/Import, api/ERA/WeekHistoryOfERA, api/ERA/LogException, api/Report/OverAllChargesDos, api/Report/ERAUnpostedAdjReport, api/TicketTracker/EditTrackDetails.
- Service/repository/business logic: CredEDIERASetupService, EligibilityService, ERAImportService, FTPService, GenerateBatch276Service.
- Database tables used: AdvEligibilityReqRe, AppointmentViewModel, CreateManualERARequest, CredEDIERALookupLists, Credit_BR_Response, CustomEdit, CustomEdit_Mapping, CustomEditsError, CustomEditsErrors_jinnah, CustomEdits_Columns, CustomEdits_FrontEnd, CustomEdits_Test, Custom_Edits, DemoERADBModel, DoInquiryByX12DataModel, EDIERANotesViewModel, EDI_ERA_Doc_Type, EDI_ERA_Documents, EDI_ERA_EFT_Grid_Report, EDI_ERA_EFT_Report, EDI_ERA_Notes, EDI_ERA_Obj_Types, EDI_ERA_Setup, EDI_ERA_Statuses, ERACHECKDETAIL, ERACHECKDETAIL_bkp20232607, ERASUMMARY, ERASUMMARY_EDI, ERASearchRequestModel, ERA_ADJUSTMENT_MAPPING_BKP_012721, ERA_Adjustment_Mapping, ERA_PLB_CODE, ERA_Request, EdiEraSetupSearchViewModel, Edits_jinnah, EraDbModel, EraSummaryRequest, Era_Summary_Impt, Get_CustomEdits_Colums, Hierarchy, MEDICINE, MEDICINE_FORMULATION, Manual_ERA_Files, Medigap_Insurances, Operating_Test, PayerMappedInsuranceSearch_Result, PutCustomEdits_values, PutCustomEdits_values_Array, RegenerateBatchCSIFileModel, RegenerateBatchFileRequestModel, Registeration, SPAppChkEligibility_Result, SP_ERAADJCODEGLOSSARY_Result, SP_ERAADJCODEGLOSSARY_VIEW_EDI_Result, SP_ERACHECKDETAIL_Result, SP_ERASEARCH_MAN_IMP_Result, SP_ERASEARCH_Result, SP_GetBatchDetail_EDI_Result, SP_InsPayerWithoutModifierAndProcedure_Result, SP_InsStateWithoutModifierAndProcedure_Result, SP_SearchCredEdiEraApp_Result, Sp_GetCSIBatchStatusMedicare_Result, TESTEDIT_03, USP_NPM_CREDIT_BALANCE_Result, User_era_request, ViewERASummaryRequest, coverage_topic_lookup, edit, editassignedaccountModel, era, era_adjustment, eracheckdetail_EDI, include_in_edi, lcd_x_coverage_topic, sp_get999Report_EDI_Result, sp_getBatchHistory_EDI_Result.
- Stored procedures/functions used: Check_if_the_Maximum_Retry_Count_has_been_Reached_AND_ALSO_SMTP, ERA_ADJUSTMENT_MAPPING_BKP_012721, ERA_Adjustment_Mapping, ERA_AppDate, ERA_Download_and_Dump_Process, ERA_EffDate, ERA_NextFollowUp, ERA_PLB_CODE, ERA_Request, ERA_Status, Get_Current_Request, Get_Current_Request_which_is_Inserted, Get_CustomEdits_Colums, Get_Mail_stats, Get_StatOfRequest_AND_Maintain_LOGS_If_no_new_Files_Found, Get_StatsRequest_AND_Maintain_STATS, Get_UserERARequest, SP_ERAADJCODEGLOSSARY_Result, SP_ERAADJCODEGLOSSARY_VIEW_EDI_Result, SP_ERACHECKDETAIL, SP_ERACHECKDETAIL_Result, SP_ERASEARCH_MAN_IMP_Result, SP_Manual_ERS_MigrateDataToLiveServer, SP_MigrateDataToLiveServer, SP_MigrateStats, SP_MigrateStats_same_prac, SP_SearchCredEdiEraApp, SP_SearchCredEdiEraApp_Result, USP_GET_EDI_ERA_EFT_Grid_Report, USP_Get_EDI_ERA_EFT_Status_Report, USP_NPM_CREDIT_BALANCE, USP_NPM_CREDIT_BALANCE_Result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Import Wizard and Sync Workers

- Feature name: Import Wizard and Sync Workers.
- Business purpose: Supports the PMS import wizard and sync workers workflow.
- Frontend route/page/component: No direct route found; shared/component-level surface; components include ImportWizardMainComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/ImportWizard/ExcelImport, api/ImportWizard/DownloadImportWizardTemplateFile, api/ImportWizard/GetImportWizard, api/ImportWizard/IssueExcelExport, api/InboxHealth/Webhook.
- Service/repository/business logic: DeltaSyncService, ImportWizardService, InboxHealthAPI, InboxHealthService.
- Database tables used: BaseResponse, EPSDTWORKERINFO, InboxHealthEvent, InboxHealthEventBaseEntity, USP_Get_ImportWizard_Log_Result, workerservice.
- Stored procedures/functions used: USP_GetIssues_Excel_Export, USP_Get_ImportWizard_Log, USP_Get_ImportWizard_Log_Result, USP_Import_Wizard.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Insurance Setup

- Feature name: Insurance Setup.
- Business purpose: Supports the PMS insurance setup workflow.
- Frontend route/page/component: InsuranceSetup, insurance-detail-report, esha-plan-aging, insGroup, detail/:id, insName, insPayer, detail/:id, insSetup; components include EshaPlanAgingReportComponent, InsuranceDetailReportComponent, InsSetupDetailComponent, InsuranceSetupComponent, ListInsSetupComponent, InsGroupSetupDetailsComponent, InsuranceSetupGroupComponent, ListInsGroupSetupComponent, InsNameSetupDetailsComponent, InsuranceSetupNameComponent, ListInsNameSetupComponent, InsSetupPayerDetailComponent, InsuranceSetupPayerComponent, ListInsSetupPayerComponent, MainInsuranceSetupComponent, InsuranceSearchComponent, PracTabInsuranceSearchComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/InsuranceSetup/GetInsuranceGroupList, api/InsuranceSetup/GetInsuranceGroup, api/InsuranceSetup/SaveInsuranceGroup, api/InsuranceSetup/DeleteInsuranceGroup, api/InsuranceSetup/GetInsuranceGroupsSelectList, api/InsuranceSetup/GetSmartInsuranceGroupsSelectList, api/InsuranceSetup/GetInsuranceNameList, api/InsuranceSetup/GetInsuranceName, api/InsuranceSetup/GetInsuranceNameModel, api/InsuranceSetup/GetInsuranceNameSelectList, api/InsuranceSetup/GetSmartInsuranceNameList, api/InsuranceSetup/SaveInsuranceName, api/InsuranceSetup/DeleteInsuranceName, api/InsuranceSetup/GetInsurancePayerList, api/InsuranceSetup/GetInsurancePayer, api/InsuranceSetup/GetInsurancePayerModel, api/InsuranceSetup/SaveInsurancePayer, api/InsuranceSetup/DeleteInsurancePayer, api/InsuranceSetup/GetSmartInsurancePayersList, api/InsuranceSetup/GetInsPayerList, api/InsuranceSetup/GetInsPayerById, api/InsuranceSetup/GetInsPayerByState, api/InsuranceSetup/GetInsuranceList, api/InsuranceSetup/GetInsurance, api/InsuranceSetup/GetInsuranceModel, api/InsuranceSetup/SaveInsurance, api/InsuranceSetup/DeleteInsurance, api/InsuranceSetup/GetRelationsSelectList, api/InsuranceSetup/AddInsurance, api/Report/GetInsuranceDetailReport.
- Service/repository/business logic: InsuranceSetupService.
- Database tables used: AddInsuranceRequest, Aging_Summary_Top_5_Payers_Result, Aging_Summary_report_Top_5_Payers_Result, Cptplan_MD, DIAGNOSIS_PAYER, Fee_Plan_Update, Functional_Group_Rejection_Response, GetInsuranceNamesByGroup_Result, GetInsurancePayersByInsPayerId_Result, GetInsurancePayersByInsPayerState_Result, GetInsurancePayersByName_Result, GetInsurancesByPayers_Result, HIPAA_278_PAYER_INFORMATION, INSURANCE_FILING_LIMIT, INSURANCE_PAYERS_PLAN, Insurance, InsuranceDetailReportResponse, InsuranceModel, InsuranceNameViewModel, InsurancePayerVM, InsurancePayerViewModel, InsuranceSearchViewModel, Insurance_Denials, Insurance_Departments, Insurance_Groups, Insurance_Names, Insurance_Notes, Insurance_Payers, Insurance_Payers_07092023, Insurance_Payers_Bkp_08232020, Insurance_Payers_Plan_Group, Insurance_Phone_Directory, Insurance_filing_limit2, Insurance_payers_formats, InsurancesByPayersViewModel, Insurances_Bkp_08232020, Insurancesbkp_07092023, MIS_TBL_Insurance_Resources_Remarks, PAYER, PayerPortal_Notes, PayerWise_Analysis_by_Report_Result, Payer_Notes, Plan_Aging_Response, Plan_setup, Procedures_Payer, PtientInsurance_06082023, PtientInsurance_06092023, SP_GetInsuranceInfo_Result, SP_InsPayer_Result, SP_InsStatePlan_Result, SP_InsuranceSearch_BK_11082018_Result, SP_InsuranceSearch_Result, SP_getcptplanlist_Result, SP_getpraticedataforCPTPlan_Result, Specialty_Groups, USP_NPM_PLAN_AGING_Result, USP_Search_Insurances_Result, User_Group, ValidateInsGroupDeletion_Result, check_CPtPlan_Result, default_group_IDs, insurance_role_engine, insurancelist, insurances_11252021, lcd_x_hcpc_code_group, lcd_x_icd9_support_group, payer_not_450, sp_insuranceardetailreport_Result.
- Stored procedures/functions used: Aging_Payer, Aging_Payer_Type, Aging_Summary_Top_5_Payers, Aging_Summary_Top_5_Payers_Result, Aging_Summary_report_Top_5_Payers, Aging_Summary_report_Top_5_Payers_Result, MIS_TBL_Insurance_Resources_Remarks, SP_InsuranceSearch_AfzalBahi, SP_InsuranceSearch_BK_11082018, SP_InsuranceSearch_BK_11082018_Result, SP_InsuranceSearch_N, SP_getcptplanlist, SP_getcptplanlist_Result, SP_getpraticedataforCPTPlan, SP_getpraticedataforCPTPlan_Result, UPDATE_TYPE, USP_NPM_PLAN_AGING, USP_NPM_PLAN_AGING_Result, USP_Search_Insurances, USP_Search_Insurances_Result, sp_GetInsuranceAging_Ubaid, sp_insuranceardetailreport, sp_insuranceardetailreport_Result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Patient Demographics

- Feature name: Patient Demographics.
- Business purpose: Supports the PMS patient demographics workflow.
- Frontend route/page/component: ticketresponse, patient, guarantors, Patient/Demographics, referral-physician, patientStatement, :param, Detail/:param, New/:param, Edit/:param, PatientSearch, AgingSummaryPat, patient-birth-days, patient-statement-report, patient-aging-report, patient-aging-analysis-report, esha-patient-aging, add, edit/:id; components include ClaimRejectionComponent, PatientStatementComponent, PatientStatementClaimsComponent, AccountassignmentComponent, AppoinmentsComponent, ClaimSummaryComponent, MainComponent, NotesComponent, PatientNotesComponent, PatientComponent, ReferralComponent, PatientSearchComponent, AgingSummaryPatientWiseComponent, EshaPatientAgingReportComponent, PatientAgingAnalysisComponent, PatientAgingReportComponent, PatientBirthDays, PatientStatementReportComponent, GuarantorComponent, GuarantorsAddEditComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Demographic/GetPatientList, api/Demographic/GetstateList, api/Demographic/SearchPatient, api/Demographic/IsPatientAlreadyExist, api/Demographic/checkDuplicateDOS, api/Demographic/GetPatientModel, api/Demographic/GetPatient, api/Demographic/DeletePatient, api/Demographic/GetFinancialGurantor, api/Demographic/GetFinancialGurantorSubscriber, api/Demographic/GetCityState, api/Demographic/AddEditPatient, api/Demographic/SearchInsurance, api/Demographic/SavePatientInsurance, api/Demographic/DeletePatientInsurance, api/Demographic/GetPatientNotes, api/Demographic/GetPatientNote, api/Demographic/SavePatientNotes, api/Demographic/DeletePatientNote, api/Demographic/SaveClaimAttachmentNotes, api/Demographic/DeleteClaimAttachmentNote, api/Demographic/UploadImage, api/Demographic/GetImage, api/Demographic/GetAppointments, api/Demographic/GetClaimModel, api/Demographic/GetAdmissionType, api/Demographic/SaveClaim, api/Demographic/GetPatientClaims, api/Demographic/DeleteClaim, api/Demographic/GetClaimNotes.
- Service/repository/business logic: DemographicService, PatientAttachmentService, ReferralPhysiciansService.
- Database tables used: AGING_SUMMARY_PATIENT_REPORT, Aging_Summary_Analysis_Report_Patient_Result, BatchPatientClaim, DublicatePatientCheckModel, GUARANTORSRAW_1011004, GUARANTORS_MAPPING_1011004, GetPatientForStatement_Result, GetPatientWithClaimsForItemizedStatement_Result, GetPatientWithClaimsForStatement_Result, Guarantor, NEW_PATIENTLETTER_FIELDS, PATIENT_35510209, PaTIENT_BKP_01142022, Patient, PatientBirthDaysReportResponse, PatientBirthDaysResponse, PatientCreatedEventData, PatientDemographicViewModel, PatientImageModel, PatientInsuranceViewModel, PatientNoteViewModel, PatientPayment, PatientPaymentDetailResponse, PatientPaymentProcessed, PatientPaymentProcessedModel, PatientSearchModel, PatientSearchResultModel, PatientSearchViewModel, PatientStatementMessages, PatientStatementRequest, PatientUpdateRequest, Patient_ASR_Response, Patient_Attachments, Patient_Insurance, Patient_Notes, Patient_Ptl_Feedback, Patient_Statement_Messages, Patient_Statement_Messages3, Patient_Updated, Patients_Data, ReferralPhysicianViewModel, Referral_Physicians, SP_ClaimPatientSearchnew_Result, SP_Claim_patientbysearch_Result, SP_GETPATIENTBDAYS_Result, SP_GUARANTORSEARCH_Result, SP_PATIENTAPPSEARCH_Result, SP_PATIENTINSSERACH_Result, SP_PATIENTSTATEMENTCOUNT_BYCLAIM_Result, SP_PATIENTSTATEMENTCOUNT_PIRUBAID_Result, SP_PATIENTSTATEMENTCOUNT_Result, SP_PatientDueForTicketTracker_Result, SP_PatientSearch_Result, SyncedPatient, Ticket_Patient_Claims_Info, Ticket_Patient_Claims_Info_ViewModel, USP_NPM_PATIENT_AGING_Result, USP_PATIENT_AGING_REPORT_NPM_Result, USP_Patient_Wise_Aging_Summary_Report_NPM_Result, patient_bkp11282018, patient_bkp_11282018, patient_statement_itemized_tets, patient_statement_itemized_tets_, patient_statement_itemized_tets_bkp, uspGetPatientAttachments_Result.
- Stored procedures/functions used: Aging_Summary_Analysis_Report_Patient, Aging_Summary_Analysis_Report_Patient_Result, Claim_Charges, Claim_Document, Claim_Due, Claim_Insurance, Claim_Insurance_Id, Claim_Notes_Id, Claim_Number, Claim_Overpayment, Claim_Reasons, Claim_Rsn, Claim_Status, Claim_Status_Category_Code, Claim_Status_Code, Claim_Status_Date, Claim_Total, Claim_Type, Claim_no, Financial_Guarantor, Financial_Guarantor_Name, SP_277CA_LinkingMessage, SP_CLAIMSUMMARYAMOUNTS, SP_CLAIMSUMMARYAMOUNTS_Hamza, SP_ClaimPatientSearchnew, SP_ClaimPatientSearchnew_Result, SP_Claim_patientbysearch, SP_Claim_patientbysearch_Result, SP_FacilitiesSearch, SP_FacilitiesSearch_Result, SP_GENERATEPATIENTSTATEMENT, SP_GENERATEPATIENTSTATEMENT_XML, SP_GENERATEPATIENTSTATEMENT_bkp_091619, SP_GETPATIENTBDAYS, SP_GETPATIENTBDAYS_Result, SP_GUARANTORSEARCH, SP_GUARANTORSEARCH_Result, SP_GetClaimsListByDOS, SP_GetClaimsListByDOS_Result, SP_InsuranceSearch, SP_InsuranceSearch_Result, SP_PATIENTAPPSEARCH, SP_PATIENTAPPSEARCH_Result, SP_PATIENTINSSERACH, SP_PATIENTINSSERACH_Result, SP_PATIENTSEARCHDUP, SP_PATIENTSTATEMENTCOUNT, SP_PATIENTSTATEMENTCOUNT_BYCLAIM, SP_PATIENTSTATEMENTCOUNT_BYCLAIM_Result, SP_PATIENTSTATEMENTCOUNT_PIRUBAID_Result, SP_PATIENTSTATEMENTCOUNT_Result, SP_PatientDueForTicketTracker, SP_PatientDueForTicketTracker_Result, SP_PatientSearch, SP_PatientSearchNew, SP_PatientSearch_Result, SP_PatientSearch_bkp12262018, SP_showEDIHistory, SP_showEDIHistory_bkp2, USP_GetPatientsWithDue, USP_NPM_PATIENT_AGING, USP_NPM_PATIENT_AGING_Result, USP_PATIENT_AGING_REPORT_NPM, USP_PATIENT_AGING_REPORT_NPM_Result, USP_Patient_Wise_Aging_Summary_Report_NPM, USP_Patient_Wise_Aging_Summary_Report_NPM_Result, USP_Search_ReferringPhysicians, sp_GetPatientAging_Ubaid, sp_result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Payments and Deposit Slip

- Feature name: Payments and Deposit Slip.
- Business purpose: Supports the PMS payments and deposit slip workflow.
- Frontend route/page/component: DepositSlip, payment, payments, monthly, daily, by-carrier, by-primary-dx, by-procedure-code, batchpayments, BatchPaymentAdvisory, payment-detail, ctp-wise-payment-details, batch-payment-report, unapplied-payment; components include DespositSlipComponent, OverallPaymentsByDaily, OverallPaymentsByMonth, PaymentByCarrier, PaymentByPrimaryDX, PaymentByPrimaryICD10, PaymentsComponent, BatchPaymentAdvisoryComponent, BatchPaymentsComponent, UnappliedPaymentsComponent, UnappliedPaymentsPostingComponent, PaymentAdvisoryComponent, PaymentPostingComponent, PaymentSearchComponent, BatchPaymentReportComponent, CtpWisePaymentDetailsComponent, PaymentDetail, UnappliedPaymentReportComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Payments/SearchPayment, api/Payments/AddInsurancePayment, api/Payments/GetPaymentList, api/Payments/CreateUpdateBatch, api/Payments/SearchBatch, api/Payments/CloseBatch, api/Payments/PostPayments, api/Payments/GetBatchPaymentSummary, api/Payments/GetBatchType, api/Payments/GetBatchCheckDetail, api/Payments/AutoCloseEligibleBatches, api/Payments/ReopenBatch, api/Payments/GetBatchDate, api/Payments/ValidateCheckNo, api/Payments/CheckIfBatchHasPayments, api/Payments/GetCurrentResponsible, api/Payments/GetBatchPayments, api/Payments/GetPayments, api/Payments/GetBatchChequeNoAndDate, api/Report/PaymentDetail, api/Report/PaymentDetailPagination, api/Report/CPTWisePaymentDetail, api/Report/CPTWisePaymentDetailPagination, api/Report/ChargesPaymentsRecent, api/Report/PaymentDailyRefresh, api/Report/PaymentMonthWise, api/Report/PaymentByCarrier, api/Report/PaymentPrimaryDX, api/Report/PaymentByPrimaryICD10, api/Report/GetBatchPaymentReport.
- Service/repository/business logic: PaymentsService.
- Database tables used: BATCHPAYMENT, BatchPaymentModel, BatchPaymentResponse, Batch_WisePayments, DEPOSIT_SLIPS, DeleteInvoicepaymentsRequest, Deposit_Bank, Deposit_Bank_Detail, ERA_UNPOSTED_PAYMENTS_EDI_Result, InsurancePaymentRequestModel, InsurancePaymentViewModel, InvoicePayment, Month_end_payments_adjustments, PaymentDetailResponse, PaymentType, Payment_By_Carrier_Result, Payment_Daily_Refresh_Result, Payment_Detail_Result, Payment_detail_Proc_Response, Payment_detail_Proc_Result, Payment_detail_Proctest_Result, PaymentsSearchRequestModel, Payments_at_CPT_Level_Result, SP_AllPaymentSearch_Result, SP_PaymentCreatiaForSreach_Result, SP_PaymentSearchlistfinal_Result, SP_PaymentSearchlistnew_Result, USP_Batch_Payment_Details_Report_Result, USP_GetBatchPayments_Result, USP_Unapplied_Payment_Details_Report_Result, UnappliedPaymentReportModel, UnappliedPaymentViewModel, UnappliedReportResponse, Unapplied_Payments, deposit, deposit1, payment, uspGetAllPaymentbySearch_Result.
- Stored procedures/functions used: ERA_Payment, ERA_UNPOSTED_PAYMENTS_EDI, ERA_UNPOSTED_PAYMENTS_EDI_Result, SP_AllPaymentSearch, SP_AllPaymentSearch_Result, SP_ChargesANDPaymentsTrend, SP_GETChargesPaymentsLastMonthsTets, SP_PaymentCreatiaForSreach, SP_PaymentCreatiaForSreach_Result, SP_PaymentSearchlistfinal, SP_PaymentSearchlistfinal_Result, SP_PaymentSearchlistnew, SP_PaymentSearchlistnew_Result, USP_Batch_Payment_Details_Report, USP_Batch_Payment_Details_Report_Result, USP_GetBatchPayments, USP_GetBatchPayments_Result, USP_NPM_By_Primary_DX_Payment, USP_NPM_Payment_By_Carrier, USP_NPM_Payment_By_Primary_ICD10, USP_NPM_Payment_Daily_Refresh, USP_NPM_Payment_Month_Wise, USP_Unapplied_Payment_Details_Report, USP_Unapplied_Payment_Details_Report_Result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Practice Setup

- Feature name: Practice Setup.
- Business purpose: Supports the PMS practice setup workflow.
- Frontend route/page/component: Facility, ProviderCPT, PracticeTAB, PracticeList, Practice, EditPractice/:id/:Type, FinancialSummaryProvider, practice-analysis-by-facility, practice-analysis-by-provider, Facility; components include ProviderCPTFeeScheduleComponent, ProviderCptfeeScheduleTempComponent, AddEditPracticeComponent, PracFacilitiesComponent, LocationsComponent, PracticeListComponent, PracticeTABComponent, ProvidersComponent, WebPortalsComponent, FinancialSummaryProviderWiseComponent, PracticeAnalysisComponent, PracticeAnalysisByProviderComponent, FacilitiesComponent, ChangePracticeComponent, ProviderCptPlanNotesComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/ClaimAssignment/GetAllAssignedClaimsForPractice, api/ClaimAssignment/GetAllAssignedAccountsForPractice, api/ClaimAssignment/GetAllActivePractices, api/ClaimAssignment/GetPracticeAssignUsers, api/Company/GetCompanyList, api/Company/GetCompanyRecord, api/Company/SaveCompany, api/Company/DeleteCompany, api/Company/GetCompaniesAndRolesSelectList, api/Company/GetOfficeList, api/Company/GetOfficeRecord, api/Company/SaveOffice, api/Company/DeleteOffice, api/Company/GetShiftList, api/Company/GetShiftRecord, api/Company/SaveShift, api/Company/DeleteShift, api/Company/GetAllTeamsList, api/Company/GetTeamList, api/Company/GetTeamRecord, api/Company/SaveTeam, api/Company/DeleteTeam, api/Company/GetCompanyOfficenDepartment, api/Company/GetOfficeIdFromDept, api/Company/GetDepartmentList, api/Company/GetDepartmentRecord, api/Company/SaveDepartment, api/Company/DeleteDepartment, api/Company/GetDesignationList, api/Company/GetDesignationRecord.
- Service/repository/business logic: CompanyService, PracticeService, VendorService.
- Database tables used: CheckPracticeCode, Claim_Provider_Diagnosis_Proc_Result, Company, Default_Setting_Practice, Department_practice, EFS_Practices, Employee_Practice, ExternalPractices_Reporting, Facility, FacilitySearchModel, Facility_Insurance_Id, Facility_Notes, Financial_Analysis_by_Provider_and_Procedure_Codes_Result, GETEFSPRACTICES_Result, GETPRACTICES_WITHDETAILS_Result, GET_ISFACILITY_Result, GetCPTPlanByProviderPlanId_Result, GetCPTPlanByProviderPlanId_Temp_Result, GetCPTPlanByProviderPlanId_Umer_Result, GetPanelBillingSummaryByPractice_Result, GetPracticeActiveUsers_Result, GetPracticeFacilites_Result, GetPracticeUserReportingDetail_Result, Group_Location, Group_Provider, MEMO_MAPPING_PRACTICE_PLAN, MONTH_END_FINANCIAL_PROVIDE_LOCATION, PRACTICES_BKP_021619, PRACTICE_CALLING_DAY_CRITERIA, PRACTICE_CPT_PLAN_GROUP, PRACTICE_DIAGNOSIS1, PRACTICE_DIVISION, PRACTICE_FACILITY, PRACTICE_LOCATIONS_PLAN, PRACTICE_PROCEDURE1, PRACTICE_SERVER, PROVIDER_PAYER_PRINTCENTER, PROVIDER_PROCEDURES, Payer_Facility_Id, Practice, Practice101100205152023_BKP, Practice2, PracticeAppointmentReason, PracticeAppointmentReasonCreateVM, PracticeAppointmentStatu, PracticeAppointmentStatusCreateVM, PracticeAppointmentStatusViewModel, PracticeDocuments_ViewModel, PracticeDxModel, PracticeFTPViewModel, PracticeFacilitesViewModel, PracticeFacilityEditViewModel, PracticeLocationUpdateRequest, PracticeSynchronization, PracticeSynchronizationLog, PracticeSynchronizationModel, PracticeUpdateRequest, PracticeVendor, PracticeViewModel, Practice_Bank_Statement, Practice_CPT_Plan, Practice_Contract, Practice_Daily_Missing_Work, Practice_Doc_Types, Practice_Docs, Practice_Groups, Practice_Locations, Practice_Locations_Plan_Group, Practice_NPI_confirmation, Practice_Notes, Practice_Providers_Plan, Practice_Providers_Plan_Group, Practice_Reporting, Practice_SMS_Settings, Practice_SignUp_Contact_Information, Practice_SignUp_Daily_Office_Hours, Practice_SignUp_Insurance_Information, Practice_SignUp_Physician_Capitation, Practice_SignUp_Physician_Facilities_Info, Practice_SignUp_Referring_Physician.
- Stored procedures/functions used: Check_Bounce_Penalty, Check_Requested_Practice_According_to_User_request, Claim_No, Claim_Payments, Claim_Provider_Diagnosis_Proc, Claim_Provider_Diagnosis_Proc_Result, EFS_PracID, EFS_Practices, ERA_EFT_STATUS, Financial_Analysis_by_Provider_and_Procedure_Codes, Financial_Analysis_by_Provider_and_Procedure_Codes_Result, Get_FTP_According_requested_Practice_Code, Get_List_Of_requests_which_are_in_process_And_with_Same_Practice_as_requested_user, Get_Stats_for_UI_if_no_PRacticeCodeFound, SP_CreateProviderCPTPlanDetails, SP_DeleteProviderPlainWithCPTS, SP_GETPRACTICEANALYSIS, SP_GETPRACTICEANALYSIS_Result, SP_GetLocationState, SP_GetProviderCPTPlan, SP_GetProviderCPTPlanID, SP_GetProviderCPTPlanID_Result, SP_GetProviderCPTPlanIDtemp, SP_GetProviderCPTPlan_Result, SP_GetStandardCPTSByPracticeState, SP_GetStandardCPTSByPracticeState_Result, SP_InsFacilityInfoWithoutModifierAndProcedure, SP_InsFacilityInfoWithoutModifierAndProcedure_Result, SP_InsFacilityPlan, SP_InsFacilityPlan_Result, SP_InsLocationPlan, SP_InsLocationPlan_Result, SP_InsLocationWithoutModifierAndProcedure, SP_InsLocationWithoutModifierAndProcedure_Result, SP_PRACTICEPROVIDERPAYERSEARCH, SP_PRACTICEPROVIDERPAYERSEARCH_Result, SP_PROVIDERPAYERSEARCH, SP_PROVIDERPAYERSEARCH_Result, SP_ProviderInfo, SP_ProviderInfo_Result, SP_ProviderPlan, SP_ProviderPlan_Result, SP_ProviderWithoutModifierAndProcedure, SP_ProviderWithoutModifierAndProcedure_Result, SP_SearchProviderCPTFeePlan, SP_SearchProviderCPTFeePlan_Result, SP_SelectAllPracticeUsers, SP_SelectAllPracticeUsers_Result, USP_GetCredPortal_By_PracticeCode, USP_GetCredPortal_By_PracticeCode_Result, USP_GetOfficeTimeForProvidersAndLocations, USP_GetOfficeTimeForProvidersAndLocations_Result, USP_Get_Practice_Docs, USP_Get_Practice_Docs_Result, USP_Get_Provider_Docs, USP_Get_Provider_Docs_Result, USP_NPM_PAYER_MAPPING, USP_NPM_PAYER_MAPPING_LOCATION, USP_NPM_PAYER_MAPPING_PROVIDER, USP_Practice_Assign_Users, sp_provider_working_times, sp_provider_working_times_Result, usp_GetPracticeReportingDetails, usp_GetPracticeReportingDetails_Result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Reports and Analytics

- Feature name: Reports and Analytics.
- Business purpose: Supports the PMS reports and analytics workflow.
- Frontend route/page/component: ReportSetup, reporting, reports, cred-app-report, hospital-status-report, hospital-grid-report, cred-grid-report, charges, by-cpt, by-hospital, by-primary-dx-dos, by-carrier, cpa, AgingSummary, FinancialSummaryCPT, RecallVisits, acount-assignmentreport, user-report; components include CredAppReportComponent, CredGridReportComponent, CredReportsComponent, HospitalGridReportComponent, HospitalStatusReportComponent, CpaComponent, ByCPTDos, ChargesByCarrierDos, ChargesByHospital, ChargesByPrimaryDxDOS, ChargesComponent, DynamicReportsComponent, AccountAssignmentreportComponent, AgingSummaryReportComponent, ChargesBreakDownReportComponent, CollectionAnalysisReportComponent, DenialReportComponent, FinancialSummaryCPTWiseComponent, MainReportsComponent, NegativeBalanceReportComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Credentialing/GetCredAppReport, api/Credentialing/GetHospitalStatusReport, api/Credentialing/GetHospitalGridReport, api/Credentialing/GetCredGridReport, api/Report/AgingSummaryAnalysisReport, api/Report/FinancialAnalysisCPTLevelReport, api/Report/holdReport, api/Report/RecallVisits, api/Report/PeriodAnalysisAndClosing, api/Report/AgingSummaryRecent, api/Report/GetUserReport, api/Report/GetUserReportPagination, api/Report/GetRollingSummaryReport, api/Report/CollectionAnalysisReport, api/Report/CollectionAnalysisReport, api/Report/DenialReportDetailPagination, api/Report/DenialReportDetail, api/Report/GetNegativeBalanceReport, api/Report/GetEshaCBRDetails, api/Report/ByCPTDos, api/Report/ByHospitalDos, api/Report/ByPrimaryDXDos, api/Report/ByCarrierDOS, api/Report/CPA, api/Report/AccounAssignmentReport, api/Report/AccounAssignmentReportPagination, api/Report/GetChargesBreakDownReport.
- Service/repository/business logic: ReportService.
- Database tables used: AGING_SUMMARY_REPORT, Aging_Summary_Analysis_Report_Result, Aging_Summary_Analysis_Reporting_Result, CPTs_Ana_by_Report_Result, CPTs_Analysis_by_Report_Result, CSIReportModel, ChargesBreakdownReportResponse, Cred_Hospital_Status_Report, Denial_Report_Response, EFS_ImpactSummary, FINANCIAL_SUMMARY_REPORT, Fiancial_Summary, Financial_Analysis_At_CPT_Level_Result, Hospital_Grid_Report, MONTH_END_AGING, MONTH_END_FINANCIAL, NegativeBalanceReportResponse, REPORT_Sami_Result, ReportRequestModel, SP_AGINGCOMPDEMO_Result, SP_AGINGDEMO_Result, SP_Cred_App_Report_Result, SP_GETPERIODANALYSISANDCLOSING_Result, SP_getuserDailyReport_Result, SP_userReportChargesNewPMOSB_Result, SP_userReportCharges_Result, USP_COLLECTION_ANALYSIS_REPORT_NPM_Result, USP_Credentialing_Grid_Report_Result, USP_Denial_Report_Result, USP_NEGATIVE_BALANCE_REPORT_Result, aging_populated_record, userDailyReportResponse.
- Stored procedures/functions used: Aging_Comparison, Aging_Summary_Analysis_Report, Aging_Summary_Analysis_Report_Result, Aging_Summary_Analysis_Reporting, Aging_Summary_Analysis_Reporting_Result, Charges_Per_Unit, EFS_AC_Ratio, EFS_Adjusted, EFS_Approved, EFS_BeqApp_Ratio, EFS_BillEqApp, EFS_Billed, EFS_ImpactSummary, EFS_PC_Ratio, Financial_Analysis_At_CPT_Level, Financial_Analysis_At_CPT_Level_Result, Financial_Summary, SP_AGINGCOMPDEMO, SP_AGINGDEMO, SP_Aging_Papulated, SP_COSSCPABYADDCRT, SP_Cred_App_Report_Result, SP_Credentialing_Report, SP_GETPERIODANALYSISANDCLOSING, SP_GETPERIODANALYSISANDCLOSING_Result, SP_GETRECALLVISITS_EGD, SP_GetCPAAnalysis, SP_PCRatio, SP_getuserDailyReport, SP_getuserDailyReport_Result, SP_laim_Charges_Summary, SP_rollingReport, SP_userReportCharges, SP_userReportChargesNewPMOSB, SP_userReportChargesNewPMOSB_Result, SP_userReportCharges_Result, USP_COLLECTION_ANALYSIS_REPORT_NPM, USP_COLLECTION_ANALYSIS_REPORT_NPM_Result, USP_Charge_Breakdown, USP_Credentialing_Grid_Report, USP_Credentialing_Grid_Report_Result, USP_Credentialing_Hospital_Status_Report, USP_Denial_Report, USP_Denial_Report_Result, USP_Hospital_Grid_Report, USP_NEGATIVE_BALANCE_REPORT, USP_NEGATIVE_BALANCE_REPORT_Result, USP_NPM_By_Carrier_DOS, USP_NPM_By_Cpt_DOS, USP_NPM_By_Hospital, USP_NPM_By_Primary_Dx_DOS, USP_NPM_COSSCPABYADDCRT, USP_NPM_OVER_ALL_CHARGES, sp_name.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Scheduler and Appointments

- Feature name: Scheduler and Appointments.
- Business purpose: Supports the PMS scheduler and appointments workflow.
- Frontend route/page/component: appointments, scheduler, officeTiming, statuses, reasons, block-appointments, Standard, NobilityCPT, PanelBilling, appointment-detail, missing-appointment-detail; components include AppointmentReasonsComponent, AppointmentSchedulerComponent, AppointmentStatusComponent, BlockAppointmentsComponent, OfficeTimingsComponent, SchedulerComponent, AppointmentDetailComponent, MissingAppointmentDetailComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Report/AppointmentDetailReport, api/Report/MissingAppointmentDetailReport, api/Scheduler/GetAppointments, api/Scheduler/GetExistingAppointments, api/Scheduler/GetAppointmentModel, api/Scheduler/GetAppointmentdetail, api/Scheduler/GetReasonsSelectList, api/Scheduler/Save, api/Scheduler/Delete, api/Scheduler/Timings, api/Scheduler/Rules, api/Scheduler/SaveOfficeTimings, api/Scheduler/SaveAppointmentRules, api/Scheduler/GetMatchingSchedules, api/Scheduler/Statuses, api/Scheduler/SaveStatus, api/Scheduler/GetPracAppointmentReasons, api/Scheduler/GetAppointmentReasons, api/Scheduler/GetUnassignedAppointmentReasons, api/Scheduler/SaveReason, api/Scheduler/ChangeColor, api/Scheduler/SlotAvailability, api/Scheduler/InquiryByAppointmentId.
- Service/repository/business logic: SchedulerService.
- Database tables used: Appointment, Appointment_Status, AppointmentsSearchViewModel, GetAppointmentById_Result, GetAppointmentEvents_Result, GetAppointment_Result, GetExistingAppointmentData_Result, GetOfficeTiming_Result, SP_Appointment_Detail_Report_Result, SP_Missing_Appointment_Report_Result, Scheduler_Types, Scheduler_customization, appointment_reasons, room_booking_appointment.
- Stored procedures/functions used: Check_Duplicate_Blocking_Rule, Check_Office_Timing, SP_Appointment_Detail_Report, SP_Appointment_Detail_Report_Result, SP_Missing_Appointment_Report, SP_Missing_Appointment_Report_Result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Shared/Common and Miscellaneous

- Feature name: Shared/Common and Miscellaneous.
- Business purpose: Supports the PMS shared/common and miscellaneous workflow.
- Frontend route/page/component: No direct route found; shared/component-level surface; components include AppComponent, BaseComponent, ErrorPageComponent, FooterComponent, LayoutComponent, NavbarComponent, TopnavbarComponent, EligblityComponent, FeeScheduleMainComponent, NobilityCPTFeeScheduleComponent, PanelBillingComponent, StandardCPTFeeScheduleComponent, OfficemanagementComponent, DXComponent, NdcComponent, ListProceduresComponent, ProceduresComponent, ColorPickerComponent, ModalWindow, PhysicianSearchComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Home/Index, api/Setup/GetGurantorsList, api/Setup/GetGurantorsList, api/Setup/GetNDCList, api/Setup/GetDXList, api/Setup/GetGurantor, api/Setup/SaveGurantor, api/Setup/SaveDX, api/Setup/UpdateDX, api/Setup/SaveNDC, api/Setup/DeleteNDC, api/Setup/DeleteDX, api/Setup/DeleteGurantor, api/Setup/GetStatesList, api/Setup/GetuserList, api/Setup/GetStandardCPTFeeSchedule, api/Setup/GetRevenueCodes, api/Setup/GetDescriptionByCPT, api/Setup/CheckCode, api/Setup/GetByAlternateCode, api/Setup/CheckDuplicateAlternateCode, api/Setup/CheckDuplicateCPT, api/Setup/PaginateStandardCPTFee, api/Setup/GetStandardNobilityCPTFeeSchedule, api/Setup/GetProcedure, api/Setup/GetDropdownsListForProcedures, api/Setup/DuplicateProcAndAlternateCode, api/Setup/SaveProcedure, api/Setup/DeleteProcedure, api/Setup/SearchProcedures.
- Service/repository/business logic: ExcelFileHandlerService, FileHandlerService, NPMLogger, PDFService, SetupService, TTService.
- Database tables used: AccountAssigneeResponse, AccountAssignee_AL, AccountAssignee_Notes, AddressType, Admission_Details, Amt, AppealAttachment, AssigneeusersList, Attachment_TypeCode, BALANCE, BatchErrorsRequestModel, BatchStatusModel, BatchesHistoryRequestModel, By_Cpt_DOS_Result, CPT, CPTChargesViewModel, CPT_FEE_STRUCTURE, CPT_Fee_Charge, CPT_HOSPBILLS, CSI_Batch, CSI_Batch_Error, CSI_Batch_Response, C__EFMigrationsHistory, Category, Charges_at_CPT_Level_Result, Check_Duplicate_Blocking_Rule_Result, Check_Office_Timing_Result, City, Clearing_Houses, ColorChangeModel, CombinedCodeModel, Components, Condition_Codes, Cpt_Current_Status, Cpt_ShortCodes, CreateAttachmentRequest, Cruduser, CustomField, CustomValue, CustomValue1, CustomValues_Column, Customised_Procedure_Description, Customised_diagnosis_Description, DO, DOCUMENT_CATEGORIES, DOSAGE_UNITS, DXSearchCriteria_Result, DXViewModel, Data12356, DataModel, Datet, Days_Of_Week, DelayReason1, DelayReasonsNew, DeleteInvoiceResponse, Deleted_Codes, DeleteinvoicepymentResponse, Delivery_Zone, Department, DepartmentViewModel, DeptShiftTiming, Designation, DesignationViewModel, Diagnosi, DiagnosisAccDel, Discharge_Status, Division, Doc_Type_Lookup, DownloadedFile, Dtp, Dummy, EFS_Suggested, ENROLLMENT_TRACKER, EOB_Adjustment_Codes, EligRequestTEST_Result, EligRequest_Result, EligRequests_Result, ExcelFieldsViewModel, FINAL2, File277CA.
- Stored procedures/functions used: Charges___, Charges_at_CPT_Level, Charges_at_CPT_Level_Result, Check_Duplicate_Blocking_Rule_Result, Check_Office_Timing_Result, EFS_Suggested, MIS_TBL_CPT_Reason, MIS_TBL_Institution_Condition_Code, NPM_API, SP_CPADEMO, SP_GETRECALLVISITS_EGD_Result, SP_GetBatchDetail1, SP_GetBatchDetail1_Result, SP_GetPricingModifier, SP_GetStandardCPTs, SP_GetStandardCPTs_Result, SP_NDCSEARCH, SP_NDCSEARCHBySearch, SP_NDCSEARCHBySearchCriteria, SP_NDCSEARCHBySearchCriteria_Result, SP_NDCSEARCHBySearch_Result, SP_NDCSEARCH_Result, SP_ProcedureSearch, SP_ProcedureSearch_BKP_Afzl, SP_ProcedureSearch_Result, USP_Charge_Breakdown_Result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### Ticket Tracker and Tasks

- Feature name: Ticket Tracker and Tasks.
- Business purpose: Supports the PMS ticket tracker and tasks workflow.
- Frontend route/page/component: No direct route found; shared/component-level surface; components include AccountLevelComponent, TasksComponent, TicketTrackerComponent, CreateTicketComponent, TicketResponseComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/TicketAttachment/TicketAttach, api/TicketTracker/GetTTDepartmentsList, api/TicketTracker/SaveTicket, api/TicketTracker/SearchTicket, api/TicketTracker/TicketAssignment, api/TicketTracker/GetTicketById, api/TicketTracker/GetTicketTrackById, api/TicketTracker/SaveTrackDetails, api/TicketTracker/DeleteTrackDetails, api/TicketTracker/GetAssignedUser, api/TicketTracker/SendTicketEmail, api/TicketTracker/SendMultipleTicketEmail, api/TicketTracker/GetTicketTrackerLookUps, api/TicketTracker/GetUsersByDepartment, api/TicketTracker/GetOpenTicketCount.
- Service/repository/business logic: TicketAttachmentsService.
- Database tables used: GetTicketTrackDetail, GetTicketsWithFiltersResult, TASK, TASK_CATEGORIES, Ticket, TicketAssignmentDetails, TicketAssignmentRequest, TicketMessageDetail, TicketSearchModel, TicketTrackerLookups, Ticket_Priority, Ticket_Reason, Ticket_Tracking, Ticket_Type, Ticket_attachments, Tickettracker, USP_GetTickets_WithFilters_Result, UsertaskAssigned, task_data_dump_cpt, usp_GetTicketsWithFilters_Anum_Result, usp_GetTicketsWithFilters_Result.
- Stored procedures/functions used: USP_GetTickets_WithFilters, USP_GetTickets_WithFilters_Result, usp_GetTicketsWithFilters_Anum_Result, usp_GetTicketsWithFilters_Result.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

### User Management and Permissions

- Feature name: User Management and Permissions.
- Business purpose: Supports the PMS user management and permissions workflow.
- Frontend route/page/component: eligblity, ticket-tracker, users, OfficeMGM, Tasks, FeeSchedule, procedures, diagnosis, ndc, credentialing, importwizard, 404, **, credApp, credPortal, credPortal, CredTasks; components include EmployeeDetailComponent, EmployeesComponent, ListEmployeesComponent, ListModuleComponent, ModuleDetailComponent, ModuleComponent, DetailPropertiesComponent, ListPropertiesComponent, PropertiesComponent, ListRoleComponent, RoleDetailComponent, RoleComponent, RoleRightsComponent, RoleWiseRightsComponent, UsersWiseRightsComponent, ListSubModuleComponent, SubModuleDetailComponent, SubModulesComponent, UserManagementComponent.
- User actions: Search/list, add/edit/view, submit/post, upload/download, filter/report, or workflow-specific actions based on component templates and controller actions.
- Backend controller/API endpoint: api/Credentialing/GetUsersByModuleName, api/Credentialing/GetCredUserByRole, api/Credentialing/GetCredUserListByRole, api/UserManagementSetup/GetModulesList, api/UserManagementSetup/GetModule, api/UserManagementSetup/DeleteModule, api/UserManagementSetup/SaveModule, api/UserManagementSetup/GetUsersList, api/UserManagementSetup/verifyEmail, api/UserManagementSetup/empIdExists, api/UserManagementSetup/SaveUser, api/UserManagementSetup/GetUser, api/UserManagementSetup/ResetPassword, api/UserManagementSetup/ResetPasswordByUser, api/UserManagementSetup/DeleteUser, api/UserManagementSetup/ChangeUserStatus, api/UserManagementSetup/GetUsersSelectList, api/UserManagementSetup/GetRoleList, api/UserManagementSetup/SaveRole, api/UserManagementSetup/GetRole, api/UserManagementSetup/DeleteRole, api/UserManagementSetup/GetRolesSelectList, api/UserManagementSetup/GetTemplateByRoleId, api/UserManagementSetup/GetTemplateByUserId, api/UserManagementSetup/SaveRoleModuleProperties, api/UserManagementSetup/SaveUserModuleProperties, api/UserManagementSetup/GetSubModuleList, api/UserManagementSetup/GetModulesSelectList, api/UserManagementSetup/GetSubModule, api/UserManagementSetup/SaveSubModule.
- Service/repository/business logic: UserManagementService.
- Database tables used: CLC_Assigned_Roles, CLC_Roles, Employee, EmployeeInformation, Module, ModuleViewModel, Module_Properties, Module_Properties_bkp20230821, Module_Properties_bkp2023_08_21, Role, Roles_Module_Properties, Sub_Module, Users_Module_Properties, Users_Module_Properties_bkp20230821, Users_Roles, office_employees, rolesss.
- Stored procedures/functions used: SP_Date_Of_Birth, SP_Employee_Id, SP_First_Name, SP_Gender, SP_Last_Name, SP_Middle_Initial, SP_Nic_Number, SP_Relation, USP_GETCredUsersByRole, USP_GETUsersListByRole.
- Validations: Client-side Angular validators/form checks plus backend model/service validation where implemented; exact required fields must be confirmed against DTOs and DB schema.
- Permissions/roles: AuthGuard/JWT required for authenticated app shell; module/property/role/user-right rules should be reconstructed from User Management data.
- Success flow: User enters criteria/data, UI calls API, controller delegates to service, service persists/query data, response updates grid/form/report/download/navigation.
- Error/exception flow: Invalid input blocks client or returns API error; service/database/integration exceptions are logged and surfaced as error notifications or failed responses.
- Dependencies/integrations: Uses shared auth, encryption, configuration, audit/logging, database, and any module-specific EDI/FTP/InboxHealth/file/report dependencies discovered in technical inventory.
- Migration notes for .NET Core 10: Preserve flow contract first, then modernize route names, typed DTOs, validation, authorization policies, async EF Core data access, background workers, and OpenAPI-backed client generation.

## API-to-Frontend Mapping

The following source-derived mapping lists UI HTTP call evidence. Exact endpoint URLs often use string concatenation and shared base URL variables, so this table should be reviewed while modernizing API clients.

| Method | UI source | Endpoint/string evidence |
| --- | --- | --- |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:535 | //     const encodedData = params.get('param'); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:550 | // this.formControls['hospitalization'].get('ptlStatus').setValue(this.claimViewModel.ClaimModel.PTL_Status) |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:701 | // this.formControls['hospitalization'].get('ptlStatus').setValue(this.claimViewModel.ClaimModel.PTL_Status) |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:703 | /UBClaim/GetallDropdowns |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:715 | this.ptlSubscription = this.formControls['hospitalization'].get('ptlStatus').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:716 | if (this.formControls['hospitalization'].get('ptlStatus').value) { |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:717 | this.formControls['hospitalization'].get('ptlReason').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:718 | this.formControls['hospitalization'].get('ptlReason').updateValueAndValidity({ onlySelf: true, emitEvent: false }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:721 | this.formControls['hospitalization'].get('ptlReason').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:722 | this.formControls['hospitalization'].get('ptlReason').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:723 | this.formControls['hospitalization'].get('ptlReason').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:733 | this.facilitySubscription = this.formControls['hospitalization'].get('facility').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:734 | if (!Common.isNullOrEmpty(this.claimViewModel.ClaimModel.Facility_Code) && !Common.isNullOrEmpty(this.formControls['hospitalization'].get('facility').value)) { |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:735 | this.formControls['hospitalization'].get('Hospital_From').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:736 | this.formControls['hospitalization'].get('Hospital_From').updateValueAndValidity({ onlySelf: true, emitEvent: false }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:738 | this.formControls['hospitalization'].get('Hospital_From').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:739 | this.formControls['hospitalization'].get('Hospital_From').updateValueAndValidity({ onlySelf: true, emitEvent: false }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:740 | this.formControls['hospitalization'].get('Hospital_From').reset() |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:767 | // this.claimForm.get('hospitalization.Hospital_From').setValue(this.claimViewModel.ClaimModel.Hospital_From); |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:841 | /Demographic/GetClaimModel?PatientAccount= |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1387 | /Demographic/GetModifiers |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1396 | /Demographic/GetstateList |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1558 | /Demographic/GetPAByAccount?aCCOUNT_NO= |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1566 | /Demographic/GetClaimModel?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1709 | let formDos = this.claimForm.get('dos') |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1710 | this.claimForm.get('main.dos').setValue(null) |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1711 | formDos = this.claimForm.get('dos') |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1713 | //       this.claimForm.get('dos').setValue({ month: null, day: null ,year: null}); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1714 | //                       this.claimForm.get('dos').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1715 | //                       this.claimForm.get('dos').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1716 | //                       this.claimForm.get('dos').setValue(''); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1718 | // this.claimForm.get('dos').setValue({}); |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1901 | /Report/DormantClaimsReports?Claim_no= |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:1905 | /Demographic/CheckCollectionStatus?Claim_no= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:2616 | this.claimForm.get('hospitalization.ptlStatus').setValue(false) |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:2620 | this.claimForm.get('hospitalization.ptlStatus').setValue(true) |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3426 | /Setup/GetRevenueCodes?Code= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3812 | this.claimForm.get('main.patientStatus').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3813 | this.claimForm.get('main.priStatus').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3814 | this.claimForm.get('main.secStatus').setValue(null); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:3815 | this.claimForm.get('main.othStatus').setValue(null); |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:4096 | /Setup/DuplicateAlternateCodeClaimCharges?AlternateCode= |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:4958 | /Demographic/GetAdmissionType?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5715 | this.formControls['hospitalization'].get('facilityDates').patchValue({ myDateRange: '' }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5724 | this.formControls['correctedClaimGroup'].get('ICN_Number').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5725 | this.formControls['correctedClaimGroup'].get('ICN_Number').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5726 | this.formControls['correctedClaimGroup'].get('RSCode').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5727 | this.formControls['correctedClaimGroup'].get('RSCode').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5731 | this.formControls['correctedClaimGroup'].get('ICN_Number').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5732 | this.formControls['correctedClaimGroup'].get('ICN_Number').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5733 | this.formControls['correctedClaimGroup'].get('RSCode').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:5734 | this.formControls['correctedClaimGroup'].get('RSCode').updateValueAndValidity({ onlySelf: true, emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6213 | //     const control = this.paymentResponsibilityForm.get(controlName); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6224 | const control = this.paymentResponsibilityForm.get(controlName); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6274 | this.paymentResponsibilityForm.get('creditbalance').setValue(this.TotaldueAmt); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6277 | this.paymentResponsibilityForm.get('overpaid').setValue(this.TotaldueAmt); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6280 | const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6281 | const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6300 | this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6301 | this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6327 | this.paymentResponsibilityForm.get('creditbalance').setValue(this.TotaldueAmt); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6328 | this.paymentResponsibilityForm.get('overpaid').setValue('') |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6332 | this.paymentResponsibilityForm.get('overpaid').setValue(this.TotaldueAmt) |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6333 | this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6337 | const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6338 | const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6355 | this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value; |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6356 | this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value; |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6387 | /Demographic/GetClaimOverPayment?claimNo= |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6400 | this.paymentResponsibilityForm.get('overpaid').setValue(overpaid); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6401 | this.paymentResponsibilityForm.get('creditbalance').setValue(creditBalance); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6408 | this.paymentResponsibilityForm.get('overpaid').setValue(overpaid); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6409 | this.paymentResponsibilityForm.get('creditbalance').setValue(creditBalance); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6687 | this.claimForm.get('main.location').setValue(this.recentClaimDetails.Location_Code); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6688 | this.claimForm.get('main.rendPhy').setValue(this.recentClaimDetails.Attending_Physician); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6689 | this.claimForm.get('main.billPhy').setValue(this.recentClaimDetails.Billing_Physician); |
| GET | NPM_UI_BackUp/src/app/Claims/claims.component.ts:6726 | this.claimForm.get('main.autofill').setValue(true); |
|  | NPM_UI_BackUp/src/app/Claims/claims.component.ts:8037 | /InsuranceSetup/GetRelationsSelectList |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:179 | /Scrubber/GetTableList |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:443 | /Scrubber/GetCustomRuleById/ |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:494 | /Scrubber/GetCustomRuleById/ |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:520 | /Scrubber/GetColumn_Lists_FrontEnd |
|  | NPM_UI_BackUp/src/app/custom-edits/custom-edits.component.ts:535 | /Scrubber/GetAllCustomEdits |
|  | NPM_UI_BackUp/src/app/directives/noSpace.directive.ts:19 | ).trim().replace(/\s/g, |
|  | NPM_UI_BackUp/src/app/directives/noSpace.directive.ts:25 | ).replace(/\s/g, |
|  | NPM_UI_BackUp/src/app/edisetup/edi-setup-main.component.ts:39 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/edisetup/edi-setup-main.component.ts:61 | /Submission/GenerateBatch_5010_P?practice_id= |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:15 | /Common/commonFileuploaddata |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:16 | /Users/UploadProfilePicture |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:17 | /Common/downloadattachedfile |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:18 | /patientattachments/Attach |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:19 | /patientattachments/UploadFiles |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:20 | /patientattachments/GetAll |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:21 | /patientattachments/GetAttachmentCodeList |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:22 | /ERA/Import |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:23 | /ERA/WeekHistoryOfERA |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:24 | /ClaimsAttachments/Attach |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:25 | /ClaimsAttachments/GetAll |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:26 | /ClaimsAttachments/GetAttachmentCodeList |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:27 | /ERA/ERAImport |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:28 | /ERA/ManualERAFileProcessing |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:29 | /Token/ResetPasswordForOTP |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:30 | /PracticeSetup/ProviderDocFileUpload |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:31 | /PracticeSetup/PracticeDocFileUpload |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:32 | /Credentialing/UploadCredAppDocument |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:33 | /Demographic/UploadImage |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:34 | /CredEDIERASetup/UploadCred_EDIERA_Document |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:35 | /ImportWizard/ExcelImport |
|  | NPM_UI_BackUp/src/app/helpers/encrypt-decrypt-interceptor.ts:36 | /ImportWizard/DownloadImportWizardTemplateFile |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:163 | /Company/GetCompanyList |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:225 | /Company/DeleteCompany?CompanyId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:237 | /Company/GetDepartmentList?officeId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:325 | /Company/DeleteDepartment?DepartmentId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:337 | /Company/GetDesignationList |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:372 | /Company/GetOfficeIdFromDept?DeptId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:430 | /Company/DeleteDesignation?DesignationId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:440 | /Company/GetOfficeList?companyId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:503 | /Company/DeleteOffice?OfficeId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:517 | /Company/GetShiftList |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:577 | /Company/DeleteShift?ShiftId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:601 | /Company/GetTeamList?companyId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:708 | /Company/DeleteTeam?TeamId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:758 | /Company/GetCompanyList |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:771 | /Company/GetOfficeList?companyId= |
|  | NPM_UI_BackUp/src/app/officemanagement/officemanagement.component.ts:783 | /Company/GetDepartmentList?officeId= |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:425 | this.patientInsurancesControl = this.PatientForm.get('patientInsurance') as FormArray; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:455 | let emailCtrl = this.formControls['contact'].get('email'); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:462 | if (this.formControls['death'].get('deceased').value === false) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:468 | if (this.formControls['guarantor'].get('relationship').value === null \|\| this.formControls['guarantor'].get('relationship').value === undefined \|\| this.formControls['guarantor'].get('relationship').value.toString() !== '7') { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:469 | this.formControls['guarantor'].get('name').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:470 | this.formControls['guarantor'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:472 | this.formControls['guarantor'].get('name').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:473 | this.formControls['guarantor'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:474 | this.formControls['guarantor'].get('name').setValue(''); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:481 | if (this.formControls['emergency'].get('relationship').value !== null && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:482 | this.formControls['emergency'].get('relationship').value === '7') { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:484 | this.formControls['emergency'].get('name').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:485 | this.formControls['emergency'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:486 | this.formControls['emergency'].get('phone').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:487 | this.formControls['emergency'].get('phone').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:488 | this.formControls['emergency'].get('relationship').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:489 | this.formControls['emergency'].get('relationship').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:490 | this.formControls['emergency'].get('name').setValue(null); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:491 | this.formControls['emergency'].get('phone').setValue(null); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:492 | } else if (this.formControls['emergency'].get('relationship').value !== null && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:493 | this.formControls['emergency'].get('relationship').value !== '7') { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:495 | this.formControls['emergency'].get('name').setValidators([Validators.required, Validators.maxLength(100)]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:496 | this.formControls['emergency'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:497 | this.formControls['emergency'].get('relationship').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:498 | this.formControls['emergency'].get('relationship').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:499 | this.formControls['emergency'].get('phone').setValidators([Validators.required, Validators.minLength(10), Validators.maxLength(10)]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:500 | this.formControls['emergency'].get('phone').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:501 | } else if (!Common.isNullOrEmpty(this.formControls['emergency'].get('phone').value) \|\| |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:502 | !Common.isNullOrEmpty(this.formControls['emergency'].get('name').value)) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:504 | this.formControls['emergency'].get('name').setValidators([Validators.required, Validators.maxLength(100)]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:505 | this.formControls['emergency'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:506 | this.formControls['emergency'].get('relationship').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:507 | this.formControls['emergency'].get('relationship').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:508 | this.formControls['emergency'].get('phone').setValidators([Validators.required, Validators.minLength(10), Validators.maxLength(10)]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:509 | this.formControls['emergency'].get('phone').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:512 | this.formControls['emergency'].get('name').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:513 | this.formControls['emergency'].get('name').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:514 | this.formControls['emergency'].get('phone').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:515 | this.formControls['emergency'].get('phone').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:516 | this.formControls['emergency'].get('relationship').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:517 | this.formControls['emergency'].get('relationship').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:524 | this.generalLastNameSub = this.PatientForm.controls['general'].get('lastName').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:529 | this.generalFirstNameSub = this.PatientForm.controls['general'].get('firstName').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:534 | this.generalDobSub = this.PatientForm.controls['general'].get('dob').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:548 | return !(this.formControls['general'].get('firstName').valid && this.formControls['general'].get('lastName').valid && (!this.emergencyGroupRequired \|\| (this.emergencyGroupRequired && this.formControls['emergency'].valid)) && valid); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:554 | this.formControls['contact'].get('email').disable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:556 | this.formControls['contact'].get('email').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:557 | this.formControls['contact'].get('email').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:560 | this.formControls['contact'].get('email').enable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:562 | this.formControls['contact'].get('email').setValidators([Validators.email, Validators.maxLength(256), Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:563 | this.formControls['contact'].get('email').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:570 | this.formControls['death'].get('deceasedDate').enable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:571 | this.formControls['death'].get('deceasedDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:572 | this.formControls['death'].get('deceasedDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:577 | this.formControls['death'].get('deceasedDate').disable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:578 | this.formControls['death'].get('deceasedDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:579 | this.formControls['death'].get('deceasedDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:587 | this.formControls['patientbilling'].get('patientbillingDate').enable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:588 | this.formControls['patientbilling'].get('patientbillingDate'); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:589 | this.formControls['patientbilling'].get('patientbillingDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:594 | this.formControls['patientbilling'].get('patientbillingDate').disable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:595 | this.formControls['patientbilling'].get('patientbillingDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:596 | this.formControls['patientbilling'].get('patientbillingDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:602 | if (this.formControls['contact'].get('email').value) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:603 | this.formControls['contact'].get('emailNotAvailable').setValue(false); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:604 | this.formControls['contact'].get('emailNotAvailable').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:606 | if (this.formControls['contact'].get('emailNotAvailable').value) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:607 | this.formControls['contact'].get('email').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:608 | this.formControls['contact'].get('email').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:611 | this.formControls['contact'].get('email').setValidators([Validators.email, Validators.maxLength(256), Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:612 | this.formControls['contact'].get('email').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:623 | // this.emailNotAvailableSub = this.formControls['contact'].get('emailNotAvailable').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:628 | // this.emailSub = this.formControls['contact'].get('email').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:634 | this.emergencyNameSub = this.formControls['emergency'].get('name').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:639 | this.emergencyRelationshipSub = this.formControls['emergency'].get('relationship').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:644 | this.emergencyPhoneSub = this.formControls['emergency'].get('phone').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:652 | this.deathDeceasedSub = this.formControls['death'].get('deceased').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:660 | this.formControls['guarantor'].get('relationship').valueChanges.subscribe(() => { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:678 | if (this.formControls['general'].get('lastName').valid && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:679 | this.formControls['general'].get('firstName').valid && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:680 | this.formControls['general'].get('dob').valid && |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:681 | this.formControls['contact'].get('zip').valid) { |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:685 | FirstName: this.formControls['general'].get('firstName').value, |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:686 | LastName: this.formControls['general'].get('lastName').value, |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:687 | zip: this.formControls['contact'].get('zip').value, |
|  | NPM_UI_BackUp/src/app/patient/patient.component.ts:707 | /Demographic/GetCitiesByZipCode?ZipCode= |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:787 | this.PatientForm.get('dob').setValue(event.formatted); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:788 | this.PatientForm.get('dob').markAsTouched(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:789 | this.PatientForm.get('dob').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:793 | this.formControls['death'].get('deceasedDate').setValue(null); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:794 | this.formControls['death'].get('deceasedDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:795 | this.formControls['death'].get('deceasedDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:799 | this.formControls['death'].get('deceasedDate').setValue(this.patient.DeathDate); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:800 | this.formControls['death'].get('deceasedDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:810 | this.formControls['patientbilling'].get('patientbillingDate').setValue(null); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:811 | this.formControls['patientbilling'].get('patientbillingDate'); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:812 | this.formControls['patientbilling'].get('patientbillingDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:816 | this.formControls['patientbilling'].get('patientbillingDate').setValue(this.patient.Hold_pt_until); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:817 | this.formControls['patientbilling'].get('patientbillingDate').updateValueAndValidity({ emitEvent: true, onlySelf: false }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:995 | this.patient.PatientInsuranceList[i].PayerDescription = group.get('payerDescription').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:996 | this.patient.PatientInsuranceList[i].Pri_Sec_Oth_Type = group.get('insuranceMode').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:997 | this.patient.PatientInsuranceList[i].Policy_Number = group.get('policyNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:998 | if(group.get('IS_Active').value==true){ |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1082 | this.patient.PatientInsuranceList[i].PayerDescription = group.get('payerDescription').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1083 | this.patient.PatientInsuranceList[i].Pri_Sec_Oth_Type = group.get('insuranceMode').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1084 | this.patient.PatientInsuranceList[i].Policy_Number = group.get('policyNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1085 | if(group.get('IS_Active').value==true){ |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1124 | this.patient.PatientInsuranceList[i].PayerDescription = group.get('payerDescription').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1125 | this.patient.PatientInsuranceList[i].Pri_Sec_Oth_Type = group.get('insuranceMode').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1126 | this.patient.PatientInsuranceList[i].Policy_Number = group.get('policyNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1127 | this.patient.PatientInsuranceList[i].Co_Payment = group.get('coPay').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1128 | this.patient.PatientInsuranceList[i].Deductions = group.get('deDuctible').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1129 | this.patient.PatientInsuranceList[i].Co_Payment_Per = group.get('coPaymentPer').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1130 | this.patient.PatientInsuranceList[i].CCN = group.get('ccn').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1131 | this.patient.PatientInsuranceList[i].Group_Number = group.get('groupNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1132 | this.patient.PatientInsuranceList[i].Group_Name = group.get('groupName').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1133 | this.patient.PatientInsuranceList[i].Relationship = group.get('relation').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1134 | this.patient.PatientInsuranceList[i].Access_Carolina_Number = group.get('accCarolinaNumber').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1135 | this.patient.PatientInsuranceList[i].Is_Capitated_Patient = group.get('isCapitated').value; |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1136 | if(group.get('IS_Active').value==true){ |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1161 | // this.PatientForm.get('image').patchValue({profilePic:null |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1294 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').setValue(guarantorName); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1295 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('relation').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1296 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('relation').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1388 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('payerDescription').setValue(Inspayer_Description); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1443 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(index).get('subscriberName').setValue(''); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1446 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1447 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1448 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').disable(); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1451 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1452 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').updateValueAndValidity({ emitEvent: false, onlySelf: true }); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1453 | (<FormArray>this.PatientForm.controls['patientInsurance']).at(this.currentInsuranceNumber).get('subscriberName').enable(); |
|  | NPM_UI_BackUp/src/app/patient/patient.component.ts:1473 | /Demographic/GetPatient?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1487 | // this.PatientForm.get('additional').patchValue({provider: this.patient.Provider_Code |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1498 | this.formControls['guarantor'].get('name').setValue(this.patient.Financial_Guarantor_Name); |
| GET | NPM_UI_BackUp/src/app/patient/patient.component.ts:1530 | this.PatientForm.get(['contact', 'email'])[this.patient.emailnotonfile == true ? 'disable' : 'enable'](); |
|  | NPM_UI_BackUp/src/app/patient/patient.component.ts:1543 | /Demographic/GetImage?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/ticket-tracker/ticket-tracker.component.ts:175 | const control = this.SearchForm.get('Patient_Account'); |
|  | NPM_UI_BackUp/src/app/ticket-tracker/ticket-tracker.component.ts:187 | /UserManagementSetup/GetUsersList |
|  | NPM_UI_BackUp/src/app/ticket-tracker/ticket-tracker.component.ts:205 | /TicketTracker/GetTTDepartmentsList |
| GET | NPM_UI_BackUp/src/app/validators/password.validator.ts:4 | let password = group.get('password').value; |
| GET | NPM_UI_BackUp/src/app/validators/password.validator.ts:5 | let confirmPassword = group.get('confirmPassword').value; |
| GET | NPM_UI_BackUp/src/app/validators/password.validator.ts:7 | group.get('confirmPassword').setErrors({ MatchPassword: true }); |
|  | NPM_UI_BackUp/src/app/appointment-scheduler/scheduler/scheduler.component.ts:1269 | /scheduler/CheckDeceasedPatient?PatAccount= |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:120 | this.claimsForm1.get('type').setValue('electronic'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:125 | //         this.claimsForm.get('type').setValue('all'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:129 | //       this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:133 | //       this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:136 | this.submissionType = this.claimsForm1.get('type').value; |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:140 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:146 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:152 | this.claimsForm.get('type').setValue('all'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:158 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:164 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:170 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:176 | this.claimsForm.get('type').setValue('professional'); |
|  | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:377 | /Submission/GetBatcheDetalis?batchId= |
|  | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response/batch-submission-response.component.ts:466 | /Submission/GetCSIBatcheDetalis?batchId= |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:79 | //             this.claimsForm.get('type').setValue('all'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:83 | //           this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:87 | //           this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:115 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:121 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:127 | this.claimsForm.get('type').setValue('all'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:133 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:139 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:145 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors/claim-submission-errors.component.ts:151 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:274 | //           this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:278 | //           this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:302 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:308 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:314 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:320 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:326 | this.claimsForm.get('type').setValue('institutional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:332 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:338 | this.claimsForm.get('type').setValue('professional'); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:730 | (<FormControl>this.batchForm.get('type')).setValue('P', { emitEvent: true }); |
| GET | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:1547 | (<FormControl>this.batchForm.get('type')).setValue('P', { emitEvent: true }); |
|  | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims/claims-submission-claims.component.ts:1578 | /Submission/View837?batchId= |
|  | NPM_UI_BackUp/src/app/claim-submission/component-scrubber/component-scrubber.component.ts:188 | /Scrubber/GetAllCustomEdits/?Practice_Code= |
|  | NPM_UI_BackUp/src/app/claim-submission/component-scrubber/component-scrubber.component.ts:253 | /Scrubber/CustomEditsStatus/ |
|  | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/claim-rejection/claim-rejection.component.ts:58 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/patient-statement/patient-statement.component.ts:60 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/Claims/Attachments/claim-attachments.component.ts:165 | /ClaimsAttachments/GetAttachmentCodeList |
|  | NPM_UI_BackUp/src/app/Claims/Attachments/claim-attachments.component.ts:178 | /ClaimsAttachments/GetAttachmentCodeList |
| GET | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:43 | this.get(this.autochecknumber); |
|  | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:148 | /Demographic/GetClaimNotes?ClaimNo= |
| GET | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:230 | this.get(this.autochecknumber); |
|  | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:234 | /Demographic/GetClaimNote?ClaimNotesId= |
| GET | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:264 | this.get(2); |
| GET | NPM_UI_BackUp/src/app/Claims/claimNotes/claim-notes.component.ts:282 | this.get(numCheck); |
|  | NPM_UI_BackUp/src/app/Claims/Diagnosis/diagnosis.component.ts:462 | /Demographic/GetDiagnosis?DiagCode= |
|  | NPM_UI_BackUp/src/app/Claims/Diagnosis/diagnosis.component.ts:645 | /Demographic/GetDiagnosis?DiagCode= |
| GET | NPM_UI_BackUp/src/app/Claims/Diagnosis/diagnosis.component.ts:689 | var that = $(this).clone().get(0); |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:143 | /submission/CheckMedicareClaim?claimId= |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:214 | /Submission/GetBatcheDetalis?batchId= |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:230 | /Submission/GetCSIBatcheDetalis?batchId= |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:291 | /Submission/GetCSIBatcheResponseDetalis?batchId= |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:604 | /InsuranceSetup/GetRelationsSelectList |
|  | NPM_UI_BackUp/src/app/Claims/Insurances/claim-insurances.component.ts:1175 | /Submission/GetCSIBatcheDetalisStatus?claimId= |
|  | NPM_UI_BackUp/src/app/Claims/Payments/payments.component.ts:998 | /Submission/ViewClaimERA?claimno= |
|  | NPM_UI_BackUp/src/app/Claims/ub04/ub04.component.ts:450 | /UBClaim/GetAllCodesData |
| GET | NPM_UI_BackUp/src/app/components/services/api.service.ts:30 | return this.httpClient.get(environment.baseUrl + url, options).pipe( |
| GET | NPM_UI_BackUp/src/app/components/services/api.service.ts:43 | return this.httpClient.get(environment.baseUrl + url, { responseType: 'blob' }).pipe( |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:52 | return this.httpClient.post(environment.baseUrl + url, body, { responseType: 'blob' }).pipe( |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:110 | return this.httpClient.post(environment.baseUrl + url, data).subscribe |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:119 | return this.httpClient.post(environment.baseUrl + url, data, options).subscribe |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:138 | return this.httpClient.post(environment.baseUrl + url, data).subscribe |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:148 | return this.httpClient.post(environment.baseUrl + url, data).subscribe |
| POST | NPM_UI_BackUp/src/app/components/services/api.service.ts:241 | return this.httpClient.post(apiUrl, { ids: rowIds }).pipe( |
| GET | NPM_UI_BackUp/src/app/components/services/api.service.ts:251 | return this.httpClient.get(environment.baseUrl + url, { |
| GET | NPM_UI_BackUp/src/app/core/navbar/navbar.component.ts:208 | this.PasswordResetForm.get('pGroup.userName').setValue(this.loggedInUser.unique_name) |
|  | NPM_UI_BackUp/src/app/core/navbar/navbar.component.ts:485 | /Alert/GetLoginAlert |
|  | NPM_UI_BackUp/src/app/credentialing/cred-portal/cred-portal.component.ts:108 | /Setup/GetPracticeList |
|  | NPM_UI_BackUp/src/app/credentialing/cred-tasks/cred-tasks.component.ts:77 | /Credentialing/GetLookupLists |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:98 | const id = Number(this.route.snapshot.paramMap.get('id')); |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:136 | /Credentialing/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:263 | /PracticeSetup/GetPracticeWithActiveProviders?PracticeId= |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:629 | /UserManagementSetup/GetUsersList |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit/cred-app-addedit.component.ts:1105 | /PracticeSetup/GetPracticeWithActiveProviders?PracticeId= |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments/cred-app-attachments.component.ts:70 | this.form.get('ApplicationId').setValue(this.ApplicationId) |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments/cred-app-attachments.component.ts:194 | if (!this.form.get("DocTypeId").value) { |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments/cred-app-attachments.component.ts:199 | const docTypeId = this.form.get("DocTypeId").value; |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments/cred-app-attachments.component.ts:373 | /Credentialing/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-list/cred-app-list.component.ts:181 | /Credentialing/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-list/cred-app-list.component.ts:191 | /PracticeSetup/GetPracticeWithActiveProviders?PracticeId= |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component.ts:109 | const id = Number(this.route.snapshot.paramMap.get('id')); |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component.ts:150 | /CredEDIERASetup/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component.ts:263 | /PracticeSetup/GetPractice?PracticeId= |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component.ts:520 | /UserManagementSetup/GetUsersList |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component.ts:71 | this.form.get('ApplicationId').setValue(this.ApplicationId) |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component.ts:189 | if (!this.form.get("DocTypeId").value) { |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component.ts:194 | const docTypeId = this.form.get("DocTypeId").value; |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component.ts:343 | /CredEDIERASetup/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-list/cred-edi-era-app-list.component.ts:168 | /CredEDIERASetup/GetLookupLists |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-app-report/cred-app-report.component.ts:161 | //     const payer = payerMap.get(key); |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-app-report/cred-app-report.component.ts:256 | const payer = payerMap.get(key); |
|  | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:64 | /PracticeSetup/GetPractice?PracticeId= |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:348 | payerCount.set(r.Payer_Name, (payerCount.get(r.Payer_Name) \|\| 0) + 1); |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:361 | const start = payerStart.get(payer)!; |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:362 | const count = payerCount.get(payer)!; |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:363 | const serial = payerSerial.get(payer)!; |
| GET | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report/cred-grid-report.component.ts:567 | //     const payer = payerMap.get(key); |
|  | NPM_UI_BackUp/src/app/credentialing/cred-reports/edi-era-eft-grid-report/edi-era-eft-grid-report.component.ts:54 | /PracticeSetup/GetPractice?PracticeId= |
|  | NPM_UI_BackUp/src/app/credentialing/cred-reports/edi-era-eft-grid-report/edi-era-eft-grid-report.component.ts:74 | /CredEDIERASetup/GetLookupLists |
|  | NPM_UI_BackUp/src/app/credentialing/cred-reports/hospital-grid-report/hospital-grid-report.component.ts:66 | /PracticeSetup/GetPractice?PracticeId= |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:245 | this.searchForm.get('ClaimIds').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:250 | this.searchForm.get('claimValue').valueChanges.subscribe((selectedClaimId: string) => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:255 | this.searchForm.get('claimValue').valueChanges.subscribe((claimID) => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:268 | this.searchForm.get('claimValue').valueChanges.subscribe(claimId => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:270 | this.searchForm.get('ClaimId').setValue(claimId); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:295 | this.patientInfo = this.searchForm.get('selected_Patient').value, |
|  | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:308 | /Demographic/GetClaimModel?PatientAccount= |
|  | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:354 | /Demographic/GetClaimModel?PatientAccount= |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:966 | this.searchForm.get('selected_Patient').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:967 | this.searchForm.get('claimValue').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1045 | this.searchForm.get('selected_Patient').setValue(this.selectedPatient);  // Set value manually |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1259 | this.searchForm.get('selected_Patient').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1260 | this.searchForm.get('claimValue').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1261 | this.searchForm.get('ClaimIds').reset(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1289 | const accountControl = this.searchForm.get('patientAccount'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1290 | const claimControl = this.searchForm.get('claimValue'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1426 | this.getClaimsByPatient(this.searchForm.get('selected_Patient').value) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1432 | const claimInput = this.searchForm.get('ClaimIds'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:1441 | const claimDropdown = this.searchForm.get('claimValue'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2702 | Patient_Account: this.searchForm.get('selected_Patient').value, |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2715 | Patient_Account: this.searchForm.get('selected_Patient').value, |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2914 | this.paymentResponsibilityForm.get('creditbalance').setValue(this.TotaldueAmt); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2915 | this.paymentResponsibilityForm.get('overpaid').setValue('') |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2919 | this.paymentResponsibilityForm.get('overpaid').setValue(this.TotaldueAmt) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2920 | this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2924 | const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2925 | const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2955 | this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:2956 | this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3476 | //             this.paymentResponsibilityForm.get('creditbalance').setValue(this.ClaimDueAmt); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3477 | //             this.paymentResponsibilityForm.get('overpaid').setValue('') |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3481 | //             this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3482 | //             this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3486 | //             const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3487 | //             const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3721 | this.paymentResponsibilityForm.get('creditbalance').setValue(this.ClaimDueAmt); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3722 | this.paymentResponsibilityForm.get('overpaid').setValue('') |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3726 | this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3727 | this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3731 | const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:3732 | const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4058 | //           this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt) |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4059 | //           this.paymentResponsibilityForm.get('creditbalance').setValue(''); |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4063 | //           const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4064 | //           const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) \|\| 0; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4208 | this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4209 | this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payment-advisory/batch-payment-advisory.component.ts:4364 | const control = this.paymentResponsibilityForm.get(controlName); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:273 | this.batchPaymentForm.get('paymentType').valueChanges.subscribe(value => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:274 | const checkNoControl = this.batchPaymentForm.get('checkNo'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:275 | const checkDateControl = this.batchPaymentForm.get('checkDate'); |
|  | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:361 | /UserManagementSetup/GetUsersList |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:419 | const paymentType = this.batchPaymentForm.get('paymentType').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:423 | this.batchPaymentForm.get('checkNo').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:424 | this.batchPaymentForm.get('checkDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:426 | this.batchPaymentForm.get('checkNo').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:427 | this.batchPaymentForm.get('checkDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:431 | this.batchPaymentForm.get('depositDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:434 | this.batchPaymentForm.get('depositDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:438 | this.batchPaymentForm.get('checkNo').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:439 | this.batchPaymentForm.get('checkDate').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:440 | this.batchPaymentForm.get('depositDate').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:483 | if (control !== 'batchDate') this.batchPaymentForm.get(control).disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:496 | if (control !== 'batchDate') this.batchPaymentForm.get(control).enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:668 | this.batchPaymentForm.get('batchDate').setValue(batchDateValue); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:671 | this.batchPaymentForm.get(field).enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:675 | this.batchPaymentForm.get('paymentType').valueChanges.subscribe((value: string) => { |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:677 | this.batchPaymentForm.get('batchType').setValue('I'); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:678 | this.batchPaymentForm.get('batchType').disable(); // Lock it |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:680 | this.batchPaymentForm.get('batchType').enable(); // Unlock for others |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:771 | // const batchId = this.batchPaymentForm.get('batchId').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1060 | const batchID = this.searchBatchForm.get('BatchID').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1128 | const batchID = this.searchBatchForm.get('BatchID').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1193 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1215 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1216 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1217 | this.batchPaymentForm.get('checkDate').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1218 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1227 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1228 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1229 | this.batchPaymentForm.get('checkDate').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1230 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1247 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1248 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1249 | const paymentType = this.batchPaymentForm.get('paymentType').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1251 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1252 | this.batchPaymentForm.get('checkDate').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1255 | this.batchPaymentForm.get('batchType').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1256 | this.batchPaymentForm.get('paymentType').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1257 | this.batchPaymentForm.get('checkNo').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1258 | this.batchPaymentForm.get('checkDate').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1501 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1502 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1503 | const paymentType = this.batchPaymentForm.get('paymentType').value; |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1506 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1507 | this.batchPaymentForm.get('CheckDate').disable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1511 | this.batchPaymentForm.get('batchType').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1512 | this.batchPaymentForm.get('paymentType').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1513 | this.batchPaymentForm.get('checkNo').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1514 | this.batchPaymentForm.get('CheckDate').enable(); |
| GET | NPM_UI_BackUp/src/app/era/batch-payments/batch-payments.component.ts:1556 | if (this.searchBatchForm && this.searchBatchForm.get('BatchDateRange')) { |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:925 | this.batchPaymentForm.get('paymentType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:926 | this.batchPaymentForm.get('batchType').disable(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:928 | this.batchPaymentForm.get('checkNo').disable(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:944 | this.batchPaymentForm.get(controlName).setValue(event.formatted \|\| ''); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:954 | const paymentType = this.batchPaymentForm.get('paymentType').value; |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:958 | this.batchPaymentForm.get('checkNo').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:959 | this.batchPaymentForm.get('checkDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:961 | this.batchPaymentForm.get('checkNo').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:962 | this.batchPaymentForm.get('checkDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:966 | this.batchPaymentForm.get('depositDate').setValidators([Validators.required]); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:968 | this.batchPaymentForm.get('depositDate').clearValidators(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:971 | this.batchPaymentForm.get('checkNo').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:972 | this.batchPaymentForm.get('checkDate').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/era-claims/era-claims.component.ts:973 | this.batchPaymentForm.get('depositDate').updateValueAndValidity(); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:72 | this.eraSearchRequest.status = queryParamMap.get('status'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:73 | this.eraSearchRequest.practiceCode = Number(queryParamMap.get('practiceCode')); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:74 | this.eraSearchRequest.patientAccount = queryParamMap.get('patientAccount'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:75 | this.eraSearchRequest.icnNo = queryParamMap.get('icnNo'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:76 | this.eraSearchRequest.checkNo = queryParamMap.get('checkNo'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:77 | this.eraSearchRequest.dateTo = queryParamMap.get('dateTo'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:78 | this.eraSearchRequest.dateFrom = queryParamMap.get('dateFrom'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:79 | this.eraSearchRequest.checkAmount = queryParamMap.get('checkAmount'); |
| GET | NPM_UI_BackUp/src/app/era/eraimport/eraimport.component.ts:80 | this.eraSearchRequest.dateType = queryParamMap.get('dateType'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:86 | this.eraSearchRequest.status = 'All'// queryParamMap.get('status'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:87 | this.eraSearchRequest.practiceCode = Number(queryParamMap.get('practiceCode')); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:88 | this.eraSearchRequest.patientAccount = queryParamMap.get('patientAccount'); |
| GET | NPM_UI_BackUp/src/app/era/manual-eraimport/manual-eraimport.component.ts:89 | this.eraSearchRequest.icnNo = queryParamMap.get('icnNo'); |

Additional UI HTTP references found: 372. See `02_Frontend_Route_Component_Inventory.md`.
