# NobilityPM Practice Management System - Updated Application Flow Document

Version: Initial upgrade-planning rewrite  
Source scope: `NPM_API_BackUp`, `NPM_UI_BackUp`, existing generated inventories, and `NobilityPM User Guide V 1.4 1.pdf`  
Purpose: Explain how users move through the PMS and how the system should be rebuilt in a clearer, safer way.

---

## 1. How To Read This Document

This document is written for mixed audiences: business users, analysts, project managers, developers, QA, and future upgrade teams.

Each module is explained in plain language:

- What the user is trying to do.
- What the system does behind the scenes.
- Which screens and APIs are involved.
- What should happen on success.
- What can go wrong.
- What to preserve or improve during the .NET Core 10 upgrade.

---

## 2. Overall User Journey

```mermaid
flowchart TD
    Start["Open NobilityPM in browser"] --> Login["Login with username/email and password"]
    Login --> OTP["Enter OTP from email"]
    OTP --> Dashboard["Dashboard"]
    Dashboard --> Practice["Select or change practice"]
    Practice --> Work["Choose module from sidebar"]

    Work --> Scheduler["Scheduler"]
    Work --> Patient["Patient Search"]
    Work --> Tasks["Tasks"]
    Work --> Payment["Payments / ERA"]
    Work --> Submission["Claim Submission"]
    Work --> PracticeProfile["Practice Profile"]
    Work --> Reports["Reports"]
    Work --> Tickets["Ticket Tracker"]
    Work --> Cred["Credentialing"]

    Scheduler --> Dashboard
    Patient --> Dashboard
    Tasks --> Dashboard
    Payment --> Dashboard
    Submission --> Dashboard
    PracticeProfile --> Dashboard
    Reports --> Dashboard
    Tickets --> Dashboard
    Cred --> Dashboard
```

### Simple Flow Summary

1. User opens the web application.
2. User logs in.
3. System validates credentials and sends OTP.
4. User enters OTP.
5. System opens the dashboard.
6. User works under a selected practice.
7. User uses sidebar modules based on permissions.
8. System saves, posts, submits, reports, or exports data depending on the workflow.

---

## 3. Behind-The-Scenes Request Flow

```mermaid
sequenceDiagram
    participant User
    participant UI as Angular UI
    participant Guard as Auth Guard / Interceptors
    participant API as Web API Controller
    participant Service as Service Layer
    participant DB as Database / Stored Procedures
    participant External as External Services

    User->>UI: Click button / open page / submit form
    UI->>Guard: Prepare request with token and context
    Guard->>API: Call API endpoint
    API->>Service: Validate and delegate work
    Service->>DB: Query or save data
    Service->>External: Optional EDI, FTP, InboxHealth, email
    DB-->>Service: Data or status
    External-->>Service: Response or file
    Service-->>API: Business result
    API-->>UI: JSON/file/status
    UI-->>User: Updated screen, message, download, or error
```

### Upgrade Goal

The new system should keep this flow but make each step easier to test and understand:

- UI uses typed API clients.
- API uses clear request/response DTOs.
- Services own business workflows.
- Database access is isolated.
- External services are adapter-based.
- Errors are consistent and user-friendly.

---

## 4. Access Flow: Login, OTP, Practice Switch, Logout

```mermaid
flowchart TD
    A["Open application"] --> B["Enter username/email and password"]
    B --> C{"Credentials valid?"}
    C -- No --> D["Show login error"]
    C -- Yes --> E["Send OTP to registered email"]
    E --> F["User enters OTP"]
    F --> G{"OTP valid?"}
    G -- No --> H["Show OTP error / allow retry"]
    G -- Yes --> I["Load user permissions and assigned practices"]
    I --> J["Open dashboard"]
    J --> K["User can change practice from top navbar"]
    K --> L["Reload dashboard for selected practice"]
```

Current screens/routes:

- `login`
- `otp`
- `forgot-password`
- authenticated shell under `LayoutComponent`

Current backend areas:

- `TokenController`
- `UserManagementSetupController`
- authentication/token handlers

Upgrade notes:

- Keep OTP behavior if still required by business.
- Move authentication to ASP.NET Core authentication middleware.
- Store selected practice context consistently.
- Return one permission payload after login so the UI can build menus reliably.

---

## 5. Dashboard Flow

```mermaid
flowchart LR
    Login["Successful login"] --> Dashboard["Dashboard loads"]
    Dashboard --> PracticeContext["Read selected practice"]
    PracticeContext --> Metrics["Load summary metrics"]
    Metrics --> Charts["Show tables/charts"]
    Charts --> Drill["User drills into reports/tasks/claims"]
```

User purpose:

- See summarized operational and financial information after login.

Success flow:

1. User logs in or changes practice.
2. Dashboard requests summary data for selected practice.
3. System shows tabular and chart summaries.
4. User navigates to deeper modules if needed.

Error flow:

- If dashboard data fails, show a friendly message and allow refresh.
- If selected practice is missing, ask user to select a practice.

Upgrade notes:

- Build dashboard APIs as read-only queries.
- Cache expensive summaries.
- Keep dashboard independent from write-heavy billing logic.

---

## 6. Scheduler Flow

```mermaid
flowchart TD
    A["Open Scheduler"] --> B["Select date/provider/location"]
    B --> C["View appointments and availability"]
    C --> D{"User action"}
    D --> E["Book appointment"]
    D --> F["Edit appointment"]
    D --> G["Manage office timing"]
    D --> H["Block appointment slot"]
    D --> I["Manage status/reason"]
    E --> J["Search/select patient"]
    J --> K["Validate availability"]
    K --> L{"Slot available?"}
    L -- Yes --> M["Save appointment"]
    L -- No --> N["Show conflict message"]
    M --> O["Eligibility may run before appointment date"]
```

Current routes:

- `appointments/scheduler`
- `appointments/officeTiming`
- `appointments/statuses`
- `appointments/reasons`
- `appointments/block-appointments`

Current backend:

- `SchedulerController`
- `SchedulerService`
- eligibility-related services

Upgrade notes:

- Validate all appointment times on the server.
- Make date/time logic timezone-safe.
- Keep appointment status and reason as setup/lookup data.
- Run advance eligibility as a background job where possible.

---

## 7. Task Flow

```mermaid
flowchart TD
    A["Open Tasks"] --> B["System loads assigned practices"]
    B --> C["Show tasks assigned to current user"]
    C --> D{"Need another user's tasks?"}
    D -- Yes --> E["Select user from dropdown"]
    E --> F["Show selected user's tasks"]
    D -- No --> G["Work own task list"]
    F --> H["Update task status/priority/notes"]
    G --> H
    H --> I["Save task update"]
```

User purpose:

- Manage claim-level and account-level work assignments.

Current backend:

- `ClaimAssignmentController`
- `ClaimAssignmentService`

Upgrade notes:

- Treat tasks as a proper work queue.
- Use standard statuses and priorities.
- Audit assignment and status changes.
- Add notification counts for assigned work.

---

## 8. Patient Search And Demographics Flow

```mermaid
flowchart TD
    A["Open Patient Search"] --> B["Enter search criteria"]
    B --> C["Click Search"]
    C --> D["System returns patient list"]
    D --> E{"User action"}
    E --> F["View patient"]
    E --> G["Edit patient"]
    E --> H["Add new patient"]
    G --> I["Update demographics, insurance, notes, alerts, attachments"]
    H --> I
    I --> J{"Required data complete?"}
    J -- Yes --> K["Save patient"]
    J -- No --> L["Save as draft or show validation"]
    F --> M["Open submodules: appointments, claim summary, claims"]
```

User purpose:

- Find patients quickly.
- Maintain demographic, insurance, note, alert, attachment, and account assignment data.

Current screens:

- `patient/PatientSearch`
- Patient detail/edit screens
- Patient attachments
- Patient notes
- Account assignment
- Alerts

Current backend:

- `DemographicController`
- `DemographicService`
- `PatientAttachmentsController`
- `AlertController`
- `ClaimAssignmentController`

Success flow:

1. User searches patient.
2. System returns matching patients.
3. User views, edits, or adds patient.
4. System validates fields.
5. Patient data is saved or saved as draft.

Error flow:

- Duplicate patient warning.
- Missing required fields.
- Invalid insurance/guarantor data.
- Attachment upload failure.

Upgrade notes:

- Build patient search as a paged query API.
- Keep patient create/edit as validated command APIs.
- Centralize patient attachment storage.
- Add audit trail for sensitive demographic changes.

---

## 9. Claims Flow

```mermaid
flowchart TD
    A["Open patient claim summary"] --> B["View existing claims"]
    B --> C{"User action"}
    C --> D["New claim"]
    C --> E["View claim"]
    C --> F["Edit claim"]
    D --> G["Enter claim header"]
    F --> G
    G --> H["Add diagnosis"]
    H --> I["Add CPT/procedure or panel code"]
    I --> J["Add insurance/claim details"]
    J --> K["Validate claim"]
    K --> L{"Valid?"}
    L -- Yes --> M["Save claim"]
    L -- No --> N["Show validation/scrubber issues"]
    M --> O["Optional: HCFA, notes, attachments, eligibility"]
```

User purpose:

- Create and maintain billing claims tied to a patient.

Current backend:

- `DemographicController`
- `UBClaimController`
- `HCFAController`
- `ClaimsAttachmentsController`
- `ScrubberController`

Important subflows:

- Diagnosis search.
- CPT/procedure entry.
- Panel code entry.
- Claim notes.
- Claim attachments.
- HCFA-1500.
- Claim-level eligibility.
- Overpayment handling and credit-balance transfer.

Upgrade notes:

- Claims need the strongest automated regression tests.
- Use transactional saves for claim header, charges, diagnosis, and insurance changes.
- Keep a full audit trail.
- Separate claim edit rules from claim submission rules.

---

## 10. Payments And ERA Flow

```mermaid
flowchart TD
    A["Open Payment / ERA module"] --> B{"Workflow"}
    B --> C["ERA Summary"]
    B --> D["Batch Payments"]
    C --> E["View ERA"]
    C --> F["Download ERA"]
    C --> G["Apply payment through batches"]
    D --> H["Create/search batch"]
    H --> I["Edit batch info"]
    I --> J["Search claim in batch"]
    J --> K["Post payment"]
    K --> L{"Payment matched?"}
    L -- Yes --> M["Apply to claim"]
    L -- No --> N["Post as unapplied payment"]
    M --> O["Close batch when complete"]
    N --> O
```

User purpose:

- Review ERA files and post payments through controlled batch workflows.

Current backend:

- `ERAController`
- `PaymentsController`
- `ERAImportService`
- `PaymentsService`
- `FTPService`
- `NPMWorkers`

Success flow:

1. ERA or batch payment is selected.
2. User finds the claim.
3. Payment is posted.
4. Batch is updated or closed.
5. Unapplied payments are tracked when claim matching is incomplete.

Error flow:

- Duplicate ERA file.
- Claim not found.
- Payment mismatch.
- Batch already closed.
- Posting transaction fails.

Upgrade notes:

- Use idempotency keys for ERA imports and posting.
- Keep all posting inside database transactions.
- Add reconciliation reports before go-live.
- Separate ERA parsing from payment posting.

---

## 11. Claim Submission Flow

```mermaid
flowchart TD
    A["Open Claim Submission"] --> B["Search claims for submission"]
    B --> C["Run scrubber"]
    C --> D{"Claims valid?"}
    D -- No --> E["Show scrubber/custom edit errors"]
    E --> F["Fix claim or custom edits"]
    F --> C
    D -- Yes --> G["Create submission batch"]
    G --> H["Add claims to batch"]
    H --> I{"Batch type"}
    I --> J["Electronic batch upload"]
    I --> K["Paper batch creation"]
    J --> L["Receive response/errors"]
    K --> L
    L --> M["Review submitted batches / CSI details"]
```

User purpose:

- Validate claims, create batches, submit claims, and manage errors/rejections.

Current backend:

- `SubmissionController`
- `ScrubberController`
- `GenerateBatch276Service`
- `ClaimBatch276`

Upgrade notes:

- Build a visible submission state machine.
- Version scrubber rules and custom edits.
- Keep generated files traceable to batch and claims.
- Do not merge submission logic into claim edit logic.

---

## 12. Practice Profile And Setup Flow

```mermaid
flowchart TD
    A["Open Practice Profile or Setup"] --> B{"Setup area"}
    B --> C["Practice"]
    B --> D["Provider"]
    B --> E["Location"]
    B --> F["Practice payers"]
    B --> G["Web portals"]
    B --> H["Insurance setup"]
    B --> I["Facilities / procedures / diagnosis / NDC / guarantors"]
    C --> J["Add/edit/save"]
    D --> J
    E --> J
    F --> J
    G --> J
    H --> J
    I --> J
```

User purpose:

- Maintain master data required for billing, scheduling, claims, and reporting.

Current backend:

- `PracticeSetupController`
- `SetupController`
- `InsuranceSetupController`
- `ReferralPhysiciansController`
- `CompanyController`
- `VendorController`

Upgrade notes:

- Treat setup modules as master-data APIs.
- Use common list/add/edit/detail patterns.
- Add duplicate checks.
- Add soft-delete and active/inactive status rules.

---

## 13. Reports Flow

```mermaid
flowchart TD
    A["Open Reports"] --> B["Select report"]
    B --> C["Enter criteria"]
    C --> D["Run report"]
    D --> E{"Report ready?"}
    E -- Yes --> F["Show results"]
    F --> G["Export/download if needed"]
    E -- No --> H["Show error or no data message"]
```

User purpose:

- Generate financial, aging, appointment, payment, claim, operational, and credentialing reports.

Current backend:

- `ReportController`
- `ReportService`
- stored procedures and report result models

Upgrade notes:

- Document each report separately: filters, columns, data source, export rules.
- Use paging for large reports.
- Consider asynchronous report generation for long-running reports.
- Keep reports read-only.

---

## 14. Ticket Tracker Flow

```mermaid
flowchart TD
    A["Open Ticket Tracker"] --> B{"User action"}
    B --> C["Create new ticket"]
    B --> D["Search tickets"]
    C --> E["Add details and attachments"]
    E --> F["Assign ticket"]
    D --> G["Open ticket"]
    F --> H["Update progress"]
    G --> H
    H --> I{"Resolved?"}
    I -- No --> H
    I -- Yes --> J["Add closure remarks"]
    J --> K["Close ticket"]
```

User purpose:

- Track operational issues or support work.

Current backend:

- `TicketTrackerController`
- `TTService`
- `TicketAttachmentsService`

Upgrade notes:

- Add clear ticket status lifecycle.
- Store attachments through shared document storage.
- Add ticket comments/history.
- Add notifications for assigned tickets.

---

## 15. Credentialing Flow

```mermaid
flowchart TD
    A["Open Credentialing"] --> B{"Workflow"}
    B --> C["Credentialing application"]
    B --> D["EDI ERA application"]
    B --> E["Credentialing reports"]
    B --> F["Credentialing portal"]
    B --> G["Credentialing tasks"]
    B --> H["Credentialing dashboard"]
    C --> I["Create/search/edit application"]
    D --> J["Create/search/edit EDI ERA setup"]
    I --> K["Upload documents and notes"]
    J --> K
    K --> L["Track status"]
```

User purpose:

- Manage provider credentialing and EDI/ERA/EFT enrollment/setup processes.

Current backend:

- `CredentialingController`
- `CredEDIERASetupController`
- `CredentialingService`
- `CredEDIERASetupService`

Upgrade notes:

- Use checklist-driven document requirements.
- Track status history.
- Keep credentialing reports separate from billing reports.
- Do not mix credentialing setup with claim submission setup.

---

## 16. Integration And Worker Flows

```mermaid
flowchart LR
    Scheduler["Scheduled job / worker"] --> DB["Database"]
    Scheduler --> FTP["FTP / files"]
    Scheduler --> Gateway["GatewayEDI / EDI"]
    Scheduler --> Inbox["InboxHealth"]
    FTP --> ERA["ERA import"]
    ERA --> Payment["Payment posting queue"]
    Inbox --> Sync["Patient/practice/provider sync"]
    Sync --> DB
```

Current worker areas:

- ERA/autoposting worker.
- External synchronization worker.
- InboxHealth sync/service logic.

Upgrade notes:

- Convert workers to .NET Worker Services.
- Add job history tables.
- Use retries and failure queues.
- Make jobs idempotent.
- Add monitoring and alerting.

---

## 17. Error Handling Model For The Upgraded System

```mermaid
flowchart TD
    A["User action"] --> B["Frontend validation"]
    B --> C{"Valid on client?"}
    C -- No --> D["Show field-level message"]
    C -- Yes --> E["Call API"]
    E --> F["Backend validation"]
    F --> G{"Valid on server?"}
    G -- No --> H["Return validation ProblemDetails"]
    G -- Yes --> I["Run business workflow"]
    I --> J{"Workflow success?"}
    J -- Yes --> K["Return success response"]
    J -- No --> L["Log error with correlation ID"]
    L --> M["Return safe user message"]
```

Every upgraded module should use the same error style:

- Field validation errors.
- Business rule errors.
- Permission errors.
- Integration errors.
- Unexpected system errors.

---

## 18. Migration Flow

```mermaid
flowchart TD
    A["Review current code and user manual"] --> B["Review database schema and procedures"]
    B --> C["Confirm active modules and unused code"]
    C --> D["Design target architecture"]
    D --> E["Build foundation: auth, layout, permissions, audit"]
    E --> F["Migrate low-risk setup modules"]
    F --> G["Migrate patient and scheduler"]
    G --> H["Migrate claims"]
    H --> I["Migrate claim submission"]
    I --> J["Migrate payments and ERA"]
    J --> K["Migrate reports, tickets, credentialing"]
    K --> L["Parallel testing and reconciliation"]
    L --> M["Go-live"]
```

Recommended migration rule:

- Do not start with payments or claim submission.
- Start with foundation and setup modules.
- Move into patients and scheduler next.
- Handle claims, submissions, and payments only after test coverage and reconciliation plans are ready.

---

## 19. Per-Module Upgrade Readiness Checklist

Use this checklist for every module before rebuilding it:

| Question | Why it matters |
|---|---|
| Which users/roles use this module? | Needed for permission migration |
| What screens are actually used? | Avoid rebuilding unused screens |
| What API actions does the module call? | Needed for API contract design |
| What tables and stored procedures are involved? | Needed for data migration and testing |
| What validations exist today? | Needed to preserve behavior |
| What files are uploaded/downloaded? | Needed for document storage design |
| What integrations are called? | Needed for adapters and credentials |
| What reports depend on this data? | Needed for reconciliation |
| What are the success and failure cases? | Needed for QA test cases |
| What should be improved during upgrade? | Avoid copying old complexity blindly |

---

## 20. Final Notes

This document should be updated after the database schema and stored procedure definitions are provided. The next version should add:

- Exact table names by module.
- Exact stored procedure purpose and parameters.
- Data ownership map.
- Report source mapping.
- High-risk business-rule test cases.
- Cutover and reconciliation checklist.

