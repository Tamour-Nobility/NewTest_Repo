# NobilityPM Practice Management System - Updated Technical Document

Version: Initial upgrade-planning rewrite  
Source scope: `NPM_API_BackUp`, `NPM_UI_BackUp`, existing generated inventories, and `NobilityPM User Guide V 1.4 1.pdf`  
Purpose: Explain the current system in a clean, understandable way so a new PMS can be rebuilt later on .NET Core 10 and a modern frontend.

---

## 1. Executive Summary

NobilityPM is a web-based Practice Management System used to manage practices, patients, appointments, claims, billing, payments, ERA activity, claim submission, reports, tickets, and credentialing work.

The current application is made of:

- An Angular 7 frontend in `NPM_UI_BackUp`.
- A legacy ASP.NET Web API backend in `NPM_API_BackUp/NPMAPI`.
- Worker projects for synchronization, ERA/autoposting, and background jobs.
- A database-heavy design using EF model classes and many stored procedures.
- Integrations for EDI/ERA, GatewayEDI, FTP, InboxHealth, email/OTP, file attachments, and reporting.

The earlier generated documents are still useful as raw inventories. This updated document is the cleaner upgrade map: it groups the application by business capability, explains what each module does, and shows how the pieces should be migrated.

---

## 2. Current System At A Glance

```mermaid
flowchart LR
    User["User in browser"] --> UI["Angular 7 UI<br/>NPM_UI_BackUp"]
    UI --> Guards["AuthGuard + Interceptors<br/>JWT, credentials, encryption"]
    Guards --> API["ASP.NET Web API<br/>NPM_API_BackUp/NPMAPI"]
    API --> Services["Service / Repository Layer"]
    Services --> DB["SQL Database<br/>Tables + Stored Procedures"]
    Services --> Files["Files and Attachments"]
    Services --> EDI["EDI / ERA / GatewayEDI / FTP"]
    Services --> Inbox["InboxHealth"]
    Workers["Background Workers<br/>NPMWorkers, NPMSyncWorker"] --> DB
    Workers --> EDI
    Workers --> Inbox
```

### Important Current Counts

These counts come from the first-pass code inventory and help size the upgrade effort:

| Area | Current count |
|---|---:|
| Angular route entries | 237 |
| Angular components | 221 |
| UI HTTP/API references | 872 |
| API controllers | 32 |
| API controller actions | 665 |
| Model/table candidates | 1,002 |
| Stored procedure/function references | 481 |

---

## 3. Recommended Target Architecture

The upgrade should not be a one-to-one rewrite of every old controller and component. It should rebuild the same business capabilities with cleaner boundaries.

```mermaid
flowchart TB
    subgraph Frontend["Modern Frontend"]
        Shell["App Shell<br/>login, layout, navigation"]
        Modules["Feature Modules<br/>patient, claims, scheduler, payments"]
        ClientAPI["Generated API Client<br/>OpenAPI/Swagger"]
    end

    subgraph Backend[".NET Core 10 Backend"]
        Auth["Identity / Auth / RBAC"]
        API["Versioned REST APIs"]
        Domain["Application Services<br/>business workflows"]
        Jobs["Hosted Services / Workers"]
        Integration["Integration Adapters"]
    end

    subgraph Data["Data Layer"]
        EF["EF Core Entities"]
        SP["Stored Procedure Contracts"]
        Audit["Audit and Logs"]
    end

    Shell --> Modules
    Modules --> ClientAPI
    ClientAPI --> API
    API --> Auth
    API --> Domain
    Domain --> EF
    Domain --> SP
    Jobs --> Domain
    Domain --> Integration
    Domain --> Audit
```

### Upgrade Principles

- Keep business workflows stable first, then improve design.
- Replace raw, action-style APIs with versioned feature APIs.
- Keep stored procedures at first, but wrap them behind clear repository contracts.
- Replace scattered permission checks with policy-based authorization.
- Replace ad hoc frontend API calls with generated typed API clients.
- Move background jobs into .NET hosted services or a worker-service deployment model.
- Add automated tests around billing, claim submission, ERA posting, and patient data flows before changing behavior.

---

## 4. Current Technical Layers

### Frontend Layer

Current frontend: Angular 7.

Main responsibilities:

- Login, OTP, forgot password, layout, sidebar, and top navigation.
- Practice switching.
- Feature screens for scheduler, tasks, patient search, claims, payments, ERA, claim submission, practice profile, reports, tickets, credentialing, and setup screens.
- HTTP calls to backend APIs through services and component-level calls.
- JWT, credentials, and encryption interceptors.

Upgrade direction:

- Rebuild as a modern Angular, React, or Blazor frontend.
- Use a clear feature-module structure.
- Use a generated API client from backend OpenAPI.
- Use centralized state only where needed: authentication, selected practice, user permissions, notifications.
- Replace jQuery/DataTables-era dependencies with modern grid, form, date, upload, and reporting components.

### Backend API Layer

Current backend: ASP.NET Web API with route template `api/{controller}/{action}/{id}`.

Main responsibilities:

- Exposes 32 controllers and 665 controller actions.
- Uses Unity dependency injection.
- Uses token validation and encryption message handlers.
- Uses global exception logging and route/user audit filters.
- Delegates most work to service classes.

Upgrade direction:

- Move to ASP.NET Core 10.
- Use built-in dependency injection.
- Use controller or minimal API endpoints grouped by feature.
- Use API versioning, Swagger/OpenAPI, ProblemDetails error responses, request validation, and structured logging.
- Replace action-heavy URLs with resource/workflow URLs, while keeping compatibility endpoints if needed during migration.

### Service / Repository Layer

Current backend services include patient demographics, claims, payments, scheduler, reports, insurance setup, practice setup, claim submission, ERA, credentialing, ticket tracker, audit logs, alerts, and integrations.

Upgrade direction:

- Organize services by business bounded context.
- Put workflow rules in application services, not controllers.
- Keep database access isolated in repositories/query services.
- Add DTOs for every request and response.
- Add validation classes for all write operations.

### Database Layer

Current database access is mixed:

- EF model/table classes.
- Stored procedure result classes.
- Raw SQL/stored procedure calls.
- Worker database access.

Upgrade direction:

- Reverse-engineer the database schema after tables/procedures are provided.
- Classify database objects into business modules.
- Migrate entity models to EF Core.
- Keep stored procedures that contain critical billing/claim logic, but document and test them.
- Introduce transactional boundaries for posting, payment, claim submission, and ERA workflows.

### Worker / Background Layer

Current worker projects:

- `NPMWorkers`: ERA/autoposting related worker project.
- `NPMSyncWorker`: external synchronization, including InboxHealth-related synchronization.
- `SecretStore`: supporting secret/configuration project.

Upgrade direction:

- Convert workers to .NET Worker Services.
- Use `IHostedService` / `BackgroundService`.
- Add retry policies, job logs, correlation IDs, and dead-letter handling.
- Keep business logic shared through application services instead of duplicated inside workers.

---

## 5. Business Module Map

```mermaid
mindmap
  root((NobilityPM))
    Access
      Login
      OTP
      Practice switch
      Role rights
    Dashboard
      Summary metrics
      Charts
      Work visibility
    Scheduler
      Appointments
      Office timing
      Blocked slots
      Status and reasons
      Advance eligibility
    Tasks
      Claim-level tasks
      Account-level tasks
      User assignment
    Patients
      Search
      Demographics
      Insurance
      Attachments
      Notes
      Alerts
      Account assignment
    Claims
      Claim summary
      New/edit claim
      Diagnosis
      CPT/procedures
      HCFA
      Attachments
      Overpayment
    Payments
      ERA summary
      Batch payments
      Payment posting
      Unapplied payments
    Claim Submission
      Scrubber
      Batches
      Upload
      Errors
      Statements
      Rejections
    Practice Profile
      Practice
      Providers
      Locations
      Payers
      Web portals
    Reports
      Aging
      Financial
      Payments
      Claims
      Appointments
      Operational
    Tickets
      Create
      Assign
      Attachments
      Progress
      Closure
    Credentialing
      Applications
      EDI ERA applications
      Reports
      Portal
      Tasks
      Dashboard
```

---

## 6. Module Details

### 6.1 Access, Login, OTP, Practice Switching, And Permissions

Business purpose: Control who can use the system, what practice they work in, and what modules they can access.

Current frontend:

- `login`, `otp`, `forgot-password`
- Main authenticated layout guarded by `AuthGuard`
- Top navigation supports change practice and logout
- Sidebar displays user/role context

Current backend:

- `TokenController`
- `UserManagementSetupController`
- `CompanyController` for organization/team/role-related setup
- `AlertController` for login alerts
- Token validation and encryption handlers

Main data concerns:

- Users, roles, modules, submodules, properties/rights
- Assigned practices
- Login audit/security events
- OTP/email configuration

Upgrade notes:

- Use ASP.NET Core Identity or a custom identity module with policy-based authorization.
- Build a permission matrix: Module -> Action -> Role/User override.
- Store selected practice as part of user session/context, not scattered component state.
- Replace custom token handling with standard JWT bearer authentication.

### 6.2 Dashboard

Business purpose: Give the user a quick operational and financial snapshot after login.

Current frontend:

- `dashboard`
- `DashBoardComponent`

Current backend:

- `DashboardController`
- `DashboardService`

User actions:

- View summarized reports.
- Review charts/tables.
- Change practice and refresh dashboard context.

Upgrade notes:

- Treat dashboard as read-only query APIs.
- Use cached summary endpoints where possible.
- Keep drill-down links to reports, claims, payments, and tasks.

### 6.3 Scheduler And Appointment Management

Business purpose: Manage provider schedules, office timing, blocked slots, appointment statuses, appointment reasons, and appointment-related eligibility.

Current frontend routes:

- `appointments/scheduler`
- `appointments/officeTiming`
- `appointments/statuses`
- `appointments/reasons`
- `appointments/block-appointments`

Current backend:

- `SchedulerController`
- `SchedulerService`
- Eligibility-related services/controllers for appointment checks

User actions:

- View calendar/scheduler.
- Search/select patient while booking appointment.
- Add/edit office timing for provider and location.
- Block appointment slots.
- Maintain appointment status and reason lookup values.
- Run or receive advance eligibility checks.

Upgrade notes:

- Separate calendar read models from appointment write commands.
- Use timezone-safe date/time handling.
- Keep eligibility checks asynchronous where possible.
- Add conflict validation for overlapping appointments and blocked slots.

### 6.4 Tasks And Work Assignment

Business purpose: Assign, view, and manage account-level and claim-level work.

Current frontend:

- `Tasks`
- `claimlevel`
- `accountlevel`

Current backend:

- `ClaimAssignmentController`
- `ClaimAssignmentService`

User actions:

- View tasks assigned to self.
- View tasks assigned to another user.
- Assign account or claim work.
- Update task status, priority, due date, and notes.

Upgrade notes:

- Model tasks as a first-class work queue.
- Create consistent status and priority values.
- Add audit trail for assignment changes.
- Provide notification APIs for task counts.

### 6.5 Patient Search And Demographics

Business purpose: Search, view, add, edit, and maintain patient records.

Current frontend:

- `patient/PatientSearch`
- `Patient/Demographics`
- patient detail tabs for demographics, appointments, claim summary, notes, alerts, and attachments

Current backend:

- `DemographicController`
- `DemographicService`
- `PatientAttachmentsController`
- `AlertController`
- `ClaimAssignmentController`

User actions:

- Search patients by criteria.
- View patient details.
- Add/edit patient demographics.
- Save draft when required data is missing.
- Attach demographic-level files.
- Add patient notes.
- Add account alerts.
- Assign account work.
- Check eligibility.

Main data concerns:

- Patient demographics
- Insurance and guarantor details
- Notes, alerts, attachments
- Account assignment
- Eligibility responses

Upgrade notes:

- Create a clean patient aggregate around demographics, contacts, insurance, notes, and attachments.
- Use strong validation for required demographic and insurance fields.
- Make patient search a query endpoint with paging and sorting.
- Keep attachments in a dedicated document service with metadata and virus-scan hooks if needed.

### 6.6 Claims And Claim Editing

Business purpose: Create, view, edit, and manage claims for patient billing.

Current frontend:

- Claim summary under patient module
- New/edit/view claim screens
- Diagnosis search
- CPT/procedure and panel code screens
- Claim notes
- HCFA-1500
- Claim attachments
- Overpayment handling

Current backend:

- `DemographicController` for patient-linked claim operations
- `UBClaimController`
- `HCFAController`
- `ClaimsAttachmentsController`
- `ClaimAssignmentController`
- `ScrubberController`

User actions:

- Create new claim.
- Search diagnosis and add procedure/CPT codes.
- Add panel codes.
- View/edit claims.
- Add claim notes.
- Generate/view HCFA-1500.
- Attach claim documents.
- Run claim-level eligibility.
- Manage overpayment responsibility and credit-balance transfers.

Upgrade notes:

- Claims are high-risk and should receive priority test coverage.
- Separate claim header, claim charges, diagnosis, insurance, payments, notes, and attachments.
- Use transactions for multi-step claim edits.
- Keep a detailed audit trail for billing-sensitive changes.

### 6.7 Payments, ERA, Batch Payments, And Unapplied Payments

Business purpose: Import, review, post, and manage payments from ERA files and manual/batch workflows.

Current frontend:

- `era/era`
- `era/erahistory`
- `era/manualeraimport`
- `era/batchpayments`
- `era/BatchPaymentAdvisory`
- `era/view/:id`
- `era/claims/:id`
- payment posting and batch payment components

Current backend:

- `ERAController`
- `PaymentsController`
- `ERAImportService`
- `PaymentsService`
- `FTPService`
- worker project `NPMWorkers`

User actions:

- View ERA summary.
- View/download ERA.
- Apply payment through batches.
- Create and search batch payments.
- Edit batch information.
- Search claims inside batch.
- Post payment at batch or claim level.
- Close batch.
- Post unapplied payments.

Upgrade notes:

- Treat payment posting as a transactionally protected workflow.
- Create a payment ledger model if not already explicit in the database.
- Keep ERA import parsing isolated from posting logic.
- Add idempotency for ERA imports and payment posting to avoid duplicate payment application.

### 6.8 Claim Submission And Scrubber

Business purpose: Prepare, validate, batch, upload, and monitor claim submissions.

Current frontend:

- `claimsubmission/scrubber/:type`
- `claimsubmission/claims`
- `claimsubmission/errors`
- `claimsubmission/batchResponse`
- `claimsubmission/patientStatement`
- `claimsubmission/Claimrejection`
- `customEdits/:type/:id`

Current backend:

- `SubmissionController`
- `ScrubberController`
- `ReportController`
- `GenerateBatch276Service`
- `ClaimBatch276`

User actions:

- Run scrubber.
- Manage custom edits.
- Search claims for submission.
- Create batches.
- Add claims to batches.
- Upload electronic batches.
- Create paper batches.
- Review batch file errors.
- Review submitted batches and CSI details.
- Generate patient statements.
- Review claim rejections.

Upgrade notes:

- Keep scrubber rules configurable and versioned.
- Separate claim selection, validation, batch creation, file generation, and upload.
- Add a submission state machine: Draft -> Validated -> Batched -> Uploaded -> Accepted/Rejected.
- Add full traceability for generated files.

### 6.9 Practice Profile And Setup

Business purpose: Maintain practice profile, providers, locations, payers, web portals, facilities, procedures, diagnosis, NDC, guarantors, and insurance setup.

Current frontend:

- `PracticeList`
- `Practice`
- `PracticeTAB`
- `EditPractice/:id/:Type`
- `Facility`
- `procedures`
- `diagnosis`
- `ndc`
- `InsuranceSetup`
- `guarantors`
- `referral-physician`

Current backend:

- `PracticeSetupController`
- `SetupController`
- `InsuranceSetupController`
- `ReferralPhysiciansController`
- `CompanyController`
- `VendorController`

User actions:

- Add/edit practice.
- Add/edit provider.
- Add/edit location.
- Map practice payers.
- Manage web portals.
- Manage insurance groups, names, payers, and plans.
- Maintain procedure, diagnosis, NDC, facility, guarantor, and referral physician setup.

Upgrade notes:

- Split setup data into clearly owned master-data modules.
- Add duplicate checks and soft-delete rules.
- Standardize lookup APIs.
- Preserve practice-code based workflows until the database model is redesigned.

### 6.10 Reports And Analytics

Business purpose: Provide operational, financial, aging, claim, appointment, payment, and credentialing reports.

Current frontend:

- `ReportSetup`
- `reporting`
- report routes for aging, financial summaries, payment details, appointments, claims, denials, negative balance, credit balance, batch payment, unapplied payment, and dynamic charge/payment reports.

Current backend:

- `ReportController`
- `ReportService`
- many stored procedure result models

User actions:

- Select report criteria.
- Generate report.
- View/export results.
- Drill into operational or financial details.

Upgrade notes:

- Treat reports as read-only query models.
- Keep expensive report execution asynchronous or paged.
- Define each report contract: filters, output columns, source procedure/query, export behavior.
- Consider a reporting database/read replica for heavy reports.

### 6.11 Ticket Tracker

Business purpose: Create and manage support/work tickets with assignment, attachments, progress, and closure.

Current frontend:

- `ticket-tracker`
- ticket response and ticket tracker components

Current backend:

- `TicketTrackerController`
- `TTService`
- `TicketAttachmentsService`

User actions:

- Create ticket.
- Add attachment.
- Search ticket.
- Assign ticket.
- Edit ticket data.
- Update progress.
- Close ticket with remarks.

Upgrade notes:

- Model ticket state clearly: Open -> Assigned/In Progress -> Waiting -> Closed.
- Store attachments in the shared document service.
- Add notifications and audit trail.

### 6.12 Credentialing

Business purpose: Manage provider credentialing applications, EDI/ERA/EFT setup applications, credentialing reports, portals, tasks, and dashboards.

Current frontend:

- `credentialing`
- credentialing application list/add/edit/view
- EDI ERA application list/add/edit/view
- credentialing reports
- credentialing portal
- credentialing tasks
- credentialing dashboard

Current backend:

- `CredentialingController`
- `CredEDIERASetupController`
- `CredentialingService`
- `CredEDIERASetupService`

User actions:

- Create credentialing application.
- Upload application documents.
- Search/edit credentialing applications.
- Create/edit EDI ERA application.
- Upload EDI ERA application documents.
- View credentialing reports.
- Maintain credentialing web portals.
- Search credentialing tasks.
- View credentialing dashboard.

Upgrade notes:

- Separate credentialing from billing/claim workflows.
- Use a document checklist model for required attachments.
- Track application status history.
- Keep credentialing reports read-only and separately optimized.

---

## 7. Main Data Domains

```mermaid
erDiagram
    PRACTICE ||--o{ PROVIDER : has
    PRACTICE ||--o{ LOCATION : has
    PRACTICE ||--o{ PATIENT : owns
    PATIENT ||--o{ APPOINTMENT : schedules
    PATIENT ||--o{ CLAIM : has
    CLAIM ||--o{ CLAIM_CHARGE : contains
    CLAIM ||--o{ CLAIM_NOTE : tracks
    CLAIM ||--o{ CLAIM_ATTACHMENT : stores
    CLAIM ||--o{ PAYMENT : receives
    ERA ||--o{ PAYMENT : posts
    PRACTICE ||--o{ INSURANCE_SETUP : configures
    USER ||--o{ TASK : assigned
    USER ||--o{ TICKET : creates
    PRACTICE ||--o{ CREDENTIALING_APPLICATION : manages
```

This is a simplified domain view. Exact table names, keys, and relationships must be completed after the database schema and stored procedure definitions are reviewed.

---

## 8. Integrations And External Dependencies

| Integration / dependency | Current role | Upgrade recommendation |
|---|---|---|
| GatewayEDI web references | Eligibility, claim/EDI-related communication | Wrap in adapter services with retry, logging, and test doubles |
| EDI/ERA libraries | Read/process EDI and ERA data | Keep parsing isolated from business posting |
| FTP | File exchange for ERA/claim workflows | Move to managed integration service with secure credentials |
| InboxHealth | Patient billing/payment integration and sync | Use dedicated integration adapter plus background sync jobs |
| Email/OTP | Login verification and alerts | Replace with configurable notification service |
| File attachments | Patient, claim, ticket, credentialing documents | Centralize in document storage service |
| Reports/export libraries | PDF/Excel/report exports | Standardize exports behind report services |

---

## 9. Cross-Cutting Concerns

### Security

- Current system uses JWT/token validation, Angular guards, and role/right modules.
- Upgrade should use standard ASP.NET Core authentication and policy-based authorization.
- Add multi-factor/OTP through a supported notification provider.

### Auditing

- Current system includes route/user audit filters and audit services.
- Upgrade should audit all sensitive operations: login, practice switch, patient edits, claim edits, payment posting, batch submission, credentialing document updates, and permission changes.

### Validation

- Current validation is mixed between frontend form checks and backend service logic.
- Upgrade should add shared validation rules through backend DTO validators and frontend generated schemas where possible.

### Error Handling

- Current API error behavior is inconsistent.
- Upgrade should use standardized `ProblemDetails` responses with clear user-safe messages and internal correlation IDs.

### Configuration And Secrets

- Current system includes app settings, local secret providers, and Azure Key Vault support.
- Upgrade should centralize secrets in Key Vault or equivalent and remove hardcoded encryption keys or credentials from frontend code.

---

## 10. Migration Roadmap

```mermaid
gantt
    title Suggested PMS Upgrade Roadmap
    dateFormat  YYYY-MM-DD
    section Discovery
    Confirm database schema and procedures     :a1, 2026-07-15, 20d
    Map current APIs to business modules       :a2, after a1, 15d
    section Foundation
    Build .NET Core 10 shell and auth          :b1, after a2, 20d
    Build modern frontend shell                :b2, after a2, 20d
    section Core Migration
    Practice, users, setup modules             :c1, after b1, 25d
    Patient and scheduler modules              :c2, after c1, 35d
    Claims and claim submission                :c3, after c2, 45d
    Payments and ERA                           :c4, after c3, 45d
    section Stabilization
    Reports, tickets, credentialing            :d1, after c4, 35d
    UAT, reconciliation, cutover               :d2, after d1, 30d
```

### Recommended Migration Order

1. Foundation: authentication, selected practice context, layout, permissions, audit, logging.
2. Low-risk setup modules: facilities, procedures, diagnosis, NDC, insurance setup, referral physicians.
3. Practice profile: practices, providers, locations, payers, web portals.
4. Patient demographics and attachments.
5. Scheduler and appointment rules.
6. Tasks and ticket tracker.
7. Claims and HCFA.
8. Claim submission and scrubber.
9. ERA, payments, batch payment posting, unapplied payments.
10. Reports and credentialing.

Payments and claims should migrate later because they carry the highest financial and compliance risk.

---

## 11. Upgrade Checklist

### Before Rebuild

- Review database schema and stored procedure definitions.
- Identify active vs unused screens/controllers.
- Confirm which features are used by Billing/Manager and other roles.
- Identify all production integrations and credentials.
- Build test cases for billing-sensitive flows.

### During Rebuild

- Create one API contract per module.
- Add automated tests before changing high-risk logic.
- Keep old and new systems comparable through reconciliation reports.
- Migrate in slices, not all at once.

### Before Go-Live

- Compare patient, claim, payment, ERA, and report outputs.
- Run parallel billing/payment tests.
- Validate user permissions.
- Validate file exports and imports.
- Confirm all worker jobs and integrations are scheduled and monitored.

---

## 12. References

- User manual: `NobilityPM User Guide V 1.4 1.pdf`
- Existing raw inventories:
  - `01_Complete_Feature_Inventory.md`
  - `02_Frontend_Route_Component_Inventory.md`
  - `03_Backend_API_Service_Inventory.md`
  - `04_Database_Dependency_Inventory.md`

