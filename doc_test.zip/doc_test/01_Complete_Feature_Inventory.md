# Complete Feature Inventory

Scope: `NPM_UI_BackUp` and `NPM_API_BackUp` only. Database schema details are pending until table/procedure definitions are supplied.

| Feature / Module | Routes | Components | Controller actions | Services | DB model/table names | Stored procedure refs |
| --- | --- | --- | --- | --- | --- | --- |
| Authentication and Security | 3 | 3 | 17 | 3 | 10 | 3 |
| Claims and UB04 | 22 | 22 | 112 | 9 | 152 | 149 |
| Credentialing | 0 | 4 | 12 | 1 | 18 | 4 |
| Dashboard and Alerts | 3 | 3 | 7 | 2 | 8 | 9 |
| ERA and EDI | 57 | 31 | 28 | 5 | 76 | 32 |
| Import Wizard and Sync Workers | 0 | 1 | 5 | 4 | 6 | 4 |
| Insurance Setup | 10 | 17 | 32 | 1 | 68 | 23 |
| Patient Demographics | 23 | 26 | 120 | 3 | 65 | 69 |
| Payments and Deposit Slip | 16 | 18 | 32 | 1 | 38 | 24 |
| Practice Setup | 12 | 15 | 159 | 3 | 172 | 64 |
| Reports and Analytics | 27 | 25 | 27 | 1 | 32 | 54 |
| Scheduler and Appointments | 13 | 8 | 23 | 1 | 14 | 6 |
| Shared/Common and Miscellaneous | 0 | 24 | 35 | 6 | 296 | 26 |
| Ticket Tracker and Tasks | 0 | 5 | 15 | 1 | 21 | 4 |
| User Management and Permissions | 51 | 19 | 41 | 1 | 17 | 10 |

## Authentication and Security

Business purpose: Authentication and Security supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
| login | LoginComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
| forgot-password | ForgotPasswordComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
| otp | OtpComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| ForgotPasswordComponent | app-forgot-password | NPM_UI_BackUp/src/app/auth/forgot-password |
| LoginComponent | app-login | NPM_UI_BackUp/src/app/auth/Login |
| OtpComponent | app-otp | NPM_UI_BackUp/src/app/auth/otp |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| POST | api/Alert/SaveLoginAlert | ResponseModel | NpmAlert model | NPM_API_BackUp/NPMAPI/Controllers/AlertController.cs:38 |
| GET | api/Alert/GetLoginAlert | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/AlertController.cs:55 |
| GET | api/TicketTracker/GetLoginTicketPopup | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:396 |
| ANY | api/Token/Auth | IHttpActionResult | [FromBody] TokenRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:38 |
| ANY | api/Token/AuthCode | IHttpActionResult | [FromBody] CodeRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:57 |
| ANY | api/Token/SetAuthCookies | void | HttpResponse response, string accessToken, string refreshToken | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:103 |
| GET | api/Token/AuthCodeResend | IHttpActionResult | long userid | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:134 |
| GET | api/Token/VerifyPassowrd | IHttpActionResult | string password | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:163 |
| ANY | api/Token/myauthmailsender | string | string receiverEmail, string name | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:232 |
| ANY | api/Token/maintainlogofOTP | bool | long userid, string Otp | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:287 |
| POST | api/Token/Logout | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:424 |
| POST | api/Token/sendOTPToResetPassword | IHttpActionResult | TokenRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:445 |
| ANY | api/Token/forgetpasswordmailsender | string | string receiverEmail, string name | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:522 |
| POST | api/Token/ResetPasswordForOTP | ResponseModel | [FromBody] ResetPasswordViewModel model | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:580 |
| ANY | api/Token/GetPracticesClientBased | ResponseModel | long ClientCode, long userId | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:598 |
| ANY | api/Token/LoginRateLimitReset | void | string userName | NPM_API_BackUp/NPMAPI/Controllers/TokenController.cs:609 |
| POST | api/UserManagementSetup/ResetPasswordForOTP | ResponseModel | [FromBody] ResetPasswordViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:110 |
| Service | Representative methods | File |
| --- | --- | --- |
| AuditLogService | Log, Log, LogBlockedUser, BlockedLogCount, GetUser, GetActiveInActiveUser, LoginRateLimitReset | NPM_API_BackUp/NPMAPI/Services/AuditLogService.cs |
| EncryptionService | HashPassword, VerifyHashedPassword, VerifyUser, UserInvalidationReason, VerifyUserResend, VerifyUserCode, VerifyUserForResetPassword, VerifyPassword, GetPracticesClientBased | NPM_API_BackUp/NPMAPI/Services/EncryptionService.cs |
| SecurityEventService | PasswordSuccess, PasswordFailed, OtpSent, OtpSentFailed, OtpVerifySuccess, OtpVerifyFailed, LoginSuccess, LoginFailed, AccessDenied, PasswordResetSuccess, PasswordResetFailed | NPM_API_BackUp/NPMAPI/Services/SecurityEventService.cs |
**Database model/table candidates:** AuditLogEntry, Audit_Block_Users, Central_Audit_Logs, NPMDBEntities, RefreshToken, SP_GetUserAuthorization_Hamza_Result, SP_GetUserAuthorization_Result, TWO_FACTOR_AUTHORAZITION, TokenRequestModel, Users_RS2F_OTP

**Stored procedure/function references:** SP_GetUserAuthorization, SP_GetUserAuthorization_Hamza_Result, SP_GetUserAuthorization_Result


## Claims and UB04

Business purpose: Claims and UB04 supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
| claimsubmission |  | ./claim-submission/claim-submission.module#ClaimSubmissionModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
|  | ClaimSubmissionComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| scrubber/:type | ComponentScrubberComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| skippedclaims | AutoSubmissionSkippedClaimsComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| claims | ClaimsSubmissionClaimsComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| errors | ClaimSubmissionErrorsComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| claims | ClaimsSubmissionClaimsComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| batchResponse | BatchSubmissionResponseComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| Claimrejection | ClaimRejectionComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| Diagnosis | DiagnosisComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
|  | MainComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| ClaimDetail/:param | ClaimsComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| ClaimSummary/:param | ClaimSummaryComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| Appoinments/:param | AppoinmentsComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| claims/:id | ERAClaims |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| claim-payment-report | ClaimPaymentReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| hold-claims-report | HoldclaimsComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| claim-assignmentreport | ClaimAssignmentreportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| scrubber-rejection-report | ScrubberRejectionReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| claim-submission-report | ClaimSubmissionReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Visit-Claim-Activity-report | VisitClaimActivityReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| claimlevel | ClaimLevelComponent |  | NPM_UI_BackUp/src/app/tasks/tasks-routing.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| AutoSubmissionSkippedClaimsComponent | app-auto-submission-skipped-claims | NPM_UI_BackUp/src/app/claim-submission/auto-submission-skipped-claims |
| BatchSubmissionResponseComponent | app-batch-submission-response | NPM_UI_BackUp/src/app/claim-submission/batch-submission-response |
| ClaimSubmissionErrorsComponent | app-claim-submission-errors | NPM_UI_BackUp/src/app/claim-submission/claim-submission-errors |
| ClaimSubmissionComponent | app-claim-submission | NPM_UI_BackUp/src/app/claim-submission |
| ClaimsSubmissionClaimsComponent | app-claims-submission-claims | NPM_UI_BackUp/src/app/claim-submission/claims-submission-claims |
| ComponentScrubberComponent | app-component-scrubber | NPM_UI_BackUp/src/app/claim-submission/component-scrubber |
| ClaimAttachmentsComponent | app-claim-attachments | NPM_UI_BackUp/src/app/Claims/Attachments |
| ClaimNotesComponent | app-claim-notes | NPM_UI_BackUp/src/app/Claims/claimNotes |
| ClaimsAssignmentComponent | app-claims-assignment | NPM_UI_BackUp/src/app/Claims/claims-assignment |
| ClaimsComponent | app-claims | NPM_UI_BackUp/src/app/Claims |
| DiagnosisComponent | app-diagnosis | NPM_UI_BackUp/src/app/Claims/Diagnosis |
| ClaimInsurancesComponent | app-claim-insurances | NPM_UI_BackUp/src/app/Claims/Insurances |
| PaymentsComponent | app-payments | NPM_UI_BackUp/src/app/Claims/Payments |
| UB04Component | app-ub04 | NPM_UI_BackUp/src/app/Claims/ub04 |
| ERAClaims | app-era-claims | NPM_UI_BackUp/src/app/era/era-claims |
| ClaimAssignmentreportComponent | app-claim-assignmentreport | NPM_UI_BackUp/src/app/reports/claim-assignmentreport |
| ClaimPaymentReportComponent | app-claim-payment-report | NPM_UI_BackUp/src/app/reports/claim-payment-report/claim-payment-report |
| ClaimSubmissionReportComponent | app-claim-submission-report | NPM_UI_BackUp/src/app/reports/claim-submission-report |
| HoldclaimsComponent | app-holdclaims | NPM_UI_BackUp/src/app/reports/holdclaims |
| ScrubberRejectionReportComponent | app-scrubber-rejection-report | NPM_UI_BackUp/src/app/reports/scrubber-rejection-report |
| VisitClaimActivityReportComponent | app-visit-claim-activity-report | NPM_UI_BackUp/src/app/reports/visit-claim-activity-report |
| ClaimLevelComponent | app-claim-level | NPM_UI_BackUp/src/app/tasks/claim-level |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| GET | api/ClaimAssignment/GetUsersList | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:20 |
| ANY | api/ClaimAssignment/PostAllAssignedClaims | ResponseModel | claimassigneeModel model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:26 |
| GET | api/ClaimAssignment/GetAssignedClaimData | ResponseModel | long claimnumber | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:32 |
| POST | api/ClaimAssignment/EditAssignedClaims | ResponseModel | editassignedclaimModel model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:38 |
| GET | api/ClaimAssignment/GetAllAssignedClaims | ResponseModel | long practice_code, long assignedByuserid | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:44 |
| GET | api/ClaimAssignment/GetSpecificAssignedClaimData | ResponseModel | long claimassignee_id | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:64 |
| GET | api/ClaimAssignment/GetSpecificAssignedClaimNotes | ResponseModel | long ClaimAssignee_notes_ID | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:70 |
| GET | api/ClaimAssignment/GetAllAssignedClaimsNotifications | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:76 |
| GET | api/ClaimAssignment/GetAllAssignedAccountsNotifications | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:82 |
| POST | api/ClaimAssignment/PostAllAssignedAccounts | ResponseModel | accountassigneeModel model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:90 |
| GET | api/ClaimAssignment/GetAllAssignedAccounts | ResponseModel | long practice_code, long assignedByuserid | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:98 |
| GET | api/ClaimAssignment/GetSpecificAssignedAccountNotes | ResponseModel | long AccountAssignee_notes_ID | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:118 |
| GET | api/ClaimAssignment/GetSpecificAssignedAccountData | ResponseModel | long accountassignee_id | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:124 |
| POST | api/ClaimAssignment/EditAssignedAccounts | ResponseModel | editassignedaccountModel model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:130 |
| GET | api/ClaimAssignment/CheckClaimAssignment | ResponseModel | long claimno | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:142 |
| GET | api/ClaimAssignment/CheckAccountAssignment | ResponseModel | long accnum | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:147 |
| POST | api/ClaimAssignment/ClaimTaskAssignment | ResponseModel | TaskAssignmentClaimList model | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:152 |
| POST | api/ClaimsAttachments/Attach | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs:34 |
| GET | api/ClaimsAttachments/GetAll | IHttpActionResult | long Claim_No | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs:99 |
| GET | api/ClaimsAttachments/GetAttachmentCodeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs:105 |
| GET | api/ClaimsAttachments/Download | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/ClaimsAttachmentsController.cs:111 |
| GET | api/HCFA/GenerateHcfa | HttpResponseMessage | string claimNo, string insuranceType, bool isPrintable = false | NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs:18 |
| GET | api/HCFA/GenerateUB | HttpResponseMessage | string claimNo, bool isPrintable = false | NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs:31 |
| GET | api/HCFA/GenerateBatchHcfa | HttpResponseMessage | string batchIds, string insuranceType, bool isPrintable = false, string status=null | NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs:42 |
| GET | api/HCFA/canPrint | bool | string batchIds | NPM_API_BackUp/NPMAPI/Controllers/HCFAController.cs:130 |
| GET | api/Payments/GetClaimsSummary | ResponseModel | string ClaimId, string practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:60 |
| POST | api/Payments/GetClaimByins | ResponseModel | insBasedClaimModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:76 |
| POST | api/Payments/PostClaims | ResponseModel | postClaim request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:85 |
| GET | api/Payments/getClaimsDetails | ResponseModel | long claimNo, long patientaccount | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:93 |
| POST | api/Payments/SaveClaimsDetails | ResponseModel | ClaimsPaymentDetailModel[] cpd | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:101 |
| GET | api/Payments/checkPostedClaims | ResponseModel | long batchno, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:109 |
| GET | api/Payments/GetClaimDetails | ResponseModel | long claimID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:161 |
| GET | api/Payments/GetClaimDetailsByClaimNumber | ResponseModel | long claimID, int practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:168 |
| GET | api/Payments/GetPostedClaims | ResponseModel | string batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:176 |
| GET | api/Payments/DeleteClaimPayment | ResponseModel | string batchID, long claimNo, string Amtdue | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:216 |
| ANY | api/RealTimeClaimStatus/GenerateBatch276 | Task<IHttpActionResult> | long practice_id, long claim_id,long Insurance_Id, string unique_name | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:27 |
| POST | api/RealTimeClaimStatus/GetCSIStatus | Task<ResponseModel> | long practiceCode, long ClaimNo | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:42 |
| ANY | api/RealTimeClaimStatus/GenerateBatch | Task<IHttpActionResult> | long practice_id, long claim_id, long Insurance_Id, string unique_name | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:47 |
| ANY | api/RealTimeClaimStatus/UploadBatches276 | Task<IHttpActionResult> | BatchUploadRequest model | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:60 |
| ANY | api/RealTimeClaimStatus/SingleClaimUploadBatches276 | Task<IHttpActionResult> | CSIClaimBatchUploadRequest model, [FromUri] bool? getUpdatedCSI = null | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:90 |
| ANY | api/RealTimeClaimStatus/SingleClaimUploadBatches276 | Task<IHttpActionResult> | CSIClaimBatchUploadRequest model, [FromUri] bool? getUpdatedCSI = null | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:135 |
| ANY | api/RealTimeClaimStatus/UploadBatches276 | Task<IHttpActionResult> | BatchUploadRequest model | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:166 |
| POST | api/RealTimeClaimStatus/RegenerateBatchFile | Task<RegenerateBatchCSIFileModel> | RegenerateBatchCSIFileModel model | NPM_API_BackUp/NPMAPI/Controllers/RealTimeClaimStatusController.cs:196 |
| GET | api/Report/DormantClaimsReport | Task<ResponseModel> | long PracticeCode, int page, int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:30 |
| GET | api/Report/DormantClaimsReports | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:36 |
| GET | api/Report/DormantClaimsReportsPagination | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:42 |
| POST | api/Report/ClaimPaymentsDetailReport | ResponseModel | [FromBody] ClaimPaymentsDetailRequest request | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:102 |
| GET | api/Report/ClaimAssignmentReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:295 |
| POST | api/Report/GetVisitClaimActivityReport | Task<ResponseModel> | PatelReportsRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:319 |
| GET | api/Scheduler/GetPaperSubmissionType | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:193 |
| GET | api/Scheduler/getClaimsTypesInBatch | ResponseModel | string batchIds | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:204 |
| POST | api/Scrubber/getAllCleanClaims | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:23 |
| POST | api/Scrubber/getViolatedClaims | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:29 |
| POST | api/Scrubber/getSkippedClaims | ResponseModel | string practiceCode | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:35 |
| ANY | api/Scrubber/AddTOScrubber | ResponseModel | ClaimsViewModel claimModel | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:40 |
| GET | api/Scrubber/GetColumn_Lists_FrontEnd | List<GetColumn_List> |  | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:48 |
| POST | api/Scrubber/GetColumsList | ResponseModel | GetColumnList GC_L | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:54 |
| GET | api/Scrubber/GetTableList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:60 |
| POST | api/Scrubber/AddCustom_Edits_Rules | ResponseModel | CustomEdits_ColumnsList ce | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:67 |
| POST | api/Scrubber/GetScrubberReport | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:75 |
| POST | api/Scrubber/GetScrubberReportPagination | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To,int page,int size | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:81 |
| POST | api/Scrubber/GetScrubberRejectionDetail | ResponseModel | string practiceCode, DateTime Date_From, DateTime Date_To | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:86 |
| GET | api/Scrubber/GetAllCustomEdits | List<Custom_Scrubber_Rules> | long Practice_Code | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:91 |
| GET | api/Scrubber/GetCustomRuleById | ResponseModel | int id | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:97 |
| GET | api/Scrubber/CustomEditsStatus | ResponseModel | int id | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:103 |
| POST | api/Scrubber/GetClaimSubmissionReport | ResponseModelForClaimSubmission | long practiceCode, DateTime Date_From, DateTime Date_To, string Status | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:112 |
| POST | api/Scrubber/GetClaimSubmissionReportPagiantion | ResponseModelForClaimSubmission | long practiceCode, DateTime Date_From, DateTime Date_To, string Status,int page,int size | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:117 |
| GET | api/Scrubber/GetEdiHistory | ResponseModelForEdiHistory | long claimNo, string Status, string statusLevel, string File277CA | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:122 |
| GET | api/Scrubber/GetClaimRejections | ResponseModelforClaimRejection | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/ScrubberController.cs:127 |
| GET | api/Setup/DuplicateAlternateCodeClaimCharges | ResponseModel | string AlternateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:307 |
| ANY | api/Submission/GenerateBatch_5010_P | ResponseModel | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:29 |
| GET | api/Submission/GenerateBatch_5010_P | Task<ResponseModel> | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:57 |
| GET | api/Submission/View837 | Task<ResponseModel> | long batchId, long practice_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:102 |
| GET | api/Submission/GenerateBatch_5010_I | Task<ResponseModel> | long practice_id, long claim_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:107 |
| POST | api/Submission/SearchClaim | ResponseModel | ClaimSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:113 |
| ANY | api/Submission/SearchBatchClaims | ResponseModel | BatchClaimsSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:115 |
| ANY | api/Submission/RemoveClaimBatch | ResponseModel | RemoveClaimBatchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:116 |
| POST | api/Submission/AddUpdateBatch | ResponseModel | BatchCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:118 |
| ANY | api/Submission/GetPendingBatchSelectListErrorCom | ResponseModel | long practiceCode, long? providerCode, string practype | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:129 |
| GET | api/Submission/GetPendingBatchSelectList | ResponseModel | long practiceCode, long? providerCode, string practype, string batch_claim_type | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:135 |
| GET | api/Submission/GetSentBatchSelectList | ResponseModel | string searchText, long practiceCode, long? providerCode | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:141 |
| POST | api/Submission/GetBatchesDetail | ResponseModel | BatchListRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:147 |
| POST | api/Submission/AddInBatch | ResponseModel | AddInBatchRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:159 |
| POST | api/Submission/LockBatch | ResponseModel | LockBatchRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:171 |
| POST | api/Submission/HoldBatch | ResponseModel | HoldBatchRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:184 |
| GET | api/Submission/GetERACheckDetails | ResponseModel | long practice_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:198 |
| GET | api/Submission/GetBatchPaymentForERA | ResponseModel | string checkNo, long practice_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:209 |
| ANY | api/Submission/UploadBatches | Task<ResponseModel> | BatchUploadRequest model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:221 |
| POST | api/Submission/UploadBatches | Task<ResponseModel> | BatchUploadRequest model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:233 |
| POST | api/Submission/GetBatchFileErrors | ResponseModel | BatchErrorsRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:277 |
| POST | api/Submission/GetBatchExceptions | ResponseModel | BatchErrorsRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:282 |
| POST | api/Submission/GetBatchesHistory | ResponseModel | BatchesHistoryRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:287 |
| GET | api/Submission/Get999Report | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:292 |
| GET | api/Submission/GetBatcheDetalis | ResponseModel | long batchId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:298 |
| GET | api/Submission/GetCSIBatcheDetalis | ResponseModel | int batchId, string claimId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:304 |
| GET | api/Submission/GetCSIBatcheResponseDetalis | ResponseModel | int batchId, long claimId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:309 |
| GET | api/Submission/GetCSIBatcheDetalisStatus | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:314 |
| GET | api/Submission/CheckMedicareClaim | ResponseModel | long? claimId,long insurance_id | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:319 |
| GET | api/Submission/DownloadEDIFile | HttpResponseMessage | long batchId | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:325 |
| POST | api/Submission/RegenerateBatchFile | Task<ResponseModel> | RegenerateBatchFileRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:356 |
| GET | api/Submission/Read | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:364 |
| POST | api/Submission/SearchERA | ResponseModel | ERASearchRequestModel model , string imp_type = null | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:370 |
| POST | api/Submission/EraSummary | ResponseModel | EraSummaryRequest model | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:376 |
| GET | api/Submission/ViewClaimERA | ResponseModel | long claimno, string check_No | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:381 |
| POST | api/Submission/ERAClaimSummary | ResponseModel | claimsummaryrequest req, string imp_type = null | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:425 |
| POST | api/Submission/ApplyERA | ResponseModel | ApplyERARequestModel req | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:431 |
| POST | api/Submission/AutoPost | ResponseModel | ERAAutoPostRequestModel request | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:437 |
| POST | api/Submission/ERAClaimsOverPayment | ResponseModel | claimsummaryrequest req | NPM_API_BackUp/NPMAPI/Controllers/SubmissionController.cs:443 |
| GET | api/TicketTracker/GetClaimInfo | ResponseModel | string claimno | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:69 |
| GET | api/UBClaim/GetAllCodesData | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/UBClaimController.cs:26 |
| GET | api/UBClaim/GetallDropdowns | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/UBClaimController.cs:32 |
| POST | api/UBClaim/ManageOccurenceSpan | Task<ResponseModel> | List<Claims_Occurrence_Code> OSClist | NPM_API_BackUp/NPMAPI/Controllers/UBClaimController.cs:42 |
| Service | Representative methods | File |
| --- | --- | --- |
| ClaimAssignmentService | GetSelectedUserList, PostAllAssignedClaimsforUser, GetAssignedClaimDataforUser, EditAssignedClaimsforUser, GetAllAssignedClaimsforspecificuser, GetAllAssignedClaimsForPracticeuser, GetAllAssignedClaimsNotificationsforuser, GetAllAssignedAccountsNotificationsforuser, GetSpecificAssignedClaimDataforuser, GetSpecificAssignedClaimNotesforuser, PostAllAssignedAccountforUser, GetAllAssignedAccountsforspecificuser, GetAllAssignedAccountsForPracticeuser, GetSpecificAssignedAccountNotesforuser, GetSpecificAssignedAccountDataforuser, EditAssignedAccountforUser, GetAllActivePractices, CheckClaimAssignment | NPM_API_BackUp/NPMAPI/Services/ClaimAssignmentService.cs |
| ClaimBatch276 | SendRequest, Trizetto, UploadBatches, SingleCSIClaimBatchUpload | NPM_API_BackUp/NPMAPI/Services/ClaimBatch276.cs |
| ClaimsAttachmentsService | GetAllClaimAttachemnt, AttachemntSave, GetAttachmentTypeCodesList, GetAttachemnt | NPM_API_BackUp/NPMAPI/Services/ClaimsAttachmentsService.cs |
| ClaimsService | SaveClaimModel, SaveClaim, GetProcedureCharges, GetProcedureCharges, CheckModificationAllowed, GetPricingModifier, GetEFSPractices, GetLocationState, GetPatientInsuranceInfo, GetInsuranceInfo, Is_Participating, IsFacility, GetCPTCode, GetCPTCode, SP_ProviderPlan, SP_InsPayer, GetInsState, GetInsLocation | NPM_API_BackUp/NPMAPI/Services/ClaimsService.cs |
| ClaimStatus | SendRequest, Trizetto, GetCSIReport | NPM_API_BackUp/NPMAPI/Services/ClaimStatus.cs |
| ClaimStatusService | GenerateSerialNumber, GenerateSerialNumberISA, GenerateSerialNumberBHTGS, SequanceNumber, SequanceNumberISA, SequanceNumberBHT, GenerateBatch_276, getSpResult, GetClaimsData, InsertIntoCSIRequestsData, GenerateSerialNumber, GenerateSerialNumberISA, GenerateSerialNumberBHTGS, SequanceNumber, SequanceNumberISA, SequanceNumberBHT, GenerateBatch_276, getSpResult | NPM_API_BackUp/NPMAPI/Services/ClaimStatusService.cs |
| ScrubberService | GetAllViolated, GetSkippedClaims, GetAllCleanClaims, AddToScrubberQueue, GetColumnList_FrontEnd, GetColumnList, GetTableList, AddCustom_Edits_Rules, GetAllCustomEdits, GetCustomRuleById, CustomEditsStatus, GetScrubberRejection, GetScrubberRejectionPagination, GetScrubberRejectionDetail, GetClaimSubmissionReport, GetClaimSubmissionReportPagination, GetEdiHistory, GetClaimRejections | NPM_API_BackUp/NPMAPI/Services/ScrubberService.cs |
| SubmissionService | GetFormattedDate, GenerateSerialNumber, InsertSerialNumber, GenerateBatch_5010_P_P, GenerateBatch_5010_P_S, ParseFile, GetClaimsSearchModels, SearchClaim, SearchBatchClaims, RemoveClaimBatch, AddUpdateBatch, GetPendingBatchSelectListErrorCom, GetPendingBatchSelectList, GetSentBatchSelectList, GetBatchesDetail, AddInBatch, CanAddClaims, LockBatch | NPM_API_BackUp/NPMAPI/Services/SubmissionService.cs |
| UBClaim | GetAllCodesData, ManageOccurenceSpan, ManageOccurenceSpan, GetallDropdowns, SaveUBClaim | NPM_API_BackUp/NPMAPI/Services/UBClaim.cs |
**Database model/table candidates:** BatchCSIResponse, BatchClaimsDetail, BatchCreateViewModel, CLAIMS_SUBMITTED, CLAIM_CHARGES_BKP20230817, CLAIM_NOTES, CLAIM_PAYMENTSBKP20230817, Claim, ClaimAssignee_CL, ClaimAssignee_Notes, ClaimAttachmentRequest, ClaimChargesUpdateRequest, ClaimDetails, ClaimErrorMessage, ClaimOverpayment, ClaimPaymentUpdateRequest, ClaimPaymentsDetailRequest, ClaimStatusTRNNumberModel, ClaimStatus_Search_Criteria, ClaimSubmission, ClaimSubmissionModel, ClaimSubmissionResponse, ClaimSummaryViewModel, ClaimUpdateRequest, Claim_Batch_Exceptions, Claim_Charges, Claim_Charges_Summary, Claim_Document, Claim_Insurance, Claim_Overpayment, Claim_Payments, Claim_Status_Codes, Claim_Worker_Injurycase, ClaimsDataModel, ClaimsDetail, ClaimsPayments_06082023, ClaimsPayments_06092023, ClaimsViewModel, Claims_06082023, Claims_06092023, Claims_Condition_Code, Claims_ICD10DX, Claims_Occurence_Span_Code, Claims_Occurrence_Code, Claims_Ptl_Feedback, Claims_Value_Code, Claims_filling_limit, CustomEdits_ClearClaims, Custom_Scrubber_Rules, DelayClaimReports_Result, ERACLAIMINFO, ERACLAIMINFO_EDI, GetBatchClaimsDetails_Result, GetBatchClaims_Result, GetClaimChargesByClaimNo_Result, GetClaimsForStatement_Result, GetPanelCodeCPTDetailsClaim_Result, GetRecentClaimDetailsWithDiagnosis_Result, HCFAImage, HCFAImagesType, HCFAResponseModel, HCFA_Attachment_Type, HCFA_Notes_List, Hcfa_fields, MIS_TBL_Corrected_Claim_Reason, Packet277CAClaimReason_Messages, Packet277CAClaims, Packet277CA_ClaimStatusCategoryCodes, Packet277CA_ClaimStatusCodes, ResubmissionCode, SP_CLAIMSUMMARYAMOUNTS_Result, SP_ClaimInsuranceSearch_Result, SP_Claim_Batch_Exception_EDI_Result, SP_Claim_Insurancebysearch_Result, SP_ClaimsSearch_EDI_Result, SP_ClaimsSearch_EDI_bkp_04112025_Result, SP_CountAssignedclaims_Result, SP_ERACLAIMDETAIL_Result, SP_ERACLAIMDETAIL_VIEW_EDI_Result, SP_ERAClaimCrossOver_Result, SP_GetAllAssignedClaimForusers_Result, SP_GetClaimById_Result, SP_GetClaimPaymentDetail_Result, SP_GetClaimPaymentDetail_Updated_Result, SP_GetClaimsListByDOS1_Result, SP_GetSpecificClaiminfo_Result, SP_PATSTATEMENT_CLAIMSUMMARY_Result, SP_PassedClaimsSearch_Result, SP_PassedClaimsSearch_Result1, SP_Search_Claim_Batch_Error_EDI_Result, SP_Search_Claim_Batch_Error_Result, SUBMISSION_SETUP, ScrubberClaim, ScrubberQueue, ScrubberQueuetest, ScrubberReportResponse, Scrubber_Rejection, Scrubber_Rejections, SubmissionMethod, Submission_Schedual, Submission_plan, SyncedClaim, SyncedClaimCharge, SyncedClaimPayment, TaskAssignmentClaimList, USP_CheckMedicareClaim_Result, USP_ERAClaimOverPayment_Result, USP_Get_Batch_ClaimDetails_Result, USP_Visit_Claim_Activity_Report_Result, VisitClaimActivityReportResponse, claimReason, claim_batch, claim_batch_detail, claim_batch_detail_test, claim_batch_error, claim_batchbkp, claim_bkp, claim_charges_06092023, claim_info_worker_injurycase, claim_insurance_06092023, claim_paymentsbkp20230818, claim_paymenttets, claim_reject_type_CO, claimassigneeModel, claimerrormessageRejection, claims_bkp20230925, claims_bkp_10012019, claims_testUbaid, claimsbkp, editassignedclaimModel, era_claim, era_claim_service, eraclaiminfo_impt, fetchFailedClaims_Result, procItemized_Statement_Claim_Due_Result, spGetAllClaimsInQueue_Result, spGetAllCleanClaims_Result, spGetBatchClaimsDiagnosis_Result, spGetBatchClaimsInfo_Result, spGetBatchClaimsInsurancesInfo_Result, spGetBatchClaimsProcedures_Result, spGetBatchClaimsProcedurestest_Result, spGetCleanClaims_Result, spGetFailedClaimsFromScrubber_Result, spGetFailedClaims_Result, sp_GetScrubberRejectionReportDetailes_Result, sp_GetScrubberRejectionReports_Result, submissionPlan, submission_Plan_bkp, submission_servers, uspGetClaimAttachments_Result, usp_GetAutoBatchSkippedClaims_Result

**Stored procedure/function references:** Aging_from_Last_submission, Check_Date, Check_No, Claim_Amount, Claim_AmtDue, Claim_AmtPaid, Claim_AssigneeID, Claim_AttendingPhysician, Claim_Batch_Exceptions, Claim_BillingPhysician, Claim_CSI_Status, Claim_Charges_Id, Claim_Charges_Imported, Claim_Charges_Issues, Claim_Charges_Summary, Claim_Charges_Total, Claim_Claimtotal, Claim_Count, Claim_DOS, Claim_Date, Claim_ID, Claim_Imported, Claim_Ins_Imported, Claim_Ins_Issues, Claim_Ins_Total, Claim_Issues, Claim_Last_Submission, Claim_NO, Claim_Numbers, Claim_Payments_Id, Claim_Pos, Claim_Procedures_Id, Claim_RMK_code, Claim_Status_Codes, Claim_Status_Request, Claim_Worker_Injurycase, Claim_id, Claim_notes, Claim_payment_Id, Claim_total, Claim_type, ERA_ADJUSTMENT_CODE, ERA_CATEGORY_CODE, ERA_Rejection_CATEGORY_CODE, MIS_TBL_Corrected_Claim_Reason, SP_CLAIMSUMMARYAMOUNTS_Result, SP_ClaimInsuranceSearch, SP_ClaimInsuranceSearch_Result, SP_Claim_Batch_Exception_EDI, SP_Claim_Batch_Exception_EDI_Result, SP_Claim_Insurancebysearch, SP_Claim_Insurancebysearch_Result, SP_ClaimsSearch, SP_ClaimsSearch_EDI, SP_ClaimsSearch_EDI_Result, SP_ClaimsSearch_EDI_bkp_04112025, SP_ClaimsSearch_EDI_bkp_04112025_Result, SP_ClaimsSearch_Result, SP_CountAssignedAccounts, SP_CountAssignedAccounts_Result, SP_CountAssignedclaims, SP_CountAssignedclaims_Result, SP_EDIHistory, SP_ERAADJCODEGLOSSARY, SP_ERAADJCODEGLOSSARY_VIEW_EDI, SP_ERAAUTOPOST, SP_ERACLAIMDETAIL, SP_ERACLAIMDETAIL_Result, SP_ERACLAIMDETAIL_VIEW_EDI, SP_ERACLAIMDETAIL_VIEW_EDI_Result, SP_ERACLAIMSAUTOPOST, SP_ERAClaimCrossOver, SP_ERAClaimCrossOver_Result, SP_ERASEARCH, SP_ERASEARCH_MAN_IMP, SP_ERASEARCH_Result, SP_GetAllAssignedClaimForusers, SP_GetAllAssignedClaimForusers_Result, SP_GetBatchDetail, SP_GetBatchDetail_EDI, SP_GetBatchDetail_EDI_Result, SP_GetBatchDetail_Paper, SP_GetBatchDetail_Paper_Result, SP_GetBatchDetail_Result, SP_GetClaimById, SP_GetClaimById_Result, SP_GetClaimPaymentDetail, SP_GetClaimPaymentDetail_Result, SP_GetClaimPaymentDetail_Updated, SP_GetClaimPaymentDetail_Updated_Result, SP_GetClaimsListByDOS1, SP_GetClaimsListByDOS1_Result, SP_GetInsuranceInfo, SP_GetInsuranceInfo_Result, SP_GetParticipating, SP_GetSpecificClaiminfo, SP_GetSpecificClaiminfo_Result, SP_GetclaimbymultiIDS, SP_GetclaimbymultiIDSforchecking, SP_Global277CAReport, SP_InsPayer, SP_InsPayerWithoutModifierAndProcedure, SP_InsPayerWithoutModifierAndProcedure_Result, SP_InsPayer_Result, SP_InsStatePlan, SP_InsStatePlan_Result, SP_InsStateWithoutModifierAndProcedure, SP_InsStateWithoutModifierAndProcedure_Result, SP_PATSTATEMENT_CLAIMSUMMARY, SP_PATSTATEMENT_CLAIMSUMMARY_Result, SP_PassedClaimsSearch, SP_PassedClaimsSearch_Result, SP_PassedClaimsSearch_Result1, SP_Search_Claim_Batch_Error, SP_Search_Claim_Batch_Error_EDI, SP_Search_Claim_Batch_Error_EDI_Result, SP_Search_Claim_Batch_Error_Result, SP_TableIdGenerator_Test, USP_CheckMedicareClaim, USP_CheckMedicareClaim_Result, USP_ERAClaimOverPayment, USP_ERAClaimOverPayment_Result, USP_GetCustomEditTable, USP_GetLatestSerialNumber, USP_GetReasonId, USP_GetReasonId_Result, USP_Get_Batch_ClaimDetails, USP_Get_Batch_ClaimDetails_Result, USP_InsertSerialNumber, USP_SUMPOSTEDAMOUNT, USP_UpdateSyncedClaim_ERA, USP_Visit_Claim_Activity_Report, USP_Visit_Claim_Activity_Report_Result, sp_FindErorrClaims, sp_GetScrubberRejectionReportDetailes, sp_GetScrubberRejectionReportDetailes_Result, sp_GetScrubberRejectionReports, sp_GetScrubberRejectionReports_Result, sp_ScrubberProcess, sp_deleteFromScrubberQueue, sp_get999Report_EDI, sp_get999Report_EDI_Result, sp_getBatchHistory, sp_getBatchHistory_EDI, sp_getBatchHistory_EDI_Result, sp_getBatchHistory_Result, usp_GetAutoBatchSkippedClaims, usp_GetAutoBatchSkippedClaims_Result, usp_update_claims_totals_new


## Credentialing

Business purpose: Credentialing supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Component | Selector | Folder |
| --- | --- | --- |
| CredAppAttachmentsComponent | app-cred-app-attachments | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-attachments |
| CredAppListComponent | app-cred-app-list | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-list |
| CredPortalComponent | app-cred-portal | NPM_UI_BackUp/src/app/credentialing/cred-portal |
| CredTasksComponent | app-cred-tasks | NPM_UI_BackUp/src/app/credentialing/cred-tasks |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| GET | api/Credentialing/GetLookupLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:35 |
| GET | api/Credentialing/GetObjectiveTypes | ResponseModel | int appTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:40 |
| POST | api/Credentialing/SearchCredApp | ResponseModel | CredAppSearchViewModel searchViewModel | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:50 |
| GET | api/Credentialing/GetCredAppById | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:57 |
| GET | api/Credentialing/GetCredAppNotes | ResponseModel | long application_Id | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:68 |
| POST | api/Credentialing/UploadCredAppDocument | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:74 |
| GET | api/Credentialing/GetCredAppDocuments | ResponseModel | long applicationId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:131 |
| GET | api/Credentialing/GetCredAppDocumentById | IHttpActionResult | long docId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:140 |
| GET | api/Credentialing/DeleteCredAppDocument | ResponseModel | long documentId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:182 |
| GET | api/Credentialing/GetCredTasks | ResponseModel | long? PracticeCode, long? UserId, int? Obj_Type_Id | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:207 |
| GET | api/Credentialing/GetTaxonomyCode | ResponseModel | string taxonomycode | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:241 |
| GET | api/Credentialing/GetCredPortals | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:246 |
| Service | Representative methods | File |
| --- | --- | --- |
| CredentialingService | GetLookupLists, GetObjectiveTypesByAppType, AddEditCredApp, SearchCredApp, GetCredAppById, AddEditCredAppNote, GetCredAppNotes, SaveCredAppDocument, GetCredAppDocuments, GetCredAppDocumentByDocId, DeleteCredAppDocument, GetUsersByModuleName, GetUserListByRole, CredAppReport, GetCredPortals, AddEditCredPortal, GetCredGridReport, GetTaxonomyCode | NPM_API_BackUp/NPMAPI/Services/CredentialingService.cs |
**Database model/table candidates:** CredAppDocumentRequest, CredAppDocumentViewModel, CredAppNoteViewModel, CredAppSearchViewModel, CredPortal_View, Cred_App_Docs, Cred_App_Notes, Cred_App_ViewModel, Cred_Application_Status, Cred_Application_Type, Cred_Contract_Type, Cred_Document_Type, Cred_Objective_Type, Cred_Portals, CredentialingLookupLists, CredentialingTasksViewModel, Credentialing_Application, SP_SearchCredApp_Result

**Stored procedure/function references:** SP_SearchCredApp, SP_SearchCredApp_Result, USP_Credentialing_Tasks, USP_Get_ObjTypes_ByAppType


## Dashboard and Alerts

Business purpose: Dashboard and Alerts supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
|  | DashBoardComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
| dashboard | DashBoardComponent | ./tickettracker/tickettracker.module#TickettrackerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| CredDashboard | CredDashboardComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| CredDashboardComponent | app-cred-dashboard | NPM_UI_BackUp/src/app/credentialing/cred-dashboard |
| DashBoardComponent | app-dash-board | NPM_UI_BackUp/src/app/dashboard |
| AlertAssignmentComponent | app-alertassignment | NPM_UI_BackUp/src/app/patient/alerts |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| POST | api/Alert/SaveAlert | ResponseModel | NpmAlert model | NPM_API_BackUp/NPMAPI/Controllers/AlertController.cs:31 |
| GET | api/Alert/GetAlertForPatient | ResponseModel | long patientaccount | NPM_API_BackUp/NPMAPI/Controllers/AlertController.cs:47 |
| GET | api/Dashboard/GetDashboardData | ResponseModel | long practiceCode,string fromDate,string toDate | NPM_API_BackUp/NPMAPI/Controllers/DashboardController.cs:18 |
| GET | api/Dashboard/GetExternalPractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DashboardController.cs:24 |
| GET | api/Dashboard/GetOpenPaymentBatches | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DashboardController.cs:31 |
| POST | api/Report/GetAgingDashboard | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:157 |
| GET | api/TicketTracker/GetTicketAlerts | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:380 |
| Service | Representative methods | File |
| --- | --- | --- |
| AlertService | GetAlertForPatient, GetLoginAlert, SaveLoginAlert, SaveAlert | NPM_API_BackUp/NPMAPI/Services/AlertService.cs |
| DashboardService | GetDashboardData, GetExternalPractices, GetOpenPaymentBatches | NPM_API_BackUp/NPMAPI/Services/DashboardService.cs |
**Database model/table candidates:** AlertModel, CPADASHBOARD, DashboardViewModel, NpmAlert, PROCEDURES_ALERTS, SP_GETAGINGDASHBOARD_Result, SP_GETAGINGDASHBOARD_Tets_Result, USPGetAlertAgainst_PAT_Result

**Stored procedure/function references:** SP_AGINGCOMPDEMO_Result, SP_AGINGDEMO_Result, SP_CPADEMO_Result, SP_GETAGINGDASHBOARD, SP_GETAGINGDASHBOARD_Result, SP_GETAGINGDASHBOARD_Tets, SP_GETAGINGDASHBOARD_Tets_Result, SP_TableIdGenerator, USP_Get_Credentialing_Dashboard_Data


## ERA and EDI

Business purpose: ERA and EDI supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
| customEdits/:type/:id | CustomEditsComponent | ./tickettracker/tickettracker.module#TickettrackerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| EDISetup |  | ./edisetup/edisetup.module#EDISetupModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| era |  | ./era/era.module#ERAModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| addedit | CredAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| addedit | CredAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| addedit/:id | CredAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| view/:id | CredAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| credEdiEraApp | CredEdiEraAppListComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| addcredEdiEraaddedit | CredEdiEraAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| editcredEdiEraaddedit/:id | CredEdiEraAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| viewcredEdiEraaddedit/:id | CredEdiEraAppAddeditComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| edi-era-eft-report | EdiEraEftReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| edi-era-eft-grid-report | EdiEraEftGridReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| overall | OverAllByDosComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
|  | EdiSetupMainComponent |  | NPM_UI_BackUp/src/app/edisetup/edisetupRouting.module.ts |
|  | ERALayout |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| era | ERAImportComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| erahistory | ErahistoryComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| manualeraimport | ManualEraimportComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| view/:id | ERAViewer |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| AddEditPanelCode | AddEditPanelCodeComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| add-edit-panel-code/:id | AddEditPanelCodeComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| credit-balance-report | CreditBalanceReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| add | AddEditProcedureComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
| edit/:id/:Desc | AddEditProcedureComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
|  | AddEditInsGroupSetupComponent | insGroup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditInsGroupSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id | AddEditInsGroupSetupComponent | insName | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | AddEditInsNameSetupComponent | insName | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditInsNameSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id | AddEditInsNameSetupComponent | insPayer | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | AddEditInsSetupPayerComponent | insPayer | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditInsSetupPayerComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id | AddEditInsSetupPayerComponent | insSetup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | AddEditInsSetupComponent | insSetup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditInsSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id/:nameId/:payerid | AddEditInsSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| detail/:id/:nameId/:payerid | AddEditInsSetupComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| add | AddEditProcedureComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| edit/:id | AddEditProcedureComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | AddEditModuleComponent | module | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditModuleComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditModuleComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditRoleComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditRoleComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditRoleComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditSubModuleComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditSubModuleComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditSubModuleComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditPropertiesComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditPropertiesComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditPropertiesComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditUserComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| add | AddEditUserComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditUserComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | AddEditEmployeeComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| edit/:id | AddEditEmployeeComponent | rights | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| AddEditAppointmentReasonComponent | add-edit-appointment-reason | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-reasons/add-edit-appointment-reason |
| AddEditAppointmentStatusComponent | add-edit-appointment-status | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-status/add-edit-appointment-status |
| NgbTimeStringAdapter | app-add-edit-block-appointments | NPM_UI_BackUp/src/app/appointment-scheduler/block-appointments/add-edit-block-appointments/add-edit-block-appointments |
| AddEditOfficeTimingComponent | add-edit-office-timing | NPM_UI_BackUp/src/app/appointment-scheduler/office-timings/add-edit-office-timing |
| CredAppAddeditComponent | app-cred-app-addedit | NPM_UI_BackUp/src/app/credentialing/cred-app/cred-app-addedit |
| CredEdiEraAppAddeditComponent | app-cred-edi-era-app-addedit | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-addedit |
| CredEdiEraAppAttachmentsComponent | app-cred-edi-era-app-attachments | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-attachments |
| CredEdiEraAppListComponent | app-cred-edi-era-app-list | NPM_UI_BackUp/src/app/credentialing/cred-edi-era-app/cred-edi-era-app-list |
| EdiEraEftGridReportComponent | app-edi-era-eft-grid-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/edi-era-eft-grid-report |
| EdiEraEftReportComponent | app-edi-era-eft-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/edi-era-eft-report |
| CustomEditsComponent | app-custom-edits | NPM_UI_BackUp/src/app/custom-edits |
| OverAllByDosComponent | over-all-by-dos-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/overall-by-dos |
| EdiSetupMainComponent | app-edi-setup-main | NPM_UI_BackUp/src/app/edisetup |
| ERALayout | app-era-layout | NPM_UI_BackUp/src/app/era/era-layout |
| ERAViewer | app-era-viewer | NPM_UI_BackUp/src/app/era/era-viewer |
| ErahistoryComponent | app-erahistory | NPM_UI_BackUp/src/app/era/erahistory |
| ERAImportComponent | app-eraimport | NPM_UI_BackUp/src/app/era/eraimport |
| ManualEraimportComponent | app-manual-eraimport | NPM_UI_BackUp/src/app/era/manual-eraimport |
| AddEditPanelCodeComponent | app-add-edit-panel-code | NPM_UI_BackUp/src/app/fee-schedule/add-edit-panel-code |
| CreditBalanceReportComponent | app-credit-balance-report | NPM_UI_BackUp/src/app/reports/credit-balance-report |
| AddEditInsSetupComponent | app-add-edit-ins-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/add-edit-ins-setup |
| AddEditInsGroupSetupComponent | app-add-edit-ins-group-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/add-edit-ins-group-setup |
| AddEditInsNameSetupComponent | app-add-edit-ins-name-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/add-edit-ins-name-setup |
| AddEditInsSetupPayerComponent | app-add-edit-ins-setup-payer | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/add-edit-ins-setup-payer |
| AddEditProcedureComponent | app-add-edit-procedure | NPM_UI_BackUp/src/app/setups/Procedures/add-edit-procedure |
| AddEditEmployeeComponent | app-add-edit-employee | NPM_UI_BackUp/src/app/user-management/employees/add-edit-employee |
| AddEditModuleComponent | app-add-edit-module | NPM_UI_BackUp/src/app/user-management/module/add-edit-module |
| AddEditPropertiesComponent | app-add-edit-properties | NPM_UI_BackUp/src/app/user-management/properties/add-edit-properties |
| AddEditRoleComponent | app-add-edit-role | NPM_UI_BackUp/src/app/user-management/role/add-edit-role |
| AddEditSubModuleComponent | app-add-edit-sub-module | NPM_UI_BackUp/src/app/user-management/sub-modules/add-edit-sub-module |
| zipdata | app-add-edit-user | NPM_UI_BackUp/src/app/user-management/users/add-edit-user |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| GET | api/CredEDIERASetup/GetLookupLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:27 |
| POST | api/CredEDIERASetup/AddEditCredApp | ResponseModel | EDI_ERA_Setup cred_App_ViewModel | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:32 |
| GET | api/CredEDIERASetup/GetCredEDIERASetupById | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:37 |
| POST | api/CredEDIERASetup/AddEditCred_EDIERA_Note | ResponseModel | EDI_ERA_Notes eDI_ERA_Notes | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:42 |
| POST | api/CredEDIERASetup/SearchCredEDIERASetup | ResponseModel | EdiEraSetupSearchViewModel searchViewModel | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:47 |
| GET | api/CredEDIERASetup/GetCred_EDIERA_Notes | ResponseModel | long application_Id | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:53 |
| POST | api/CredEDIERASetup/UploadCred_EDIERA_Document | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:59 |
| GET | api/CredEDIERASetup/GetCred_EDIERA_Documents | ResponseModel | long applicationId | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:116 |
| GET | api/CredEDIERASetup/GetCred_EDIERA_DocumentById | IHttpActionResult | long docId | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:125 |
| GET | api/CredEDIERASetup/DeleteCred_EDIERA_Document | ResponseModel | long documentId | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:167 |
| POST | api/CredEDIERASetup/AddTPAName | ResponseModel | TPA_Name_List tPA_Name_List | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:175 |
| GET | api/CredEDIERASetup/GetEDIERAEFTReport | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:180 |
| GET | api/CredEDIERASetup/GetEDIERAEFTGridReport | ResponseModel | long practiceCode,long ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:185 |
| POST | api/CredEDIERASetup/AddClearingHouse | ResponseModel | Clearing_Houses clearing_Houses | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:190 |
| POST | api/CredEDIERASetup/AddSoft | ResponseModel | Practice_Software practice_Software | NPM_API_BackUp/NPMAPI/Controllers/CredEDIERASetupController.cs:195 |
| POST | api/Credentialing/AddEditCredApp | ResponseModel | Cred_App_ViewModel cred_App_ViewModel | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:45 |
| POST | api/Credentialing/AddEditCredAppNote | ResponseModel | Cred_App_Notes cred_App_Notes | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:63 |
| POST | api/Credentialing/AddEditCredPortal | ResponseModel | CredPortal_View cred_portal | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:251 |
| ANY | api/ERA/GetUserId | static long |  | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:37 |
| POST | api/ERA/ERAImport | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:50 |
| POST | api/ERA/ManualERAFileProcessing | Task<ResponseModel> | ERA_Request ERA | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:102 |
| POST | api/ERA/Import | Task<ResponseModel> | ERA_Request ERA | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:272 |
| ANY | api/ERA/Import | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:443 |
| POST | api/ERA/WeekHistoryOfERA | ResponseModel | CheckPracticeCode Search | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:469 |
| GET | api/ERA/LogException | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/ERAController.cs:478 |
| POST | api/Report/OverAllChargesDos | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:257 |
| GET | api/Report/ERAUnpostedAdjReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:301 |
| ANY | api/TicketTracker/EditTrackDetails | ResponseModel | TicketMessageDetail model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:264 |
| Service | Representative methods | File |
| --- | --- | --- |
| CredEDIERASetupService | GetLookupLists, AddEditCredEDIERASetup, GetCredEDIERASetupById, SearchCredEDIERASetup, AddEditCred_EDIERA_Notes, GetCred_EDIERA_Notes, SaveCred_EDIERA_Document, GetCred_EDIERA_Documents, GetCred_EDIERA_DocumentByDocId, DeleteCred_EDIERA_Document, AddTPAName, AddClearingHouse, AddSoft, GetEDIERAEFTReport, GetEDIERAEFTGridReport | NPM_API_BackUp/NPMAPI/Services/CredEDIERASetupService.cs |
| EligibilityService | DoInquiryByX12Data, DoInquiry, GetEligibilityModel | NPM_API_BackUp/NPMAPI/Services/EligibilityService.cs |
| ERAImportService | GetUserId, SaveManualERAFile, Manual_Era_User_Request, ManualERADownloadDumpProcess, Era_User_Request, ERA_Download_and_Dump_Process, SearchWeeklyHistory | NPM_API_BackUp/NPMAPI/Services/ERAImportService.cs |
| FTPService | upload | NPM_API_BackUp/NPMAPI/Services/FTPService.cs |
| GenerateBatch276Service | GenerateSerialNumber, GenerateSerialNumberISA, GenerateSerialNumberBHTGS, SequanceNumber, SequanceNumberISA, SequanceNumberBHT, GenerateBatch_276277, getSpResult, GetClaimsData, AddUpdateBatch, UploadBatches, SingleCSIClaimBatchUpload, UploadFileToFTP, GetBatchFilePath, RegenerateBatchCSIFile, AddUpdateClaimBatchError, InsertMultipleClaimsIntoCSIRequestsData | NPM_API_BackUp/NPMAPI/Services/GenerateBatch276Service.cs |
**Database model/table candidates:** AdvEligibilityReqRe, AppointmentViewModel, CreateManualERARequest, CredEDIERALookupLists, Credit_BR_Response, CustomEdit, CustomEdit_Mapping, CustomEditsError, CustomEditsErrors_jinnah, CustomEdits_Columns, CustomEdits_FrontEnd, CustomEdits_Test, Custom_Edits, DemoERADBModel, DoInquiryByX12DataModel, EDIERANotesViewModel, EDI_ERA_Doc_Type, EDI_ERA_Documents, EDI_ERA_EFT_Grid_Report, EDI_ERA_EFT_Report, EDI_ERA_Notes, EDI_ERA_Obj_Types, EDI_ERA_Setup, EDI_ERA_Statuses, ERACHECKDETAIL, ERACHECKDETAIL_bkp20232607, ERASUMMARY, ERASUMMARY_EDI, ERASearchRequestModel, ERA_ADJUSTMENT_MAPPING_BKP_012721, ERA_Adjustment_Mapping, ERA_PLB_CODE, ERA_Request, EdiEraSetupSearchViewModel, Edits_jinnah, EraDbModel, EraSummaryRequest, Era_Summary_Impt, Get_CustomEdits_Colums, Hierarchy, MEDICINE, MEDICINE_FORMULATION, Manual_ERA_Files, Medigap_Insurances, Operating_Test, PayerMappedInsuranceSearch_Result, PutCustomEdits_values, PutCustomEdits_values_Array, RegenerateBatchCSIFileModel, RegenerateBatchFileRequestModel, Registeration, SPAppChkEligibility_Result, SP_ERAADJCODEGLOSSARY_Result, SP_ERAADJCODEGLOSSARY_VIEW_EDI_Result, SP_ERACHECKDETAIL_Result, SP_ERASEARCH_MAN_IMP_Result, SP_ERASEARCH_Result, SP_GetBatchDetail_EDI_Result, SP_InsPayerWithoutModifierAndProcedure_Result, SP_InsStateWithoutModifierAndProcedure_Result, SP_SearchCredEdiEraApp_Result, Sp_GetCSIBatchStatusMedicare_Result, TESTEDIT_03, USP_NPM_CREDIT_BALANCE_Result, User_era_request, ViewERASummaryRequest, coverage_topic_lookup, edit, editassignedaccountModel, era, era_adjustment, eracheckdetail_EDI, include_in_edi, lcd_x_coverage_topic, sp_get999Report_EDI_Result, sp_getBatchHistory_EDI_Result

**Stored procedure/function references:** Check_if_the_Maximum_Retry_Count_has_been_Reached_AND_ALSO_SMTP, ERA_ADJUSTMENT_MAPPING_BKP_012721, ERA_Adjustment_Mapping, ERA_AppDate, ERA_Download_and_Dump_Process, ERA_EffDate, ERA_NextFollowUp, ERA_PLB_CODE, ERA_Request, ERA_Status, Get_Current_Request, Get_Current_Request_which_is_Inserted, Get_CustomEdits_Colums, Get_Mail_stats, Get_StatOfRequest_AND_Maintain_LOGS_If_no_new_Files_Found, Get_StatsRequest_AND_Maintain_STATS, Get_UserERARequest, SP_ERAADJCODEGLOSSARY_Result, SP_ERAADJCODEGLOSSARY_VIEW_EDI_Result, SP_ERACHECKDETAIL, SP_ERACHECKDETAIL_Result, SP_ERASEARCH_MAN_IMP_Result, SP_Manual_ERS_MigrateDataToLiveServer, SP_MigrateDataToLiveServer, SP_MigrateStats, SP_MigrateStats_same_prac, SP_SearchCredEdiEraApp, SP_SearchCredEdiEraApp_Result, USP_GET_EDI_ERA_EFT_Grid_Report, USP_Get_EDI_ERA_EFT_Status_Report, USP_NPM_CREDIT_BALANCE, USP_NPM_CREDIT_BALANCE_Result


## Import Wizard and Sync Workers

Business purpose: Import Wizard and Sync Workers supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Component | Selector | Folder |
| --- | --- | --- |
| ImportWizardMainComponent | app-import-wizard-main | NPM_UI_BackUp/src/app/import-wizard/import-wizard-main |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| POST | api/ImportWizard/ExcelImport | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:35 |
| GET | api/ImportWizard/DownloadImportWizardTemplateFile | HttpResponseMessage |  | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:106 |
| GET | api/ImportWizard/GetImportWizard | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:140 |
| GET | api/ImportWizard/IssueExcelExport | ResponseModel | long imprtbatchid , long practicecode | NPM_API_BackUp/NPMAPI/Controllers/ImportWizardController.cs:146 |
| POST | api/InboxHealth/Webhook | Task<IHttpActionResult> |  | NPM_API_BackUp/NPMAPI/Controllers/InboxHealthController.cs:24 |
| Service | Representative methods | File |
| --- | --- | --- |
| DeltaSyncService | GetSyncedPractice, GetSyncedclaim, UpdateClaim, CreateClaimCharge, UpdateClaimCharge, deleteClaimCharge, UpdateClaimPayment, UpdatePatient, UpdatePractice, UpdatePracticeLocation, UpdateProvider, GetPyments_Invoice, DeletePayments, DeleteInvoice | NPM_API_BackUp/NPMAPI/Services/DeltaSyncService.cs |
| ImportWizardService | BulkInsertImportPatient, GetImportWizard, IssueExcelExport | NPM_API_BackUp/NPMAPI/Services/ImportWizardService.cs |
| InboxHealthAPI | Put, Create, Get, Delete | NPM_API_BackUp/NPMAPI/Services/InboxHealthAPI.cs |
| InboxHealthService | onPatientPaymentProcessed | NPM_API_BackUp/NPMAPI/Services/InboxHealthService.cs |
**Database model/table candidates:** BaseResponse, EPSDTWORKERINFO, InboxHealthEvent, InboxHealthEventBaseEntity, USP_Get_ImportWizard_Log_Result, workerservice

**Stored procedure/function references:** USP_GetIssues_Excel_Export, USP_Get_ImportWizard_Log, USP_Get_ImportWizard_Log_Result, USP_Import_Wizard


## Insurance Setup

Business purpose: Insurance Setup supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
| InsuranceSetup |  | ./setups/setups.module#SetupsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| insurance-detail-report | InsuranceDetailReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| esha-plan-aging | EshaPlanAgingReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
|  | MainInsuranceSetupComponent | insGroup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| insGroup | InsuranceSetupGroupComponent | insGroup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| detail/:id | InsGroupSetupDetailsComponent | insName | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| insName | InsuranceSetupNameComponent | insName | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| insPayer | InsuranceSetupPayerComponent | insPayer | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| detail/:id | InsSetupPayerDetailComponent | insSetup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| insSetup | InsuranceSetupComponent | insSetup | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| EshaPlanAgingReportComponent | app-esha-plan-aging-report | NPM_UI_BackUp/src/app/reports/esha-plan-aging-report |
| InsuranceDetailReportComponent | app-insurance-detail-report | NPM_UI_BackUp/src/app/reports/Insurance-Detail-Report/insurance-detail-report |
| InsSetupDetailComponent | app-ins-setup-detail | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/ins-setup-detail |
| InsuranceSetupComponent | app-insurance-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup |
| ListInsSetupComponent | app-list-ins-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup/list-ins-setup |
| InsGroupSetupDetailsComponent | app-ins-group-setup-details | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/ins-group-setup-details |
| InsuranceSetupGroupComponent | app-insurance-setup-group | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group |
| ListInsGroupSetupComponent | app-list-ins-group-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-group/list-ins-group-setup |
| InsNameSetupDetailsComponent | app-ins-name-setup-details | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/ins-name-setup-details |
| InsuranceSetupNameComponent | app-insurance-setup-name | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name |
| ListInsNameSetupComponent | app-list-ins-name-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-name/list-ins-name-setup |
| InsSetupPayerDetailComponent | app-ins-setup-payer-detail | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/ins-setup-payer-detail |
| InsuranceSetupPayerComponent | app-insurance-setup-payer | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer |
| ListInsSetupPayerComponent | app-list-ins-setup-payer | NPM_UI_BackUp/src/app/setups/InsuranceSetup/insurance-setup-payer/list-ins-setup-payer |
| MainInsuranceSetupComponent | app-main-insurance-setup | NPM_UI_BackUp/src/app/setups/InsuranceSetup |
| InsuranceSearchComponent | insurance-search | NPM_UI_BackUp/src/app/shared/insurance-search |
| PracTabInsuranceSearchComponent | prac-tab-insurance-search | NPM_UI_BackUp/src/app/shared/prac-tab-insurance-search copy |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| ANY | api/InsuranceSetup/GetInsuranceGroupList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:20 |
| ANY | api/InsuranceSetup/GetInsuranceGroup | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:24 |
| POST | api/InsuranceSetup/SaveInsuranceGroup | ResponseModel | [FromBody] Insurance_Groups model | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:29 |
| GET | api/InsuranceSetup/DeleteInsuranceGroup | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:41 |
| GET | api/InsuranceSetup/GetInsuranceGroupsSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:46 |
| GET | api/InsuranceSetup/GetSmartInsuranceGroupsSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:51 |
| ANY | api/InsuranceSetup/GetInsuranceNameList | ResponseModel | long InsuranceGroupId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:65 |
| ANY | api/InsuranceSetup/GetInsuranceName | ResponseModel | long InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:69 |
| GET | api/InsuranceSetup/GetInsuranceNameModel | ResponseModel | long? InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:74 |
| GET | api/InsuranceSetup/GetInsuranceNameSelectList | ResponseModel | long? InsuranceGroupId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:79 |
| GET | api/InsuranceSetup/GetSmartInsuranceNameList | ResponseModel | long? InsuranceGroupId, string searchText | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:84 |
| POST | api/InsuranceSetup/SaveInsuranceName | ResponseModel | [FromBody] InsuranceNameModelViewModel model | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:89 |
| GET | api/InsuranceSetup/DeleteInsuranceName | ResponseModel | long InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:101 |
| GET | api/InsuranceSetup/GetInsurancePayerList | ResponseModel | long InsuranceGroupId, long InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:110 |
| GET | api/InsuranceSetup/GetInsurancePayer | ResponseModel | long InsurancePayerId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:115 |
| GET | api/InsuranceSetup/GetInsurancePayerModel | ResponseModel | long? InsurancePayerId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:120 |
| POST | api/InsuranceSetup/SaveInsurancePayer | ResponseModel | [FromBody] InsurancePayerViewModel model | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:125 |
| GET | api/InsuranceSetup/DeleteInsurancePayer | ResponseModel | long InsurancePayerId, long InsuranceNameId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:137 |
| GET | api/InsuranceSetup/GetSmartInsurancePayersList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:142 |
| GET | api/InsuranceSetup/GetInsPayerList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:157 |
| GET | api/InsuranceSetup/GetInsPayerById | ResponseModel | string InsurancePayerId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:162 |
| GET | api/InsuranceSetup/GetInsPayerByState | ResponseModel | string InsurancePayerState | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:167 |
| ANY | api/InsuranceSetup/GetInsuranceList | ResponseModel | long? GroupId, string insuranceName, string insurancePayerName | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:171 |
| GET | api/InsuranceSetup/GetInsurance | ResponseModel | long InsuranceId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:179 |
| GET | api/InsuranceSetup/GetInsuranceModel | ResponseModel | long? InsuranceId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:184 |
| POST | api/InsuranceSetup/SaveInsurance | ResponseModel | [FromBody] Insurance model | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:189 |
| GET | api/InsuranceSetup/DeleteInsurance | ResponseModel | long InsuranceId, long InsurancePayerId | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:201 |
| GET | api/InsuranceSetup/GetRelationsSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:206 |
| POST | api/InsuranceSetup/AddInsurance | ResponseModel | [FromBody] AddInsuranceRequest addInsuranceRequest | NPM_API_BackUp/NPMAPI/Controllers/InsuranceSetupController.cs:215 |
| GET | api/Report/GetInsuranceDetailReport | ResponseModel | long? PracCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:162 |
| GET | api/Report/GetInsuranceDetailReportPagination | ResponseModel | long? PracCode,int page,int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:168 |
| ANY | api/Report/GetPlanAgingReportDetails | ResponseModel | long? PracticeCode, int Page, int Count, bool perPageRecord | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:245 |
| Service | Representative methods | File |
| --- | --- | --- |
| InsuranceSetupService | DeleteInsuranceGroup, GetInsuranceGroup, GetInsuranceGroupList, SaveInsuranceGroup, GetInsuranceGroupsSelectList, GetSmartInsuranceGroupsSelectList, DeleteInsuranceName, GetInsuranceName, GetInsuranceNameModel, GetInsuranceNameSelectList, GetSmartInsuranceNameList, GetInsuranceNameList, SaveInsuranceName, GetInsurancePayerList, GetInsPayerById, GetInsPayerByState, GetInsurancePayer, GetInsurancePayerModel | NPM_API_BackUp/NPMAPI/Services/InsuranceSetupService.cs |
**Database model/table candidates:** AddInsuranceRequest, Aging_Summary_Top_5_Payers_Result, Aging_Summary_report_Top_5_Payers_Result, Cptplan_MD, DIAGNOSIS_PAYER, Fee_Plan_Update, Functional_Group_Rejection_Response, GetInsuranceNamesByGroup_Result, GetInsurancePayersByInsPayerId_Result, GetInsurancePayersByInsPayerState_Result, GetInsurancePayersByName_Result, GetInsurancesByPayers_Result, HIPAA_278_PAYER_INFORMATION, INSURANCE_FILING_LIMIT, INSURANCE_PAYERS_PLAN, Insurance, InsuranceDetailReportResponse, InsuranceModel, InsuranceNameViewModel, InsurancePayerVM, InsurancePayerViewModel, InsuranceSearchViewModel, Insurance_Denials, Insurance_Departments, Insurance_Groups, Insurance_Names, Insurance_Notes, Insurance_Payers, Insurance_Payers_07092023, Insurance_Payers_Bkp_08232020, Insurance_Payers_Plan_Group, Insurance_Phone_Directory, Insurance_filing_limit2, Insurance_payers_formats, InsurancesByPayersViewModel, Insurances_Bkp_08232020, Insurancesbkp_07092023, MIS_TBL_Insurance_Resources_Remarks, PAYER, PayerPortal_Notes, PayerWise_Analysis_by_Report_Result, Payer_Notes, Plan_Aging_Response, Plan_setup, Procedures_Payer, PtientInsurance_06082023, PtientInsurance_06092023, SP_GetInsuranceInfo_Result, SP_InsPayer_Result, SP_InsStatePlan_Result, SP_InsuranceSearch_BK_11082018_Result, SP_InsuranceSearch_Result, SP_getcptplanlist_Result, SP_getpraticedataforCPTPlan_Result, Specialty_Groups, USP_NPM_PLAN_AGING_Result, USP_Search_Insurances_Result, User_Group, ValidateInsGroupDeletion_Result, check_CPtPlan_Result, default_group_IDs, insurance_role_engine, insurancelist, insurances_11252021, lcd_x_hcpc_code_group, lcd_x_icd9_support_group, payer_not_450, sp_insuranceardetailreport_Result

**Stored procedure/function references:** Aging_Payer, Aging_Payer_Type, Aging_Summary_Top_5_Payers, Aging_Summary_Top_5_Payers_Result, Aging_Summary_report_Top_5_Payers, Aging_Summary_report_Top_5_Payers_Result, MIS_TBL_Insurance_Resources_Remarks, SP_InsuranceSearch_AfzalBahi, SP_InsuranceSearch_BK_11082018, SP_InsuranceSearch_BK_11082018_Result, SP_InsuranceSearch_N, SP_getcptplanlist, SP_getcptplanlist_Result, SP_getpraticedataforCPTPlan, SP_getpraticedataforCPTPlan_Result, UPDATE_TYPE, USP_NPM_PLAN_AGING, USP_NPM_PLAN_AGING_Result, USP_Search_Insurances, USP_Search_Insurances_Result, sp_GetInsuranceAging_Ubaid, sp_insuranceardetailreport, sp_insuranceardetailreport_Result


## Patient Demographics

Business purpose: Patient Demographics supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
| ticketresponse | TicketResponseComponent | ./patient/patient.module#PatientModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| patient |  | ./patient/patient.module#PatientModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| guarantors |  | ./setups/guarantors/guarantors.module#GuarantorsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| Patient/Demographics |  | ./Claims/claims.module#ClaimsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| referral-physician |  | ./setups/referral-physician/referral-physician.module#ReferralPhysiciansModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| patientStatement | PatientStatementComponent |  | NPM_UI_BackUp/src/app/claim-submission/claim-submission-routing-module.module.ts |
| :param | PatientComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| Detail/:param | PatientComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| New/:param | PatientComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| Edit/:param | PatientComponent |  | NPM_UI_BackUp/src/app/Claims/claims-routing.module.ts |
| PatientSearch | PatientSearchComponent |  | NPM_UI_BackUp/src/app/patient/patient-routing.module.ts |
| AgingSummaryPat | AgingSummaryPatientWiseComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| patient-birth-days | PatientBirthDays |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| patient-statement-report | PatientStatementReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| patient-aging-report | PatientAgingReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| patient-aging-analysis-report | PatientAgingAnalysisComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| esha-patient-aging | EshaPatientAgingReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
|  | GuarantorsListComponent |  | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-routing.module.ts |
| add | GuarantorsAddEditComponent |  | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-routing.module.ts |
| edit/:id | GuarantorsAddEditComponent |  | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-routing.module.ts |
|  | ReferralPhysicianComponent |  | NPM_UI_BackUp/src/app/setups/referral-physician/referral-physician-routing.module.ts |
| :id/:type | AddEditReferralPhysicianComponent |  | NPM_UI_BackUp/src/app/setups/referral-physician/referral-physician-routing.module.ts |
| guarantor | GuarantorComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| ClaimRejectionComponent | app-claim-rejection | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/claim-rejection |
| PatientStatementComponent | app-patient-statement | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/patient-statement |
| PatientStatementClaimsComponent | app-patient-statement-claims | NPM_UI_BackUp/src/app/claim-submission/patient-statement-main/patient-statement-claims |
| AccountassignmentComponent | app-accountassignment | NPM_UI_BackUp/src/app/patient/accountassignment |
| AppoinmentsComponent | app-appoinments | NPM_UI_BackUp/src/app/patient/appoinments |
| ClaimSummaryComponent | app-claim-summary | NPM_UI_BackUp/src/app/patient/ClaimSummary |
| MainComponent | app-main | NPM_UI_BackUp/src/app/patient/Main |
| NotesComponent | app-notes | NPM_UI_BackUp/src/app/patient/Patient/Notes |
| PatientNotesComponent | patient-notes | NPM_UI_BackUp/src/app/patient/Patient/patient-notes |
| PatientComponent | app-patient | NPM_UI_BackUp/src/app/patient |
| ReferralComponent | app-referral | NPM_UI_BackUp/src/app/patient/Referrals |
| PatientSearchComponent | app-patient-search | NPM_UI_BackUp/src/app/patient/search |
| AgingSummaryPatientWiseComponent | app-aging-summary-patient-wise | NPM_UI_BackUp/src/app/reports/aging-summary-patient-wise |
| EshaPatientAgingReportComponent | app-esha-patient-aging-report | NPM_UI_BackUp/src/app/reports/esha-patient-aging-report |
| PatientAgingAnalysisComponent | app-patient-aging-analysis | NPM_UI_BackUp/src/app/reports/patient-aging-analysis |
| PatientAgingReportComponent | app-patient-aging-report | NPM_UI_BackUp/src/app/reports/patient-aging-report |
| PatientBirthDays | patient-birth-days-report | NPM_UI_BackUp/src/app/reports/patient-birth-days |
| PatientStatementReportComponent | app-patient-statement-report | NPM_UI_BackUp/src/app/reports/patient-statement-report |
| GuarantorComponent | app-guarantor | NPM_UI_BackUp/src/app/setups/Guarantor |
| GuarantorsAddEditComponent | app-guarantors-add-edit | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-add-edit |
| GuarantorsListComponent | app-guarantors-list | NPM_UI_BackUp/src/app/setups/guarantors/guarantors-list |
| zipdata | app-add-edit-referral-physician | NPM_UI_BackUp/src/app/setups/referral-physician/add-edit-referral-physician |
| ReferralPhysicianComponent | app-referral-physician | NPM_UI_BackUp/src/app/setups/referral-physician |
| ZipData | app-add-edit-guarantor-shared | NPM_UI_BackUp/src/app/shared/guarantors/add-edit-guarantor-shared |
| ListGuarantorsSharedComponent | app-list-guarantors-shared | NPM_UI_BackUp/src/app/shared/guarantors/list-guarantors-shared |
| PatientAttachmentsComponent | patient-attachments | NPM_UI_BackUp/src/app/shared/patient-attachments |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| ANY | api/Demographic/GetPatientList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:37 |
| ANY | api/Demographic/GetstateList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:42 |
| POST | api/Demographic/SearchPatient | ResponseModel | [FromBody] PatientSearchModel SearchModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:49 |
| POST | api/Demographic/IsPatientAlreadyExist | ResponseModel | DublicatePatientCheckModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:54 |
| GET | api/Demographic/checkDuplicateDOS | ResponseModel | long patientAccount, DateTime dos | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:65 |
| GET | api/Demographic/GetPatientModel | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:71 |
| GET | api/Demographic/GetPatient | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:76 |
| GET | api/Demographic/DeletePatient | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:81 |
| ANY | api/Demographic/GetFinancialGurantor | ResponseModel | string Name | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:85 |
| ANY | api/Demographic/GetFinancialGurantorSubscriber | ResponseModel | string Name | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:89 |
| ANY | api/Demographic/GetCityState | ResponseModel | string ZipCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:93 |
| POST | api/Demographic/AddEditPatient | ResponseModel | [FromBody] PatientCreateViewModel PatientModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:98 |
| POST | api/Demographic/SearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:154 |
| POST | api/Demographic/SavePatientInsurance | ResponseModel | [FromBody] Patient_Insurance Model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:159 |
| GET | api/Demographic/DeletePatientInsurance | ResponseModel | long PatientAccount, long PatientInsuranceId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:171 |
| ANY | api/Demographic/GetPatientNotes | ResponseModel | long PatientAccount, int? number | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:175 |
| ANY | api/Demographic/GetPatientNote | ResponseModel | long PatientNotesId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:179 |
| POST | api/Demographic/SavePatientNotes | ResponseModel | [FromBody] Patient_Notes PatientNote | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:184 |
| ANY | api/Demographic/DeletePatientNote | ResponseModel | long PatientAccount, long PatientNotesId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:197 |
| POST | api/Demographic/SaveClaimAttachmentNotes | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:203 |
| POST | api/Demographic/DeleteClaimAttachmentNote | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:218 |
| POST | api/Demographic/UploadImage | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:226 |
| GET | api/Demographic/GetImage | ResponseModel | long PatientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:246 |
| ANY | api/Demographic/GetAppointments | ResponseModel | long PatientAccount = 0 | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:259 |
| ANY | api/Demographic/GetClaimModel | ResponseModel | long PatientAccount, long ClaimNo = 0 | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:263 |
| ANY | api/Demographic/GetAdmissionType | ResponseModel | long PatientAccount, string ClaimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:267 |
| POST | api/Demographic/SaveClaim | Task<ResponseModel> | ClaimsViewModel ClaimModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:272 |
| ANY | api/Demographic/GetPatientClaims | ResponseModel | long ClaimNo = 0 | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:307 |
| ANY | api/Demographic/DeleteClaim | ResponseModel | long ClaimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:311 |
| ANY | api/Demographic/GetClaimNotes | ResponseModel | long ClaimNo, int? number | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:315 |
| ANY | api/Demographic/GetClaimNote | ResponseModel | long ClaimNotesId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:319 |
| GET | api/Demographic/GetServiceTypeCodesDescription | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:324 |
| GET | api/Demographic/GetModifiers | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:331 |
| POST | api/Demographic/SaveClaimNotes | ResponseModel | [FromBody] CLAIM_NOTES ClaimNote | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:336 |
| ANY | api/Demographic/DeleteClaimNote | ResponseModel | long PatientAccount, long PatientNotesId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:348 |
| ANY | api/Demographic/SearchFacilities | ResponseModel | [FromBody] FacilitySearchModel FacilityModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:361 |
| GET | api/Demographic/GetDiagnosis | ResponseModel | string DiagCode, string DiagDesc, long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:366 |
| ANY | api/Demographic/SavePatientClaimDiagnose | ResponseModel | string DiagCode, long ClaimNo, bool IsEdit, int Sequence | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:386 |
| ANY | api/Demographic/GetPatientClaimsSummary | ResponseModel | long PatientAccount = 0, bool IncludeDeleted = false, bool isAmountDueGreaterThanZero = false | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:397 |
| POST | api/Demographic/GetProcedureCharges | ResponseModel | [FromBody] CPTWiseCharges obj | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:402 |
| POST | api/Demographic/ValidateAddress | ResponseModel | [FromBody] ValidateAddreesRequestViewModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:407 |
| GET | api/Demographic/GetPatientSelectList | ResponseModel | string searchText, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:429 |
| GET | api/Demographic/GetInsuranceSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:434 |
| GET | api/Demographic/GetPatientSummary | ResponseModel | long patientAccount, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:461 |
| GET | api/Demographic/GetClaimSummaryByNo | ResponseModel | long claimNo, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:466 |
| GET | api/Demographic/GetPatientClaimsForStatement | ResponseModel | long patientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:471 |
| POST | api/Demographic/GeneratePatientStatement | ResponseModel | PatientStatementRequest model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:476 |
| POST | api/Demographic/GeneratePatientStatementdn | ResponseModel | PatientStatementRequest model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:487 |
| ANY | api/Demographic/GenItemizedPatientStatement | ResponseModel | Patient_Statement_Itemized model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:502 |
| GET | api/Demographic/GetStatementPatient | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:514 |
| GET | api/Demographic/GetCitiesByZipCode | ResponseModel | string zipCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:520 |
| GET | api/Demographic/GetPAByAccount | ResponseModel | long aCCOUNT_NO | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:527 |
| GET | api/Demographic/GetClaimAndDos | ResponseModel | long patientAcc | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:534 |
| GET | api/Demographic/CheckCollectionStatus | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:540 |
| GET | api/Demographic/getClaimDetails | ResponseModel | long Claim_no | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:547 |
| POST | api/Demographic/AddOrUpdatePanelCPTCodes | ResponseModel | PanelCPTCodeList panelCPTCodeList | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:555 |
| GET | api/Demographic/getPanelCodeCpt | ResponseModel | long PracticeCode, long ProviderCode, long LocationCode, string cptCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:561 |
| GET | api/Demographic/getPanelCodeCptClaim | ResponseModel | long PracticeCode, long ProviderCode, long LocationCode, string PanelCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:567 |
| GET | api/Demographic/IsAlternateCodeRemoved | ResponseModel | string Cpt_Code, string Cpt_Description, string AlernateCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:576 |
| GET | api/Demographic/GetPanelAlternateCode | ResponseModel | long PracticeCode, long ProviderCode, long LocationCode, string AlternateCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:583 |
| GET | api/Demographic/CheckPanelCodeExists | ResponseModel | long PracticeCode, long ProviderCode, long LocationCode, string PanelCode, long panelBillingCodeId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:589 |
| POST | api/Demographic/deleteRows | ResponseModel | long[] rowIds | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:599 |
| GET | api/Demographic/GetPanelCodeDetailsForEdits | ResponseModel | long panelBillingCodeId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:605 |
| GET | api/Demographic/PanelCodeStatus | ResponseModel | int panelBillingCodeId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:611 |
| ANY | api/Demographic/ShowPacket277CAClaimReason | ResponseModel | string claimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:622 |
| POST | api/Demographic/AddClaimOverPayment | Task<ResponseModel> | ClaimOverpayment claimOverpayment | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:692 |
| GET | api/Demographic/GetClaimOverPayment | Task<ResponseModel> | long claimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:714 |
| GET | api/Demographic/GetStateDropDownList | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:722 |
| GET | api/Demographic/GetClaimsWithPatientDue | ResponseModel | long practicecode, long patientaccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:738 |
| POST | api/Demographic/InsertOrUpdateClaimPayments | ResponseModel | List<Claim_Payments> paymentList | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:743 |
| POST | api/Demographic/SaveUnappliedAmount | ResponseModel | UnappliedPaymentViewModel unappliedPayment | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:748 |
| GET | api/Demographic/GetUnappliedPaymentsByBatchNo | ResponseModel | string batchNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:753 |
| POST | api/Demographic/GetBillingPhysiciansList | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:759 |
| POST | api/Demographic/DeleteUnappliedPayment | ResponseModel | long unappliedPaymentId | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:767 |
| GET | api/Demographic/GetUnappliedAmountByPatient | ResponseModel | long patientAccount | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:773 |
| GET | api/Demographic/GetClaimsDetailsByPatient | ResponseModel | long Patient_Account | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:778 |
| GET | api/Demographic/GetBatchDetailsByPatient | ResponseModel | long Patient_Account | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:783 |
| GET | api/Demographic/SearchReferringPhysicians | ResponseModel | string firstName, string lastName, string npi, string zip, string city, string state | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:790 |
| ANY | api/Demographic/SaveClaimModel | ResponseModel | ClaimsViewModel ClaimModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:798 |
| ANY | api/Demographic/GetClaimInsurance | ResponseModel | long claimNo | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:803 |
| GET | api/ItemizedPatientStatment/GenerateItemizedPsForPrint | HttpResponseMessage | long patientAccount, long practiceCode, string messageToPrint | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:21 |
| POST | api/ItemizedPatientStatment/GenerateItemizedPsForDownload | HttpResponseMessage | StatmentDownloadRequestModel model | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:51 |
| GET | api/ItemizedPatientStatment/GeneraterollingForDownload | HttpResponseMessage | string prac_code , string duration | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:81 |
| GET | api/ItemizedPatientStatment/GetAllMessages | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:114 |
| POST | api/ItemizedPatientStatment/AddMessage | ResponseModel | PatientStatementMessages Model | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:121 |
| POST | api/ItemizedPatientStatment/EditMessage | ResponseModel | PatientStatementMessages Model | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:129 |
| GET | api/ItemizedPatientStatment/DeleteMessage | ResponseModel | long MessageID | NPM_API_BackUp/NPMAPI/Controllers/ItemizedPatientStatmentController.cs:136 |
| POST | api/PatientAttachments/Attach | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:29 |
| GET | api/PatientAttachments/Delete | IHttpActionResult | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:83 |
| GET | api/PatientAttachments/GetAll | IHttpActionResult | long patientAccount | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:89 |
| GET | api/PatientAttachments/ClaimDelete | IHttpActionResult | long id,long Document_ID | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:94 |
| GET | api/PatientAttachments/GetAttachmentCodeList | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:100 |
| GET | api/PatientAttachments/Download | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:105 |
| ANY | api/PatientAttachments/TicketAttach | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:135 |
| POST | api/PatientAttachments/UploadFiles | Task<IHttpActionResult> |  | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:190 |
| GET | api/PatientAttachments/DeleteTicketAttachment | IHttpActionResult | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:270 |
| GET | api/PatientAttachments/DownloadTicketAttachment | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:276 |
| GET | api/PatientAttachments/DownloadStatementPdf | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PatientAttachmentsController.cs:306 |
| POST | api/Payments/AddPatientPayment | ResponseModel | [FromBody] PatientPayment request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:42 |
| POST | api/Payments/GetClaimBypatient | ResponseModel | patientBasedClaimModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:68 |
| GET | api/Payments/GetPatientsWithDue | ResponseModel | bool isDueOnly, int practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:146 |
| GET | api/Payments/GetPatientsClaims | ResponseModel | long patient_account, bool due_only | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:153 |
| POST | api/ReferralPhysicians/CreateReferralPhysician | Task<ResponseModel> | ReferralPhysicianViewModel model | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:18 |
| POST | api/ReferralPhysicians/UpdateReferralPhysician | Task<ResponseModel> | ReferralPhysicianViewModel model | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:24 |
| GET | api/ReferralPhysicians/GetReferralPhysicianByRefCode | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:30 |
| GET | api/ReferralPhysicians/GetReferralPhysicians | Task<ResponseModel> | int page, int count, string pattern | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:35 |
| POST | api/ReferralPhysicians/ChangeDeleteStatus | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:40 |
| POST | api/ReferralPhysicians/ChangeActiveStatus | Task<ResponseModel> | long refCode | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:45 |
| GET | api/ReferralPhysicians/GetActiveReferralPhysicians | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:50 |
| GET | api/ReferralPhysicians/GetActiveInactiveReferralPhysicians | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/ReferralPhysiciansController.cs:56 |
| GET | api/Report/AgingSummaryPatientAnalysisReport | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:48 |
| POST | api/Report/PatientBirthDays | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:139 |
| GET | api/Report/PatientAgingReport | Task<ResponseModel> | long PracticeCode, bool isExport = false, int page=1, int size = 10 | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:210 |
| GET | api/Report/PatientAgingAnalysisReport | Task<ResponseModel> | long PracticeCode, bool isExport = false, int page = 1, int size = 10 | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:215 |
| ANY | api/Report/GetPatientAgingSummaryDetails | ResponseModel | long? practiceCode, int Page, int Count, bool perPageRecord | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:241 |
| GET | api/Scheduler/CheckDeceasedPatient | ResponseModel | long PatAccount | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:466 |
| GET | api/TicketTracker/GetPatientDueAmt | ResponseModel | string patientacc, long claimno | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:21 |
| GET | api/TicketTracker/GetPatientCompleteInfo | ResponseModel | string patientacc, string ticketType | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:37 |
| GET | api/TicketTracker/GetPatientInfo | ResponseModel | string patientacc | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:85 |
| GET | api/TicketTracker/GetPatientAccounts | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:101 |
| Service | Representative methods | File |
| --- | --- | --- |
| DemographicService | SearchPatient, GetPatientList, IsPatientAlreadyExist, checkDuplicateDOS, GetPatientModel, GetPatient, DeletePatient, GetFinancialGurantor, GetFinancialGurantorSubscriber, AddEditPatient, GetAppointments, GetPatientClaimsSummary, GetPracticeClaims, GetPatientClaim, GetPatientReferrals, TestFunc, GetPatientNotes, DeletePatientInsurance | NPM_API_BackUp/NPMAPI/Services/DemographicService.cs |
| PatientAttachmentService | Delete, ClaimDelete, GetAll, Save, GetAttachmentTypeCodesList, Get, GetTicketAttachment, SaveTicketAttachment, DeleteTicketAttachment, GetPatientNote | NPM_API_BackUp/NPMAPI/Services/PatientAttachmentService.cs |
| ReferralPhysiciansService | CreateReferralPhysician, ChangeDeleteStatus, ChangeActiveStatus, GetReferralPhysician, GetActiveReferralPhysicians, GetActiveInactiveReferralPhysicians, GetReferralPhysicians, UpdateReferralPhysician | NPM_API_BackUp/NPMAPI/Services/ReferralPhysiciansService.cs |
**Database model/table candidates:** AGING_SUMMARY_PATIENT_REPORT, Aging_Summary_Analysis_Report_Patient_Result, BatchPatientClaim, DublicatePatientCheckModel, GUARANTORSRAW_1011004, GUARANTORS_MAPPING_1011004, GetPatientForStatement_Result, GetPatientWithClaimsForItemizedStatement_Result, GetPatientWithClaimsForStatement_Result, Guarantor, NEW_PATIENTLETTER_FIELDS, PATIENT_35510209, PaTIENT_BKP_01142022, Patient, PatientBirthDaysReportResponse, PatientBirthDaysResponse, PatientCreatedEventData, PatientDemographicViewModel, PatientImageModel, PatientInsuranceViewModel, PatientNoteViewModel, PatientPayment, PatientPaymentDetailResponse, PatientPaymentProcessed, PatientPaymentProcessedModel, PatientSearchModel, PatientSearchResultModel, PatientSearchViewModel, PatientStatementMessages, PatientStatementRequest, PatientUpdateRequest, Patient_ASR_Response, Patient_Attachments, Patient_Insurance, Patient_Notes, Patient_Ptl_Feedback, Patient_Statement_Messages, Patient_Statement_Messages3, Patient_Updated, Patients_Data, ReferralPhysicianViewModel, Referral_Physicians, SP_ClaimPatientSearchnew_Result, SP_Claim_patientbysearch_Result, SP_GETPATIENTBDAYS_Result, SP_GUARANTORSEARCH_Result, SP_PATIENTAPPSEARCH_Result, SP_PATIENTINSSERACH_Result, SP_PATIENTSTATEMENTCOUNT_BYCLAIM_Result, SP_PATIENTSTATEMENTCOUNT_PIRUBAID_Result, SP_PATIENTSTATEMENTCOUNT_Result, SP_PatientDueForTicketTracker_Result, SP_PatientSearch_Result, SyncedPatient, Ticket_Patient_Claims_Info, Ticket_Patient_Claims_Info_ViewModel, USP_NPM_PATIENT_AGING_Result, USP_PATIENT_AGING_REPORT_NPM_Result, USP_Patient_Wise_Aging_Summary_Report_NPM_Result, patient_bkp11282018, patient_bkp_11282018, patient_statement_itemized_tets, patient_statement_itemized_tets_, patient_statement_itemized_tets_bkp, uspGetPatientAttachments_Result

**Stored procedure/function references:** Aging_Summary_Analysis_Report_Patient, Aging_Summary_Analysis_Report_Patient_Result, Claim_Charges, Claim_Document, Claim_Due, Claim_Insurance, Claim_Insurance_Id, Claim_Notes_Id, Claim_Number, Claim_Overpayment, Claim_Reasons, Claim_Rsn, Claim_Status, Claim_Status_Category_Code, Claim_Status_Code, Claim_Status_Date, Claim_Total, Claim_Type, Claim_no, Financial_Guarantor, Financial_Guarantor_Name, SP_277CA_LinkingMessage, SP_CLAIMSUMMARYAMOUNTS, SP_CLAIMSUMMARYAMOUNTS_Hamza, SP_ClaimPatientSearchnew, SP_ClaimPatientSearchnew_Result, SP_Claim_patientbysearch, SP_Claim_patientbysearch_Result, SP_FacilitiesSearch, SP_FacilitiesSearch_Result, SP_GENERATEPATIENTSTATEMENT, SP_GENERATEPATIENTSTATEMENT_XML, SP_GENERATEPATIENTSTATEMENT_bkp_091619, SP_GETPATIENTBDAYS, SP_GETPATIENTBDAYS_Result, SP_GUARANTORSEARCH, SP_GUARANTORSEARCH_Result, SP_GetClaimsListByDOS, SP_GetClaimsListByDOS_Result, SP_InsuranceSearch, SP_InsuranceSearch_Result, SP_PATIENTAPPSEARCH, SP_PATIENTAPPSEARCH_Result, SP_PATIENTINSSERACH, SP_PATIENTINSSERACH_Result, SP_PATIENTSEARCHDUP, SP_PATIENTSTATEMENTCOUNT, SP_PATIENTSTATEMENTCOUNT_BYCLAIM, SP_PATIENTSTATEMENTCOUNT_BYCLAIM_Result, SP_PATIENTSTATEMENTCOUNT_PIRUBAID_Result, SP_PATIENTSTATEMENTCOUNT_Result, SP_PatientDueForTicketTracker, SP_PatientDueForTicketTracker_Result, SP_PatientSearch, SP_PatientSearchNew, SP_PatientSearch_Result, SP_PatientSearch_bkp12262018, SP_showEDIHistory, SP_showEDIHistory_bkp2, USP_GetPatientsWithDue, USP_NPM_PATIENT_AGING, USP_NPM_PATIENT_AGING_Result, USP_PATIENT_AGING_REPORT_NPM, USP_PATIENT_AGING_REPORT_NPM_Result, USP_Patient_Wise_Aging_Summary_Report_NPM, USP_Patient_Wise_Aging_Summary_Report_NPM_Result, USP_Search_ReferringPhysicians, sp_GetPatientAging_Ubaid, sp_result


## Payments and Deposit Slip

Business purpose: Payments and Deposit Slip supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
| DepositSlip |  | ./deposite-slip/deposite-slip.module#DepositeSlipModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| payment |  | ./payment/payment.module#PaymentModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
|  | DespositSlipComponent |  | NPM_UI_BackUp/src/app/deposite-slip/depositeSlipRouting.module.ts |
| payments | PaymentsComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| monthly | OverallPaymentsByMonth |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| daily | OverallPaymentsByDaily |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-carrier | PaymentByCarrier |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-primary-dx | PaymentByPrimaryDX |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-procedure-code | PaymentByPrimaryICD10 |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| batchpayments | BatchPaymentsComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
| BatchPaymentAdvisory | BatchPaymentAdvisoryComponent |  | NPM_UI_BackUp/src/app/era/era-routing.module.ts |
|  | PaymentSearchComponent |  | NPM_UI_BackUp/src/app/payment/payment-routing.module.ts |
| payment-detail | PaymentDetail |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| ctp-wise-payment-details | CtpWisePaymentDetailsComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| batch-payment-report | BatchPaymentReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| unapplied-payment | UnappliedPaymentReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| DespositSlipComponent | app-desposit-slip | NPM_UI_BackUp/src/app/deposite-slip |
| OverallPaymentsByDaily | overall-payments-by-daily-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/overall-payments-by-daily |
| OverallPaymentsByMonth | overall-payments-by-month-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/overall-payments-by-month |
| PaymentByCarrier | payment-by-carrier-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/payment-by-carrier |
| PaymentByPrimaryDX | payment-by-primary-dx-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/payment-by-primary-dx |
| PaymentByPrimaryICD10 | payment-by-primary-icd10-report | NPM_UI_BackUp/src/app/dynamic-reports/payments/payment-by-primary-icd10 |
| PaymentsComponent | payment-report | NPM_UI_BackUp/src/app/dynamic-reports/payments |
| BatchPaymentAdvisoryComponent | app-batch-payment-advisory | NPM_UI_BackUp/src/app/era/batch-payment-advisory |
| BatchPaymentsComponent | app-batch-payments | NPM_UI_BackUp/src/app/era/batch-payments |
| UnappliedPaymentsComponent | app-unapplied-payments | NPM_UI_BackUp/src/app/era/unapplied-payments |
| UnappliedPaymentsPostingComponent | app-unapplied-payments-posting | NPM_UI_BackUp/src/app/era/unapplied-payments-posting |
| PaymentAdvisoryComponent | app-payment-advisory | NPM_UI_BackUp/src/app/payment/payment-advisory/payment-advisory |
| PaymentPostingComponent | app-payment-posting | NPM_UI_BackUp/src/app/payment/payment-posting/payment-posting |
| PaymentSearchComponent | app-payment-search | NPM_UI_BackUp/src/app/payment/payment-search/payment-search |
| BatchPaymentReportComponent | app-batch-payment-report | NPM_UI_BackUp/src/app/reports/batch-payment-report |
| CtpWisePaymentDetailsComponent | app-ctp-wise-payment-details | NPM_UI_BackUp/src/app/reports/ctp-wise-payment-details/ctp-wise-payment-details |
| PaymentDetail | app-payment-detail | NPM_UI_BackUp/src/app/reports/payment-detail |
| UnappliedPaymentReportComponent | app-unapplied-payment-report | NPM_UI_BackUp/src/app/reports/unapplied-payment-report |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| POST | api/Payments/SearchPayment | ResponseModel | PaymentsSearchRequestModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:21 |
| POST | api/Payments/AddInsurancePayment | ResponseModel | [FromBody] InsurancePaymentViewModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:29 |
| ANY | api/Payments/GetPaymentList | List<SelectListViewModel> |  | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:54 |
| POST | api/Payments/CreateUpdateBatch | ResponseModel | [FromBody] BatchCreateModel batchData | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:120 |
| POST | api/Payments/SearchBatch | ResponseModel | BatchsSearchRequestModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:127 |
| POST | api/Payments/CloseBatch | ResponseModel | [FromBody] BatchsSearchRequestModel request | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:136 |
| POST | api/Payments/PostPayments | ResponseModel | ClaimsViewModel ClaimModel,long batchID,string batchDate | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:187 |
| GET | api/Payments/GetBatchPaymentSummary | ResponseModel | string batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:195 |
| GET | api/Payments/GetBatchType | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:202 |
| GET | api/Payments/GetBatchCheckDetail | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:209 |
| POST | api/Payments/AutoCloseEligibleBatches | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:225 |
| POST | api/Payments/ReopenBatch | ResponseModel | long BatchId | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:233 |
| GET | api/Payments/GetBatchDate | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:239 |
| GET | api/Payments/ValidateCheckNo | ResponseModel | string CheckNo, long Practice_Code, DateTime BatchOpenDate, string PaymentType, long? BatchID = null | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:246 |
| POST | api/Payments/CheckIfBatchHasPayments | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:251 |
| GET | api/Payments/GetCurrentResponsible | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:257 |
| GET | api/Payments/GetBatchPayments | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:264 |
| GET | api/Payments/GetPayments | ResponseModel | long claimId | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:270 |
| GET | api/Payments/GetBatchChequeNoAndDate | ResponseModel | long batchID | NPM_API_BackUp/NPMAPI/Controllers/PaymentsController.cs:275 |
| GET | api/Report/PaymentDetail | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, long? PatientAccount | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:66 |
| GET | api/Report/PaymentDetailPagination | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, long? PatientAccount, int page, int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:72 |
| GET | api/Report/CPTWisePaymentDetail | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:78 |
| GET | api/Report/CPTWisePaymentDetailPagination | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo, int page, int count | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:83 |
| POST | api/Report/ChargesPaymentsRecent | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:151 |
| ANY | api/Report/PaymentDailyRefresh | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:333 |
| POST | api/Report/PaymentMonthWise | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:339 |
| POST | api/Report/PaymentByCarrier | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:345 |
| POST | api/Report/PaymentPrimaryDX | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:351 |
| POST | api/Report/PaymentByPrimaryICD10 | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:357 |
| POST | api/Report/GetBatchPaymentReport | ResponseModel | BatchPaymentModel batchpayment | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:362 |
| POST | api/Report/GetUnappliedPaymentReport | ResponseModel | UnappliedPaymentReportModel unappliedpayment | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:367 |
| GET | api/UserManagementSetup/GetPostingUnappliedPaymentUsersList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:196 |
| Service | Representative methods | File |
| --- | --- | --- |
| PaymentsService | AddInsurancePayment, AddPatientPayment, GetPaymentList, SearchPayment, GetClaimsSummary, GetClaimBypatientdetials, GetClaimByinsdetials, PostClaims, getClaimsDetails, SaveClaimsDetails, checkPostedClaims, CreateUpdateBatch, SearchBatch, CloseBatch, GetPatientsWithDue, GetPatientsClaims, GetClaimDetails, GetClaimDetailsByClaimNumber | NPM_API_BackUp/NPMAPI/Services/PaymentsService.cs |
**Database model/table candidates:** BATCHPAYMENT, BatchPaymentModel, BatchPaymentResponse, Batch_WisePayments, DEPOSIT_SLIPS, DeleteInvoicepaymentsRequest, Deposit_Bank, Deposit_Bank_Detail, ERA_UNPOSTED_PAYMENTS_EDI_Result, InsurancePaymentRequestModel, InsurancePaymentViewModel, InvoicePayment, Month_end_payments_adjustments, PaymentDetailResponse, PaymentType, Payment_By_Carrier_Result, Payment_Daily_Refresh_Result, Payment_Detail_Result, Payment_detail_Proc_Response, Payment_detail_Proc_Result, Payment_detail_Proctest_Result, PaymentsSearchRequestModel, Payments_at_CPT_Level_Result, SP_AllPaymentSearch_Result, SP_PaymentCreatiaForSreach_Result, SP_PaymentSearchlistfinal_Result, SP_PaymentSearchlistnew_Result, USP_Batch_Payment_Details_Report_Result, USP_GetBatchPayments_Result, USP_Unapplied_Payment_Details_Report_Result, UnappliedPaymentReportModel, UnappliedPaymentViewModel, UnappliedReportResponse, Unapplied_Payments, deposit, deposit1, payment, uspGetAllPaymentbySearch_Result

**Stored procedure/function references:** ERA_Payment, ERA_UNPOSTED_PAYMENTS_EDI, ERA_UNPOSTED_PAYMENTS_EDI_Result, SP_AllPaymentSearch, SP_AllPaymentSearch_Result, SP_ChargesANDPaymentsTrend, SP_GETChargesPaymentsLastMonthsTets, SP_PaymentCreatiaForSreach, SP_PaymentCreatiaForSreach_Result, SP_PaymentSearchlistfinal, SP_PaymentSearchlistfinal_Result, SP_PaymentSearchlistnew, SP_PaymentSearchlistnew_Result, USP_Batch_Payment_Details_Report, USP_Batch_Payment_Details_Report_Result, USP_GetBatchPayments, USP_GetBatchPayments_Result, USP_NPM_By_Primary_DX_Payment, USP_NPM_Payment_By_Carrier, USP_NPM_Payment_By_Primary_ICD10, USP_NPM_Payment_Daily_Refresh, USP_NPM_Payment_Month_Wise, USP_Unapplied_Payment_Details_Report, USP_Unapplied_Payment_Details_Report_Result


## Practice Setup

Business purpose: Practice Setup supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
|  |  | ./practice-setup/practice-setup.module#PracticeSetupModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| Facility |  | ./setups/Facility/facility.module#facilityModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ProviderCPT | ProviderCptfeeScheduleTempComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| PracticeTAB | PracticeTABComponent |  | NPM_UI_BackUp/src/app/practice-setup/practiceSetupRouting.module.ts |
| PracticeList | PracticeListComponent |  | NPM_UI_BackUp/src/app/practice-setup/practiceSetupRouting.module.ts |
| Practice | AddEditPracticeComponent |  | NPM_UI_BackUp/src/app/practice-setup/practiceSetupRouting.module.ts |
| EditPractice/:id/:Type | PracticeTABComponent |  | NPM_UI_BackUp/src/app/practice-setup/practiceSetupRouting.module.ts |
| FinancialSummaryProvider | FinancialSummaryProviderWiseComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| practice-analysis-by-facility | PracticeAnalysisComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| practice-analysis-by-provider | PracticeAnalysisByProviderComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
|  | FacilitiesComponent |  | NPM_UI_BackUp/src/app/setups/Facility/facilityRouting.module.ts |
| Facility | FacilitiesComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| ProviderCPTFeeScheduleComponent | app-provider-cptfee-schedule | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule |
| ProviderCptfeeScheduleTempComponent | app-provider-cptfee-schedule-temp | NPM_UI_BackUp/src/app/fee-schedule/provider-cptfee-schedule-temp |
| AddEditPracticeComponent | app-add-edit-practice | NPM_UI_BackUp/src/app/practice-setup/addeditpractice |
| PracFacilitiesComponent | app-facility | NPM_UI_BackUp/src/app/practice-setup/Facilities |
| LocationsComponent | app-locations | NPM_UI_BackUp/src/app/practice-setup/Locations |
| PracticeListComponent | app-practice-list | NPM_UI_BackUp/src/app/practice-setup/practiceList |
| PracticeTABComponent | app-practice-tab | NPM_UI_BackUp/src/app/practice-setup/practiceTAB |
| ProvidersComponent | app-providers | NPM_UI_BackUp/src/app/practice-setup/providers |
| WebPortalsComponent | app-web-portals | NPM_UI_BackUp/src/app/practice-setup/web-portals |
| FinancialSummaryProviderWiseComponent | app-financial-summary-provider-wise | NPM_UI_BackUp/src/app/reports/financial-summary-provider-wise |
| PracticeAnalysisComponent | practice-analysis-report | NPM_UI_BackUp/src/app/reports/practice-analysis |
| PracticeAnalysisByProviderComponent | practice-analysis-by-provider-report | NPM_UI_BackUp/src/app/reports/practice-analysis-by-provider |
| FacilitiesComponent | app-facilities | NPM_UI_BackUp/src/app/setups/Facility |
| ChangePracticeComponent | app-change-practice | NPM_UI_BackUp/src/app/shared/change-practice |
| ProviderCptPlanNotesComponent | app-provider-cpt-plan-notes | NPM_UI_BackUp/src/app/shared/provider-cpt-plan-notes |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| GET | api/ClaimAssignment/GetAllAssignedClaimsForPractice | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:58 |
| GET | api/ClaimAssignment/GetAllAssignedAccountsForPractice | ResponseModel | long practice_code | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:112 |
| GET | api/ClaimAssignment/GetAllActivePractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:137 |
| GET | api/ClaimAssignment/GetPracticeAssignUsers | ResponseModel | long userid | NPM_API_BackUp/NPMAPI/Controllers/ClaimAssignmentController.cs:157 |
| ANY | api/Company/GetCompanyList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:20 |
| ANY | api/Company/GetCompanyRecord | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:24 |
| POST | api/Company/SaveCompany | ResponseModel | [FromBody] Company model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:30 |
| GET | api/Company/DeleteCompany | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:43 |
| GET | api/Company/GetCompaniesAndRolesSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:48 |
| ANY | api/Company/GetOfficeList | ResponseModel | long? companyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:56 |
| ANY | api/Company/GetOfficeRecord | ResponseModel | long OfficeId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:60 |
| POST | api/Company/SaveOffice | ResponseModel | [FromBody] Office model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:66 |
| GET | api/Company/DeleteOffice | ResponseModel | long OfficeId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:79 |
| ANY | api/Company/GetShiftList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:88 |
| ANY | api/Company/GetShiftRecord | ResponseModel | long ShiftId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:92 |
| POST | api/Company/SaveShift | ResponseModel | [FromBody] Shift model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:98 |
| GET | api/Company/DeleteShift | ResponseModel | long shiftId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:111 |
| ANY | api/Company/GetAllTeamsList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:119 |
| ANY | api/Company/GetTeamList | ResponseModel | int? companyId, int? officeId, int? departmentId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:123 |
| ANY | api/Company/GetTeamRecord | ResponseModel | long TeamId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:127 |
| POST | api/Company/SaveTeam | ResponseModel | [FromBody] TeamViewModel model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:133 |
| GET | api/Company/DeleteTeam | ResponseModel | long TeamId, int OfficeId, int DepartmentId, int CompanyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:146 |
| ANY | api/Company/GetCompanyOfficenDepartment | ResponseModel | long CompanyId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:152 |
| ANY | api/Company/GetOfficeIdFromDept | ResponseModel | long DeptId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:160 |
| ANY | api/Company/GetDepartmentList | ResponseModel | long? officeId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:164 |
| ANY | api/Company/GetDepartmentRecord | ResponseModel | long DepartmentId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:168 |
| POST | api/Company/SaveDepartment | ResponseModel | [FromBody] Department model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:174 |
| GET | api/Company/DeleteDepartment | ResponseModel | long DepartmentId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:187 |
| ANY | api/Company/GetDesignationList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:196 |
| ANY | api/Company/GetDesignationRecord | ResponseModel | long DesignationId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:200 |
| POST | api/Company/SaveDesignation | ResponseModel | [FromBody] DesignationViewModel model | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:206 |
| GET | api/Company/DeleteDesignation | ResponseModel | long DesignationId | NPM_API_BackUp/NPMAPI/Controllers/CompanyController.cs:219 |
| GET | api/Credentialing/GetActivePractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:197 |
| GET | api/Credentialing/GetCredProviderDetails | ResponseModel | string HospitalName , long ProviderCode | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:263 |
| GET | api/Demographic/InquiryByPracPatProvider | ResponseModelForE | long PracticeCode, long PatAcccount, long ProviderCode, long insurance_id | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:148 |
| ANY | api/Demographic/GetFacilitySelectList | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:353 |
| ANY | api/Demographic/GetFacility | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:357 |
| POST | api/Demographic/AddDxToProvider | ResponseModel | [FromBody] PracticeDxModel PracDxModel | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:371 |
| POST | api/Demographic/GetPracticeClaims | ResponseModel | ClaimSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:418 |
| GET | api/Demographic/GetProviderSelectList | ResponseModel | string searchText, long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:439 |
| GET | api/Demographic/GetLocationSelectList | ResponseModel | string searchText, long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:444 |
| GET | api/Demographic/GetPanelBillingLocationSelectList | ResponseModel | long practiceCode, bool all = false | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:451 |
| GET | api/Demographic/GetPracticeDefaultLocation | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:456 |
| GET | api/Demographic/GetPanelBillingSummaryByPractice | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:594 |
| POST | api/Demographic/ProviderPayerSearchInsurance | ResponseModel | [FromBody] InsuranceSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/DemographicController.cs:731 |
| ANY | api/PracticeSetup/GetPractices | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:24 |
| GET | api/PracticeSetup/GetPracticesByUserRights | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:29 |
| GET | api/PracticeSetup/GetPractice | ResponseModel | long? practiceId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:34 |
| GET | api/PracticeSetup/GetPracticeWithActiveProviders | ResponseModel | long? practiceId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:39 |
| GET | api/PracticeSetup/ActivateInActivePractice | ResponseModel | long practiceId, bool isActive | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:44 |
| POST | api/PracticeSetup/PostSavePractice | ResponseModel | Practice model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:52 |
| GET | api/PracticeSetup/GetPracticeSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:63 |
| ANY | api/PracticeSetup/GetPracticeNotesList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:69 |
| ANY | api/PracticeSetup/GetPracticeNote | ResponseModel | long PracticeNotesId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:73 |
| POST | api/PracticeSetup/SavePracticeNote | ResponseModel | [FromBody] Practice_Notes PracticeNote | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:78 |
| GET | api/PracticeSetup/DeletePracticetNote | ResponseModel | long PracticeId, long PracticeNotesId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:89 |
| ANY | api/PracticeSetup/GetSpecialInstructionList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:95 |
| ANY | api/PracticeSetup/GetSpecialInstruction | ResponseModel | long QuestionId, long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:99 |
| ANY | api/PracticeSetup/GetSpecialInstructionQuestionByCategory | ResponseModel | long CategoryId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:103 |
| POST | api/PracticeSetup/SaveSpecialInstruction | ResponseModel | [FromBody] Practice_Special_Instruction_Answers model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:108 |
| GET | api/PracticeSetup/DeleteSpecialInstruction | ResponseModel | long QuestionId, long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:119 |
| ANY | api/PracticeSetup/GetProviders | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:125 |
| ANY | api/PracticeSetup/GetProvider | ResponseModel | long providerId, long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:129 |
| POST | api/PracticeSetup/SaveProvider | ResponseModel | Provider model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:134 |
| GET | api/PracticeSetup/ActivateInActiveProvider | ResponseModel | long providerId, long PracticeId, bool isActive | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:145 |
| ANY | api/PracticeSetup/GetProviderNotesList | ResponseModel | long ProviderId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:151 |
| ANY | api/PracticeSetup/GetProviderNote | ResponseModel | long ProviderNoteId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:156 |
| POST | api/PracticeSetup/SaveProviderNote | ResponseModel | [FromBody] Provider_Notes ProviderNote | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:161 |
| GET | api/PracticeSetup/DeleteProviderNote | ResponseModel | long ProviderId, long ProviderNotesId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:172 |
| ANY | api/PracticeSetup/GetProviderWorkingHours | ResponseModel | long ProviderId, long LocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:178 |
| ANY | api/PracticeSetup/GetPracticeResources | ResponseModel | long practiceId, long LocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:184 |
| ANY | api/PracticeSetup/GetProviderResources | ResponseModel | long ProviderId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:188 |
| ANY | api/PracticeSetup/GetProviderPayers | ResponseModel | long ProviderId, long LocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:194 |
| GET | api/PracticeSetup/GetPracticePayers | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:202 |
| GET | api/PracticeSetup/DeletePracticePayers | ResponseModel | long PracticeId, string ProviderPayerId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:208 |
| POST | api/PracticeSetup/MapPayer | ResponseModel | [FromBody] InsuranceModel model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:214 |
| ANY | api/PracticeSetup/GetPracticeLocationList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:222 |
| ANY | api/PracticeSetup/GetPracticeLocation | ResponseModel | long PracticeId, long PracticeLocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:226 |
| POST | api/PracticeSetup/SavePracticeLocation | ResponseModel | [FromBody] Practice_Locations PracticeLocation | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:231 |
| GET | api/PracticeSetup/DeletePracticeLocation | ResponseModel | long PracticeId, long PracticeLocationId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:242 |
| ANY | api/PracticeSetup/GetPracticeFacilityList | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:248 |
| ANY | api/PracticeSetup/GetPracticeFacility | ResponseModel | long PracticeId, long PracticeFacilityId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:252 |
| POST | api/PracticeSetup/SavePracticeFacility | ResponseModel | PRACTICE_FACILITY model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:257 |
| GET | api/PracticeSetup/DeletePracticeFacility | ResponseModel | long PracticeId, long PracticeFacilityId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:268 |
| ANY | api/PracticeSetup/GetPracticeSpecialityCategoryOne | ResponseModel | long GroupNo | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:274 |
| ANY | api/PracticeSetup/GetPracticeSpecialityCategoryTwo | ResponseModel | long GroupNo, int CatLevel | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:278 |
| POST | api/PracticeSetup/AddPracticeSynchronization | ResponseModel | [FromBody] PracticeSynchronizationModel model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:283 |
| ANY | api/PracticeSetup/GetPracticeSynchronization | ResponseModel | long practiceid | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:287 |
| GET | api/PracticeSetup/GetSpecialityGroups | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:293 |
| GET | api/PracticeSetup/GetSpecializations | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:299 |
| GET | api/PracticeSetup/GetWcbRatings | Task<ResponseModel> |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:305 |
| GET | api/PracticeSetup/GetActiveUsersForPractice | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:311 |
| GET | api/PracticeSetup/GetDivisionForUser | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:316 |
| GET | api/PracticeSetup/IsAutoFillEnableForPractice | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:322 |
| GET | api/PracticeSetup/GetRecentClaimDetails | ResponseModel | long patientAccount, long practiceCode,string claimType | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:327 |
| POST | api/PracticeSetup/SaveReportingDetails | ResponseModel | Practice_Reporting model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:335 |
| GET | api/PracticeSetup/GetReportingDetailOfPracticeUser | ResponseModel | long userID, long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:341 |
| GET | api/PracticeSetup/TaxonomyCode | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:347 |
| GET | api/PracticeSetup/NPICode | ResponseModel | long PracticeId | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:353 |
| GET | api/PracticeSetup/GetPracticeReportingDetail | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:359 |
| POST | api/PracticeSetup/AddOrUpdateProviderResources | ResponseModel | [FromBody] Provider_Resources resource | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:364 |
| GET | api/PracticeSetup/GetAllProviderResources | ResponseModel | long practiceCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:379 |
| GET | api/PracticeSetup/GetExpiredPortalsByTeamLead | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:384 |
| GET | api/PracticeSetup/GetProviderDocTypeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:389 |
| GET | api/PracticeSetup/GetProviderStateList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:394 |
| POST | api/PracticeSetup/SaveProviderDocs | ResponseModel | [FromBody] ProviderDocuments_ViewModel model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:399 |
| POST | api/PracticeSetup/ProviderDocFileUpload | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:404 |
| GET | api/PracticeSetup/GetProviderDocList | ResponseModel | long PracticeCode, long ProviderCode, string Doc_Type | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:409 |
| GET | api/PracticeSetup/Download | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:414 |
| GET | api/PracticeSetup/GetProviderDocBYId | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:457 |
| GET | api/PracticeSetup/DeleteProviderDocBYid | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:462 |
| GET | api/PracticeSetup/GetPracticeDocList | ResponseModel | long PracticeCode, string Doc_Type | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:467 |
| GET | api/PracticeSetup/GetPracticeDocTypeList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:472 |
| POST | api/PracticeSetup/SavePracticeDocs | ResponseModel | [FromBody] PracticeDocuments_ViewModel model | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:477 |
| GET | api/PracticeSetup/GetPracticeDocBYId | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:482 |
| GET | api/PracticeSetup/DeletePracticeDocBYid | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:487 |
| POST | api/PracticeSetup/PracticeDocFileUpload | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:492 |
| GET | api/PracticeSetup/DownloadPracFile | HttpResponseMessage | long id | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:497 |
| GET | api/PracticeSetup/GetPracticeSoftware | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/PracticeSetupController.cs:540 |
| GET | api/Report/FinancialAnalysisByProviderandProcCodesReport | ResponseModel | long PracticeCode, DateTime DateFrom, DateTime DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:54 |

Additional controller actions in this module: 39. See backend inventory.
| Service | Representative methods | File |
| --- | --- | --- |
| CompanyService | GetCompanyList, GetCompanyRecord, SaveCompany, DeleteCompany, GetCompaniesAndRolesSelectList, GetOfficeList, GetOfficeRecord, SaveOffice, DeleteOffice, GetShiftList, GetShiftRecord, SaveShift, DeleteShift, GetTeamList, GetTeamRecord, SaveTeam, DeleteTeam, GetCompanyOfficenDepartment | NPM_API_BackUp/NPMAPI/Services/CompanyService.cs |
| PracticeService | GetPractices, GetPracticesByUserRights, GetActivePractices, GetPracticeModel, GetPractice, GetPracticeWithActiveProviders, ActivateInActivePractice, PostSavePractice, GetPracticeSelectList, GetPracticeFTPInfo, GetBatchCSIPracticeFTPInfo, GetFTPEnabledPractices, GetManualERAEnabledPractices, GetFTPEnabledPractices, GetPracticeNotesList, GetPracticeNote, SavePracticeNote, DeletePracticetNote | NPM_API_BackUp/NPMAPI/Services/PracticeService.cs |
| VendorService | GetVendor | NPM_API_BackUp/NPMAPI/Services/VendorService.cs |
**Database model/table candidates:** CheckPracticeCode, Claim_Provider_Diagnosis_Proc_Result, Company, Default_Setting_Practice, Department_practice, EFS_Practices, Employee_Practice, ExternalPractices_Reporting, Facility, FacilitySearchModel, Facility_Insurance_Id, Facility_Notes, Financial_Analysis_by_Provider_and_Procedure_Codes_Result, GETEFSPRACTICES_Result, GETPRACTICES_WITHDETAILS_Result, GET_ISFACILITY_Result, GetCPTPlanByProviderPlanId_Result, GetCPTPlanByProviderPlanId_Temp_Result, GetCPTPlanByProviderPlanId_Umer_Result, GetPanelBillingSummaryByPractice_Result, GetPracticeActiveUsers_Result, GetPracticeFacilites_Result, GetPracticeUserReportingDetail_Result, Group_Location, Group_Provider, MEMO_MAPPING_PRACTICE_PLAN, MONTH_END_FINANCIAL_PROVIDE_LOCATION, PRACTICES_BKP_021619, PRACTICE_CALLING_DAY_CRITERIA, PRACTICE_CPT_PLAN_GROUP, PRACTICE_DIAGNOSIS1, PRACTICE_DIVISION, PRACTICE_FACILITY, PRACTICE_LOCATIONS_PLAN, PRACTICE_PROCEDURE1, PRACTICE_SERVER, PROVIDER_PAYER_PRINTCENTER, PROVIDER_PROCEDURES, Payer_Facility_Id, Practice, Practice101100205152023_BKP, Practice2, PracticeAppointmentReason, PracticeAppointmentReasonCreateVM, PracticeAppointmentStatu, PracticeAppointmentStatusCreateVM, PracticeAppointmentStatusViewModel, PracticeDocuments_ViewModel, PracticeDxModel, PracticeFTPViewModel, PracticeFacilitesViewModel, PracticeFacilityEditViewModel, PracticeLocationUpdateRequest, PracticeSynchronization, PracticeSynchronizationLog, PracticeSynchronizationModel, PracticeUpdateRequest, PracticeVendor, PracticeViewModel, Practice_Bank_Statement, Practice_CPT_Plan, Practice_Contract, Practice_Daily_Missing_Work, Practice_Doc_Types, Practice_Docs, Practice_Groups, Practice_Locations, Practice_Locations_Plan_Group, Practice_NPI_confirmation, Practice_Notes, Practice_Providers_Plan, Practice_Providers_Plan_Group, Practice_Reporting, Practice_SMS_Settings, Practice_SignUp_Contact_Information, Practice_SignUp_Daily_Office_Hours, Practice_SignUp_Insurance_Information, Practice_SignUp_Physician_Capitation, Practice_SignUp_Physician_Facilities_Info, Practice_SignUp_Referring_Physician, Practice_Software, Practice_Special_Instruction_Answers, Practice_Special_Instruction_AnswersReview, Practice_Special_Instruction_Category, Practice_Special_Instruction_Questions, Practice_Specialty, Practice_Termination, Practice_Termination_Steps, Practice_Transcription_Amount, Practice_Transcription_Rate, Practice_Types, Practices_Techincal_Information, Practices_VAS_Other, Provider, ProviderAppointmentRuleViewModel, ProviderCptPlanNotesVM, ProviderDocuments_ViewModel, ProviderFeeScheduleSearchVM, ProviderSchedulesViewModel, ProviderUpdateRequest, ProviderWise_Financials_by_Report_Result, ProviderWorkingDayTimeViewModel, Provider_Appointment_Rules, Provider_Attachments, Provider_Cpt_Contractual_Plan, Provider_Cpt_Contractual_Plan_Details, Provider_Cpt_Contractual_Plan_Notes, Provider_Cpt_Plan, Provider_Cpt_Plan_Details, Provider_Cpt_Plan_Details_bkp01122023, Provider_Cpt_Plan_Notes, Provider_Cpt_Plan_bkp_1_10_2023_, Provider_Diagnosis, Provider_Doc_Types, Provider_Docs, Provider_Initial_Settings, Provider_Notes, Provider_Oncall, Provider_Payers, Provider_Resource_Mapping, Provider_Resources, Provider_US_Holidays, Provider_Working_Days_Time, Provider_Working_Days_Time_Temp, Provider_Year_Holidays, ProvidersByPracticeResponse, Providers_Plan, Providers_Plan_Group, SP_GETPRACTICEANALYSIS_Result, SP_GetProviderCPTPlanID_Result, SP_GetProviderCPTPlan_Result, SP_GetStandardCPTSByPracticeState_Result, SP_InsFacilityInfoWithoutModifierAndProcedure_Result, SP_InsFacilityPlan_Result, SP_InsLocationPlan_Result, SP_InsLocationWithoutModifierAndProcedure_Result, SP_PRACTICEPROVIDERPAYERSEARCH_Result, SP_PROVIDERPAYERSEARCH_Result, SP_ProviderInfo_Result, SP_ProviderPlan_Result, SP_ProviderWithoutModifierAndProcedure_Result, SP_SearchProviderCPTFeePlan_Result, SP_SelectAllPracticeUsers_Result, SyncExcludedPractice, SyncedPractice, SyncedPracticeLocation, SyncedProvider, Type_of_facility, USP_GetCredPortal_By_PracticeCode_Result, USP_GetOfficeTimeForProvidersAndLocations_Result, USP_Get_Practice_Docs_Result, USP_Get_Provider_Docs_Result, Users_Practice_Provider, Vendor, check_provider_cptplan_existence, era_provider_adjustment, ins_provider_no, lkup_location_ids, mainfacility, practice_gender, practice_information, provider_payerTEST, providercptplanModel, providers_reasons_timeunits, room_location, showprovidercptplan, spGetBatchClaimsProviderPayers_Result, spGetBatchCompanyDetails_Result, sp_provider_working_times_Result, uspGetBatchClaimsProviderPayersDataFromUSP_Result, uspGetBatchClaimsProviderPayers_Result, usp_GetPracticeReportingDetails_Result

**Stored procedure/function references:** Check_Bounce_Penalty, Check_Requested_Practice_According_to_User_request, Claim_No, Claim_Payments, Claim_Provider_Diagnosis_Proc, Claim_Provider_Diagnosis_Proc_Result, EFS_PracID, EFS_Practices, ERA_EFT_STATUS, Financial_Analysis_by_Provider_and_Procedure_Codes, Financial_Analysis_by_Provider_and_Procedure_Codes_Result, Get_FTP_According_requested_Practice_Code, Get_List_Of_requests_which_are_in_process_And_with_Same_Practice_as_requested_user, Get_Stats_for_UI_if_no_PRacticeCodeFound, SP_CreateProviderCPTPlanDetails, SP_DeleteProviderPlainWithCPTS, SP_GETPRACTICEANALYSIS, SP_GETPRACTICEANALYSIS_Result, SP_GetLocationState, SP_GetProviderCPTPlan, SP_GetProviderCPTPlanID, SP_GetProviderCPTPlanID_Result, SP_GetProviderCPTPlanIDtemp, SP_GetProviderCPTPlan_Result, SP_GetStandardCPTSByPracticeState, SP_GetStandardCPTSByPracticeState_Result, SP_InsFacilityInfoWithoutModifierAndProcedure, SP_InsFacilityInfoWithoutModifierAndProcedure_Result, SP_InsFacilityPlan, SP_InsFacilityPlan_Result, SP_InsLocationPlan, SP_InsLocationPlan_Result, SP_InsLocationWithoutModifierAndProcedure, SP_InsLocationWithoutModifierAndProcedure_Result, SP_PRACTICEPROVIDERPAYERSEARCH, SP_PRACTICEPROVIDERPAYERSEARCH_Result, SP_PROVIDERPAYERSEARCH, SP_PROVIDERPAYERSEARCH_Result, SP_ProviderInfo, SP_ProviderInfo_Result, SP_ProviderPlan, SP_ProviderPlan_Result, SP_ProviderWithoutModifierAndProcedure, SP_ProviderWithoutModifierAndProcedure_Result, SP_SearchProviderCPTFeePlan, SP_SearchProviderCPTFeePlan_Result, SP_SelectAllPracticeUsers, SP_SelectAllPracticeUsers_Result, USP_GetCredPortal_By_PracticeCode, USP_GetCredPortal_By_PracticeCode_Result, USP_GetOfficeTimeForProvidersAndLocations, USP_GetOfficeTimeForProvidersAndLocations_Result, USP_Get_Practice_Docs, USP_Get_Practice_Docs_Result, USP_Get_Provider_Docs, USP_Get_Provider_Docs_Result, USP_NPM_PAYER_MAPPING, USP_NPM_PAYER_MAPPING_LOCATION, USP_NPM_PAYER_MAPPING_PROVIDER, USP_Practice_Assign_Users, sp_provider_working_times, sp_provider_working_times_Result, usp_GetPracticeReportingDetails, usp_GetPracticeReportingDetails_Result


## Reports and Analytics

Business purpose: Reports and Analytics supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
| ReportSetup |  | ./reports/reports.module#ReportsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| reporting |  | ./dynamic-reports/dynamic-reports.module#DynamicReportsModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| reports | CredReportsComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| cred-app-report | CredAppReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| hospital-status-report | HospitalStatusReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| hospital-grid-report | HospitalGridReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| cred-grid-report | CredGridReportComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
|  | DynamicReportsComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| charges | ChargesComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-cpt | ByCPTDos |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-hospital | ChargesByHospital |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-primary-dx-dos | ChargesByPrimaryDxDOS |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| by-carrier | ChargesByCarrierDos |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
| cpa | CpaComponent |  | NPM_UI_BackUp/src/app/dynamic-reports/dynamic-reports.routing.module.ts |
|  | MainReportsComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| AgingSummary | AgingSummaryReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| FinancialSummaryCPT | FinancialSummaryCPTWiseComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| RecallVisits | RecallVisits |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| acount-assignmentreport | AccountAssignmentreportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| user-report | UserReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| rollingsummary | RollingsummaryreportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| pending-batch-report | PendingBatchReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| unposted-adjustment-report | UnpostedAdjustmentReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| collection-analysis-report | CollectionAnalysisReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Charges-BreakDown-report | ChargesBreakDownReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Negative-Balance-Report | NegativeBalanceReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| denial-report | DenialReportComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| CredAppReportComponent | app-cred-app-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-app-report |
| CredGridReportComponent | app-cred-grid-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-grid-report |
| CredReportsComponent | app-cred-reports | NPM_UI_BackUp/src/app/credentialing/cred-reports/cred-reports |
| HospitalGridReportComponent | app-hospital-grid-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/hospital-grid-report |
| HospitalStatusReportComponent | app-hospital-status-report | NPM_UI_BackUp/src/app/credentialing/cred-reports/hospital-status-report |
| CpaComponent | app-cpa | NPM_UI_BackUp/src/app/dynamic-reports/charges/by-cpa/cpa |
| ByCPTDos | by-cpt-dos-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/by-cpt-dos |
| ChargesByCarrierDos | charges-by-carrier-dos-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/charges-by-carrier-dos |
| ChargesByHospital | charges-by-hospital-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/charges-by-hospital |
| ChargesByPrimaryDxDOS | charges-by-primary-dx-dos-report | NPM_UI_BackUp/src/app/dynamic-reports/charges/charges-by-primary-dx-dos |
| ChargesComponent | charges-report | NPM_UI_BackUp/src/app/dynamic-reports/charges |
| DynamicReportsComponent | dynamic-reports | NPM_UI_BackUp/src/app/dynamic-reports |
| AccountAssignmentreportComponent | app-account-assignmentreport | NPM_UI_BackUp/src/app/reports/account-assignmentreport |
| AgingSummaryReportComponent | app-aging-summary-report | NPM_UI_BackUp/src/app/reports/aging-summary-report |
| ChargesBreakDownReportComponent | app-charges-break-down-report | NPM_UI_BackUp/src/app/reports/charges-break-down-report |
| CollectionAnalysisReportComponent | app-collection-analysis-report | NPM_UI_BackUp/src/app/reports/collection-analysis-report |
| DenialReportComponent | app-denial-report | NPM_UI_BackUp/src/app/reports/denial-report |
| FinancialSummaryCPTWiseComponent | app-financial-summary-cptwise | NPM_UI_BackUp/src/app/reports/financial-summary-cptwise |
| MainReportsComponent | app-main-reports | NPM_UI_BackUp/src/app/reports |
| NegativeBalanceReportComponent | app-negative-balance-report | NPM_UI_BackUp/src/app/reports/negative-balance-report |
| PendingBatchReportComponent | app-pending-batch-report | NPM_UI_BackUp/src/app/reports/pending-batch-report |
| RecallVisits | recall-visits-report | NPM_UI_BackUp/src/app/reports/recall-visits |
| RollingsummaryreportComponent | app-rollingsummaryreport | NPM_UI_BackUp/src/app/reports/rollingsummaryreport |
| UnpostedAdjustmentReportComponent | app-unposted-adjustment-report | NPM_UI_BackUp/src/app/reports/unposted-adjustment-report |
| UserReportComponent | app-user-report | NPM_UI_BackUp/src/app/reports/user-report |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| GET | api/Credentialing/GetCredAppReport | ResponseModel | long practiceCode, int? ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:202 |
| GET | api/Credentialing/GetHospitalStatusReport | ResponseModel | long practiceCode, long ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:231 |
| GET | api/Credentialing/GetHospitalGridReport | ResponseModel | long practiceCode,long providercode, long ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:236 |
| GET | api/Credentialing/GetCredGridReport | ResponseModel | long practiceCode, long providerCode, int ObjTypeId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:258 |
| GET | api/Report/AgingSummaryAnalysisReport | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:25 |
| GET | api/Report/FinancialAnalysisCPTLevelReport | ResponseModel | long PracticeCode, DateTime DateFrom, DateTime DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:60 |
| GET | api/Report/holdReport | ResponseModel | long PracticeCode | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:95 |
| POST | api/Report/RecallVisits | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:121 |
| POST | api/Report/PeriodAnalysisAndClosing | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:127 |
| POST | api/Report/AgingSummaryRecent | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:145 |
| GET | api/Report/GetUserReport | ResponseModel | string PracCode, string userid,string dateFrom,string dateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:174 |
| GET | api/Report/GetUserReportPagination | ResponseModel | string PracCode, string userid, string dateFrom, string dateTo,int page,int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:180 |
| GET | api/Report/GetRollingSummaryReport | ResponseModel | string PracCode, string duration | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:185 |
| ANY | api/Report/CollectionAnalysisReport | ResponseModel | long? PracticeCode, DateTime? DateFrom, DateTime? DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:197 |
| GET | api/Report/CollectionAnalysisReport | Task<ResponseModel> | long PracticeCode, DateTime? DateFrom, DateTime? DateTo, bool isExport = false, int page = 1, int size = 10 | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:203 |
| GET | api/Report/DenialReportDetailPagination | ResponseModel | long? PracticeCode,string Criteria, DateTime? DateFrom, DateTime? DateTo, int page, int count | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:221 |
| GET | api/Report/DenialReportDetail | ResponseModel | long? PracticeCode, string Criteria, DateTime? DateFrom, DateTime? DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:227 |
| GET | api/Report/GetNegativeBalanceReport | Task<ResponseModel> | long practiceCode, string responsibleParty, string dateCriteria, DateTime dateFrom, DateTime dateTo, Boolean isExport, int pageSize, int PageNo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:232 |
| GET | api/Report/GetEshaCBRDetails | ResponseModel | long? practiceCode, int Page, int Count, bool perPageRecord | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:237 |
| POST | api/Report/ByCPTDos | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:263 |
| POST | api/Report/ByHospitalDos | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:269 |
| POST | api/Report/ByPrimaryDXDos | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:275 |
| POST | api/Report/ByCarrierDOS | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:281 |
| POST | api/Report/CPA | ResponseModel | ReportRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:287 |
| GET | api/Report/AccounAssignmentReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:307 |
| GET | api/Report/AccounAssignmentReportPagination | ResponseModel | long PracticeCode, string DateFrom, string DateTo,int page, int size | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:313 |
| POST | api/Report/GetChargesBreakDownReport | Task<ResponseModel> | PatelReportsRequestModel req | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:324 |
| Service | Representative methods | File |
| --- | --- | --- |
| ReportService | AgingSummaryAnalysisReport, DormantClaimsReport, DormantClaimsReports, DormantClaimsReportsPagination, AgingSummaryPatientAnalysisReport, FinancialAnalysisByProviderandProcCodesReport, FinancialAnalysisCPTLevelReport, PaymentDetail, PaymentDetailPagination, CPTWisePaymentDetail, CPTWisePaymentDetailPagination, DenialReportDetailPagination, DenialReportDetail, GetEshaCBRDetails, GetPatientAgingSummaryDetails, GetPlanAgingReportDetails, AppointmentDetailReport, ClaimPaymentsDetailReport | NPM_API_BackUp/NPMAPI/Services/ReportService.cs |
**Database model/table candidates:** AGING_SUMMARY_REPORT, Aging_Summary_Analysis_Report_Result, Aging_Summary_Analysis_Reporting_Result, CPTs_Ana_by_Report_Result, CPTs_Analysis_by_Report_Result, CSIReportModel, ChargesBreakdownReportResponse, Cred_Hospital_Status_Report, Denial_Report_Response, EFS_ImpactSummary, FINANCIAL_SUMMARY_REPORT, Fiancial_Summary, Financial_Analysis_At_CPT_Level_Result, Hospital_Grid_Report, MONTH_END_AGING, MONTH_END_FINANCIAL, NegativeBalanceReportResponse, REPORT_Sami_Result, ReportRequestModel, SP_AGINGCOMPDEMO_Result, SP_AGINGDEMO_Result, SP_Cred_App_Report_Result, SP_GETPERIODANALYSISANDCLOSING_Result, SP_getuserDailyReport_Result, SP_userReportChargesNewPMOSB_Result, SP_userReportCharges_Result, USP_COLLECTION_ANALYSIS_REPORT_NPM_Result, USP_Credentialing_Grid_Report_Result, USP_Denial_Report_Result, USP_NEGATIVE_BALANCE_REPORT_Result, aging_populated_record, userDailyReportResponse

**Stored procedure/function references:** Aging_Comparison, Aging_Summary_Analysis_Report, Aging_Summary_Analysis_Report_Result, Aging_Summary_Analysis_Reporting, Aging_Summary_Analysis_Reporting_Result, Charges_Per_Unit, EFS_AC_Ratio, EFS_Adjusted, EFS_Approved, EFS_BeqApp_Ratio, EFS_BillEqApp, EFS_Billed, EFS_ImpactSummary, EFS_PC_Ratio, Financial_Analysis_At_CPT_Level, Financial_Analysis_At_CPT_Level_Result, Financial_Summary, SP_AGINGCOMPDEMO, SP_AGINGDEMO, SP_Aging_Papulated, SP_COSSCPABYADDCRT, SP_Cred_App_Report_Result, SP_Credentialing_Report, SP_GETPERIODANALYSISANDCLOSING, SP_GETPERIODANALYSISANDCLOSING_Result, SP_GETRECALLVISITS_EGD, SP_GetCPAAnalysis, SP_PCRatio, SP_getuserDailyReport, SP_getuserDailyReport_Result, SP_laim_Charges_Summary, SP_rollingReport, SP_userReportCharges, SP_userReportChargesNewPMOSB, SP_userReportChargesNewPMOSB_Result, SP_userReportCharges_Result, USP_COLLECTION_ANALYSIS_REPORT_NPM, USP_COLLECTION_ANALYSIS_REPORT_NPM_Result, USP_Charge_Breakdown, USP_Credentialing_Grid_Report, USP_Credentialing_Grid_Report_Result, USP_Credentialing_Hospital_Status_Report, USP_Denial_Report, USP_Denial_Report_Result, USP_Hospital_Grid_Report, USP_NEGATIVE_BALANCE_REPORT, USP_NEGATIVE_BALANCE_REPORT_Result, USP_NPM_By_Carrier_DOS, USP_NPM_By_Cpt_DOS, USP_NPM_By_Hospital, USP_NPM_By_Primary_Dx_DOS, USP_NPM_COSSCPABYADDCRT, USP_NPM_OVER_ALL_CHARGES, sp_name


## Scheduler and Appointments

Business purpose: Scheduler and Appointments supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
| appointments |  | ./appointment-scheduler/appointment-scheduler.module#AppointmentSchedulerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
|  | AppointmentSchedulerComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| scheduler | SchedulerComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| officeTiming | OfficeTimingsComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| statuses | AppointmentStatusComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| reasons | AppointmentReasonsComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
| block-appointments | BlockAppointmentsComponent |  | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-scheduler-routing.module.ts |
|  | FeeScheduleMainComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| Standard | StandardCPTFeeScheduleComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| NobilityCPT | NobilityCPTFeeScheduleComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| PanelBilling | PanelBillingComponent |  | NPM_UI_BackUp/src/app/fee-schedule/feeScheduleRouting.module.ts |
| appointment-detail | AppointmentDetailComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| missing-appointment-detail | MissingAppointmentDetailComponent |  | NPM_UI_BackUp/src/app/reports/reportsRouting.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| AppointmentReasonsComponent | app-appointment-reasons | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-reasons |
| AppointmentSchedulerComponent | app-appointment-scheduler | NPM_UI_BackUp/src/app/appointment-scheduler |
| AppointmentStatusComponent | app-appointment-status | NPM_UI_BackUp/src/app/appointment-scheduler/appointment-status |
| BlockAppointmentsComponent | app-block-appointments | NPM_UI_BackUp/src/app/appointment-scheduler/block-appointments/block-appointments |
| OfficeTimingsComponent | app-office-timings | NPM_UI_BackUp/src/app/appointment-scheduler/office-timings |
| SchedulerComponent | app-scheduler | NPM_UI_BackUp/src/app/appointment-scheduler/scheduler |
| AppointmentDetailComponent | app-appointment-detail | NPM_UI_BackUp/src/app/reports/appointment-detail |
| MissingAppointmentDetailComponent | app-missing-appointment-detail | NPM_UI_BackUp/src/app/reports/missing-appointment-detail/missing-appointment-detail |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| GET | api/Report/AppointmentDetailReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:89 |
| GET | api/Report/MissingAppointmentDetailReport | ResponseModel | long PracticeCode, string DateFrom, string DateTo | NPM_API_BackUp/NPMAPI/Controllers/ReportController.cs:115 |
| POST | api/Scheduler/GetAppointments | ResponseModel | AppointmentsSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:34 |
| POST | api/Scheduler/GetExistingAppointments | ResponseModel | AppointmentCreateModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:47 |
| GET | api/Scheduler/GetAppointmentModel | ResponseModel | long practiceCode, long? id | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:67 |
| GET | api/Scheduler/GetAppointmentdetail | ResponseModel | long? id, long pataccount, string appDate | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:72 |
| GET | api/Scheduler/GetReasonsSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:77 |
| POST | api/Scheduler/Save | ResponseModel | [FromBody] AppointmentCreateModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:82 |
| GET | api/Scheduler/Delete | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:93 |
| POST | api/Scheduler/Timings | ResponseModel | TimingSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:122 |
| POST | api/Scheduler/Rules | ResponseModel | ProviderAppointmentRuleViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:135 |
| POST | api/Scheduler/SaveOfficeTimings | ResponseModel | OfficeTimingCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:161 |
| POST | api/Scheduler/SaveAppointmentRules | ResponseModel | ProviderAppointmentRuleViewModel rule | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:172 |
| POST | api/Scheduler/GetMatchingSchedules | ResponseModel | ProviderSchedulesViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:237 |
| GET | api/Scheduler/Statuses | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:248 |
| POST | api/Scheduler/SaveStatus | ResponseModel | PracticeAppointmentStatusCreateVM model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:268 |
| GET | api/Scheduler/GetPracAppointmentReasons | ResponseModel | long practiceCode, long providerCode, long locationCode | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:280 |
| GET | api/Scheduler/GetAppointmentReasons | ResponseModel | string searchText = "", bool all = false | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:285 |
| GET | api/Scheduler/GetUnassignedAppointmentReasons | ResponseModel | long practiceCode, long providerCode, long locationCode, string searchText = "" | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:290 |
| POST | api/Scheduler/SaveReason | ResponseModel | PracticeAppointmentReasonCreateVM model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:295 |
| POST | api/Scheduler/ChangeColor | ResponseModel | ColorChangeModel model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:300 |
| POST | api/Scheduler/SlotAvailability | ResponseModel | SlotAvailabilityRequestVM model | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:317 |
| GET | api/Scheduler/InquiryByAppointmentId | ResponseModel | long PracticeCode, long AppointmentId | NPM_API_BackUp/NPMAPI/Controllers/SchedulerController.cs:329 |
| Service | Representative methods | File |
| --- | --- | --- |
| SchedulerService | GetAppointments, GetExistingAppointments, GetProviderAppointmentSettings, GetAppointmentModel, GetAppointmentdetail, GetReasonsSelectList, Save, Save, Delete, Timings, Rules, GetProviderAppointmentRules, SaveOfficeTimings, SaveAppointmentRules, GetProviderSchedules, GetProviderSchedulesWithLocation, GetOfficeTimingForProvidersAndLocations, GetProviderBlockedSchedules | NPM_API_BackUp/NPMAPI/Services/SchedulerService.cs |
**Database model/table candidates:** Appointment, Appointment_Status, AppointmentsSearchViewModel, GetAppointmentById_Result, GetAppointmentEvents_Result, GetAppointment_Result, GetExistingAppointmentData_Result, GetOfficeTiming_Result, SP_Appointment_Detail_Report_Result, SP_Missing_Appointment_Report_Result, Scheduler_Types, Scheduler_customization, appointment_reasons, room_booking_appointment

**Stored procedure/function references:** Check_Duplicate_Blocking_Rule, Check_Office_Timing, SP_Appointment_Detail_Report, SP_Appointment_Detail_Report_Result, SP_Missing_Appointment_Report, SP_Missing_Appointment_Report_Result


## Shared/Common and Miscellaneous

Business purpose: Shared/Common and Miscellaneous supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Component | Selector | Folder |
| --- | --- | --- |
| AppComponent | app-root | NPM_UI_BackUp/src/app |
| BaseComponent | app-base | NPM_UI_BackUp/src/app/core/base |
| ErrorPageComponent | app-error-page | NPM_UI_BackUp/src/app/core/error-page |
| FooterComponent | app-footer | NPM_UI_BackUp/src/app/core/footer |
| LayoutComponent | app-layout | NPM_UI_BackUp/src/app/core/layout |
| NavbarComponent | app-navbar | NPM_UI_BackUp/src/app/core/navbar |
| TopnavbarComponent | app-topnavbar | NPM_UI_BackUp/src/app/core/topnavbar |
| EligblityComponent | app-eligblity | NPM_UI_BackUp/src/app/eligblity |
| FeeScheduleMainComponent | app-fee-schedule-main | NPM_UI_BackUp/src/app/fee-schedule |
| NobilityCPTFeeScheduleComponent | app-nobility-cptfee-schedule | NPM_UI_BackUp/src/app/fee-schedule/nobility-cptfee-schedule |
| PanelBillingComponent | app-panel-billing | NPM_UI_BackUp/src/app/fee-schedule/panel-billing |
| StandardCPTFeeScheduleComponent | app-standard-cptfee-schedule | NPM_UI_BackUp/src/app/fee-schedule/standard-cptfee-schedule |
| OfficemanagementComponent | app-officemanagement | NPM_UI_BackUp/src/app/officemanagement |
| DXComponent | app-dx | NPM_UI_BackUp/src/app/setups/dx |
| NdcComponent | app-ndc | NPM_UI_BackUp/src/app/setups/ndc |
| ListProceduresComponent | app-list-procedures | NPM_UI_BackUp/src/app/setups/Procedures/list-procedures |
| ProceduresComponent | app-procedures | NPM_UI_BackUp/src/app/setups/Procedures |
| ColorPickerComponent | color-picker | NPM_UI_BackUp/src/app/shared/color-picker |
| ModalWindow | modal-window | NPM_UI_BackUp/src/app/shared/modal-window |
| PhysicianSearchComponent | search-referring-physician | NPM_UI_BackUp/src/app/shared/search-referring-physician |
| ListUserComponent | app-list-user | NPM_UI_BackUp/src/app/user-management/users/list-user |
| ResetPasswordComponent | app-reset-password | NPM_UI_BackUp/src/app/user-management/users/reset-password |
| UserDetailComponent | app-user-detail | NPM_UI_BackUp/src/app/user-management/users/user-detail |
| UsersComponent | app-users | NPM_UI_BackUp/src/app/user-management/users |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| ANY | api/Home/Index | ActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/HomeController.cs:8 |
| ANY | api/Setup/GetGurantorsList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:54 |
| POST | api/Setup/GetGurantorsList | ResponseModel | Guarantor model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:59 |
| POST | api/Setup/GetNDCList | ResponseModel | NDCViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:64 |
| POST | api/Setup/GetDXList | ResponseModel | DXViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:70 |
| ANY | api/Setup/GetGurantor | ResponseModel | long GurantorId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:74 |
| POST | api/Setup/SaveGurantor | ResponseModel | [FromBody] Guarantor model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:80 |
| POST | api/Setup/SaveDX | ResponseModel | [FromBody] Diagnosi model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:93 |
| POST | api/Setup/UpdateDX | ResponseModel | [FromBody] Diagnosi model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:105 |
| POST | api/Setup/SaveNDC | ResponseModel | [FromBody] NDCModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:118 |
| GET | api/Setup/DeleteNDC | ResponseModel | long NDC_ID | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:130 |
| GET | api/Setup/DeleteDX | ResponseModel | string DX_Code | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:136 |
| GET | api/Setup/DeleteGurantor | ResponseModel | long GurantorId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:142 |
| ANY | api/Setup/GetStatesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:151 |
| ANY | api/Setup/GetuserList | ResponseModel | long PracCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:165 |
| ANY | api/Setup/GetStandardCPTFeeSchedule | ResponseModel | string StateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:176 |
| ANY | api/Setup/GetRevenueCodes | Task<ResponseModel> | string Code | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:187 |
| GET | api/Setup/GetDescriptionByCPT | ResponseModel | string ProviderCPTPCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:266 |
| GET | api/Setup/CheckCode | ResponseModel | string Code | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:273 |
| GET | api/Setup/GetByAlternateCode | ResponseModel | string AlternateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:280 |
| GET | api/Setup/CheckDuplicateAlternateCode | ResponseModel | string AlternateCode, string ProviderCPTPlainId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:299 |
| GET | api/Setup/CheckDuplicateCPT | ResponseModel | string ProviderCPTCode, string ProviderCPTPlainId | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:313 |
| POST | api/Setup/PaginateStandardCPTFee | ResponseModel | long practiceCode, Pager pager | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:331 |
| GET | api/Setup/GetStandardNobilityCPTFeeSchedule | ResponseModel | string StateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:361 |
| GET | api/Setup/GetProcedure | ResponseModel | string procedureCode, string alternateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:397 |
| GET | api/Setup/GetDropdownsListForProcedures | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:402 |
| GET | api/Setup/DuplicateProcAndAlternateCode | ResponseModel | string AlternateCode, string ProcCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:408 |
| POST | api/Setup/SaveProcedure | ResponseModel | [FromBody] ProcedureViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:416 |
| GET | api/Setup/DeleteProcedure | ResponseModel | string procedureCode, string alternateCode | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:429 |
| POST | api/Setup/SearchProcedures | ResponseModel | ProceduresSearchViewModel model | NPM_API_BackUp/NPMAPI/Controllers/SetupController.cs:434 |
| ANY | api/Values/Get | IEnumerable<string> |  | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:16 |
| ANY | api/Values/Get | string | int id | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:22 |
| ANY | api/Values/Post | void | [FromBody]string value | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:28 |
| ANY | api/Values/Put | void | int id, [FromBody]string value | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:33 |
| ANY | api/Values/Delete | void | int id | NPM_API_BackUp/NPMAPI/Controllers/ValuesController.cs:38 |
| Service | Representative methods | File |
| --- | --- | --- |
| ExcelFileHandlerService | InsertExcelData, ProcessExcel, GetAllowedSheetHeaders | NPM_API_BackUp/NPMAPI/Services/ExcelFileHandlerService.cs |
| FileHandlerService | UploadImage, UploadTicketImage, DownloadFile | NPM_API_BackUp/NPMAPI/Services/FileHandlerService.cs |
| NPMLogger | GetInstance, Debug, Error, Info, Warning | NPM_API_BackUp/NPMAPI/Services/NPMLogger.cs |
| PDFService | GenerateItemizedPatientStatment, GenerateIPsForDownload, GenerateItemizedPsForDownload, GenerateRollingFordowloadForDownload, AddMessage, EditMessage, DeleteMessage, GetAllMessages | NPM_API_BackUp/NPMAPI/Services/PDFService.cs |
| SetupService | DeleteFacility, GetFacility, GetFacilityList, SaveFacility, SaveGurantor, SaveNDC, SaveDX, UpdateDX, DeleteGurantor, DeleteNDC, DeleteDX, GetGurantor, GetGurantorsList, GetGurantorsList, GetNDCList, GetDXList, GetPracticeList, GetEshaPracticeList | NPM_API_BackUp/NPMAPI/Services/SetupService.cs |
| TTService | GetPatientCompleteInfo, GetClaimInfo, GetPatientAccounts, GetPatientDueAmt, GetPatientInfo, GetPracticeInfo, GetRenderingProvider, GetTTDepartmentsList, SaveTicket, SaveTicket, SearchTicket, TicketAssignment, GetTicketById, GetProviderList, GetTicketTrackById, SaveTrackDetails, EditTrackDetails, DeleteTrackDetails | NPM_API_BackUp/NPMAPI/Services/TTService.cs |
**Database model/table candidates:** AccountAssigneeResponse, AccountAssignee_AL, AccountAssignee_Notes, AddressType, Admission_Details, Amt, AppealAttachment, AssigneeusersList, Attachment_TypeCode, BALANCE, BatchErrorsRequestModel, BatchStatusModel, BatchesHistoryRequestModel, By_Cpt_DOS_Result, CPT, CPTChargesViewModel, CPT_FEE_STRUCTURE, CPT_Fee_Charge, CPT_HOSPBILLS, CSI_Batch, CSI_Batch_Error, CSI_Batch_Response, C__EFMigrationsHistory, Category, Charges_at_CPT_Level_Result, Check_Duplicate_Blocking_Rule_Result, Check_Office_Timing_Result, City, Clearing_Houses, ColorChangeModel, CombinedCodeModel, Components, Condition_Codes, Cpt_Current_Status, Cpt_ShortCodes, CreateAttachmentRequest, Cruduser, CustomField, CustomValue, CustomValue1, CustomValues_Column, Customised_Procedure_Description, Customised_diagnosis_Description, DO, DOCUMENT_CATEGORIES, DOSAGE_UNITS, DXSearchCriteria_Result, DXViewModel, Data12356, DataModel, Datet, Days_Of_Week, DelayReason1, DelayReasonsNew, DeleteInvoiceResponse, Deleted_Codes, DeleteinvoicepymentResponse, Delivery_Zone, Department, DepartmentViewModel, DeptShiftTiming, Designation, DesignationViewModel, Diagnosi, DiagnosisAccDel, Discharge_Status, Division, Doc_Type_Lookup, DownloadedFile, Dtp, Dummy, EFS_Suggested, ENROLLMENT_TRACKER, EOB_Adjustment_Codes, EligRequestTEST_Result, EligRequest_Result, EligRequests_Result, ExcelFieldsViewModel, FINAL2, File277CA, File999, FileSegmentValue, Gender, GetCSI_BatchDetails_Result, GetColumnList, GetColumn_List, GetPanelALternateCodeDetails_Result, GetTeamsByOffice_Result, GetUnassignedAppointmemtReasons_Result, HASHHASHA, Hard_Coded_Value, Hard_Coded_Valuenew, ISA_Identifier, InsCardCategory, Insurnace_Names_Bkp_08232020, Issue_test, Language, MEMO_MAPPING, MIS_TBL_CPT_Reason, MIS_TBL_Institution_Condition_Code, Maintenance, MaritalStatu, Modifier, Myalldata, NAME, NDCModel, NDCSearchCriteria_Result, NDCViewModel, NDC_CrossWalk, NDC_CrossWalk_bkp_02192024, NDC_List_Update, NDC_List_Updated, NEW_CATEGORY, NEW_GCODE, NPMDBEntities, New_Code, New_Codes, Nobility_standardcptfee, Notes_Description, Notes_Description_Category, ObjTypeViewModel, Occurrence_Codes, Occurrence_Span_Codes, Office, OfficeViewModel, Office_Test_Detail, Office_tests, Output277, PHARMACy, PHY_BA_AGREEMENT, PP_BillingSoftware, PQRI_INDIVIDUAL_MEASURES, PTLReason, Packet277CA_Data, Packet277CA_EntityIdentifierCodes, Packet999_Data, PacketFileVital, PacketFileVitals_Tets, PacketFileVitals_Tets1, PacketFileVitals_Tets2, Panel_Billing_Code_Cptdetail, Panel_Billing_Code_detail, Phone_Types, PhysicianSearchModel, Place_Of_Services, Possible_Options, Post, Prac_MeetingSchedule, Prac_TermDate_Process, Prac_Term_Date_Steps, Procedure, ProcedureViewModel, Procedure_Category, Procedure_tets, Product, Ptl_Description, Qty, REJECT_TYPE_DESCRIPTION, ROUTE, Race, Ref, Relationship, Resource, ResponseModel, ResponseModel277, RevenueF, RevenueT, Revenue_Codes, SMTPConfigModel, SPDataModel, SPS_Reason, SP_CPADEMO_Result, SP_CountAssignedAccounts_Result, SP_FacilitiesSearch_Result, SP_GETRECALLVISITS_EGD_Result, SP_GetBatchDetail1_Result, SP_GetBatchDetail_Result, SP_GetStandardCPTs_Result, SP_NDCSEARCHBySearchCriteria_Result, SP_NDCSEARCHBySearch_Result, SP_NDCSEARCH_Result, SP_ProcedureSearch_Result, SS_abn_codes, STANDARD_CPT_FEE, SaveTrackDetails, Sceduler_Types, Scheduling_Workday_Options, Scrcubber, Second_level_rejection, Section, SegmentType, SelectListViewModel, Service_Logs, Service_Type_Codes, Service_Type_Codes_Description, Shift, SlotAvailabilityRequestVM, Source_of_Admission, SpecialInstructionViewModel, Specialization

**Stored procedure/function references:** Charges___, Charges_at_CPT_Level, Charges_at_CPT_Level_Result, Check_Duplicate_Blocking_Rule_Result, Check_Office_Timing_Result, EFS_Suggested, MIS_TBL_CPT_Reason, MIS_TBL_Institution_Condition_Code, NPM_API, SP_CPADEMO, SP_GETRECALLVISITS_EGD_Result, SP_GetBatchDetail1, SP_GetBatchDetail1_Result, SP_GetPricingModifier, SP_GetStandardCPTs, SP_GetStandardCPTs_Result, SP_NDCSEARCH, SP_NDCSEARCHBySearch, SP_NDCSEARCHBySearchCriteria, SP_NDCSEARCHBySearchCriteria_Result, SP_NDCSEARCHBySearch_Result, SP_NDCSEARCH_Result, SP_ProcedureSearch, SP_ProcedureSearch_BKP_Afzl, SP_ProcedureSearch_Result, USP_Charge_Breakdown_Result


## Ticket Tracker and Tasks

Business purpose: Ticket Tracker and Tasks supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Component | Selector | Folder |
| --- | --- | --- |
| AccountLevelComponent | app-account-level | NPM_UI_BackUp/src/app/tasks/account-level |
| TasksComponent | app-tasks | NPM_UI_BackUp/src/app/tasks |
| TicketTrackerComponent | app-ticket-tracker | NPM_UI_BackUp/src/app/ticket-tracker |
| CreateTicketComponent | app-create-ticket | NPM_UI_BackUp/src/app/tickettracker/create-ticket |
| TicketResponseComponent | app-ticket-response | NPM_UI_BackUp/src/app/tickettracker/ticket-response |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| ANY | api/TicketAttachment/TicketAttach | IHttpActionResult |  | NPM_API_BackUp/NPMAPI/Controllers/TicketAttachmentController.cs:26 |
| GET | api/TicketTracker/GetTTDepartmentsList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:133 |
| POST | api/TicketTracker/SaveTicket | ResponseModel | [FromBody] Tickettracker model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:149 |
| POST | api/TicketTracker/SearchTicket | ResponseModel | TicketSearchModel model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:166 |
| ANY | api/TicketTracker/TicketAssignment | ResponseModel | TicketAssignmentRequest model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:183 |
| ANY | api/TicketTracker/GetTicketById | ResponseModel | long ticketid, long tickettrailid | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:199 |
| ANY | api/TicketTracker/GetTicketTrackById | ResponseModel | long ticketid | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:215 |
| POST | api/TicketTracker/SaveTrackDetails | ResponseModel | SaveTrackDetails model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:248 |
| POST | api/TicketTracker/DeleteTrackDetails | ResponseModel | [FromBody] TicketMessageDetail model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:281 |
| ANY | api/TicketTracker/GetAssignedUser | ResponseModel | long practicecode | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:297 |
| POST | api/TicketTracker/SendTicketEmail | ResponseModel | [FromBody] Tickettracker model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:314 |
| ANY | api/TicketTracker/SendMultipleTicketEmail | ResponseModel | [FromBody] Tickettracker model | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:330 |
| GET | api/TicketTracker/GetTicketTrackerLookUps | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:347 |
| GET | api/TicketTracker/GetUsersByDepartment | ResponseModel | long departmentId | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:364 |
| GET | api/TicketTracker/GetOpenTicketCount | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Controllers/TicketTrackerController.cs:412 |
| Service | Representative methods | File |
| --- | --- | --- |
| TicketAttachmentsService | Save | NPM_API_BackUp/NPMAPI/Services/TicketAttachmentsService.cs |
**Database model/table candidates:** GetTicketTrackDetail, GetTicketsWithFiltersResult, TASK, TASK_CATEGORIES, Ticket, TicketAssignmentDetails, TicketAssignmentRequest, TicketMessageDetail, TicketSearchModel, TicketTrackerLookups, Ticket_Priority, Ticket_Reason, Ticket_Tracking, Ticket_Type, Ticket_attachments, Tickettracker, USP_GetTickets_WithFilters_Result, UsertaskAssigned, task_data_dump_cpt, usp_GetTicketsWithFilters_Anum_Result, usp_GetTicketsWithFilters_Result

**Stored procedure/function references:** USP_GetTickets_WithFilters, USP_GetTickets_WithFilters_Result, usp_GetTicketsWithFilters_Anum_Result, usp_GetTicketsWithFilters_Result


## User Management and Permissions

Business purpose: User Management and Permissions supports the PMS workflow area implied by its Angular pages, Web API controllers, services, EF models, and database routines. This will be refined after database schema review.

| Route path | Component | Lazy module/redirect | Source |
| --- | --- | --- | --- |
|  | LayoutComponent |  | NPM_UI_BackUp/src/app/app-routing.module.ts |
| eligblity | EligblityComponent | ./tickettracker/tickettracker.module#TickettrackerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ticket-tracker | TicketResponseComponent | ./tickettracker/tickettracker.module#TickettrackerModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| users |  | ./user-management/user-management.module#UserManagementModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| OfficeMGM |  | ./officemanagement/officemanagement.module#OfficemanagementModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| Tasks |  | ./tasks/tasks.module#TasksModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| FeeSchedule |  | ./fee-schedule/fee-schedule.module#FeeScheduleModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| procedures |  | ./setups/Procedures/procedures.module#proceduresModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| diagnosis |  | ./setups/dx/dx.module#dxModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ndc |  | ./setups/ndc/ndc.module#ndcModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| credentialing | ErrorPageComponent | ./credentialing/credentialing.module#CredentialingModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| importwizard | ErrorPageComponent | ./import-wizard/import-wizard.module#ImportWizardModule | NPM_UI_BackUp/src/app/app-routing.module.ts |
| 404 | ErrorPageComponent | /404 | NPM_UI_BackUp/src/app/app-routing.module.ts |
| ** |  | /404 | NPM_UI_BackUp/src/app/app-routing.module.ts |
|  | CredAppListComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| credApp | CredAppListComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| credPortal | CredPortalComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| credPortal | CredPortalComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
| CredTasks | CredTasksComponent |  | NPM_UI_BackUp/src/app/credentialing/credentialing-routing.module.ts |
|  | ImportWizardMainComponent |  | NPM_UI_BackUp/src/app/import-wizard/import-wizard-routing.module.ts |
|  | OfficemanagementComponent |  | NPM_UI_BackUp/src/app/officemanagement/officeManagementRouting.module.ts |
|  | DXComponent |  | NPM_UI_BackUp/src/app/setups/dx/dxRouting.module.ts |
|  | NdcComponent |  | NPM_UI_BackUp/src/app/setups/ndc/ndc-routing.module.ts |
|  | ProceduresComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
|  | ListProceduresComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
| list | ListProceduresComponent |  | NPM_UI_BackUp/src/app/setups/Procedures/proceduresRouting.module.ts |
| detail/:id | InsNameSetupDetailsComponent | insPayer | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| procedures | ProceduresComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | ListProceduresComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
| list | ListProceduresComponent |  | NPM_UI_BackUp/src/app/setups/setupRouting.module.ts |
|  | TasksComponent |  | NPM_UI_BackUp/src/app/tasks/tasks-routing.module.ts |
| accountlevel | AccountLevelComponent |  | NPM_UI_BackUp/src/app/tasks/tasks-routing.module.ts |
|  | TicketTrackerComponent |  | NPM_UI_BackUp/src/app/tickettracker/tickettracker-routing.module.ts |
| create-ticket | CreateTicketComponent |  | NPM_UI_BackUp/src/app/tickettracker/tickettracker-routing.module.ts |
| create-ticket/:id/:trailid | CreateTicketComponent |  | NPM_UI_BackUp/src/app/tickettracker/tickettracker-routing.module.ts |
| module | ModuleComponent | module | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | ModuleDetailComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| role | RoleComponent | role | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | RoleDetailComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| submodule | SubModulesComponent | submodule | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | SubModuleDetailComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| properties | PropertiesComponent | properties | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | DetailPropertiesComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| users | UsersComponent | users | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | UserDetailComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| employees | EmployeesComponent | employees | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| detail/:id | EmployeeDetailComponent | rights | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| rights | RoleRightsComponent | rights | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
|  | RoleWiseRightsComponent | rights | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| rolewise | RoleWiseRightsComponent |  | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| userwise | UsersWiseRightsComponent |  | NPM_UI_BackUp/src/app/user-management/userManagementRouting.module.ts |
| Component | Selector | Folder |
| --- | --- | --- |
| EmployeeDetailComponent | app-employee-detail | NPM_UI_BackUp/src/app/user-management/employees/employee-detail |
| EmployeesComponent | app-employees | NPM_UI_BackUp/src/app/user-management/employees |
| ListEmployeesComponent | app-list-employees | NPM_UI_BackUp/src/app/user-management/employees/list-employees |
| ListModuleComponent | app-list-module | NPM_UI_BackUp/src/app/user-management/module/list-module |
| ModuleDetailComponent | app-module-detail | NPM_UI_BackUp/src/app/user-management/module/module-detail |
| ModuleComponent | app-module | NPM_UI_BackUp/src/app/user-management/module |
| DetailPropertiesComponent | app-detail-properties | NPM_UI_BackUp/src/app/user-management/properties/detail-properties |
| ListPropertiesComponent | app-list-properties | NPM_UI_BackUp/src/app/user-management/properties/list-properties |
| PropertiesComponent | app-properties | NPM_UI_BackUp/src/app/user-management/properties |
| ListRoleComponent | app-list-role | NPM_UI_BackUp/src/app/user-management/role/list-role |
| RoleDetailComponent | app-role-detail | NPM_UI_BackUp/src/app/user-management/role/role-detail |
| RoleComponent | app-role | NPM_UI_BackUp/src/app/user-management/role |
| RoleRightsComponent | app-role-rights | NPM_UI_BackUp/src/app/user-management/role-rights |
| RoleWiseRightsComponent | app-role-wise-rights | NPM_UI_BackUp/src/app/user-management/role-rights/role-wise-rights |
| UsersWiseRightsComponent | app-users-wise-rights | NPM_UI_BackUp/src/app/user-management/role-rights/users-wise-rights |
| ListSubModuleComponent | app-list-sub-module | NPM_UI_BackUp/src/app/user-management/sub-modules/list-sub-module |
| SubModuleDetailComponent | app-sub-module-detail | NPM_UI_BackUp/src/app/user-management/sub-modules/sub-module-detail |
| SubModulesComponent | app-sub-modules | NPM_UI_BackUp/src/app/user-management/sub-modules |
| UserManagementComponent | app-user-management | NPM_UI_BackUp/src/app/user-management |
| HTTP | Endpoint | Return | Params | Controller file |
| --- | --- | --- | --- | --- |
| GET | api/Credentialing/GetUsersByModuleName | ResponseModel | string moduleName | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:190 |
| GET | api/Credentialing/GetCredUserByRole | ResponseModel | string Role | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:212 |
| GET | api/Credentialing/GetCredUserListByRole | ResponseModel | string Role, long practiceId | NPM_API_BackUp/NPMAPI/Controllers/CredentialingController.cs:218 |
| ANY | api/UserManagementSetup/GetModulesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:20 |
| GET | api/UserManagementSetup/GetModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:25 |
| GET | api/UserManagementSetup/DeleteModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:30 |
| POST | api/UserManagementSetup/SaveModule | ResponseModel | [FromBody] ModuleViewModel Model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:35 |
| GET | api/UserManagementSetup/GetUsersList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:52 |
| GET | api/UserManagementSetup/verifyEmail | ResponseModel | string vEmail | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:58 |
| GET | api/UserManagementSetup/empIdExists | ResponseModel | long vEmpId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:66 |
| POST | api/UserManagementSetup/SaveUser | ResponseModel | [FromBody] UserCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:73 |
| GET | api/UserManagementSetup/GetUser | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:100 |
| POST | api/UserManagementSetup/ResetPassword | ResponseModel | [FromBody] ResetPasswordViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:127 |
| POST | api/UserManagementSetup/ResetPasswordByUser | ResponseModel | [FromBody] ResetPasswordForuserViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:144 |
| GET | api/UserManagementSetup/DeleteUser | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:172 |
| POST | api/UserManagementSetup/ChangeUserStatus | ResponseModel | [FromBody] UserStatusChangeViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:177 |
| GET | api/UserManagementSetup/GetUsersSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:189 |
| GET | api/UserManagementSetup/GetRoleList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:205 |
| POST | api/UserManagementSetup/SaveRole | ResponseModel | [FromBody] RoleViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:211 |
| GET | api/UserManagementSetup/GetRole | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:223 |
| GET | api/UserManagementSetup/DeleteRole | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:229 |
| GET | api/UserManagementSetup/GetRolesSelectList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:235 |
| GET | api/UserManagementSetup/GetTemplateByRoleId | ResponseModel | long roleId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:241 |
| GET | api/UserManagementSetup/GetTemplateByUserId | ResponseModel | long userId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:247 |
| POST | api/UserManagementSetup/SaveRoleModuleProperties | ResponseModel | [FromBody] RoleModulePropertyCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:253 |
| POST | api/UserManagementSetup/SaveUserModuleProperties | ResponseModel | [FromBody] UserModulePropertyCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:265 |
| GET | api/UserManagementSetup/GetSubModuleList | ResponseModel | long? moduleId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:279 |
| GET | api/UserManagementSetup/GetModulesSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:284 |
| GET | api/UserManagementSetup/GetSubModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:289 |
| POST | api/UserManagementSetup/SaveSubModule | ResponseModel | [FromBody] SubModuleViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:294 |
| GET | api/UserManagementSetup/DeleteSubModule | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:306 |
| GET | api/UserManagementSetup/GetSubModulePropertiesList | ResponseModel | long? subModuleId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:314 |
| GET | api/UserManagementSetup/GetSubModuleProperty | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:319 |
| GET | api/UserManagementSetup/GetSubModulesSelectList | ResponseModel | string searchText | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:324 |
| GET | api/UserManagementSetup/GetSubModulesSelectList | ResponseModel | string searchText, long moduleId | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:329 |
| POST | api/UserManagementSetup/SaveSubModuleProperty | ResponseModel | [FromBody] SubModulePropertiesCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:334 |
| GET | api/UserManagementSetup/DeleteProperty | ResponseModel | long id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:345 |
| GET | api/UserManagementSetup/GetEmployeesList | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:356 |
| POST | api/UserManagementSetup/SaveEmployee | ResponseModel | [FromBody] EmployeeCreateViewModel model | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:362 |
| GET | api/UserManagementSetup/GetEmployee | ResponseModel | long Id | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:374 |
| GET | api/UserManagementSetup/GetListsOfSelectLists | ResponseModel |  | NPM_API_BackUp/NPMAPI/Controllers/UserManagementSetupController.cs:380 |
| Service | Representative methods | File |
| --- | --- | --- |
| UserManagementService | GetModule, GetModulesList, SaveModule, DeleteModule, GetModulesSelectList, GetUsersList, SaveUser, GetUser, ResetPasswordForOTP, ResetPassword, ResetPasswordForUser, DeleteUser, ChangeUserStatus, GetUsersSelectList, GetUser, GetUserRoleAndRights, verifyEmail, empIdExists | NPM_API_BackUp/NPMAPI/Services/UserManagementService.cs |
**Database model/table candidates:** CLC_Assigned_Roles, CLC_Roles, Employee, EmployeeInformation, Module, ModuleViewModel, Module_Properties, Module_Properties_bkp20230821, Module_Properties_bkp2023_08_21, Role, Roles_Module_Properties, Sub_Module, Users_Module_Properties, Users_Module_Properties_bkp20230821, Users_Roles, office_employees, rolesss

**Stored procedure/function references:** SP_Date_Of_Birth, SP_Employee_Id, SP_First_Name, SP_Gender, SP_Last_Name, SP_Middle_Initial, SP_Nic_Number, SP_Relation, USP_GETCredUsersByRole, USP_GETUsersListByRole

