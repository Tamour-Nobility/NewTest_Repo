# SMS Codex Project Context Master

**Purpose:** Standalone implementation handoff for a new Codex/ChatGPT account.  
**Product:** Existing web-based, multi-tenant, multi-campus SaaS School Management System.  
**Market direction:** Pakistan-first, extensible to broader markets.  
**Primary principle:** **Connected workflows over disconnected modules.**

---

## 1. Read-First Rule

This is **not a greenfield project**. The application already has broad functionality. Before creating any new feature, inspect the existing repository, database, migrations, routes, permissions, role-specific views, background jobs, integrations and tests.

A prior product review was read-only, so a feature described as "missing" may already exist behind another role, hidden navigation, unfinished wiring or an unpopulated workflow.

### Required classification before implementation

For every requested feature, classify it as:

- **FIX** — existing behavior is materially wrong or unsafe
- **ENHANCE** — existing feature should be extended
- **VERIFY** — behavior/existence is uncertain and must be inspected/tested
- **MISSING** — confirmed absent after code/schema inspection
- **STRATEGIC** — later differentiator, not core operational work

**Never create a parallel module before proving the existing capability cannot be extended.**

---

## 2. Existing Product Capabilities

The current codebase already includes substantial foundations in:

- Campuses
- Academic Years
- Classes
- Sections
- Subjects
- Student admission
- Student profile and lifecycle
- Student documents
- Guardians
- Teachers and staff
- HR organization/contracts/leave/attendance/performance/training/recruitment
- Student attendance
- Fee heads/structures/invoices/receipt publishing/reports
- Academic planning/calendar/curriculum/lesson plans/resources/teacher diary
- Timetable
- Homework
- Exams/marks/results
- Advanced question bank
- Question papers
- Online assessments and marking
- Library
- Transport
- Hostel
- Accounting/finance/budgets/bank reconciliation
- Inventory
- Expenses
- Payroll
- Certificates
- ID cards
- Communications/notices
- Reporting/assurance/compliance/audit/backups/retention
- Subscription display
- Roles/permissions
- User security
- Help center

Protect this breadth. Most future work should improve depth, integration and configurability.

---

## 3. Known Review Limitations

The prior review did **not** prove:

- save/update/delete behavior
- real payment handling
- result publishing behavior
- backend authorization enforcement
- JavaScript-heavy interaction behavior
- mobile/responsive quality
- actual notification delivery
- real workflow performance under populated production-like data

Therefore repository inspection and disposable test data are required before final implementation decisions.

---

## 4. Immediate Technical Risks (Wave 0)

Address before large feature expansion:

1. Intermittent HTTP 500/503 behavior
2. Tenant isolation validation across reads/writes/files/exports/jobs/APIs
3. Campus-scoped authorization
4. Backup Assurance score accuracy
5. Audit redaction of secrets/sensitive values
6. Export-specific permissions and logging
7. Inconsistent campus-scope terminology
8. Clear validation/error handling
9. Safe bulk operations with preview and retry behavior
10. Immutable/reversible handling of high-impact records

---

## 5. Core Architecture Principles

### 5.1 Tenant isolation
Every tenant-owned entity/query/command/file/export/job/notification must be server-side scoped.

Never use UI hiding as a security boundary.

### 5.2 Campus-aware authorization
Think conceptually as:

`Tenant + Campus Scope + Role + Permission + Record Relationship`

Examples:
- school owner: school-wide
- principal: assigned campus(es)
- teacher: assigned students/classes unless separately authorized
- accountant: allowed campuses + financial permissions
- parent: linked children only

### 5.3 One scope vocabulary
Use:
- **School-wide**
- **Selected Campuses**
- **Single Campus**

Avoid ambiguous "Default", "All", "Tenant Wide" combinations unless explicitly defined.

### 5.4 Common lifecycle pattern
Where relevant:

`Draft → Submitted → Approved → Posted/Published → Corrected/Reversed/Cancelled`

Do not silently overwrite published financial/academic history.

### 5.5 Effective-dated configuration
Preserve history for:
- fee structures
- grading scales
- salary structures
- curricula
- organization assignment
- transport routes/assignments
- rules and policies

### 5.6 Auditability
Record when appropriate:
- actor
- timestamp
- tenant/campus
- entity/action
- reason
- safe old/new values
- approval
- request/correlation ID

Never audit passwords, reset tokens, payment credentials or unnecessary highly sensitive content.

### 5.7 Preview / dry run
Use before:
- recurring billing
- late-fee generation
- promotion
- rollover
- bulk communication
- payroll generation
- bank matching
- data imports
- bulk edits

### 5.8 Idempotency
Retries must not duplicate:
- invoices
- notifications
- accounting postings
- payroll runs
- external sync records

---

## 6. Product Design Principles

### One authoritative person/family model
Reuse identities across modules instead of duplicating names/contact data.

Examples:
- library member → Student/Employee
- transport driver → Employee/Contractor
- parent shared across siblings
- Employee feeds HR, payroll, timetable, assets

### Configuration over customization
Target 80–90% of school variation through configuration rather than branches/custom code.

High-value configurable areas:
- custom fields
- forms
- grading
- fee rules
- approvals
- notifications
- attendance rules
- curricula
- document templates
- report templates
- numbering schemes
- master data

### Role-specific experiences
Expected distinct experiences:
- Owner/Principal
- Teacher
- Accountant/Cashier
- HR
- Admissions/Reception
- Librarian
- Transport
- Hostel
- Parent
- Student
- SaaS Platform Operator

### Action-oriented dashboards
Dashboards should answer:
- What needs attention?
- What is overdue?
- What failed?
- What changed?
- What requires approval?

---

## 7. Connected Workflow Targets

### Admissions
`Inquiry → Application → Documents → Test/Interview → Offer → Acceptance → Admission Fee → Student/Household → Class Assignment → Portal → Welcome`

### Attendance
`Teacher My Day → Mark → Finalize → Absence Rules → Guardian Notification → Consecutive-Absence Check → Intervention Task`

### Academics
`Curriculum → Learning Outcome → Lesson Plan → Timetable → Delivery → Homework/Assessment → Gradebook → Intervention → Report Card`

### Fees
`Fee Structure → Billing Preview → Invoice → Parent Notification → Payment → Reconciliation → Receipt → GL Posting → Aging/Collections`

### Teacher Leave
`Leave Request → Approval → Affected Timetable → Substitute Suggestion → Assignment → Notification → Workload Update`

### Transport
`Assignment → Route/Stop → Fee Charge → Boarding → Guardian Alert → School Arrival → Return Boarding → Drop Alert`

### Student Transfer
`Request → Fee/Library/Hostel/Asset Clearance → Approval → Transfer Certificate → Enrollment History → Portal/Access Adjustment`

### Procurement
`Requisition → Budget Check → Approval → Quotations → PO → Goods Receipt → Inventory/Asset → Supplier Invoice → AP → Payment → Reconciliation`

---

## 8. Highest-Value Roadmap Gaps

Keep these visible even when working deeply in a single module:

1. Admissions CRM + online admissions
2. Household/family model
3. Student 360
4. Parent portal
5. Student portal
6. Health/clinic
7. Behavior/discipline
8. Counseling/wellbeing
9. Period attendance + attendance alerts
10. Teacher My Day
11. Master timetable + substitution
12. Continuous gradebook
13. Report-card designer/transcripts
14. Result moderation/locking
15. Recurring fee billing
16. Bank/payment reconciliation
17. Refund/credit/advance handling
18. Defaulter collections workflow
19. WhatsApp/provider integration
20. Rules/workflow automation engine
21. Task/escalation engine
22. Exception queues
23. Houses/clubs/sports/trips
24. Pickup/gate/visitor management
25. Transport daily/live operations
26. Procurement/vendors/assets/maintenance
27. Configurable forms/custom fields/reports
28. Role-specific dashboards
29. Global search
30. SaaS entitlements/white labeling
31. APIs/webhooks
32. School Command Center
33. AI only after operational data/workflows are reliable

---

## 9. Recommended Codex Implementation Waves

### Wave 0 — Stability & Security
- 500/503 diagnostics
- tenant isolation audit
- campus scope
- audit redaction
- backup Assurance correction
- error/validation framework
- irreversible-action controls

### Wave 1 — Core Configuration
- global campus/year context
- School Settings
- master data
- grading
- rooms/resources
- year opening/closing
- reusable approvals/lifecycle foundations

### Wave 2 — Admissions → Student → Family
- admissions CRM
- public application
- application/test/interview/offer flow
- household model
- Student 360
- document workflow
- enrollment conversion

### Wave 3 — Parent & Student Experience
- parent portal
- multi-child household
- student portal
- forms/consents
- leave requests
- notification center
- PWA/mobile/low-bandwidth UX

### Wave 4 — Attendance & Daily Operations
- explicit Unmarked state
- period attendance
- correction workflow
- absence alerts
- Teacher My Day
- substitution integration
- optional offline attendance

### Wave 5 — Academics
- learning outcomes
- master timetable/conflict engine
- teacher workload
- gradebook
- homework improvements
- results moderation
- report cards/transcripts

### Wave 6 — Fees
- recurring billing
- duplicate protection
- installments
- sibling discounts
- concessions/scholarships
- late fees
- advances/overpayments/refunds/credits
- family statements
- cashier/day close
- bank import/reconciliation
- defaulter workflow

### Wave 7 — Communications & Automation
- provider abstraction
- WhatsApp/SMS/email diagnostics
- multilingual templates
- workflow/rules engine
- tasks/escalations
- exception queues
- automation history/dry run

### Wave 8 — Student Life & Safety
- health/clinic
- immunization/medication
- counseling
- behavior
- houses
- clubs/sports
- trips
- pickup/gate/visitor workflows

### Wave 9 — Operational Modules
- transport stops/live ops/alerts
- hostel daily operations
- library barcode/reservations/fine automation
- optional canteen/student wallet

### Wave 10 — HR / Payroll / ERP
- employee lifecycle
- shifts
- onboarding/offboarding
- structured payroll components
- payroll approval/GL
- procurement
- vendors/AP
- assets
- maintenance

### Wave 11 — SaaS Platform
- subscription entitlements
- usage metering
- guided tenant onboarding
- white label/custom domain
- MFA/SSO
- support impersonation
- APIs/webhooks
- integration health

### Wave 12 — Intelligence
- School Command Center
- configurable dashboards/reports
- advanced analytics
- AI copilots only after reliable workflows/data

---

## 10. Features That Must Not Be Accidentally Rebuilt

Inspect and extend these existing areas first:

- Student Lifecycle
- Student Documents
- HR / Leave / Performance / Recruitment
- Finance / Journals / Bank Reconciliation
- Academic Planning
- Question Bank
- Question Papers
- Online Assessments
- Library
- Transport
- Hostel
- Communications/templates
- Assurance/Audit/Backup
- Roles & Permissions
- Certificates
- ID Cards

---

## 11. Pakistan-Fit Requirements

Where relevant, support:

- PKR
- B-Form/CRC vs adult CNIC/NICOP/passport identity types
- domestic phone numbers normalized to +92
- Urdu + English templates
- RTL rendering
- cash collection and bank deposits
- printable challans/receipts
- approved Raast/payment-provider integrations
- configurable board/curriculum
- low-bandwidth/mobile workflows
- effective-dated tax/payroll rules rather than hard-coded values

Do not claim regulatory/tax compliance without current specialist validation.

---

## 12. Standard Implementation Brief Codex Should Produce Before Coding

For each feature, first report:

### A. Existing state
- routes/screens
- entities/tables
- services
- permissions
- jobs/events
- tests

### B. Classification
FIX / ENHANCE / VERIFY / MISSING / STRATEGIC

### C. Desired workflow
State transitions and actors.

### D. Data impact
- tables/columns
- relationships/indexes
- migration/backfill
- tenant/campus scope
- historical/effective dating

### E. Backend impact
- service/domain logic
- validation
- authorization
- APIs
- jobs/events
- idempotency

### F. UI impact
- screens/components
- validation
- role visibility
- bulk preview
- empty states
- mobile behavior

### G. Audit/security
- sensitive fields
- permissions
- audit
- approvals
- irreversible actions

### H. Tests
At minimum consider:
- happy path
- validation
- tenant isolation
- campus scope
- role permissions
- duplicates
- retries/idempotency
- historical integrity
- corrections/reversals
- bulk scale

### I. Rollout
- migration
- backfill
- feature flag
- seed/default configuration
- compatibility with existing tenants

---

## 13. Non-Negotiable Quality Themes

Every substantial feature should be evaluated for:

- tenant isolation
- campus authorization
- permissions
- auditability
- validation
- duplicate prevention
- idempotency
- historical integrity
- correction/reversal
- failure/retry
- accessibility
- mobile/responsive behavior
- data privacy
- import/export
- configurable policy instead of unnecessary hard-coding

---

## 14. Prompt to Use in a New Codex Account

After uploading this file and the archive, use:

> Read `SMS_Codex_Project_Context_Master.md` and `SMS_Product_Improvement_Conversation_Archive.md` completely before proposing changes. Treat them as project context. Inspect the current repository to verify which capabilities already exist. Do not implement anything until you classify the requested item as FIX, ENHANCE, VERIFY, MISSING, or STRATEGIC and explain the existing implementation you found. Prefer extending existing modules over creating duplicates. Preserve tenant/campus isolation, auditability, historical integrity, preview/dry-run for bulk actions, retry/idempotency and the agreed Wave 0–12 roadmap.

For best results also upload:
- `SMS_UI_Inventory.md`
- `SMS_Product_Review.md`
- `SMS_Final_Recommendation_and_Codex_Roadmap.docx`
- the actual repository

---

## 15. Final Product Direction

**Current state:** Broad school-management/ERP foundation with substantial functionality already represented.

**Target state:** A configurable, secure, multi-tenant, multi-campus **School Operating Platform** where Admissions, Students, Families, Teachers, Academics, Attendance, Fees, Communications, Finance and Operations behave as connected processes.

The long-term differentiator is not the raw module count.

It is:

> **One authoritative data model + connected workflows + configurable rules + automation + role-specific experiences + trustworthy analytics.**
