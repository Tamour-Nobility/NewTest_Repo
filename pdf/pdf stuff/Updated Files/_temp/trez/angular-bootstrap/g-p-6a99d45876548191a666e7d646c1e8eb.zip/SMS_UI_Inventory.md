# School Management System: Read-only UI inventory

Observed 18 September 2026 through authenticated school-owner page views. This lists controls rendered by the server. No form was submitted; behavior and backend validation remain untested.

The same role-permission layout is represented once. Repeated query variants with the same controls are consolidated. Dynamic record names and identifiers are omitted.

## /

**Screen:** Dashboard - Ali Model School · Dashboard; Attendance Trend; Operational Alerts; Six-Month Collections; Student Distribution.
**Table columns:** Date, Present, Absent, Other, Rate / Month, Collected, Refunded, Net / Campus, Class, Students.

## /Account/ChangePassword

**Screen:** Change Password - School Management · Change password.
**Rendered fields/options:** CurrentPassword (password); NewPassword (password); ConfirmPassword (password).
**Buttons:** Change password and sign out.

## /Campuses

**Screen:** Campus Setup - Ali Model School · Campuses; Campus Directory; Add Campus.
**Rendered fields/options:** Name; Code; Address; Phone; Email; IsActive (checkbox).
**Buttons:** Add Campus.
**Table columns:** Name, Code, Address, Phone, Email, Status, Actions.

## /AcademicYears

**Screen:** Academic Year Setup - Ali Model School · Academic Years; Academic Year Directory; Add Academic Year.
**Rendered fields/options:** Name; StartDate (date); EndDate (date); IsCurrent (checkbox); IsActive (checkbox).
**Buttons:** Add Academic Year.
**Table columns:** Name, Start, End, Current, Status, Action.

## /SchoolClasses

**Screen:** Class Setup - Ali Model School · Classes; Class Directory; Add Class.
**Rendered fields/options:** Name; SortOrder (number); IsActive (checkbox); CampusId (3 choices).
**Buttons:** Add Class.
**Table columns:** Name, Order, Sections, Status, Actions.

## /Sections

**Screen:** Section Setup - Ali Model School · Sections; Section Directory; Add Section.
**Rendered fields/options:** Name; IsActive (checkbox); SchoolClassId (0 choices); CampusId (3 choices).
**Buttons:** Add Section.
**Table columns:** Class, Section, Status, Actions.

## /Subjects

**Screen:** Subject Setup - Ali Model School · Subjects; Subject Directory; Add Subject.
**Rendered fields/options:** Code; Name; IsActive (checkbox); CampusId (3 choices).
**Buttons:** Add Subject.
**Table columns:** Code, Name, Status, Actions.

## /Students

**Screen:** Students - Ali Model School · Students; Student Directory; Promote selected students; Set student password.
**Rendered fields/options:** search; PromotionDate (date); StudentIds (checkbox); NewPassword (password); ConfirmPassword (password); RequirePasswordChange (checkbox); campusId (3 choices); status (All statuses, Applicant, Active, Suspended, Withdrawn, Graduated, Expelled, Alumni); pageSize (10, 20, 50, 100); ToAcademicYearId (2 choices); ToSchoolClassId (1 choices); ToSectionId (1 choices).
**Buttons:** Filters.
**Table columns:** Admission, Student, Class / Section, Campus, Contact, Status, Admission Date, Actions.

## /Students/Create

**Screen:** New Student Admission - Ali Model School · New Student Admission; Student Information; Academic Assignment; Previous School History; Primary Parent / Guardian; Address & Emergency Contact; Medical & Special Needs; Review & Save.
**Rendered fields/options:** PhotoFile (file); AdmissionNumber; AdmissionDate (date); FirstName; LastName; DateOfBirth (date); BloodGroup; NationalId; MobilePhone; Email (email); PreviousSchoolName; PreviousSchoolClass; PreviousSchoolReasonForLeaving; PrimaryGuardianFullName; PrimaryGuardianRelationship; PrimaryGuardianPhone; PrimaryGuardianAlternatePhone; PrimaryGuardianEmail (email); PrimaryGuardianNationalId; PrimaryGuardianOccupation; PrimaryGuardianCity; EmergencyContactName; EmergencyContactPhone; HasSpecialNeeds (checkbox); Gender (Unknown, Male, Female, Other); CampusId (3 choices); ClassId (1 choices); SectionId (1 choices); PrimaryGuardianAddress (long text); Address (long text); MedicalNotes (long text); SpecialNeedsDetails (long text); RequiredAccommodations (long text); Notes (long text).
**Buttons:** 1 Student Information Personal details.

## /ParentGuardians

**Screen:** Parents & Guardians - Ali Model School · Parents & Guardians.
**Rendered fields/options:** search.
**Buttons:** Search.
**Table columns:** Name, Relationship, Phone, Email, Students, Status, Action.

## /Teachers

**Screen:** Teachers - Ali Model School · Teachers.
**Rendered fields/options:** search.
**Buttons:** Search.
**Table columns:** Employee #, Name, Designation, Department, Campus, Phone, Status, Action.

## /StaffMembers

**Screen:** Staff Members - Ali Model School · Staff Members.
**Rendered fields/options:** search.
**Buttons:** Search.
**Table columns:** Employee #, Name, Type, Department, Designation, Phone, Status, Action.

## /Hr

**Screen:** HR & Staff Management - Ali Model School · HR & Staff Management; Employee directory; Workforce health; Add or update department; Add or update designation; Employment contract; Leave policy setup; Request leave.
**Rendered fields/options:** Code ×3; Name ×3; IsActive (checkbox) ×3; Description ×2; Grade; StartDate (date); EndDate (date); ProbationEndDate (date); BaseSalary (number); WeeklyHours (number); NoticePeriodDays (number); year (number); AnnualEntitlementDays (number); MaximumCarryForwardDays (number); IsPaid (checkbox); AllowCarryForward (checkbox); RequiresDocument (checkbox); FromDate (date); ToDate (date); Reason; AttendanceDate (date); CheckInTime (time); CheckOutTime (time); Remarks; fromDate (date); toDate (date); PeriodFrom (date); PeriodTo (date); OverallRating (number); DocumentType; DocumentNumber; IssuedOn (date); ExpiresOn (date); DocumentFile (file); Notes ×3; Title ×2; Provider; StartsOn (date); EndsOn (date); Cost (number); CertificateUrl; ReferenceNumber; Positions (number); OpensOn (date); ClosesOn (date); FullName; Email (email); Phone; InterviewOn (datetime-local); Rating (number); ResumeUrl; CampusId (3 choices); ManagerEmployeeType (3 choices); ManagerEmployeeId (1 choices); DepartmentId (1 choices) ×3; EmployeeType (2 choices) ×6; EmployeeId (1 choices) ×6; DesignationId (1 choices) ×2; ContractType (Permanent, FixedTerm, Probation, PartTime, Visiting, Internship); Status (Draft, Active, Expired, Terminated); LeaveTypeId (1 choices); Status (Present, Absent, Late, HalfDay, OnLeave, Remote, Holiday); Status (Draft, InReview, Acknowledged, Completed); Status (Planned, InProgress, Completed, Cancelled); Status (Draft, Open, Closed, Cancelled); VacancyId (1 choices); Status (Applied, Shortlisted, Interview, Offered, Hired, Rejected, Withdrawn); Terms (long text); Goals (long text); Strengths (long text); ImprovementPlan (long text); Description (long text); Requirements (long text).
**Buttons:** Overview.
**Table columns:** Employee, Type, Department, Designation, Status / Department, Code, Designations, Status / Employee, Contract, Dates, Department, Salary, Status / action / Employee, Leave, Dates, Days, Status, Actions / Date, Employee, Status, Time, Hours, Remarks / Employee, Document, Number, Expiry, Status, Action / Employee, Training, Provider, Dates, Status, Cost.

## /Attendance/Daily

**Screen:** Daily Attendance - Ali Model School · Daily Attendance; Find Students; Mark Attendance.
**Rendered fields/options:** AttendanceDate (date); CampusId (3 choices); AcademicYearId (2 choices); ClassId (1 choices); SectionId (1 choices).
**Buttons:** Load.

## /Attendance/Summary

**Screen:** Attendance Summary - Ali Model School · Attendance Summary; Report Filters; Daily Breakdown.
**Rendered fields/options:** fromDate (date); toDate (date); CampusId (3 choices); ClassId (1 choices); SectionId (1 choices).
**Buttons:** Run Report.
**Table columns:** Date, Total, Present, Absent, Late, Leave.

## /FeeHeads

**Screen:** Fee Heads - Ali Model School · Fee Heads.
**Rendered fields/options:** search.
**Buttons:** Search.
**Table columns:** Code, Name, Default Amount, Required, Status.

## /FeeStructures

**Screen:** Fee Structures - Ali Model School · Fee Structures.
**Table columns:** Name, Academic Year, Class, Section, Cycle, Due Day, Total.

## /FeeInvoices

**Screen:** Fee Invoices - Ali Model School · Fee Invoices.
**Rendered fields/options:** search.
**Buttons:** Search.
**Table columns:** Invoice, Student, Class, Issue, Due, Total, Paid, Balance, Status.

## /FeeReceiptPublishing

**Screen:** Publish Fee Receipts - Ali Model School · Publish Fee Receipts; Delivery Channels; Email Options; SMS Options; Email Preview.
**Rendered fields/options:** search; periodYear (number); EmailEnabled (checkbox); SmsEnabled (checkbox); NotificationEnabled (checkbox); EmailSubject; classId (1 choices); sectionId (1 choices); academicYearId (2 choices); periodMonth (All, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec); paymentStatus (All, Issued, PartiallyPaid, Paid, Overdue); published (All, Unpublished, Published); PublishPreviouslyPublished (Publish only unpublished receipts, Publish all selected receipts again); EmailBody (long text); SmsMessage (long text).
**Buttons:** Apply Filters.
**Table columns:** Student, Class, Guardian, Period, Invoice / Receipt, Dates, Total, Paid, Outstanding, Status, Publish.

## /FeeReceiptPublishing/History

**Screen:** Receipt Publishing History - Ali Model School · Receipt Publishing History.
**Table columns:** Batch, Date, Created By, Fee Period, Channels, Total, Success, Failed, Status.

## /FeeReports/Summary

**Screen:** Fee Summary - Ali Model School · Fee Summary Report.
**Rendered fields/options:** fromDate; toDate; campusId (3 choices); classId (1 choices); sectionId (1 choices).
**Buttons:** Run.

## /AcademicPlanning

**Screen:** Academic Planning & LMS - Ali Model School · Academic Planning & LMS; Add academic term; Add calendar event; Terms; Academic calendar; Add curriculum / syllabus unit; Syllabus coverage; Create lesson plan.
**Rendered fields/options:** Name; Sequence (number) ×2; StartDate (date); EndDate (date); IsCurrent (checkbox); Title ×4; StartsOn (datetime-local); EndsOn (datetime-local); Location; IsAllDay (checkbox); IsPublished (checkbox) ×3; Code; PlannedStartDate (date); PlannedEndDate (date); PlannedPeriods (number); LessonDate (date); PeriodCount (number); ResourceUrl; File (file); EntryDate (date); PeriodsDelivered (number); TopicCovered; StudentsPresent (number); StudentsAbsent (number); academicYearId (2 choices); AcademicYearId (1 choices) ×6; CampusId (3 choices) ×2; AcademicTermId (1 choices); EventType (Academic, Examination, AssignmentDeadline, ParentTeacherMeeting, Activity, Sports, Meeting, Holiday, Other); Audience (Everyone, Students, Teachers, Parents, Staff); SchoolClassId (1 choices) ×4; SubjectId (1 choices) ×4; Status (Planned, InProgress, Completed, Deferred); SectionId (1 choices) ×3; CurriculumUnitId (1 choices) ×3; ResourceType (Document, Video, Audio, Presentation, Link, Worksheet, Recording, Other); Visibility (Students, TeachersOnly, StudentsAndParents); LessonPlanId (1 choices); Description (long text) ×3; LearningObjectives (long text) ×2; PriorKnowledge (long text); TeachingMethod (long text); Activities (long text); Resources (long text); AssessmentMethod (long text); Differentiation (long text); HomeworkNotes (long text); TeachingNotes (long text); StudentEngagement (long text); HomeworkAssigned (long text); Challenges (long text); FollowUpActions (long text).
**Buttons:** Apply.
**Table columns:** Date, Event, Audience, Status / Class / Subject, Unit, Plan, Coverage, Status / Date, Lesson, Teacher, Status, Review / Date, Teacher, Class / Subject, Topic, Periods, Attendance, Follow-up.

## /Timetable

**Screen:** Timetable - Ali Model School · Class Timetable.
**Rendered fields/options:** academicYearId (2 choices); schoolClassId (1 choices); sectionId (1 choices); dayOfWeek (All Days, Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday).
**Buttons:** Filter.
**Table columns:** Day, Time, Class, Subject, Teacher, Room, Status.

## /Homework

**Screen:** Homework - Ali Model School · Homework & Assignments.
**Rendered fields/options:** search; status (All Status, Draft, Assigned, Closed).
**Buttons:** Filter.
**Table columns:** Title, Class, Subject / Unit, Due, Status, Submissions.

## /Exams

**Screen:** Exams - Ali Model School · Exams.
**Table columns:** Name, Academic Year, Class, Dates, Status, Results.

## /QuestionBank

**Screen:** Question Bank - Ali Model School · Question Bank; Add to Paper; Student Question Preview.
**Rendered fields/options:** unnamed select (All / Generic); unnamed select (All Subjects); unnamed select (All Types, SingleCorrectMcq, MultipleCorrectMcq, TrueFalse, ShortAnswer, DetailedAnswer, FillInTheBlank, Matching, ImageHotspot); unnamed select (All Levels, Easy, Medium, Hard, Advanced); unnamed select (All Statuses, Draft, Active, Archived); unnamed select (Select paper); unnamed select (Select section).
**Buttons:** Apply Filters.
**Table columns:** Question, Type, Class, Subject, Topic, Difficulty, Marks, Usage, Status, Actions.

## /QuestionPapers

**Screen:** Question Papers - Ali Model School · Question Papers.
**Rendered fields/options:** unnamed select (All years, 2026-2027); unnamed select (All classes); unnamed select (All subjects); unnamed select (All statuses, Draft, Ready, Published, Closed, Archived).
**Buttons:** Apply.
**Table columns:** Paper, Year / Exam, Class / Subject, Duration, Marks, Questions, Status, Actions.

## /OnlineAssessments

**Screen:** Online Assessments - Ali Model School · Online Assessments.
**Rendered fields/options:** status (All statuses, Draft, Published, Closed, Archived).
**Buttons:** Filter.
**Table columns:** Assessment, Class / Subject, Availability, Configuration, Audience, Status.

## /StudentAssessments

**Screen:** My Assessments - Ali Model School · My Assessments; Nothing here yet.
**Buttons:** Available 0.

## /StudentAssessmentResults

**Screen:** My Assessment Results - Ali Model School · My Assessment Results; No released results yet.

## /AssessmentMarking

**Screen:** Assessment Marking - Ali Model School · Assessment Marking.
**Table columns:** Assessment, Class / Subject, Attempts, Awaiting teacher, Graded.

## /AssessmentResults

**Screen:** Assessment Results - Ali Model School · Assessment Results.
**Table columns:** Assessment, Exam integration, Marking, Release.

## /Results/Summary

**Screen:** Result Summary - Ali Model School.
**Rendered fields/options:** examId (2 choices).
**Buttons:** View Results.

## /LibraryBooks

**Screen:** Library Books - Ali Model School · Library Books.
**Rendered fields/options:** search; category.
**Buttons:** Filter.
**Table columns:** Book, Accession, Category, Shelf, Copies, Available.

## /LibraryMembers

**Screen:** Library Members - Ali Model School · Library Members.
**Rendered fields/options:** search; memberType (5 choices).
**Buttons:** Filter.
**Table columns:** Member, Code, Type, Phone, Active Issues, Status.

## /LibraryIssues

**Screen:** Library Issues - Ali Model School · Book Issue & Return.
**Rendered fields/options:** search; status (All Status, Issued, Returned, Overdue, Lost, Cancelled).
**Buttons:** Filter.
**Table columns:** Book, Member, Issue Date, Due Date, Status, Fine.

## /LibraryReports/Summary

**Screen:** Library Summary - Ali Model School · Library Summary.

## /TransportRoutes

**Screen:** Transport Routes - Ali Model School · Transport Routes.
**Rendered fields/options:** search.
**Buttons:** Filter.
**Table columns:** Route, Path, Monthly Fee, Stops, Students, Status.

## /TransportVehicles

**Screen:** Transport Vehicles - Ali Model School · Transport Vehicles.
**Rendered fields/options:** search.
**Buttons:** Filter.
**Table columns:** Vehicle, Registration, Type, Capacity, Driver, Students.

## /TransportAssignments

**Screen:** Transport Assignments - Ali Model School · Student Transport Assignments.
**Rendered fields/options:** search.
**Buttons:** Filter.
**Table columns:** Student, Route, Stop, Vehicle, Monthly Fee, Status.

## /TransportReports/Summary

**Screen:** Transport Summary - Ali Model School · Transport Summary.

## /HostelBuildings

**Screen:** Hostel Buildings - Ali Model School · Hostel Buildings.
**Rendered fields/options:** search.
**Buttons:** Search.
**Table columns:** Code, Name, Campus, Warden, Rooms, Beds, Occupied, Status.

## /HostelRooms

**Screen:** Hostel Rooms - Ali Model School · Hostel Rooms.
**Table columns:** Building, Room, Floor, Type, Capacity, Beds, Occupied, Status.

## /HostelBeds

**Screen:** Hostel Beds - Ali Model School · Hostel Beds.
**Table columns:** Building, Room, Bed, Status, Monthly Fee, Active.

## /HostelAllocations

**Screen:** Hostel Allocations - Ali Model School · Hostel Allocations.
**Rendered fields/options:** search.
**Buttons:** Search.
**Table columns:** Student, Building, Room/Bed, Start, Monthly Fee, Status.

## /HostelReports/Summary

**Screen:** Hostel Summary - Ali Model School · Hostel Capacity Summary.
**Table columns:** Available Beds, Occupied Beds, Maintenance Beds, Monthly Hostel Receivable, Security Deposits Held.

## /Finance

**Screen:** Finance & Accounting - Ali Model School · Finance & Accounting; Income statement; Balance sheet; Position; Trial balance; Add or edit account; Fiscal period; Manual journal voucher.
**Rendered fields/options:** fromDate (date); toDate (date); Code; Name ×2; Description ×2; IsControlAccount (checkbox); AllowManualPosting (checkbox); IsActive (checkbox) ×2; StartDate (date); EndDate (date); EntryDate (date); ReferenceNumber; Lines[0].Description; Lines[0].Debit (number); Lines[0].Credit (number); Lines[1].Description; Lines[1].Debit (number); Lines[1].Credit (number); Lines[2].Description; Lines[2].Debit (number); Lines[2].Credit (number); Lines[3].Description; Lines[3].Debit (number); Lines[3].Credit (number); Amount (number); Notes ×2; StatementDate (date); StatementBalance (number); DepositsInTransit (number); OutstandingPayments (number); OtherAdjustments (number); Complete (checkbox); campusId (3 choices); AccountType (5 choices); Category (Cash, Bank, Receivable, OtherCurrentAsset, FixedAsset, Payable, OtherCurrentLiability, LongTermLiability, Capital, RetainedEarnings, FeeIncome, OtherIncome, PayrollExpense, OperatingExpense, DepreciationExpense); ParentAccountId (1 choices); CampusId (3 choices) ×2; Lines[0].FinanceAccountId (1 choices); Lines[1].FinanceAccountId (1 choices); Lines[2].FinanceAccountId (1 choices); Lines[3].FinanceAccountId (1 choices); FiscalPeriodId (2 choices); FinanceAccountId (1 choices) ×2; Status (Draft, Approved, Closed).
**Buttons:** Apply.
**Table columns:** Code, Account, Type, Debit, Credit, Net / Code, Account, Type, Category, Balance, Status / Period, Dates, Campus, Status / Account, Description, Debit, Credit / Date, Voucher, Description, Source, Debit / Credit, Status / Period, Account, Budget, Actual, Variance, Status / Date, Account, Statement, Book, Reconciled, Difference, Status.

## /Inventory

**Screen:** Inventory - Ali Model School · Inventory.
**Table columns:** Code, Item, Category, Stock, Unit Cost, Value, Status.

## /Expenses

**Screen:** Expenses - Ali Model School · Expenses.
**Table columns:** Date, Voucher, Payee, Category, Amount, Status.

## /Payroll

**Screen:** Payroll - Ali Model School · Payroll; Payroll Runs; Active Salary Structures.
**Rendered fields/options:** Month (number); Year (number); CampusId (3 choices).
**Buttons:** Generate Payroll.
**Table columns:** Period, Employees, Gross, Deductions, Net, Status / Employee, Type, Basic, Allowances, Deductions, Net.

## /Certificates

**Screen:** Certificates - Ali Model School · Certificates.
**Table columns:** Number, Student, Type, Date, Status.

## /IdCards

**Screen:** ID Cards - Ali Model School · ID Cards.
**Table columns:** Card, Holder, Type, Validity, Status.

## /Communications

**Screen:** Communication & Engagement - Ali Model School · Communication & Engagement; Start a private student conversation; Schedule parent-teacher meeting; Create survey or poll; Reusable email and SMS templates.
**Rendered fields/options:** Subject ×2; StartsOn (datetime-local); EndsOn (datetime-local); LocationOrLink; Agenda; Title; Question; ClosesOn (datetime-local); Options[0]; Options[1]; Options[2]; Options[3]; AllowComment (checkbox); IsAnonymous (checkbox); Name; IsActive (checkbox); StudentId (1 choices) ×2; TeacherId (1 choices) ×2; Mode (InPerson, Online, Phone); Audience (Everyone, Students, Parents, Teachers, Staff, Class, Section); SchoolClassId (1 choices); SectionId (1 choices); Channel (Email, Sms); Message (long text); Body (long text).
**Buttons:** Conversations 0.
**Table columns:** Date, Student / teacher, Mode, Status, Agenda, Actions / Name, Channel, Subject, Status.

## /Notices

**Screen:** Notices - Ali Model School · Notices.
**Rendered fields/options:** search.
**Buttons:** Search.

## /Reports

**Screen:** Operational Reports - Ali Model School · Operational Reports; Attendance Trend; Operational Alerts; Six-Month Collections; Student Distribution.
**Rendered fields/options:** fromDate (date); toDate (date).
**Buttons:** Refresh.
**Table columns:** Date, Present, Absent, Other, Rate / Month, Collected, Refunded, Net / Campus, Class, Students.

## /Assurance

**Screen:** Reporting, Compliance & Reliability - Ali Model School · Reporting, Compliance & Reliability; Unassigned class or section; Missing date of birth; Missing guardian link; Missing health profile; Employees without active contract; Failed notification deliveries; Overdue obligations.
**Rendered fields/options:** Code; Title ×2; Category; RegulatoryAuthority; Owner; DueDate (date); RenewalDays (number); IsActive (checkbox) ×3; CorrectiveActionDueDate (date); Name; RecipientEmails; NextRunOn (datetime-local); fromDate (date); toDate (date); auditEntity; auditSearch; ReferenceNumber; Service; DetectedOn (datetime-local); Impact; RootCause; CorrectiveAction; ResolutionNotes; BackupType; StorageLocation; StartedOn (datetime-local); CompletedOn (datetime-local); SizeBytes (number); RestoreTested (checkbox); RestoreTestedOn (datetime-local); Notes ×2; DataCategory; RetentionDays (number); LegalHold (checkbox); Risk (Low, Medium, High, Critical); Status (Draft, Compliant, AtRisk, NonCompliant, Waived); ReportKind (Executive, Enrollment, Attendance, Finance, HumanResources, Compliance, Audit, Reliability); Frequency (Daily, Weekly, Monthly, Quarterly); Severity (Low, Medium, High, Critical); Status (Open, Investigating, Monitoring, Resolved); Status (Planned, Running, Succeeded, Failed); Disposition (Review, Archive, Anonymize, Delete); Findings (long text); CorrectiveAction (long text).
**Buttons:** Assurance.
**Table columns:** Name, Report, Next run, Status / Started, Report, Rows, Status, Snapshot / Timestamp, User, Action, Entity, Trace, Changes / Reference, Service / impact, Severity, Status, Detected / Started, Type, Protected location, Status, Restore tested, Verifier / Category, Retention, Disposition, Legal hold, Last reviewed, Status.

## /Subscriptions

**Screen:** Subscriptions - Ali Model School · Subscriptions; Standard Trial.

## /Security

**Screen:** Roles & Permissions - Ali Model School · Roles & Permissions; System Roles; Permission Catalog; Academic; Academic Planning; Assessments; Attendance; Audit Logs.
**Table columns:** Role, Description, Action.

## /Help

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Help articles; Getting Started; Dashboard; Student List; New Student Admission; Student Profile.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Campuses/Edit/{id}

**Screen:** Campus Setup - Ali Model School · Campuses; Campus Directory; Edit Campus.
**Rendered fields/options:** Name; Code; Address; Phone; Email; IsActive (checkbox).
**Buttons:** Add Campus.
**Table columns:** Name, Code, Address, Phone, Email, Status, Actions.

## /AcademicYears/Edit/{id}

**Screen:** Academic Year Setup - Ali Model School · Academic Years; Academic Year Directory; Edit Academic Year.
**Rendered fields/options:** Name; StartDate (date); EndDate (date); IsCurrent (checkbox); IsActive (checkbox).
**Buttons:** Add Academic Year.
**Table columns:** Name, Start, End, Current, Status, Action.

## /Students/Details/{id}

**Screen:** Student Profile - Ali Model School · Student Profile; Personal Information; Parents / Guardians; Health & Emergency Information; Add Parent / Guardian; Set student password.
**Rendered fields/options:** FullName; Relationship; Phone; AlternatePhone; Email (email); NationalId; Occupation; City; IsPrimaryContact (checkbox); NewPassword (password); ConfirmPassword (password); RequirePasswordChange (checkbox); Address (long text).
**Buttons:** Overview.

## /Students/Edit/{id}

**Screen:** Edit Student - Ali Model School · Edit Student; Personal Information; Academic Assignment; Emergency & Notes.
**Rendered fields/options:** PhotoFile (file); AdmissionNumber; AdmissionDate (date); Status; FirstName; LastName; DateOfBirth (date); BloodGroup; NationalId; MobilePhone; Email (email); PreviousSchoolName; EmergencyContactName; EmergencyContactPhone; Gender (Unknown, Male, Female, Other); CampusId (3 choices); ClassId (1 choices); SectionId (1 choices); Address (long text); MedicalNotes (long text); Notes (long text).
**Buttons:** Update Student.

## /Students/Lifecycle/{id}

**Screen:** Student Lifecycle - Ali Model School · In progress; Required-document checklist; Complete admission; Previous school history; Medical & special needs; Siblings; Internal / external transfer; Suspension, withdrawal or expulsion.
**Rendered fields/options:** File (file) ×4; DocumentName; IsRequired (checkbox); Remarks ×5; InvoiceDueDate (date); GenerateInitialInvoice (checkbox); InviteParent (checkbox); SchoolName; City; FromDate (date); ToDate (date); LastClassOrGrade; ReasonForLeaving; TransferCertificateNumber; PhysicianName; PhysicianPhone; HasSpecialNeeds (checkbox); ExternalSchoolName; EffectiveDate (date) ×3; Reason ×2; GenerateTransferCertificate (checkbox); GraduationDate (date); remarks; CampusId (3 choices) ×2; SchoolClassId (1 choices) ×2; SectionId (1 choices) ×2; FeeStructureId (1 choices); ToCampusId (3 choices); ToSchoolClassId (1 choices); ToSectionId (1 choices); Status (Suspend, Reinstate suspended student, Withdraw, Expel); MedicalConditions (long text); Allergies (long text); CurrentMedications (long text); SpecialNeedsDetails (long text); RequiredAccommodations (long text); EmergencyInstructions (long text).
**Buttons:** Admission & documents.
**Table columns:** Document, Required, Status, File, Actions / Date, Category, Event, Details, Outcome, Amount.

## /Attendance/Student?studentId={id}

**Screen:** Student Attendance - Ali Model School · Student Attendance; Attendance History.
**Table columns:** Date, Status, Remarks.

## /IdCards/Student?studentId={id}

**Screen:** Issue ID Card - Ali Model School · Issue ID Card; Card details.
**Rendered fields/options:** CardNumber; IssueDate (date); ExpiryDate (date); HolderType (Student, Teacher, Staff); unnamed select (Select a teacher); unnamed select (Select a staff member).
**Buttons:** Issue and open.

## /Certificates/Create?studentId={id}

**Screen:** Issue Certificate - Ali Model School · Issue Certificate; Certificate details; Live preview.
**Rendered fields/options:** CertificateNumber; IssueDate (date); CertificateTemplateId (1 choices).
**Buttons:** Generate and open.

## /ParentGuardians/Create

**Screen:** Add Parent / Guardian - Ali Model School · Add Parent / Guardian.
**Rendered fields/options:** FullName; Relationship; Phone; AlternatePhone; Email; NationalId; Occupation; City; Address; IsActive (checkbox); Notes (long text).
**Buttons:** Save.

## /ParentGuardians/Edit/{id}

**Screen:** Edit Parent / Guardian - Ali Model School · Edit Parent / Guardian.
**Rendered fields/options:** FullName; Relationship; Phone; AlternatePhone; Email; NationalId; Occupation; City; Address; IsActive (checkbox); Notes (long text).
**Buttons:** Save.

## /Teachers/Create

**Screen:** Add Teacher - Ali Model School · Add Teacher; Personal Information; Contact Information; Employment & Academic Information.
**Rendered fields/options:** FullName; FatherName; DateOfBirth (date); NationalId; Phone; AlternatePhone; Email (email); EmergencyContactName; EmergencyContactPhone; EmployeeNumber; JoiningDate (date); Department; Designation; Qualification; Specialization; IsActive (checkbox); Gender (Select gender, Unknown, Male, Female, Other); CampusId (3 choices); Status (Active, OnLeave, Suspended, Resigned, Terminated); Address (long text).
**Buttons:** Save Teacher.

## /AcademicPlanning?tab=resources

**Screen:** Academic Planning & LMS - Ali Model School · Academic Planning & LMS; Add academic term; Add calendar event; Terms; Academic calendar; Add curriculum / syllabus unit; Syllabus coverage; Create lesson plan.
**Rendered fields/options:** Name; Sequence (number) ×2; StartDate (date); EndDate (date); IsCurrent (checkbox); Title ×4; StartsOn (datetime-local); EndsOn (datetime-local); Location; IsAllDay (checkbox); IsPublished (checkbox) ×3; Code; PlannedStartDate (date); PlannedEndDate (date); PlannedPeriods (number); LessonDate (date); PeriodCount (number); ResourceUrl; File (file); EntryDate (date); PeriodsDelivered (number); TopicCovered; StudentsPresent (number); StudentsAbsent (number); academicYearId (2 choices); AcademicYearId (1 choices) ×6; CampusId (3 choices) ×2; AcademicTermId (1 choices); EventType (Academic, Examination, AssignmentDeadline, ParentTeacherMeeting, Activity, Sports, Meeting, Holiday, Other); Audience (Everyone, Students, Teachers, Parents, Staff); SchoolClassId (1 choices) ×4; SubjectId (1 choices) ×4; Status (Planned, InProgress, Completed, Deferred); SectionId (1 choices) ×3; CurriculumUnitId (1 choices) ×3; ResourceType (Document, Video, Audio, Presentation, Link, Worksheet, Recording, Other); Visibility (Students, TeachersOnly, StudentsAndParents); LessonPlanId (1 choices); Description (long text) ×3; LearningObjectives (long text) ×2; PriorKnowledge (long text); TeachingMethod (long text); Activities (long text); Resources (long text); AssessmentMethod (long text); Differentiation (long text); HomeworkNotes (long text); TeachingNotes (long text); StudentEngagement (long text); HomeworkAssigned (long text); Challenges (long text); FollowUpActions (long text).
**Buttons:** Apply.
**Table columns:** Date, Event, Audience, Status / Class / Subject, Unit, Plan, Coverage, Status / Date, Lesson, Teacher, Status, Review / Date, Teacher, Class / Subject, Topic, Periods, Attendance, Follow-up.

## /AcademicPlanning?tab=diary

**Screen:** Academic Planning & LMS - Ali Model School · Academic Planning & LMS; Add academic term; Add calendar event; Terms; Academic calendar; Add curriculum / syllabus unit; Syllabus coverage; Create lesson plan.
**Rendered fields/options:** Name; Sequence (number) ×2; StartDate (date); EndDate (date); IsCurrent (checkbox); Title ×4; StartsOn (datetime-local); EndsOn (datetime-local); Location; IsAllDay (checkbox); IsPublished (checkbox) ×3; Code; PlannedStartDate (date); PlannedEndDate (date); PlannedPeriods (number); LessonDate (date); PeriodCount (number); ResourceUrl; File (file); EntryDate (date); PeriodsDelivered (number); TopicCovered; StudentsPresent (number); StudentsAbsent (number); academicYearId (2 choices); AcademicYearId (1 choices) ×6; CampusId (3 choices) ×2; AcademicTermId (1 choices); EventType (Academic, Examination, AssignmentDeadline, ParentTeacherMeeting, Activity, Sports, Meeting, Holiday, Other); Audience (Everyone, Students, Teachers, Parents, Staff); SchoolClassId (1 choices) ×4; SubjectId (1 choices) ×4; Status (Planned, InProgress, Completed, Deferred); SectionId (1 choices) ×3; CurriculumUnitId (1 choices) ×3; ResourceType (Document, Video, Audio, Presentation, Link, Worksheet, Recording, Other); Visibility (Students, TeachersOnly, StudentsAndParents); LessonPlanId (1 choices); Description (long text) ×3; LearningObjectives (long text) ×2; PriorKnowledge (long text); TeachingMethod (long text); Activities (long text); Resources (long text); AssessmentMethod (long text); Differentiation (long text); HomeworkNotes (long text); TeachingNotes (long text); StudentEngagement (long text); HomeworkAssigned (long text); Challenges (long text); FollowUpActions (long text).
**Buttons:** Apply.
**Table columns:** Date, Event, Audience, Status / Class / Subject, Unit, Plan, Coverage, Status / Date, Lesson, Teacher, Status, Review / Date, Teacher, Class / Subject, Topic, Periods, Attendance, Follow-up.

## /Timetable/Create

**Screen:** Add Timetable Slot - Ali Model School · Add Timetable Slot.
**Rendered fields/options:** StartTime (time); EndTime (time); RoomNumber; SortOrder (number); IsBreak (checkbox); IsActive (checkbox); AcademicYearId (2 choices); SchoolClassId (1 choices); SectionId (1 choices); SubjectId (1 choices); TeacherId (1 choices); DayOfWeek (Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday); Notes (long text).
**Buttons:** Save.

## /Homework/Create

**Screen:** Add Homework - Ali Model School · Add Homework; Assignment Information; Academic Assignment; Submission Rules; Attachment & Availability.
**Rendered fields/options:** Title; AssignedDate (date); DueDate (date); MaxScore (number); AllowLateSubmission (checkbox); Attachment (file); IsActive (checkbox); Status (Draft, Assigned, Closed); AcademicYearId (2 choices); SchoolClassId (1 choices); SectionId (1 choices); SubjectId (1 choices); TeacherId (1 choices); CurriculumUnitId (1 choices); Description (long text); Instructions (long text).
**Buttons:** Save Homework.

## /Exams/Create

**Screen:** Create Exam - Ali Model School · Create Exam.
**Rendered fields/options:** Name; Code; PassingMarksPercentage; StartDate (date); EndDate (date); IsActive (checkbox); Status (Draft, Scheduled, MarksEntry, Published, Cancelled); CampusId (3 choices); AcademicYearId (1 choices); SchoolClassId (1 choices); SectionId (1 choices); Remarks (long text).
**Buttons:** Save Exam.

## /Exams/Details/{id}

**Screen:** Exam Details - Ali Model School · Annual; Exam Info; Subject Result Summary.
**Buttons:** Publish Result.
**Table columns:** Subject, Entries, Average, Total.

## /QuestionBank/Create

**Screen:** Create Question - Ali Model School · Create Question; Answer Options; Hotspot Image and Correct Region; Student Question Preview; Insert formula; Insert table.
**Rendered fields/options:** Code; Chapter; Unit; Topic; Subtopic; Marks; EstimatedTimeMinutes (number); Options[0].DisplayOrder; Options[0].IsCorrect (checkbox); Options[1].DisplayOrder; Options[1].IsCorrect (checkbox); Options[2].DisplayOrder; Options[2].IsCorrect (checkbox); Options[3].DisplayOrder; Options[3].IsCorrect (checkbox); NumericTolerance (number); TagsText; IsActive (checkbox); CampusId (3 choices); SchoolClassId (1 choices); SubjectId (1 choices); Type (SingleCorrectMcq, MultipleCorrectMcq, TrueFalse, ShortAnswer, DetailedAnswer, FillInTheBlank, Matching, ImageHotspot); Difficulty (Easy, Medium, Hard, Advanced); Status (Draft, Active); unnamed select (); unnamed select (Correct point + tolerance, Correct circle, Correct rectangle, Correct polygon, Point, Circle, Rectangle, Polygon, Arrow, Line, Highlight, Text label); MarkingMode (AllOrNothing, PartialCredit).
**Buttons:** Ω.
**Table columns:** Order, Option / Answer, Matching Pair, Correct.

## /QuestionPapers/Create

**Screen:** Create Question Paper - Ali Model School · Create Question Paper.
**Rendered fields/options:** Title; PaperCode; DurationMinutes (number); TotalMarks; CampusId (3 choices); AcademicYearId (2 choices); SchoolClassId (1 choices); SubjectId (1 choices); ExamId (2 choices); Instructions (long text).
**Buttons:** Save and open builder.

## /LibraryBooks/Create

**Screen:** Add Library Book - Ali Model School · Add Library Book; Book Identity; Publication & Classification; Inventory & Availability.
**Rendered fields/options:** AccessionNumber; Isbn; Title; Author; Publisher; Category; Language; Edition; PublishedYear (number); ShelfLocation; Price (number); IsActive (checkbox); TotalCopies (number); AvailableCopies (number); LostCopies (number); CampusId (3 choices); Remarks (long text).
**Buttons:** Save Book.

## /LibraryMembers/Create

**Screen:** Add Library Member - Ali Model School · Add Library Member.
**Rendered fields/options:** MemberCode; FullName; Phone; Email; MaxBooksAllowed (number); IsBlocked (checkbox); IsActive (checkbox); BlockReason; CampusId (3 choices); MemberType (4 choices); Remarks (long text).
**Buttons:** Save Member.

## /LibraryIssues/Create

**Screen:** Issue Book - Ali Model School · Issue Library Book.
**Rendered fields/options:** IssueDate; DueDate; LibraryBookId (1 choices); LibraryMemberId (1 choices); Remarks (long text).
**Buttons:** Issue Book.

## /TransportRoutes/Create

**Screen:** Add Transport Route - Ali Model School · Add Transport Route.
**Rendered fields/options:** RouteCode; Name; StartPoint; EndPoint; MonthlyFee (number); IsActive (checkbox); CampusId (3 choices); Description (long text); Remarks (long text).
**Buttons:** Save Route.

## /TransportVehicles/Create

**Screen:** Add Vehicle - Ali Model School · Add Transport Vehicle.
**Rendered fields/options:** VehicleNumber; RegistrationNumber; VehicleType; Capacity (number); DriverName; DriverPhone; AssistantName; AssistantPhone; InsuranceExpiryDate (date); FitnessExpiryDate (date); IsActive (checkbox); CampusId (3 choices); Remarks (long text).
**Buttons:** Save Vehicle.

## /TransportAssignments/Create

**Screen:** Assign Student Transport - Ali Model School · Assign Student Transport.
**Rendered fields/options:** StartDate (date); EndDate (date); MonthlyFee (number); PickupAddress; DropOffAddress; IsActive (checkbox); StudentId (2 choices); TransportRouteId (1 choices); TransportVehicleId (1 choices); Status (Active, Suspended, Stopped); Notes (long text).
**Buttons:** Save Assignment.

## /HostelBuildings/Create

**Screen:** Add Hostel Building - Ali Model School · Add Hostel Building.
**Rendered fields/options:** Code; Name; GenderRestriction; WardenName; WardenPhone; Capacity (number); Address; IsActive (checkbox); CampusId (3 choices); Remarks (long text).
**Buttons:** Save.

## /HostelRooms/Create

**Screen:** Add Hostel Room - Ali Model School · Add Hostel Room.
**Rendered fields/options:** RoomNumber; Floor; RoomType; Capacity (number); IsActive (checkbox); HostelBuildingId (0 choices); Remarks (long text).
**Buttons:** Save.

## /HostelBeds/Create

**Screen:** Add Hostel Bed - Ali Model School · Add Hostel Bed.
**Rendered fields/options:** BedNumber; MonthlyFee; IsActive (checkbox); HostelRoomId (0 choices); Status (Available, Occupied, Maintenance, Reserved); Remarks (long text).
**Buttons:** Save.

## /HostelAllocations/Create

**Screen:** Allocate Hostel Bed - Ali Model School · Allocate Hostel Bed.
**Rendered fields/options:** StartDate (date); EndDate (date); MonthlyFee; SecurityDeposit; IsActive (checkbox); GuardianContactName; GuardianContactPhone; StudentId (1 choices); HostelBuildingId (0 choices); HostelRoomId (0 choices); HostelBedId (0 choices); Status (Active, Ended, Cancelled); Notes (long text).
**Buttons:** Save.

## /Finance?tab=overview

**Screen:** Finance & Accounting - Ali Model School · Finance & Accounting; Income statement; Balance sheet; Position; Trial balance; Add or edit account; Fiscal period; Manual journal voucher.
**Rendered fields/options:** fromDate (date); toDate (date); Code; Name ×2; Description ×2; IsControlAccount (checkbox); AllowManualPosting (checkbox); IsActive (checkbox) ×2; StartDate (date); EndDate (date); EntryDate (date); ReferenceNumber; Lines[0].Description; Lines[0].Debit (number); Lines[0].Credit (number); Lines[1].Description; Lines[1].Debit (number); Lines[1].Credit (number); Lines[2].Description; Lines[2].Debit (number); Lines[2].Credit (number); Lines[3].Description; Lines[3].Debit (number); Lines[3].Credit (number); Amount (number); Notes ×2; StatementDate (date); StatementBalance (number); DepositsInTransit (number); OutstandingPayments (number); OtherAdjustments (number); Complete (checkbox); campusId (3 choices); AccountType (5 choices); Category (Cash, Bank, Receivable, OtherCurrentAsset, FixedAsset, Payable, OtherCurrentLiability, LongTermLiability, Capital, RetainedEarnings, FeeIncome, OtherIncome, PayrollExpense, OperatingExpense, DepreciationExpense); ParentAccountId (1 choices); CampusId (3 choices) ×2; Lines[0].FinanceAccountId (1 choices); Lines[1].FinanceAccountId (1 choices); Lines[2].FinanceAccountId (1 choices); Lines[3].FinanceAccountId (1 choices); FiscalPeriodId (2 choices); FinanceAccountId (1 choices) ×2; Status (Draft, Approved, Closed).
**Buttons:** Apply.
**Table columns:** Code, Account, Type, Debit, Credit, Net / Code, Account, Type, Category, Balance, Status / Period, Dates, Campus, Status / Account, Description, Debit, Credit / Date, Voucher, Description, Source, Debit / Credit, Status / Period, Account, Budget, Actual, Variance, Status / Date, Account, Statement, Book, Reconciled, Difference, Status.

## /Finance?tab=accounts

**Screen:** Finance & Accounting - Ali Model School · Finance & Accounting; Income statement; Balance sheet; Position; Trial balance; Add or edit account; Fiscal period; Manual journal voucher.
**Rendered fields/options:** fromDate (date); toDate (date); Code; Name ×2; Description ×2; IsControlAccount (checkbox); AllowManualPosting (checkbox); IsActive (checkbox) ×2; StartDate (date); EndDate (date); EntryDate (date); ReferenceNumber; Lines[0].Description; Lines[0].Debit (number); Lines[0].Credit (number); Lines[1].Description; Lines[1].Debit (number); Lines[1].Credit (number); Lines[2].Description; Lines[2].Debit (number); Lines[2].Credit (number); Lines[3].Description; Lines[3].Debit (number); Lines[3].Credit (number); Amount (number); Notes ×2; StatementDate (date); StatementBalance (number); DepositsInTransit (number); OutstandingPayments (number); OtherAdjustments (number); Complete (checkbox); campusId (3 choices); AccountType (5 choices); Category (Cash, Bank, Receivable, OtherCurrentAsset, FixedAsset, Payable, OtherCurrentLiability, LongTermLiability, Capital, RetainedEarnings, FeeIncome, OtherIncome, PayrollExpense, OperatingExpense, DepreciationExpense); ParentAccountId (1 choices); CampusId (3 choices) ×2; Lines[0].FinanceAccountId (1 choices); Lines[1].FinanceAccountId (1 choices); Lines[2].FinanceAccountId (1 choices); Lines[3].FinanceAccountId (1 choices); FiscalPeriodId (2 choices); FinanceAccountId (1 choices) ×2; Status (Draft, Approved, Closed).
**Buttons:** Apply.
**Table columns:** Code, Account, Type, Debit, Credit, Net / Code, Account, Type, Category, Balance, Status / Period, Dates, Campus, Status / Account, Description, Debit, Credit / Date, Voucher, Description, Source, Debit / Credit, Status / Period, Account, Budget, Actual, Variance, Status / Date, Account, Statement, Book, Reconciled, Difference, Status.

## /Finance?tab=periods

**Screen:** Finance & Accounting - Ali Model School · Finance & Accounting; Income statement; Balance sheet; Position; Trial balance; Add or edit account; Fiscal period; Manual journal voucher.
**Rendered fields/options:** fromDate (date); toDate (date); Code; Name ×2; Description ×2; IsControlAccount (checkbox); AllowManualPosting (checkbox); IsActive (checkbox) ×2; StartDate (date); EndDate (date); EntryDate (date); ReferenceNumber; Lines[0].Description; Lines[0].Debit (number); Lines[0].Credit (number); Lines[1].Description; Lines[1].Debit (number); Lines[1].Credit (number); Lines[2].Description; Lines[2].Debit (number); Lines[2].Credit (number); Lines[3].Description; Lines[3].Debit (number); Lines[3].Credit (number); Amount (number); Notes ×2; StatementDate (date); StatementBalance (number); DepositsInTransit (number); OutstandingPayments (number); OtherAdjustments (number); Complete (checkbox); campusId (3 choices); AccountType (5 choices); Category (Cash, Bank, Receivable, OtherCurrentAsset, FixedAsset, Payable, OtherCurrentLiability, LongTermLiability, Capital, RetainedEarnings, FeeIncome, OtherIncome, PayrollExpense, OperatingExpense, DepreciationExpense); ParentAccountId (1 choices); CampusId (3 choices) ×2; Lines[0].FinanceAccountId (1 choices); Lines[1].FinanceAccountId (1 choices); Lines[2].FinanceAccountId (1 choices); Lines[3].FinanceAccountId (1 choices); FiscalPeriodId (2 choices); FinanceAccountId (1 choices) ×2; Status (Draft, Approved, Closed).
**Buttons:** Apply.
**Table columns:** Code, Account, Type, Debit, Credit, Net / Code, Account, Type, Category, Balance, Status / Period, Dates, Campus, Status / Account, Description, Debit, Credit / Date, Voucher, Description, Source, Debit / Credit, Status / Period, Account, Budget, Actual, Variance, Status / Date, Account, Statement, Book, Reconciled, Difference, Status.

## /Finance?tab=journals

**Screen:** Finance & Accounting - Ali Model School · Finance & Accounting; Income statement; Balance sheet; Position; Trial balance; Add or edit account; Fiscal period; Manual journal voucher.
**Rendered fields/options:** fromDate (date); toDate (date); Code; Name ×2; Description ×2; IsControlAccount (checkbox); AllowManualPosting (checkbox); IsActive (checkbox) ×2; StartDate (date); EndDate (date); EntryDate (date); ReferenceNumber; Lines[0].Description; Lines[0].Debit (number); Lines[0].Credit (number); Lines[1].Description; Lines[1].Debit (number); Lines[1].Credit (number); Lines[2].Description; Lines[2].Debit (number); Lines[2].Credit (number); Lines[3].Description; Lines[3].Debit (number); Lines[3].Credit (number); Amount (number); Notes ×2; StatementDate (date); StatementBalance (number); DepositsInTransit (number); OutstandingPayments (number); OtherAdjustments (number); Complete (checkbox); campusId (3 choices); AccountType (5 choices); Category (Cash, Bank, Receivable, OtherCurrentAsset, FixedAsset, Payable, OtherCurrentLiability, LongTermLiability, Capital, RetainedEarnings, FeeIncome, OtherIncome, PayrollExpense, OperatingExpense, DepreciationExpense); ParentAccountId (1 choices); CampusId (3 choices) ×2; Lines[0].FinanceAccountId (1 choices); Lines[1].FinanceAccountId (1 choices); Lines[2].FinanceAccountId (1 choices); Lines[3].FinanceAccountId (1 choices); FiscalPeriodId (2 choices); FinanceAccountId (1 choices) ×2; Status (Draft, Approved, Closed).
**Buttons:** Apply.
**Table columns:** Code, Account, Type, Debit, Credit, Net / Code, Account, Type, Category, Balance, Status / Period, Dates, Campus, Status / Account, Description, Debit, Credit / Date, Voucher, Description, Source, Debit / Credit, Status / Period, Account, Budget, Actual, Variance, Status / Date, Account, Statement, Book, Reconciled, Difference, Status.

## /Finance?tab=budgets

**Screen:** Finance & Accounting - Ali Model School · Finance & Accounting; Income statement; Balance sheet; Position; Trial balance; Add or edit account; Fiscal period; Manual journal voucher.
**Rendered fields/options:** fromDate (date); toDate (date); Code; Name ×2; Description ×2; IsControlAccount (checkbox); AllowManualPosting (checkbox); IsActive (checkbox) ×2; StartDate (date); EndDate (date); EntryDate (date); ReferenceNumber; Lines[0].Description; Lines[0].Debit (number); Lines[0].Credit (number); Lines[1].Description; Lines[1].Debit (number); Lines[1].Credit (number); Lines[2].Description; Lines[2].Debit (number); Lines[2].Credit (number); Lines[3].Description; Lines[3].Debit (number); Lines[3].Credit (number); Amount (number); Notes ×2; StatementDate (date); StatementBalance (number); DepositsInTransit (number); OutstandingPayments (number); OtherAdjustments (number); Complete (checkbox); campusId (3 choices); AccountType (5 choices); Category (Cash, Bank, Receivable, OtherCurrentAsset, FixedAsset, Payable, OtherCurrentLiability, LongTermLiability, Capital, RetainedEarnings, FeeIncome, OtherIncome, PayrollExpense, OperatingExpense, DepreciationExpense); ParentAccountId (1 choices); CampusId (3 choices) ×2; Lines[0].FinanceAccountId (1 choices); Lines[1].FinanceAccountId (1 choices); Lines[2].FinanceAccountId (1 choices); Lines[3].FinanceAccountId (1 choices); FiscalPeriodId (2 choices); FinanceAccountId (1 choices) ×2; Status (Draft, Approved, Closed).
**Buttons:** Apply.
**Table columns:** Code, Account, Type, Debit, Credit, Net / Code, Account, Type, Category, Balance, Status / Period, Dates, Campus, Status / Account, Description, Debit, Credit / Date, Voucher, Description, Source, Debit / Credit, Status / Period, Account, Budget, Actual, Variance, Status / Date, Account, Statement, Book, Reconciled, Difference, Status.

## /Finance?tab=bank

**Screen:** Finance & Accounting - Ali Model School · Finance & Accounting; Income statement; Balance sheet; Position; Trial balance; Add or edit account; Fiscal period; Manual journal voucher.
**Rendered fields/options:** fromDate (date); toDate (date); Code; Name ×2; Description ×2; IsControlAccount (checkbox); AllowManualPosting (checkbox); IsActive (checkbox) ×2; StartDate (date); EndDate (date); EntryDate (date); ReferenceNumber; Lines[0].Description; Lines[0].Debit (number); Lines[0].Credit (number); Lines[1].Description; Lines[1].Debit (number); Lines[1].Credit (number); Lines[2].Description; Lines[2].Debit (number); Lines[2].Credit (number); Lines[3].Description; Lines[3].Debit (number); Lines[3].Credit (number); Amount (number); Notes ×2; StatementDate (date); StatementBalance (number); DepositsInTransit (number); OutstandingPayments (number); OtherAdjustments (number); Complete (checkbox); campusId (3 choices); AccountType (5 choices); Category (Cash, Bank, Receivable, OtherCurrentAsset, FixedAsset, Payable, OtherCurrentLiability, LongTermLiability, Capital, RetainedEarnings, FeeIncome, OtherIncome, PayrollExpense, OperatingExpense, DepreciationExpense); ParentAccountId (1 choices); CampusId (3 choices) ×2; Lines[0].FinanceAccountId (1 choices); Lines[1].FinanceAccountId (1 choices); Lines[2].FinanceAccountId (1 choices); Lines[3].FinanceAccountId (1 choices); FiscalPeriodId (2 choices); FinanceAccountId (1 choices) ×2; Status (Draft, Approved, Closed).
**Buttons:** Apply.
**Table columns:** Code, Account, Type, Debit, Credit, Net / Code, Account, Type, Category, Balance, Status / Period, Dates, Campus, Status / Account, Description, Debit, Credit / Date, Voucher, Description, Source, Debit / Credit, Status / Period, Account, Budget, Actual, Variance, Status / Date, Account, Statement, Book, Reconciled, Difference, Status.

## /Inventory/Create

**Screen:** Add Inventory Item - Ali Model School · Add Inventory Item.
**Rendered fields/options:** Code; Name; Category; Unit; OpeningQuantity; ReorderLevel; UnitCost; Location; IsActive (checkbox); CampusId (3 choices); Description (long text).
**Buttons:** Save.

## /Expenses/Create

**Screen:** New Expense - Ali Model School · New Expense.
**Rendered fields/options:** VoucherNumber; ExpenseDate (date); Category; Payee; Amount; PaymentMethod; ReferenceNumber; CampusId (3 choices); Description (long text).
**Buttons:** Save Draft.

## /Payroll/Structure

**Screen:** Salary Structure - Ali Model School · New Salary Structure.
**Rendered fields/options:** basicSalary (number); allowances (number); deductions (number); effectiveFrom (date); employeeType (2 choices); staffEmployeeId (1 choices); teacherEmployeeId (1 choices).
**Buttons:** Save.

## /Certificates/Templates

**Screen:** Certificate Templates - Ali Model School · Certificate Templates.
**Table columns:** Name, Type, Orientation, Status, Updated, Actions.

## /Certificates/Create

**Screen:** Issue Certificate - Ali Model School · Issue Certificate; Certificate details; Live preview.
**Rendered fields/options:** CertificateNumber; IssueDate (date); CertificateTemplateId (1 choices).
**Buttons:** Generate and open.

## /IdCards/Create

**Screen:** Issue ID Card - Ali Model School · Issue ID Card; Card details.
**Rendered fields/options:** CardNumber; IssueDate (date); ExpiryDate (date); HolderType (Student, Teacher, Staff); unnamed select (Select a teacher); unnamed select (Select a staff member).
**Buttons:** Issue and open.

## /Notices/Create

**Screen:** Create Notice - Ali Model School · Create Notice.
**Rendered fields/options:** Title; PublishOn (datetime-local); ExpiresOn (datetime-local); Attachment (file); Priority (Low, Normal, High, Urgent); Audience (Everyone, Students, Parents, Teachers, Staff, Class, Section); CampusId (3 choices); SchoolClassId (1 choices); SectionId (1 choices); Body (long text).
**Buttons:** Save Draft.

## /Security/Users

**Screen:** User Security - Ali Model School · User Security; User Directory; Invite User; Set student password.
**Rendered fields/options:** search; FullName; Email (email); Roles (checkbox) ×12; NewPassword (password); ConfirmPassword (password); RequirePasswordChange (checkbox); pageSize (10, 25, 50, 100).
**Buttons:** Filter.
**Table columns:** User, School, Roles, Security, Status, Actions.

## /Security/RolePermissions/{id}

**Screen:** Accountant Permissions - Ali Model School · Accountant Permissions; Academic; Academic Planning; Assessments; Attendance; Audit Logs; Certificates; Communication & Engagement.
**Rendered fields/options:** SelectedPermissions (checkbox) ×135.
**Buttons:** Save Permissions.

## /Help/Category/getting-started

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Getting Started; Dashboard.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Help/Category/students

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Students; Student List; New Student Admission; Student Profile; Student ID Cards; Student Certificates.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Help/Category/fees

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Fees; Fee Structure; Collect Payment; Publish Fee Receipts.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Help/Category/attendance

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Attendance; Student Attendance.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Help/Category/examinations

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Examinations; Exams; Results.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Help/Category/assessments

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Assessments; Question Bank; Paper Generator; Online Assessment; Assessment Marking.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Help/Category/administration

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Administration; Users; Roles & Permissions; School Settings.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Help/Article/getting-started

**Screen:** Getting Started - Ali Model School · Getting Started; Related help; Need something else?.

## /Help/Article/dashboard

**Screen:** Dashboard - Ali Model School · Dashboard; Related help; Need something else?.

## /Help/Article/student-list

**Screen:** Student List - Ali Model School · Student List; Related help; Need something else?.

## /Help/Article/new-student-admission

**Screen:** New Student Admission - Ali Model School · New Student Admission; Related help; Need something else?.

## /Help/Article/student-profile

**Screen:** Student Profile - Ali Model School · Student Profile; Related help; Need something else?.

## /Help/Article/student-id-cards

**Screen:** Student ID Cards - Ali Model School · Student ID Cards; Need something else?.

## /Help/Article/student-certificates

**Screen:** Student Certificates - Ali Model School · Student Certificates; Need something else?.

## /Help/Article/fee-structure

**Screen:** Fee Structure - Ali Model School · Fee Structure; Related help; Need something else?.

## /Help/Article/collect-fee-payment

**Screen:** Collect Payment - Ali Model School · Collect Payment; Related help; Need something else?.

## /Help/Article/publish-fee-receipts

**Screen:** Publish Fee Receipts - Ali Model School · Publish Fee Receipts; Related help; Need something else?.

## /Help/Article/student-attendance

**Screen:** Student Attendance - Ali Model School · Student Attendance; Need something else?.

## /Help/Article/exams

**Screen:** Exams - Ali Model School · Exams; Related help; Need something else?.

## /Help?page={n}

**Screen:** Help Center - Ali Model School · How can we help?; Browse topics; Help articles; Getting Started; Dashboard; Student List; New Student Admission; Student Profile.
**Rendered fields/options:** search (search).
**Buttons:** Search.

## /Files?ownerEntityType=Student&ownerEntityId={id}

**Screen:** Documents - Ali Model School · Documents.
**Rendered fields/options:** Category; File (file).
**Buttons:** Upload.
**Table columns:** File, Category, Size, Uploaded.

## /Exams/Edit/{id}

**Screen:** Edit Exam - Ali Model School · Edit Exam.
**Rendered fields/options:** Name; Code; PassingMarksPercentage; StartDate (date); EndDate (date); IsActive (checkbox); Status (Draft, Scheduled, MarksEntry, Published, Cancelled); CampusId (3 choices); AcademicYearId (1 choices); SchoolClassId (1 choices); SectionId (1 choices); Remarks (long text).
**Buttons:** Save Exam.

## /Marks/Entry?examId={id}

**Screen:** Marks Entry - Ali Model School.
**Rendered fields/options:** subjectId (1 choices).
**Buttons:** Load Sheet.

## /Certificates/CreateTemplate

**Screen:** New Certificate Template - Ali Model School · New Certificate Template; Template preview.
**Rendered fields/options:** Name; Title; IsActive (checkbox); IsDefault (checkbox); CertificateType (Bonafide, Character, Transfer, Completion, Custom); Orientation (Portrait, Landscape); BodyTemplate (long text); FooterText (long text).
**Buttons:** Save Template.

## /Help/Article/results

**Screen:** Results - Ali Model School · Results; Need something else?.

## /Help/Article/question-bank

**Screen:** Question Bank - Ali Model School · Question Bank; Related help; Need something else?.

## /Help/Article/paper-generator

**Screen:** Paper Generator - Ali Model School · Paper Generator; Related help; Need something else?.

## /Help/Article/online-assessment

**Screen:** Online Assessment - Ali Model School · Online Assessment; Related help; Need something else?.

## /Help/Article/assessment-marking

**Screen:** Assessment Marking - Ali Model School · Assessment Marking; Related help; Need something else?.

## /Help/Article/users

**Screen:** Users - Ali Model School · Users; Related help; Need something else?.

## /Help/Article/roles-and-permissions

**Screen:** Roles & Permissions - Ali Model School · Roles & Permissions; Related help; Need something else?.

## /Help/Article/school-settings

**Screen:** School Settings - Ali Model School · School Settings; Related help; Need something else?.

## Additional screens recovered on individual retry

- **Add Staff:** FullName, FatherName, DateOfBirth, Gender, NationalId, Phone, AlternatePhone, Email, EmergencyContactName/Phone, Address, CampusId, EmployeeNumber, JoiningDate, StaffType (Administrative, Academic, Accounts, Reception, Library, Transport, Hostel, Support, Other), Department, Designation, Status, IsActive.
- **Add Fee Head:** Code, Name, CampusId, DefaultAmount, DisplayOrder, IsRequired, IsActive, Description.
- **Create Fee Structure:** Name, CampusId, AcademicYearId, SchoolClassId, SectionId, BillingCycle, DueDay, Notes, and five fee lines with FeeHeadId, Amount, DiscountAmount, IsActive.
- **Create Fee Invoice:** StudentId, AcademicYearId, FeeStructureId, IssueDate, DueDate, PeriodMonth/Year, Remarks, five manual lines with FeeHead, Amount, DiscountAmount, plus IssueNow.
- **Academic Planning tabs:** Calendar, Curriculum and Lesson Plans loaded on individual retry and shared the same rendered controls as the main planning page.

## Coverage limits

Some role-specific permission URLs intermittently returned server errors during a burst of read requests; the shared 135-permission editor and the role catalogue were inspected. No save, submit, publish, approval, deletion, import, upload, or payment action was used. Records created by other users, dynamic dependent selectors, export file contents, and client-side validation were not tested.