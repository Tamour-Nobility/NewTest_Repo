# SMS Product Improvement Discussion — Transfer Archive

**Purpose:** Portable context archive for another ChatGPT/Codex account.  
**Discussion date:** 18 September 2026  
**Primary product:** Web-based, multi-tenant SaaS School Management System (SMS)  
**Target usage:** Pakistan-first school market, while keeping the product architecturally extensible.

> This is a model-friendly reconstruction of the visible SMS product-improvement discussion and the review artifacts used in it. It is intended for continuity of work. It is not an official export of hidden platform metadata or private reasoning.

---

## 1. User's Original Objective

The user wanted to explore what features should be added to an existing **web-based multi-tenant SaaS School Management System** to make it more robust, attractive and commercially strong.

The product direction agreed during the discussion was not to maximize the number of menus. The product should become a connected school operating platform where data entered in one workflow automatically drives the next relevant workflow.

Core design principle:

> **Do not build 100 independent modules. Build connected workflows.**

Examples discussed:

- Admission accepted → student created → roll number assigned → parent account → initial fee invoice → class assignment → welcome notification.
- Student absent → attendance saved → parent notified → consecutive-absence rule evaluated → intervention task/escalation.
- Teacher leave approved → affected timetable identified → substitute suggested → teacher notified → workload updated.
- Fee structure → recurring billing → invoice → payment → bank reconciliation → receipt → accounting posting → aging/collections.

---

## 2. First Broad Product Exploration

The first recommendation grouped the product into:

- Student Management
- Academics
- Attendance
- Fees
- Parent experience
- Teacher experience
- Communication
- HR
- School Operations
- Reporting
- SaaS Administration
- Security

High-value ideas included:

- Student 360 profile
- advanced fee management
- WhatsApp/SMS communication engine
- parent portal
- flexible grading/assessment rules
- report-card designer
- timetable conflict detection and later auto-generation
- teacher daily workspace
- homework/assignment management
- admissions CRM
- academic-year rollover
- true tenant/campus configuration
- subscriptions, plans and feature flags
- management dashboards that answer operational questions

---

## 3. Expanded Feature Exploration

The next pass deliberately explored areas that traditional SMS products often omit.

### Student / family / safety
- continuous student lifecycle
- student document vault
- sibling and household linkage
- emergency contacts
- authorized pickup
- gate passes
- visitor management
- behavior/discipline
- house system
- achievements
- counseling
- special-needs support
- health/clinic records
- emergency alerts

### Academic / LMS
- lesson planning
- curriculum tracking
- learning outcomes
- question bank
- exam paper builder
- online examinations
- result moderation and locking
- teacher workload
- substitute-teacher management
- resource booking
- school calendar
- PTM scheduling
- digital consent forms
- trips
- clubs/sports

### Operations / ERP
- certificate/document generation
- configurable templates
- digital ID/QR
- transport routes and live tracking
- bus arrival/boarding alerts
- vehicle compliance and maintenance
- library + digital library
- inventory and assets
- maintenance tickets
- procurement and vendors
- hostel
- canteen/student wallet

### Finance / fee operations
- fee forecasting
- defaulter management
- promise-to-pay
- bank reconciliation
- refunds
- budgeting
- expenses
- approval workflows

### Communications
- complaint/helpdesk
- surveys
- announcements
- emergency broadcast
- delivery tracking
- communication history
- multilingual/Urdu support

### SaaS platform
- PWA/mobile
- offline attendance
- QR/RFID/biometric integrations
- configurable custom fields
- form builder
- report builder
- dashboard builder
- saved views
- global search
- notification center
- role-specific dashboards
- audit trail
- MFA/session security
- tenant backup/restore
- feature flags
- tenant branding/white-label
- usage metering
- tenant health dashboard
- controlled support impersonation
- guided onboarding
- demo data
- product usage analytics
- in-app feedback
- release notes

The product maturity model discussed was:

1. **Complete SMS**
2. **Connected School ERP**
3. **Smart School Platform**
4. **Intelligent School Platform**

The recommendation was to build a strong Level 3 before making AI the centerpiece.

---

## 4. Review Artifacts Supplied by the User

The user provided two logical documents, each in both Markdown and DOCX formats:

- `SMS_UI_Inventory.md` / `SMS_UI_Inventory.docx`
- `SMS_Product_Review.md` / `SMS_Product_Review.docx`

The two formats were treated as duplicates of the same evidence rather than four independent reviews.

### Review scope and limitations

The product review was performed on 18 September 2026 using a SchoolAdmin / school-owner perspective.

It was **read-only**:
- no form submissions
- no save/update/delete
- no publishing
- no real payment processing
- no approval execution
- no upload workflow testing
- no backend authorization proof
- no complete JavaScript interaction testing
- no mobile/responsive validation

Therefore:

> **Missing / not evidenced means the review did not prove the feature exists. Codex must inspect the repository and database before implementing anything.**

---

## 5. Major Existing Capabilities Confirmed by the Review

The application is already broad and should not be treated as a greenfield SMS.

### Core setup
- campuses
- academic years
- classes
- sections
- subjects

### Students and families
- student directory
- multi-step admission
- parent/guardian directory
- student profile
- student lifecycle
- required document checklist
- previous school
- medical/special needs
- siblings
- internal/external transfer
- suspension/withdrawal/expulsion
- re-enrollment
- graduation/alumni status
- ID cards
- certificates

### HR
- teachers
- staff
- departments/designations
- contracts
- leave policies/balances/requests
- staff attendance
- performance reviews
- employee documents
- training
- recruitment/vacancies

### Attendance
- daily attendance
- attendance summary
- individual student attendance history

### Fees
- fee heads
- fee structures
- invoices
- receipt publishing
- publishing history
- fee reporting

### Academics / LMS
- terms
- academic calendar
- curriculum/syllabus units
- syllabus coverage
- lesson plans
- resources
- teacher diary
- timetable
- homework

### Exams / assessments
- exams
- marks entry
- result summaries
- question bank
- question papers
- online assessments
- student assessment screens
- marking
- result release/integration

### Operations
- library
- transport
- hostel

### Finance / ERP
- chart of accounts
- income statement
- balance sheet
- trial balance
- fiscal periods
- journals
- budgets
- bank reconciliation
- inventory
- expenses
- payroll

### Communications / governance
- private conversations
- PTM scheduling
- surveys/polls
- email/SMS templates
- notices
- assurance/compliance
- scheduled reports
- audit logs
- incidents
- backup/restore evidence
- retention policies
- subscriptions
- roles/permissions
- user security
- help center

---

## 6. Highest-Priority Review Findings

The review identified several issues to address before major expansion:

- intermittent HTTP 500/503 responses during sequential page reads
- Assurance showed a high score even though a verified backup was not recorded
- user invitation did not visibly show campus-scope assignment
- 135 permission checkboxes without a clear effective-access experience
- School Settings described in help but not visible in navigation
- no clearly evidenced recurring billing/bank import workflow
- inconsistent campus-scope terminology
- exports could expose sensitive information without dedicated export controls

---

## 7. Strategic Product Direction Agreed

The application should evolve from:

> **Broad functional SMS / ERP foundation**

into:

> **Integrated, configurable, multi-campus School Operating Platform**

The most important transformation is deeper workflow integration, not merely additional CRUD pages.

The highest-value areas identified were:

- Student + Household 360
- Admissions CRM
- Parent and Student portals
- Recurring fee/payment/reconciliation engine
- Teacher My Day + continuous gradebook
- Health / behavior / student support
- Master scheduling
- Workflow and rules automation
- School Command Center
- SaaS configuration, entitlements and integrations

---

## 8. Status Vocabulary Used

- **FIX** — existing capability has a correctness/control problem.
- **ENHANCE** — existing capability is valid but incomplete.
- **VERIFY** — review could not prove whether a capability exists or works.
- **MISSING** — confirmed absent after repository/database inspection.
- **STRATEGIC** — later differentiator rather than immediate operational requirement.

---

## 9. Full Final Recommendation (36 sections + Codex roadmap)

The following is the complete detailed recommendation document that was generated from the review.

---


School Management SaaS
Final Improvement Recommendation

Comprehensive Gap Catalogue (1-36) and Recommended Implementation Order for Codex

Prepared from the reviewed SMS Product Review and UI Inventory
Review basis: 18 September 2026

| Scope note: The source review was read-only. Save behavior, backend validation, JavaScript interactions, actual payment flows, role enforcement, notification delivery, responsive/mobile behavior and several role-specific experiences were not functionally tested. In this document, "Missing" means not evidenced by the supplied review. Before Codex creates a new feature, it should inspect the existing code/database and verify that an equivalent capability does not already exist behind another role, route or workflow. |
| --- |

## How to read this document

The current application is already beyond a basic school-management system. It has substantial foundations in student lifecycle management, HR, accounting, assessments, library, transport, hostel, communications, audit/assurance and multi-campus administration. The recommendation therefore focuses on workflow depth, connected operations, customer-facing experiences, SaaS controls and strategic differentiation rather than simply adding more disconnected modules.

| Status | Meaning |
| --- | --- |
| MISSING | Not evidenced in the review; verify code first, then implement if absent. |
| ENHANCE | Existing capability is present but should be extended or connected more deeply. |
| FIX/CONTROL | Existing capability or architecture needs correction, safety controls or stronger operational behavior. |
| VERIFY | Role-specific or deeper behavior may exist; inspect before creating anything new. |
| STRATEGIC | Later differentiator/premium capability after operational foundations are reliable. |

## 1. Platform reliability and structural foundation - do this before adding major features

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Reliability | FIX/CONTROL - Intermittent 500/503 errors | New features have little value if critical pages are unreliable. | Reproduce normal user navigation under load; add centralized exception handling, correlation IDs, structured logging, request tracing and health monitoring. Categorize DB timeout, authorization failure, dependency failure and application exception separately. Provide a friendly retry/error screen instead of generic failure. |
| Tenant security | FIX/CONTROL - Tenant isolation validation | Multi-tenancy is the foundation of the SaaS. | Every query, command, download, background job, export, attachment and notification must enforce TenantId. Do not rely on UI filtering. Add automated cross-tenant integration tests. |
| Campus security | FIX/CONTROL - Campus-scoped authorization | Current user invitation does not visibly assign campuses. | Model access as Tenant + Campus + Role + Permission. Let a principal manage Campus A without seeing Campus B unless explicitly authorized. Add effective-access preview before saving permissions. |
| Campus context | FIX/CONTROL - Inconsistent campus scope terminology | All, Default, Tenant Wide and similar labels create accidental data errors. | Standardize to School-wide / Selected Campuses / Single Campus. Add persistent campus selector in global header. Display inherited campus context on every form. |
| Academic context | ENHANCE - Global Academic Year context | Users repeatedly select years and can work in the wrong year. | Place current Academic Year/Term in global context header similar to campus. Every academic screen should clearly display effective year. |
| Workflow architecture | MISSING - Generic record lifecycle | Different modules currently use unrelated status models. | Establish a standard lifecycle: Draft -> Submitted -> Approved -> Posted/Published -> Corrected/Reversed/Cancelled. Use where appropriate for fees, payroll, journals, results, notices, certificates and high-risk records. |
| Approval architecture | MISSING - Generic approval engine | Approvals are needed throughout the product. | Build one reusable engine supporting requester, approver role/user, sequential/parallel approval, threshold, reason, attachments, escalation, approval history and rejection/revision. Reuse it for refund, fee concession, expense, payroll, results, expulsion, purchase requests, etc. |
| Master data | ENHANCE - Central reference/master-data engine | Several modules use free text where governed values are preferable. | Centralize Department, Designation, Guardian Relationship, Payment Method, Vehicle Type, Expense Category, Document Type, Room Type, Incident Type, Fee Category, Leave Type, etc. Allow tenant-defined values with Active/Inactive and effective dates. |
| Audit | FIX/CONTROL - Audit redaction | Audit functionality exists but may capture sensitive values. | Never persist passwords, tokens, payment credentials or unnecessary medical details inside before/after JSON. Capture actor, date/time, entity, action, scope, reason, request correlation ID and changed fields. |
| Backup/DR | FIX/CONTROL - Assurance score vs unverified backup | Current review found 90% readiness despite no verified backup. | Change unknown backup state to Unknown/Critical, not healthy. Track last backup, last successful restore test, RPO/RTO, verification person and evidence. |
| Error UX | MISSING - Standard validation/error framework | Read-only review could not verify validation. | Implement server + client validation consistently. Preserve entered data after validation failures; display field errors; never surface raw exceptions. |
| Background jobs | MISSING - Job monitoring | Automation will depend heavily on background processing. | Create job dashboard: job type, tenant, started/completed time, processed count, failed count, retry count, status, error reason. Make recurring jobs idempotent. |

## 2. School configuration and academic structure

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| School Settings | FIX/CONTROL - Settings exists in help but not navigation | Tenant owners need self-service configuration. | Add visible School Settings area controlled by permission. Include school name, logo, favicon, branding, contact information, currency, timezone, date format, language, receipt configuration and communication defaults. |
| Campus Setup | ENHANCE - Enhanced campus profile | Existing campus record is basic. | Add principal, working days, timings, timezone if different, campus logo, capacity, contact person, geo location, billing identity and operational status. |
| Academic Year | ENHANCE - Year opening/closing workflow | Current year setup is basic. | Add year-opening wizard, terms, holidays, fee setup, class setup and rollover. Year closure should lock prior-period transactions and preserve history. |
| Terms/Semesters | ENHANCE - Formal term configuration | Terms exist in Academic Planning but should become central configuration. | Terms must drive assessments, result cards, lesson planning, attendance reporting and fee periods where applicable. |
| Board/Curriculum | MISSING - Education board/curriculum master | Important for Pakistani schools and multiple school types. | Configure FBISE, Punjab boards, Cambridge or custom curriculum without hard-coding them. Link board/curriculum to classes/subjects. |
| Grading setup | MISSING - Configurable grading scales | Schools use different grading schemes. | Define percentage ranges, grades, GPA points, remarks, passing criteria, rounding method and effective year. |
| Working Calendar | ENHANCE - Central academic calendar | Calendar exists but needs to control operations. | Holidays and closures should automatically affect attendance, payroll rules, library due dates, timetable and scheduled academic events. |
| Classes | ENHANCE - Rich class configuration | Current class setup is minimal. | Add educational stage, progression order, capacity, fee group, curriculum/board, default class teacher and age range. |
| Sections | ENHANCE - Capacity/room/class-teacher configuration | Current section record is minimal. | Add capacity, room, class teacher, stream/group and schedule constraints. |
| Subjects | ENHANCE - Rich subject definition | Subject currently has code/name/campus. | Add compulsory/elective, grade applicability, credit/weight, language, practical/theory classification, board/curriculum and default periods/week. |
| Electives | MISSING - Elective/course-group management | Needed in senior grades and configurable curricula. | Allow students to select subject groups, enforce combinations and capacities, manage approvals and feed selections into timetable/exams. |
| Buildings/Rooms | MISSING - Academic room master | Room appears as free text in timetable. | Create campus -> building -> floor -> room hierarchy with type, capacity and facilities. Reuse across timetable, examinations, events and resource booking. |
| Resource Booking | MISSING - Shared resource reservation | Labs/auditorium/projectors can conflict. | Allow booking of labs, halls, sports areas and devices. Detect overlapping bookings. |

## 3. Admissions and enrollment - one of the largest current opportunity areas

The current student admission screen is already substantial, but the system largely starts when the school is ready to create the student. A commercial SMS benefits greatly from owning the pre-admission journey as well.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Admissions CRM | MISSING - Inquiry/lead management | Schools need to track prospects before applications. | Create stages: Inquiry -> Contacted -> Campus Visit -> Application -> Test -> Interview -> Offered -> Accepted -> Enrolled/Lost. Assign admission officers and follow-up dates. |
| Public admission portal | MISSING - Online application | Removes manual forms/data entry. | Public school-branded form allowing parent account creation, student details, documents, desired class/campus and submission tracking. |
| Applicant portal | MISSING - Application status tracking | Improves family experience. | Candidate family can see checklist, missing documents, test date, interview date, fee due, decision and enrollment tasks. |
| Admission source | ENHANCE - Add source/channel | Helps schools understand marketing ROI. | Capture walk-in, website, Facebook, Google, referral, sibling, banner, agent, school event, etc. |
| Marketing campaign | MISSING - Campaign attribution | Gives school owners business insight. | Link inquiries to campaign and calculate inquiries -> applications -> enrollments conversion. |
| Seat planning | MISSING - Grade/section seat capacity | Prevents over-enrollment. | Calculate capacity, occupied, reserved and available seats by campus/class/section. |
| Waitlist | MISSING - Admission waiting list | Valuable for full classes. | Rank applicants, maintain priority/date, reserve seat temporarily and notify family when a place opens. |
| Entrance testing | MISSING - Admission test workflow | Common for private schools. | Schedule test, subjects, marks, evaluator, result and pass/fail/review. Reuse Question Bank later if appropriate. |
| Admission interview | MISSING - Structured interview | Current admissions form has no workflow. | Schedule interviewer, rubric/questions, rating, notes and final recommendation. |
| Applicant document checklist | ENHANCE - Extend student lifecycle documents earlier | Documents currently become stronger after student creation. | Allow requirements to be configured by grade/campus and tracked before enrollment. |
| Duplicate detection | ENHANCE - Add robust matching | Prevent duplicate student/family records. | Detect CNIC/B-Form, guardian phone, email, student name+DOB and prior application matches before creation. |
| Scholarship application | MISSING - Financial aid workflow | Different from simply entering a discount. | Application -> documents -> review -> award -> expiry/renewal -> fee structure adjustment. |
| Offer/admission decision | MISSING - Formal decision workflow | Creates traceability. | Accepted/Rejected/Waitlisted/Conditional; include decision reason, expiry date and approval where required. |
| Enrollment contract | MISSING - Digital confirmation | Helps complete enrollment digitally. | Terms/undertaking, fee policy, transport/medical consent, digital acknowledgement/signature and timestamp. |
| Admission payment | ENHANCE - Integrate admissions with fees | Current lifecycle can generate an initial invoice. | Turn this into one workflow: acceptance -> admission invoice -> payment -> student activation. |
| Conversion workflow | ENHANCE - Automate applicant -> active student | Current lifecycle partially supports this. | On completion: assign admission/roll number, class/section, create household links, portal accounts, initial fees, document checklist and welcome communications. |
| Admission analytics | MISSING - Funnel dashboard | School owner should know the admission pipeline. | Inquiry counts, conversion %, lost reasons, conversion by campus/class/source/campaign and admission officer. |

## 4. Student master record and family/guardian model

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Student 360 | ENHANCE - Expand current profile | Current profile + lifecycle are good foundations but not a full unified view. | One screen/timeline should show academics, attendance, fees, communications, health, behavior, library, transport, hostel, documents, achievements and lifecycle events. |
| Household model | MISSING - Family/household entity | A guardian may have several children. | Create Household/Family record and attach all guardians/students. Shared address/contact/payment preferences should not be duplicated unnecessarily. |
| Sibling view | ENHANCE - Existing sibling capability needs expansion | Siblings appear in lifecycle. | From any student/guardian show all siblings, campuses, fee balances, attendance alerts and parent portal account. |
| Guardian roles | ENHANCE - Rich relationship permissions | Current relationship is mostly descriptive. | Separate Legal Guardian, Primary Contact, Emergency Contact, Fee Payer, Pickup Authorized, Portal Access Allowed, Receives Academic Notices, Receives Financial Notices. |
| Custody rules | MISSING - Controlled custody/contact restrictions | Critical operationally. | Record contact/pickup restrictions, supporting documents, effective dates and highly restricted visibility. |
| Parent preferences | MISSING - Language/channel preferences | Improves communication success. | Preferred language, WhatsApp/SMS/email/push options and notification categories. |
| B-Form/CNIC distinction | ENHANCE - Pakistan-specific identity model | Generic NationalId is insufficient. | Store identity type separately: CRC/B-Form, CNIC/NICOP/passport, number, expiry where applicable, verification state. |
| Student identifiers | ENHANCE - Separate IDs cleanly | Different schools use several identifiers. | Admission No., Roll No., Registration No., Board No., biometric/card ID should be separate effective-dated identifiers. |
| Custom fields | MISSING - Tenant-configurable student fields | Prevents custom development for every school. | School administrator defines text, number, date, select, checkbox fields and visibility/required rules. |
| Student documents | ENHANCE - Mature document vault | Existing documents are basic. | Document type, issue/expiry, required status, version, verification by/date, confidentiality, preview, malware scanning and retention. |
| Lifecycle | ENHANCE - Strengthen existing excellent foundation | Already one of the stronger areas. | Add approvals for waiver/expulsion, clearance, generated letters, fees settlement, effective dates and rollback/reversal rules. |
| Student transfer | ENHANCE - Add clearance workflow | Existing internal/external transfer exists. | Before transfer verify finance, library, hostel, transport and school-property clearance. Generate transfer certificate automatically. |
| Graduation | ENHANCE - Structured graduation completion | Graduation exists as lifecycle status. | Add graduation eligibility, pending fees/books/documents, final transcript/certificate and alumni conversion. |
| Alumni | MISSING - Dedicated alumni module | Alumni status exists but not an alumni experience. | Alumni contact record, graduation cohort, further education/employment, events, communications and optional donations/fundraising later. |

## 5. Student health, safety, behavior and wellbeing

This is one of the clearer gaps compared with larger K-12 systems. The product captures medical notes and special needs, but there is no visible full school clinic, behavior or counseling module.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Health profile | ENHANCE - Expand medical fields | Current medical notes/special needs are static. | Structured medical conditions, allergies, blood group, emergency plan, physician, insurance if needed and permission controls. |
| Immunizations | MISSING - Vaccination records | Common school requirement. | Vaccine name, dose, date, evidence, next due date and exemptions if relevant. |
| Medication | MISSING - Medication management | Needed where a school nurse administers medicine. | Medication, dosage, schedule, prescribing doctor, guardian consent, administration log and stock if held by clinic. |
| Nurse/clinic visits | MISSING - School clinic log | Creates operational history. | Check-in, complaint, observations, treatment, medication, disposition, guardian contacted and staff member. |
| Health alerts | MISSING - Controlled student alerts | Teachers need relevant safety information without seeing full records. | For example, surface severe-allergy alerts to authorized roles with the minimum required information. |
| Counseling | MISSING - Counseling/wellbeing module | Academic performance is not the only student concern. | Referral, counselor assignment, appointment, follow-up and highly restricted notes/access. |
| Behavior/discipline | MISSING - Incident management | Major gap in student lifecycle. | Incident type, date/location, students involved, witnesses, action, consequence, parent notification, follow-up and appeal. |
| Merit/demerit | MISSING - Configurable behavior points | Useful for many schools. | Tenant-configurable positive/negative points and behavior categories. |
| Special needs | ENHANCE - Expand existing support fields | Existing fields already capture accommodations. | Add structured accommodation plan, responsible staff, review date and relevant teacher visibility. |
| Safeguarding workflow | MISSING - Restricted concern workflow | Schools may need controlled escalation. | Separate highly restricted role/access, concern recording, escalation owner and audit. Keep implementation aligned to local policy rather than hard-coded legislation. |
| Emergency workflow | MISSING - Emergency incident/contact flow | Useful during real incidents. | Emergency contact priority, actions taken, ambulance/hospital details if applicable and family notification audit. |

## 6. Attendance and daily school operations

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Default attendance state | FIX/CONTROL - Do not default unmarked students to Present | The review identified this as an operational risk. | Use Unmarked until explicitly reviewed. Display Marked X / Total Y. Prevent finalization with unmarked students unless permission/confirmation. |
| Attendance codes | ENHANCE - Rich attendance states | Present/Absent/Late/Leave is basic. | Add excused/unexcused absence, medical, school activity, early departure, remote if appropriate and tenant-defined codes. |
| Period attendance | MISSING - Period/subject attendance | Useful for secondary schools. | Support daily + per-period mode configurable per campus/class. |
| Late arrival | MISSING - Late/gate check-in | Connect attendance with gate operations. | Capture arrival time, reason, gate/operator and automatically update attendance. |
| Early departure | MISSING - Student checkout | Useful safety control. | Guardian authorization, reason, approval, pickup person and departure time. |
| Attendance correction | ENHANCE - Formal correction workflow | Existing history should not be silently overwritten. | Teacher requests edit after cutoff -> authorized user approves -> audit old/new state. |
| Parent alerts | MISSING - Attendance automation | High-value parent feature. | Absence or late attendance can trigger configurable SMS/WhatsApp/push notification after attendance finalization. |
| Consecutive absence | MISSING - Rule-based intervention | Helps schools respond early. | For example, 3 consecutive days -> teacher alert; 5 -> coordinator task. Threshold should be configurable. |
| Chronic absence analytics | MISSING - Attendance risk reporting | More valuable than basic daily summaries. | Monthly %, trend, consecutive absence, repeated Monday/Friday absence, attendance by subject/period. |
| QR/RFID/Biometric | MISSING - Optional attendance integrations | Schools may want automated capture. | Design adapter/integration interface rather than hard-coding one vendor. |
| Offline attendance | MISSING - Low-connectivity capability | Particularly practical locally. | PWA/mobile cache class roster, capture attendance offline, synchronize with conflict resolution. |
| Attendance locking | MISSING - Finalization | Prevent unnoticed historical editing. | Draft -> Finalized -> Corrected. |
| Teacher My Day | MISSING - Dedicated daily workspace | Teachers should not navigate the whole ERP. | Today's classes, take attendance, homework, lesson plan, pending marking, substitutions and notices. |

## 7. Timetable, scheduling and teacher workload

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Conflict engine | ENHANCE - Add robust conflict detection | Current slot form can create overlapping resources unless backend prevents it. | Check teacher, class/section, room, campus/travel, subject constraints and unavailable periods. |
| Teacher availability | MISSING - Availability matrix | Needed before intelligent scheduling. | Define working days, free periods, part-time hours and unavailable times. |
| Subject weekly quota | MISSING - Period requirements | Enables schedule validation. | Store desired periods/week for each class+subject. |
| Master timetable builder | MISSING - Visual timetable workspace | Manual slot entry does not scale. | Grid view allowing drag/drop, conflict highlighting, filters and unscheduled requirement list. |
| Auto timetable | STRATEGIC - Constraint-based timetable generator | Valuable premium differentiator. | Generate suggestions considering teacher availability, rooms, periods, subject quotas and breaks. Human approves final schedule. |
| Substitute teachers | MISSING - Substitution management | Common daily problem. | Absence -> identify qualified available teacher -> assign -> notify teacher/class -> update workload record. |
| Teacher workload | MISSING - Workload dashboard | Prevents overloading. | Teaching periods, substitutions, free periods, extracurricular responsibility and weekly totals. |
| Alternating schedules | MISSING - Week A/B or rotation support | Some schools require rotating timetables. | Make cycle configurable rather than hard-coded. |
| Exam timetable | MISSING - Separate examination scheduling | Exam setup has dates but not robust subject schedule. | Date/time, subject, room, invigilators, student group and clash detection. |
| Printable/mobile schedule | ENHANCE - Multiple views | Improve adoption. | Teacher, student, class, room and campus schedule views. |
| Room booking | MISSING - Shared resource integration | Prevents lab/auditorium conflicts. | Timetable and event bookings should use the same resource calendar. |

## 8. Curriculum, lesson planning and teacher academic workspace

Academic Planning is already one of the stronger modules. The goal should be to make it easier to use and connect it with teaching outcomes.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Learning outcomes | MISSING - Structured outcomes/standards | Moves system beyond syllabus text. | Curriculum -> units -> learning outcomes -> lessons -> assignments/questions -> results. |
| Curriculum versioning | ENHANCE - Effective-dated curriculum | Curriculum can change between years. | Do not overwrite old year curriculum. |
| Textbook/resources | ENHANCE - Structured references | Existing resources are flexible but broad. | Book, chapter, page, URL, document/video resource and licensing metadata. |
| Lesson approval | ENHANCE - Formal workflow | Review status exists; strengthen process. | Draft -> Submitted -> Reviewed/Approved -> Delivered. |
| Lesson delivery | ENHANCE - Link planned vs actually taught | Teacher diary exists. | Compare planned date/periods to delivered coverage automatically. |
| Syllabus progress | ENHANCE - Better analytics | Current coverage exists. | Completion %, behind/ahead schedule and expected completion based on academic calendar. |
| Substitute lesson handover | MISSING - Link to substitution | Helps teaching continuity. | Substitute teacher sees lesson plan/resources for missed teacher. |
| Teacher notes | ENHANCE - Personal/private vs shared notes | Need visibility controls. | Separate teacher-only note, parent-visible remark and official student comment. |
| Class/advisory groups | MISSING - Student group framework | Useful beyond class/section. | Advisory groups, remedial groups, clubs, teams and study groups using common membership model. |

## 9. Homework, LMS and continuous gradebook

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Homework submissions | ENHANCE - Strengthen submission workflow | Submission count exists. | Student upload/text submission, timestamp, late indicator, resubmission version and teacher feedback. |
| Multiple attachments | ENHANCE - Expand homework attachments | Useful for assignments. | Documents, images, audio/video/link with safe file policies. |
| Rubrics | MISSING - Assignment rubrics | Speeds consistent grading. | Criteria, levels, points, feedback and reuse templates. |
| Scheduled release | MISSING - Assignment scheduling | Teachers plan ahead. | Publish date/time separate from assigned date. |
| Differentiated assignment | MISSING - Different work for selected students/groups | Supports learning needs. | Same class but different assignment/content/due date/accommodation. |
| Missing work alerts | MISSING - Missing assignment monitoring | Parents/students benefit strongly. | Dashboard and notifications for overdue/missing submissions. |
| Continuous gradebook | MISSING - Gradebook outside formal exams | Major academic gap. | Teacher gradebook combining homework, quiz, project, class participation and exams. |
| Assessment weighting | MISSING - Configurable components | Needed for term grades. | Quiz 10%, assignment 20%, midterm 30%, final 40% or any school-defined rule. |
| Discussion/class stream | STRATEGIC - Lightweight class collaboration | Optional LMS expansion. | Announcements/resources/discussion within course if market demand justifies it. |
| Parent visibility | ENHANCE - Configurable academic visibility | Parents need actionable information. | School decides when scores/feedback become parent-visible. |

## 10. Examinations, assessments, results and academic records

The question bank and assessment capability is already unusually broad. It should be preserved and deepened instead of rebuilt.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Exam terms | ENHANCE - Link exams to term/series | Exam currently mostly class/date based. | For example: First Term, Mid-Year, Annual, Mock, Monthly Test. |
| Subject rules | MISSING - Subject-specific marks/passing | One global pass percentage is limiting. | Total theory/practical/project marks, passing marks, grace rules and absent/exempt states. |
| Grade scheme | MISSING - Central grade rules | Needed for report cards. | Reuse school grading configuration rather than exam-specific logic. |
| Marks validation | ENHANCE - Stronger entry controls | Prevent wrong results. | Maximum mark validation, missing/absent codes, suspicious outliers, completion progress. |
| Bulk marks import | MISSING - Spreadsheet import preview | High-value admin capability. | Template download -> upload -> validation preview -> rejected rows -> confirm. |
| Result moderation | MISSING - Approval workflow | Critical before publishing. | Teacher submit -> HOD review -> exam controller/principal approval -> publish. |
| Result locking | MISSING - Lock published marks | Prevent silent history changes. | Correction creates new version/revision with reason and approval. |
| Report card designer | MISSING - Major missing feature | Different schools demand custom formats. | Logo, sections, subjects, grade, percentage, attendance, remarks, signatures, ranking policy and custom fields. |
| Transcript | MISSING - Multi-year academic transcript | Important school record. | Consolidate historical term/year results and completion status. |
| Progress report | MISSING - Mid-term/non-final reporting | Useful before formal exams. | Combine gradebook, behavior, attendance and teacher remarks. |
| Honor roll/awards | MISSING - Optional rules | Some schools expect it. | Define tenant rules for academic awards rather than hard-code. |
| Class rank | MISSING - Optional configurable ranking | Policies differ. | Allow schools to enable/disable and configure tie handling. |
| Graduation progress | MISSING - Completion tracker | Useful in senior levels. | Subjects/credits/requirements completed vs remaining. |
| Result publication | ENHANCE - Parent/student release workflow | Current Publish Result exists. | Preview exactly what parent/student will see; optionally schedule release. |
| Result acknowledgement | MISSING - Parent acknowledgment | Useful for electronic report cards. | Track viewed/downloaded/acknowledged. |
| Question review | ENHANCE - Approval/version workflow | Question bank is advanced but governance is needed. | Draft -> reviewed -> approved -> archived with author/reviewer. |
| Question analytics | STRATEGIC - Item analysis | Strong differentiator. | Difficulty index, discrimination, frequently missed options and performance across attempts. |
| Paper blueprint | MISSING - Structured paper design | Improves academic quality. | Desired marks/questions by topic, outcome, difficulty and question type. |
| Random variants | STRATEGIC - Question paper variants | Useful for examination integrity. | Generate A/B/C papers from same blueprint with controlled randomization. |
| Online assessment recovery | ENHANCE - Resilience rules | Needed for real exams. | Autosave, reconnection, attempt recovery, submission receipt and time accommodation. |

## 11. Fee management, billing and collections - major commercial priority

The Product Review already identifies recurring billing as one of the biggest visible gaps.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Fee structure versions | ENHANCE - Add effective dates/versioning | Structures should not alter historical invoices. | New fee amount creates a new effective version. |
| Flexible fee lines | FIX/CONTROL - Remove fixed five-line assumption | Current screen exposes five fee lines. | Use dynamic fee-line collection. |
| Charge types | ENHANCE - Extend Fee Heads | Enables proper automation. | Recurring, one-time, refundable, optional, transport, hostel, activity, security deposit etc. |
| Recurring billing | MISSING - Monthly/periodic fee generation | Essential for practical operation. | Scheduled generation by structure with dry-run preview and exceptions. |
| Duplicate protection | MISSING - Invoice idempotency | Avoid duplicate monthly invoices. | Unique rule such as Student + FeePeriod + Structure/version. |
| Installment plans | MISSING - Flexible payment schedule | Needed for many families. | Divide fees into scheduled installments with due dates. |
| Sibling discount | MISSING - Family-aware concession | Very common. | Rules based on sibling count/order or configured percentage/amount. |
| Scholarship/concession | MISSING - Structured concession engine | Manual discount is insufficient. | Type, amount/%, approval, reason, effective dates and renewal. |
| Late fee | MISSING - Configurable penalty rules | Automates collections. | Grace period, fixed/percentage, one-time/recurring, maximum cap and exemptions. |
| Proration | MISSING - Mid-period joining/leaving rules | Avoid manual calculations. | Tenant-configurable daily/monthly proration. |
| Carry-forward | MISSING - Outstanding balance handling | Necessary across periods. | Define how prior balance appears in next statement without duplicating AR. |
| Partial payment | ENHANCE - Ensure robust allocation | Invoice displays paid/balance but behavior is unverified. | Allocate payment across fee heads/invoices using explicit rules. |
| Advance payment | MISSING - Family credit balance | Parents often pay in advance. | Maintain wallet/credit and auto-allocate when invoices are issued. |
| Overpayment | MISSING - Handle excess safely | Prevent accounting inconsistencies. | Store unallocated credit or refund. |
| Refunds | MISSING - Refund workflow | Current system does not visibly evidence it. | Request -> approval -> refund transaction -> ledger/reconciliation -> receipt. |
| Credit notes | MISSING - Financial correction | Never just edit issued invoice totals. | Reverse/adjust through auditable credit note. |
| Family statement | MISSING - Household financial view | Parent may have several children. | Consolidated family outstanding/paid statement with per-child detail. |
| Cash collection | ENHANCE - Cashier workflow | Important locally. | Cashier, register/session, receipt number, payment method and daily closing. |
| Day closing | MISSING - Cashier settlement | Reduces leakage/errors. | Expected cash vs counted cash, bank deposits and variance approval. |
| Online payment | MISSING - Payment gateway integration | Reduces manual collection. | Provider abstraction allowing local bank/payment integrations later. |
| Raast/QR | MISSING - Pakistan payment option | High-value local capability. | Support merchant QR/partner-bank integration where commercially and technically appropriate. |
| Bank statement import | MISSING - Reconciliation import | Reduces accountant workload. | CSV/XLS/API import -> matching engine -> unmatched queue -> manual confirmation. |
| Auto reconciliation | STRATEGIC - Matching engine | Strong operational differentiator. | Match amount/reference/student/invoice while retaining human review for uncertain matches. |
| Fee reminders | MISSING - Automated communication | Helps collection. | Before due, on due, overdue + configurable escalation. |
| Promise-to-pay | MISSING - Collection follow-up | Useful for defaulters. | Record promised amount/date and automatically create follow-up if missed. |
| Defaulter management | MISSING - Collections queue | Gives accounts staff workflow. | Aging, last contact, commitment, waiver request and follow-up assignment. |
| Fee aging | MISSING - 0-30/31-60 etc. | Management needs receivable quality. | Drill down to student/family/invoice. |
| Invoice vs receipt | FIX/CONTROL - Correct terminology/workflow | Review notes current publishing can blur them. | Invoice = amount due; receipt = payment evidence. Do not publish an unpaid receipt. |
| Receipt delivery | ENHANCE - Delivery evidence | Publishing history already exists. | Per recipient/provider ID, delivered/failed, retry and exact receipt/template version. |
| Transport/hostel linkage | ENHANCE - Integrate charges automatically | Modules already store monthly fees. | Enrollment/assignment should create or remove recurring charges using effective dates. |
| Canteen/activity charges | MISSING - Future charge source | Enables one parent account. | All billable school services should feed the same billing engine. |

## 12. Parent and student digital experience - another major missing layer

The reviewed UI proves guardian records and student assessment routes exist, but it does not evidence a complete family/student portal. Because the review was conducted as SchoolAdmin, verify the role-specific application before implementing a duplicate portal.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Parent portal | VERIFY - Full guardian portal | One of the strongest adoption/sales features. | First verify any role-specific implementation. If incomplete, provide children, attendance, results, homework, timetable, fees, receipts, notices, documents, meetings and requests from one account. |
| Multi-child account | MISSING - Household portal | Parents should not maintain separate accounts. | One login switches children/campuses. |
| Student portal | VERIFY - Expand beyond assessments | Current routes show My Assessments/Results only. | Verify existing role routes; target timetable, homework, submissions, grades, attendance, resources, notices, calendar and fee visibility depending age/policy. |
| Parent self-service | MISSING - Controlled profile updates | Reduces reception workload. | Parent proposes phone/address/emergency changes -> school approves where needed. |
| Leave request | MISSING - Parent/student request | Common daily workflow. | Request date/range, reason/document -> school approval -> attendance update. |
| PTM booking | ENHANCE - Expand current meeting scheduling | Meetings currently can be created administratively. | Teachers publish availability; parent selects slot; confirmations/reminders; check-in/no-show. |
| Appointment request | MISSING - General appointments | Parent may need principal/accounts/admin. | Department/staff, reason, preferred time and workflow. |
| Forms/consents | MISSING - Digital forms | Removes paper forms. | Trips, medical permissions, media consent, undertakings, surveys and annual updates. |
| Digital signature | MISSING - Electronic acknowledgment | Useful for policies/forms. | Store signer, timestamp, version and agreement text. |
| Parent inbox | MISSING - Unified communications | Prevent messages being scattered. | Notices, messages, reminders, meeting updates and system notifications in one center. |
| Mobile/PWA | MISSING - Responsive installable portal | Families primarily use phones. | Design PWA first; native apps can come later if justified. |
| Low-bandwidth mode | MISSING - Pakistan-market UX | Improves usability. | Lightweight pages, compressed assets and graceful intermittent connectivity. |
| Notification center | MISSING - In-app notifications | Complements SMS/email. | Read/unread, type, deep-link and preferences. |

## 13. Communications and engagement

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| WhatsApp | MISSING - Provider-based integration | Very important locally. | Use approved provider abstraction; templates/consent/delivery IDs. Do not hard-code a single vendor. |
| SMS | ENHANCE - Stronger delivery diagnostics | SMS exists. | Provider message ID, cost, failure reason, retry policy and account credit monitoring. |
| Email | ENHANCE - Delivery tracking | Email templates exist. | Bounce, failure, sent timestamp and provider tracking where available. |
| Template management | ENHANCE - Version/approval/localization | Templates already exist. | Version templates, language, approval state and variables. |
| Urdu | MISSING - Multilingual templates/UI readiness | Valuable Pakistani differentiator. | UTF-8, RTL layout, Urdu message templates and bilingual documents. |
| Preference center | MISSING - Guardian consent/preferences | Avoid unwanted communications. | Financial, academic, marketing and emergency categories. |
| Quiet hours | MISSING - Communication rules | Prevent inappropriate automated messages. | Emergency messages can override. |
| Emergency broadcast | MISSING - High-priority workflow | Valuable school safety capability. | Audience preview, multi-channel send, delivery monitoring and acknowledgments. |
| Notice read receipts | MISSING - Acknowledgement | Particularly useful for important notices. | Track delivered/read/acknowledged without assuming SMS read unless provider supports it. |
| Complaint/helpdesk | MISSING - Parent/student case management | Communication needs accountability. | Category, ticket, owner, SLA, status, messages, resolution and satisfaction. |
| Surveys | ENHANCE - Extend existing polls | Existing survey/poll foundation. | Targeted distribution, anonymous rules, exports, dashboards and minimum-group privacy. |
| Communication timeline | MISSING - Student/family history | Helps resolve disputes. | Authorized staff see relevant communications attached to student/household. |

## 14. Activities, clubs, houses, sports and student life

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| House system | MISSING - Houses and points | Common in many private schools. | Houses, student membership, points, events and leaderboard. |
| Clubs | MISSING - Club/society management | Supports extracurricular life. | Club, supervisor, members, meetings, events and announcements. |
| Sports | MISSING - Sports/team management | Major school activity domain. | Sports, teams, coaches, roster, practice and match schedule. |
| Fixtures/results | MISSING - Competition management | Gives families/student portal value. | Opponent, venue, score/result, tournament and achievements. |
| Achievements | MISSING - Student achievements | Builds complete student record. | Academic, sports, arts, competitions, certificates and awards. |
| Events registration | MISSING - Event participation | Useful school-wide. | Capacity, registration, attendance and optional fee. |
| Trips/excursions | MISSING - School trip workflow | Currently not evidenced. | Trip plan, students/staff, transport, cost, emergency contacts, health alerts and attendance. |
| Trip consent | MISSING - Guardian consent | Replace paperwork. | Digital consent + payment + emergency details. |
| Activity fee integration | MISSING - Connected billing | Avoid duplicate financial processes. | Optional activities can create fee charge automatically. |

## 15. Transport

Transport exists, but it is predominantly configuration/assignment rather than a full daily transport operation.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Stops | ENHANCE - Structured route stops | Route has start/end but detailed stop management was not evidenced. | Stop name, GPS location, order, pickup time, drop time and capacity. |
| Route versioning | MISSING - Effective-dated routes | Routes change throughout year. | Preserve historical assignments. |
| GPS tracking | STRATEGIC - Live bus location | Strong parent-facing premium feature. | Integrate supported GPS providers through API abstraction. |
| ETA | STRATEGIC - Arrival prediction | Improves parent experience. | Show approximate bus arrival from live data when available. |
| Parent alert | MISSING - Bus notifications | High-value safety/UX. | Boarding, approaching stop, dropped off, delay/cancellation. |
| Bus attendance | MISSING - Boarding/alighting record | Important student safety feature. | QR/RFID/manual scan; compare against school attendance. |
| Capacity control | ENHANCE - Validate assignments | Vehicle capacities exist. | Prevent or warn overbooking. |
| Driver master | ENHANCE - Link driver to employee | Current driver/helper are free text. | Staff/contractor record, CNIC/license, expiry, contact and background docs. |
| Vehicle maintenance | MISSING - Maintenance schedule | Existing insurance/fitness expiry is not enough. | Service intervals, repairs, inspection and downtime. |
| Fuel | MISSING - Fuel log | Supports cost analysis. | Quantity, cost, mileage and vehicle. |
| Transport incidents | MISSING - Accident/breakdown log | Operational safety. | Event, location, vehicle, students, action and follow-up. |
| Temporary change | MISSING - One-day route changes | Real schools frequently need this. | Guardian-requested temporary stop/route with approval and expiry. |
| Transport analytics | ENHANCE - Expand report | Current summary can go further. | Occupancy %, fee collection, route cost/profitability, punctuality and incidents. |

## 16. Hostel / residence

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Capacity rules | ENHANCE - Strong validation | Existing buildings/rooms/beds are a good foundation. | Ensure building/room/bed capacities cannot conflict. |
| Room movement | MISSING - Bed transfer workflow | Students change rooms. | Effective dates, old/new bed and reason. |
| Hostel attendance | MISSING - Night register | Critical boarding operation. | Present/out/on leave/missing with daily verification. |
| Hostel leave | MISSING - Leave/pass workflow | Students may leave campus. | Guardian request/approval, expected return and actual return. |
| Hostel visitors | MISSING - Visitor log | Safety and traceability. | Visitor, student, time in/out and authorization. |
| Hostel incidents | MISSING - Residence incident log | Centralize boarding issues. | Behavior/health/maintenance categories. |
| Hostel fee sync | ENHANCE - Integrate automatically | Monthly fee already exists. | Allocation -> recurring fee; end allocation -> stop future charges. |
| Security deposit | ENHANCE - Deposit ledger/refund | Deposit field exists. | Deposit held, deductions, refund approval and accounting entry. |
| Meals | MISSING - Meal-plan capability | Useful for boarding schools. | Meal plan, dates, dietary notes, billing and attendance if needed. |

## 17. Library

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Title vs copy | FIX/CONTROL - Separate book title and physical copy | Current editable counts can become inconsistent. | Book title/catalog record + individual copy/barcode/accession records. |
| Barcode/QR | MISSING - Scan-based circulation | Speeds real library operation. | Issue/return via scan. |
| Member identity | FIX/CONTROL - Reuse student/staff record | Current member can duplicate name/contact. | LibraryMember links to Person/Student/Employee. |
| Renewals | MISSING - Book renewal | Standard library flow. | Renewal count/limits and blocked reservations. |
| Reservations | MISSING - Hold queue | Useful for unavailable books. | Queue by request date with expiry. |
| Fine engine | ENHANCE - Automate fines | Fine field exists. | Grace days, holidays, per-day rate, maximum, waiver approval. |
| Notifications | MISSING - Due/overdue reminders | Reduces lost items. | Before due and overdue rules. |
| Lost/damaged books | MISSING - Settlement | Need financial handling. | Replacement charge/waiver and optional fee integration. |
| Digital library | MISSING - Electronic resources | Expands LMS. | PDFs, eBooks, links, videos and access rights. |
| Acquisition | MISSING - Library procurement integration | Helps manage new books. | Request -> order -> receive -> catalog. |
| Library analytics | ENHANCE - Expand reporting | Existing summary is basic. | Popular books, low usage, overdue trends and acquisition demand. |

## 18. HR, teacher and staff management

The HR module is already broad. The main work is integration and operational refinement rather than a completely new HR system.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Unified employee model | ENHANCE - Teacher/staff identity consolidation | Teachers and staff share many attributes. | One Employee core with subtype/roles can reduce duplication while retaining academic-specific teacher data. |
| Org structure | ENHANCE - Effective-dated hierarchy | Department/designation already exists. | Manager, department, position changes should preserve history. |
| Shifts | MISSING - Staff shift management | Needed for support/security/transport staff. | Shift, roster, grace, overtime and attendance policy. |
| Qualifications | ENHANCE - Structured qualifications | Current qualification is largely text. | Degree/certification, institution, year, document and expiry where relevant. |
| Compliance documents | ENHANCE - Stronger expiry management | Employee documents already exist. | Automated reminders and mandatory-by-role rules. |
| Onboarding | MISSING - New employee checklist | Recruitment exists but handoff can improve. | Offer accepted -> documents -> contract -> user account -> payroll -> assets -> training. |
| Offboarding | MISSING - Employee exit process | Essential control. | Resignation/termination, clearance, assets, final salary, account deactivation and documents. |
| Recruitment portal | ENHANCE - Expand existing vacancy pipeline | Recruitment already exists. | Public jobs page, applicant portal, structured scoring and interview feedback. |
| Background checks | MISSING - Configurable evidence tracking | Schools may require screening. | Store check type/status/date/document based on school policy. |
| Leave accrual | ENHANCE - Automate entitlement | Policies/balances exist. | Monthly/yearly accrual, carry forward, expiry and adjustment audit. |
| Holiday integration | ENHANCE - Use campus calendars | Prevent wrong leave calculations. | Shared calendar source. |
| Teacher substitution | MISSING - Connect HR leave to timetable | High-value workflow. | Approved teacher leave automatically generates affected-class substitution queue. |
| Performance | ENHANCE - Expand appraisal | Existing reviews are a good start. | Goals, classroom observation, evidence, competency ratings, acknowledgment and development plan. |
| Training matrix | ENHANCE - Role-based training | Existing training records. | Mandatory courses by role + due/expiry/completion. |
| Staff self-service | MISSING - Employee portal | Reduces HR workload. | Leave, payslips, documents, profile update, training and attendance. |
| Asset assignment | MISSING - Connect HR with assets | Needed for laptops/keys/cards. | Issue/return employee assets with offboarding clearance. |

## 19. Payroll

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Salary components | FIX/CONTROL - Replace only aggregate allowance/deduction | Current structure is too coarse. | Basic, housing, transport, bonus, overtime, tax, loan, provident fund, etc. as effective-dated components. |
| Payroll rules | MISSING - Formula/rules engine | Different employees have different rules. | Fixed amount, percentage, formula and eligibility. |
| Attendance integration | MISSING - Payroll input preview | Avoid manual mismatch. | Show absences, unpaid leave, overtime etc. before generation. |
| Loans/advances | MISSING - Employee financial deductions | Common payroll requirement. | Principal, installments, balance and payroll deduction. |
| Tax configuration | MISSING - Effective-dated tax rules | Avoid hard-coded yearly values. | Make rules configurable and have local specialists validate regulatory implementation. |
| Payroll preview | ENHANCE - Dry run | Generation must be safe. | Preview employee-by-employee changes/exceptions before finalization. |
| Approval | MISSING - Maker/checker | Payroll is high-risk. | Prepared -> Reviewed -> Approved -> Paid. |
| Payroll lock | MISSING - Immutable finalized run | Prevent retrospective editing. | Correction/reversal via new transactions. |
| Payslip | MISSING - Employee payslip portal/PDF | Expected HR capability. | Branded, downloadable, historical. |
| Bank file | MISSING - Salary disbursement export | Helps accountant. | Bank-format-specific adapter/export. |
| Payroll -> GL | MISSING - Accounting integration | Prevent double entry. | Approved payroll generates finance journal. |

## 20. Inventory, assets, procurement and maintenance

Current inventory is mainly a stock item master. This area can become much more useful operationally.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Stock ledger | MISSING - Inventory movements | Current stock should not be directly edited continuously. | Receipt, issue, transfer, adjustment and return transactions. |
| Stock count | MISSING - Physical inventory count | Needed for reconciliation. | Count session -> variance -> approval -> adjustment. |
| Inter-campus transfer | MISSING - Stock movement | Multi-campus needs this. | From/to location, dispatch, receive and variance. |
| Purchase requisition | MISSING - Procurement workflow | Departments need to request goods. | Requester, items, quantity, purpose, budget and approval. |
| Quotations | MISSING - Vendor quotation comparison | Improves purchasing controls. | Multiple quotes, comparison and selection reason. |
| Purchase order | MISSING - PO | Standard procurement control. | Approved requisition -> vendor PO. |
| Goods receipt | MISSING - GRN/receiving | Closes procurement loop. | Quantity received/rejected and inventory update. |
| Vendor master | MISSING - Vendor management | Expenses currently use free-text payee. | Supplier contacts, tax details, bank/payment data access controlled, contracts and history. |
| Asset register | MISSING - Fixed assets | Inventory and assets are different. | Serial no., purchase date, value, location, custodian, warranty and status. |
| Asset assignment | MISSING - Issue assets to user/room | Accountability. | Employee/student/room allocation, issue date, return/condition. |
| Depreciation | MISSING - Optional accounting integration | Useful for larger schools. | Configurable method and GL posting. |
| Maintenance tickets | MISSING - Facility/service desk | Highly practical. | AC, electricity, computers, furniture, plumbing etc. with owner/status/SLA. |
| Preventive maintenance | MISSING - Scheduled asset maintenance | Reduces failures. | Recurring service schedule for vehicles/equipment. |

## 21. Finance and accounting

The accounting module has a solid starting foundation with chart of accounts, periods, journals, statements, budgets and reconciliation.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Posting architecture | FIX/CONTROL - Define subledger -> GL integration | Separate modules must reconcile. | Fees, refunds, expenses, payroll, inventory/asset events should create controlled ledger postings. |
| Journal immutability | FIX/CONTROL - Approved/posted journals must not be edited | Accounting control. | Reverse and repost rather than overwrite. |
| Fiscal locks | ENHANCE - Strong close/reopen | Period exists. | Closed periods block posting; reopening requires approval/reason. |
| Opening balances | MISSING - Migration/onboarding | Schools need starting balance. | Controlled import for accounts, AR and cash/bank. |
| Bank import | MISSING - Statement import | Existing reconciliation appears manual. | CSV/XLS/API provider adapter and transaction matching. |
| Accounts payable | MISSING - Vendor payable workflow | Expense record is not full AP. | Invoice received -> approval -> payable -> payment -> reconciliation. |
| Payment batches | MISSING - Supplier payments | Useful in larger schools. | Group approved vendor payments and generate bank instruction/export. |
| Budget control | ENHANCE - Prevent overspend | Budgets already exist. | Warning/block based on tenant policy when requisition/expense exceeds available budget. |
| Cost centers | MISSING - Finance dimensions | Essential for multi-campus/department reporting. | Campus, department, project/activity dimensions. |
| Attachments | MISSING - Voucher evidence | Important audit trail. | Invoice, receipt, approval document. |
| Tax | MISSING - Configurable tax/withholding | Avoid hard-coded rates. | Effective-dated configuration plus reporting. |
| Financial close cockpit | STRATEGIC - Strong differentiator | Owner/accountant need one close view. | Bank reconciled? fees posted? payroll posted? expenses pending? open periods? variances? |

## 22. Canteen, meal plans and student wallet

This should be an add-on, not part of the first implementation wave.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Canteen | MISSING - Optional module | Useful premium add-on. | Products/menu, pricing and sales. |
| Student wallet | MISSING - Prepaid account | Parents can control spending. | Top-up, balance, transactions, limits and refunds. |
| QR/ID payment | STRATEGIC - Cashless school | Strong modern-school feature. | Student ID/QR used at canteen or school shop. |
| Meal plan | MISSING - Subscription meals | Useful for boarding/day schools. | Plan, dates, dietary flags, billing. |
| Dietary alerts | ENHANCE - Integrate health | Safety. | Only expose necessary allergy information to authorized canteen staff. |

## 23. Certificates, ID cards, gate, pickup and visitor management

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Certificates | ENHANCE - Strengthen existing feature | Templates already exist. | Approval, campus/year serials, bilingual templates, revocation and issuance history. |
| QR verification | MISSING - Certificate verification | Reduces forgery. | Public limited verification page showing certificate validity without exposing excessive student data. |
| ID designer | MISSING - Configurable card templates | Current issue flow lacks designer in evidence. | School logo, photo, fields, QR/barcode, orientation. |
| Bulk card issuance | MISSING - Mass printing | Admin productivity. | Generate class/section cards in batch. |
| Replacement/revocation | MISSING - Card lifecycle | Lost cards need invalidation. | Issue replacement and mark prior card revoked. |
| Authorized pickup | MISSING - Student pickup management | Important for younger students. | Approved pickup persons, photo/contact/relationship, validity. |
| Gate pass | MISSING - Early-leave pass | Connect attendance + security. | Student, reason, approver, pickup person and QR/reference. |
| Visitor management | MISSING - Major missing operational feature | Security and professionalism. | Visitor details, purpose, host, ID reference, badge/pass, check-in/out and optional pre-approval. |
| Event visitor pass | MISSING - Temporary bulk passes | Useful PTM/events. | Pre-registration and QR check-in. |

## 24. Reporting, analytics and management intelligence

Current reports largely replicate dashboard-style operational information. The next level should be a reusable reporting platform rather than adding isolated reports forever.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Report catalog | MISSING - Central report library | Users need predictable navigation. | Academics, Attendance, Fees, Finance, HR, Admissions, Transport, Hostel, Library etc. |
| Saved filters | MISSING - Saved report views | Frequent reports become one click. | Private/shared saved filter sets. |
| Scheduled reports | ENHANCE - Existing assurance scheduling should become user-facing | Reduces manual work. | Schedule PDF/Excel/email with campus/role authorization. |
| Custom report builder | MISSING - Self-service reporting | Reduces custom dev requests. | Select approved dataset, fields, filters, grouping and calculations. |
| Export permissions | FIX/CONTROL - Separate export rights | CSV can expose sensitive data. | View does not automatically mean Export. |
| KPI dictionary | MISSING - Standard definitions | Prevent disagreement over numbers. | Definition for Active Student, Collection, Outstanding, Attendance Rate etc. |
| Data freshness | MISSING - As-of timestamp | Makes dashboards trustworthy. | Show last refresh/data through date. |
| Drill-down | ENHANCE - Make every KPI actionable | Dashboard numbers should lead somewhere. | Click outstanding fees -> relevant invoices. |
| Campus comparison | MISSING - Multi-campus intelligence | Key SaaS differentiator. | Compare enrollment, fees, attendance, results and staff utilization. |
| Cohort analytics | MISSING - Compare groups over time | Academic improvement. | Class/section/gender/etc. only where privacy/appropriateness is satisfied. |
| Admission analytics | MISSING - Funnel analytics | Commercial insight. | Leads -> applications -> admissions. |
| Fee analytics | MISSING - Aging/collection forecasting | Owner insight. | Collection rate, overdue trends and expected collections. |
| Academic analytics | MISSING - Performance trends | School improvement. | Subject/class/teacher/assessment trend. |
| Teacher workload analytics | MISSING - Staff utilization | Scheduling/management. | Workload and substitutions. |
| School Command Center | STRATEGIC - Upgrade dashboard dramatically | This could become signature functionality. | Needs Attention queue: fee defaulters, attendance risk, admissions pending, results awaiting approval, bus issues, contracts expiring, notifications failed etc. |

## 25. Workflow automation and rules engine - perhaps the strongest strategic opportunity

This is the area that can transform the product from many modules into a genuine operating platform. A practical architecture is: Event -> Rule -> Conditions -> Actions -> Task/Notification/Domain Change -> Audit, rather than independent scheduled jobs for every feature.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Rules engine | MISSING - Trigger-condition-action framework | Avoid custom code for every automation. | Example: Attendance finalized -> Student absent -> Notify guardian. |
| Approval builder | MISSING - Configurable routing | Schools differ. | For example: expense > 50,000 -> Principal + Owner; smaller -> accountant manager. |
| Notification rules | MISSING - Configurable events | Makes system proactive. | Fee due, absence, result publish, document expiry, vehicle fitness expiry etc. |
| Task engine | MISSING - System/user tasks | Automation needs follow-up ownership. | Task, owner, due date, priority, linked record and completion. |
| Escalations | MISSING - SLA/escalation rules | Prevent ignored tasks. | Overdue task -> manager alert. |
| Exception queues | MISSING - Action-oriented problem lists | Better than passive reports. | Missing documents, unmatched payments, timetable conflicts, attendance gaps, failed notifications etc. |
| Automation history | MISSING - Traceability | Users need trust. | Rule triggered, records affected, action result and failure reason. |
| Dry-run | MISSING - Preview bulk automation | Prevent accidental mass changes. | Particularly billing, promotion, late fees, notifications and rollover. |
| Idempotency | MISSING - Safe retries | Background tasks will fail/retry. | Same run must not generate duplicate invoices/messages/postings. |
| Workflow templates | STRATEGIC - Reusable preconfigured automations | Great onboarding benefit. | Fee Reminder Workflow, Absence Escalation, Admission Document Chase, etc. |

## 26. Multi-campus and school-group management

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Central policies | MISSING - School-wide defaults with campus overrides | Multi-campus operation needs governance. | Fee, grading, attendance, academic policies can inherit from tenant with authorized overrides. |
| Campus transfer | ENHANCE - Existing transfer should preserve full history | Essential for school groups. | Student remains same person while enrollment moves. |
| Central curriculum | ENHANCE - Shared academic setup | Avoid duplicate data. | Define centrally, assign campuses/classes. |
| Central fee templates | MISSING - Reusable structures | Easier setup. | Common fee structure cloned/overridden by campus. |
| Central HR | ENHANCE - Employee cross-campus assignment | Teachers may work in multiple campuses. | Employment home campus + assignments. |
| Campus comparison | MISSING - Executive dashboard | School owners need group view. | Enrollment, attendance, collections, results, staffing, expenses. |
| Franchise model | STRATEGIC - Future option | Could open another market. | Head-office configuration + franchise-specific tenant policies, only if business model requires it. |

## 27. SaaS subscriptions, platform owner and monetization

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Subscription quotas | ENHANCE - Expand current trial display | Current plan already shows limits. | Real-time Students X/500, Users X/75, Campuses X/3, storage, messages etc. |
| Feature entitlements | MISSING - Plan-level feature flags | Enables SaaS packaging. | CanUseHostel, CanUsePayroll, etc. through a proper entitlement system, not scattered checks. |
| Add-ons | MISSING - Modular upgrades | Better monetization. | Transport GPS, Accounting, Payroll, LMS, Advanced Assessments etc. |
| Trial handling | MISSING - Grace/read-only behavior | Do not lock schools out of critical records. | Trial expiry -> appropriate grace period and controlled read-only/export capability. |
| Upgrade flow | MISSING - Plan comparison | Improves sales. | Usage/feature gap -> upgrade CTA. |
| Platform owner dashboard | MISSING - SaaS operations console | Tenant admin is different from SchoolAdmin. | Tenants, subscriptions, usage, revenue, health, job failures, notifications, storage and support cases. |
| Tenant onboarding | MISSING - Guided creation | Reduces implementation cost. | School -> campuses -> academic year -> classes -> fees -> users -> import -> go-live checklist. |
| White labeling | MISSING - Premium capability | Stronger for larger customers. | Logo, colors, email identity, custom subdomain/domain, branded documents. |
| Custom domain | STRATEGIC - Premium plan | Valuable for established schools. | For example: portal.school.edu.pk with secure domain verification. |
| Tenant health | MISSING - SaaS success metrics | Helps customer success. | Setup completeness, active users, usage, failed integrations/jobs and expiring trial. |

## 28. Security and identity

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| MFA | MISSING - Missing in observed UI | Important for owner/finance/security roles. | TOTP/app or other appropriate MFA; enforce by role/tenant policy. |
| Passkeys | STRATEGIC - Modern authentication | Improves security/UX later. | Optional. |
| SSO | STRATEGIC - Enterprise feature | Useful for larger customers. | Microsoft/Google/OIDC/SAML depending target customers. |
| Sessions | ENHANCE - Expand revoke-session capability | Existing user security is a good start. | Active sessions, device/browser, last activity and revoke. |
| Privileged alerts | MISSING - Security notifications | Detect risky administrative actions. | Role elevation, password reset, bulk export, tenant/campus scope change. |
| Permission preview | MISSING - Effective permissions | 135 checkboxes can become unmanageable. | Show final calculated permissions from all roles. |
| Permission dependencies | MISSING - Prevent invalid combinations | For example edit without view. | Warn or automatically include dependencies. |
| Custom roles | ENHANCE - Extend role model | Built-in roles exist. | Tenant-defined roles cloned from templates. |
| Test-as-role | STRATEGIC - Admin preview | Helps configuration. | Secure role simulation without becoming another user. |
| Support impersonation | MISSING - SaaS support tool | Customer support often needs it. | Explicit reason, limited duration, visible banner and immutable audit. |
| Data export governance | FIX/CONTROL - Export controls | Existing CSV links increase risk. | Permission, reason, logging, optional masking/watermark and expiry for generated files. |

## 29. APIs, integrations and ecosystem

No visible integration platform appears in the review, while interoperability is increasingly a major differentiator in established school platforms.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Public API | MISSING - Controlled tenant API | Future-proofs the product. | Versioned API, scoped authentication, rate limits and audit. |
| Webhooks | MISSING - Event integration | External systems need real-time changes. | Student created, payment received, attendance marked, result published etc. |
| API keys/apps | MISSING - Integration credentials | Avoid sharing user passwords. | App registration, scopes, secrets rotation and revocation. |
| Integration framework | MISSING - Provider adapters | Prevent tight coupling. | SMS, WhatsApp, email, payment, GPS, biometric providers implement standard interfaces. |
| Microsoft/Google | STRATEGIC - Productivity integration | Attractive for modern schools. | Identity/calendar/classroom storage depending customer demand. |
| Accounting export | STRATEGIC - External accounting | Smaller schools may retain accounting product. | Configurable export/integration rather than forcing internal accounting. |
| Integration marketplace | STRATEGIC - Mature SaaS capability | Ecosystem advantage. | Installed integrations by tenant with configuration/health status. |

## 30. Data import, migration and bulk operations

This is commercially more important than it appears. A school buying your system already has students somewhere - Excel or another SMS.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Import wizard | MISSING - General import framework | Customer onboarding depends on it. | Upload -> map columns -> validate -> preview -> import -> downloadable errors. |
| Student import | MISSING - Bulk student migration | Large onboarding savings. | Include guardian/household relationship support. |
| Fee balances | MISSING - Opening receivables import | Needed mid-year migration. | Preserve opening balance separately from generated invoices. |
| Historical results | MISSING - Optional academic history import | Schools may require it. | Support simplified historical transcript import. |
| Employees | MISSING - Staff migration | HR onboarding. | Templates and validation. |
| Library inventory | MISSING - Book import | Libraries may have thousands of records. | ISBN/accession/copy import. |
| Bulk edit | MISSING - Generic bulk operation framework | Admin productivity. | Controlled field-specific updates with preview/audit. |
| Data export | ENHANCE - Comprehensive tenant export | Builds customer trust. | Authorized export of school's own structured data. |
| Migration audit | MISSING - Import batch history | Troubleshooting. | Who imported what, row counts, errors and rollback where safe. |

## 31. Self-service customization - essential for scalable SaaS

Long-term SaaS principle: a school-specific difference should become configuration whenever practical, not another code branch.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Custom fields | MISSING - Tenant-defined fields | Eliminates many custom requests. | Apply to Student, Guardian, Employee, Admission etc. |
| Form builder | MISSING - Custom forms | Very powerful differentiator. | Fields, sections, validations, audience, workflow and acknowledgements. |
| Report builder | MISSING - Self-service reports | Reduces development workload. | Curated safe datasets rather than direct DB access. |
| Dashboard widgets | MISSING - Configurable dashboards | Different roles care about different KPIs. | Widget library with permissions. |
| Saved views | MISSING - User views/filters | Small but highly useful. | Save student/fee/attendance filter sets. |
| Document templates | ENHANCE - Extend certificate concepts | Many school documents follow same pattern. | Letter, receipt, report card, admission offer, transfer letter etc. |
| Numbering schemes | MISSING - Configurable sequences | Schools have different numbering. | Admission numbers, invoices, receipts, vouchers, certificates by campus/year. |

## 32. Navigation, usability and productivity

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Global search | MISSING - Search across application | Major usability improvement. | Student, guardian, employee, invoice, receipt, book etc. |
| Command palette | STRATEGIC - Modern power-user UX | Speeds frequent actions. | Search Add Student, Collect Fee, Mark Attendance. |
| Role home pages | MISSING - Role-specific dashboard | Principal is not accountant is not teacher. | Same platform but different operational priorities. |
| Recent items | MISSING - Quick navigation | Helps administrative users. | Recently accessed students/invoices/etc. |
| Favorites | MISSING - User shortcuts | Reduce menu complexity. | Pin common screens/reports. |
| Empty states | ENHANCE - Improve setup guidance | Review noted empty dependent selectors. | Explain prerequisite and provide direct Create Class link. |
| Accessibility | FIX/CONTROL - Needs functional verification | Not tested by read-only review. | Keyboard, focus, screen reader, contrast, zoom, validation and RTL testing. |
| Responsive/mobile | FIX/CONTROL - Needs testing | Not verified. | Prioritize teacher/parent/student/account collection workflows. |
| Autosave | MISSING - Long forms | Admission/lesson plan forms can lose work. | Draft/autosave and recovery where appropriate. |

## 33. Customer support and product operations

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Help Center | ENHANCE - Expand existing 20 articles | Existing foundation is good but coverage is limited. | Add HR, finance, library, transport, hostel, assurance, payroll etc. |
| Contextual help | ENHANCE - Deep-link help | Good SaaS UX. | ? opens help for current screen/action. |
| Guided onboarding | MISSING - Setup checklist | Helps new tenants self-activate. | Percentage complete and next required task. |
| Product tours | MISSING - Optional guided walkthrough | Useful for complex modules. | Short role-specific walkthroughs. |
| Release notes | MISSING - In-app What's New | SaaS customers need change awareness. | Version/date/features/action required. |
| In-app feedback | MISSING - Feedback/bug capture | Improves product discovery. | Include screen/module and optional screenshot/log context. |
| Support tickets | MISSING - Customer support workflow | Important as tenants grow. | Tenant/user/module/severity/status/conversation. |
| Status/incident communication | MISSING - SaaS operational transparency | Helpful during outages. | Service incident announcements to tenant admins. |
| Feature usage analytics | MISSING - Product analytics | Helps decide development priorities. | Which tenants use modules/features; avoid collecting unnecessary personal data. |

## 34. Alumni, advancement and community

This should come after the operational core unless target customers explicitly demand it.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Alumni directory | MISSING - Beyond Alumni status | Extends student lifecycle. | Cohort, contact, education/employment and communications. |
| Alumni events | MISSING - Community engagement | Useful for mature schools. | Event registrations and communications. |
| Donations/fundraising | STRATEGIC - Long-term premium capability | Relevant for some institutions. | Campaigns, pledges, donations, receipts and donor history. |
| Community groups | STRATEGIC - Parent/alumni/student communities | Optional advanced feature. | Groups, announcements/events and controlled membership. |

## 35. AI and intelligent assistance - after the core is trustworthy

AI should be Level 4 of the product, not the layer hiding incomplete Level 1-3 workflows.

| Area | Feature / Current Gap | Why it matters | Details |
| --- | --- | --- | --- |
| Natural-language reporting | STRATEGIC - AI analytics assistant | Makes complex reporting accessible. | For example: Show Grade 8 students below 75% attendance with declining Math results. Permission scope must be enforced before querying data. |
| Communication drafting | STRATEGIC - AI writing assistant | Saves staff time. | Draft fee reminder, notice, teacher feedback etc.; staff reviews before sending. |
| Quiz generation | STRATEGIC - Teacher assistant | Leverages existing Question Bank. | Generate draft questions by grade/unit/outcome/difficulty, never auto-publish. |
| Lesson-plan assistant | STRATEGIC - Academic productivity | Uses curriculum context. | Draft objectives/activities/resources for teacher review. |
| Data summaries | STRATEGIC - Principal assistant | Useful executive capability. | Summarize trends and exceptions with links to underlying data. |
| Timetable suggestions | STRATEGIC - Constraint assistance | Could augment auto scheduler. | Recommend - not silently change - schedules. |
| Fee collection insights | STRATEGIC - Collections intelligence | Highlights patterns. | Explainable segmentation; avoid automatic punitive decisions. |
| Student intervention signals | STRATEGIC - Academic support | Combine attendance/assignments/results. | Flag patterns for educator review; never present AI as definitive diagnosis or disciplinary decision. |
| Help assistant | STRATEGIC - Product support chatbot | Reduces training/support cost. | Ground answers in the application's current help/documentation. |

## 36. The connected workflows I would ultimately expect

This is where the preceding capabilities become a connected school operating platform rather than separate modules.

| Workflow | Connected flow |
| --- | --- |
| Admission | Inquiry -> Application -> Documents -> Test/Interview -> Offer -> Acceptance -> Admission Fee -> Student + Household Created -> Class Assignment -> Parent Portal -> Welcome Communication |
| Daily attendance | Teacher My Day -> Class Attendance -> Finalize -> Absence Rules -> Parent Notification -> Consecutive Absence Check -> Intervention Task |
| Academic teaching | Curriculum -> Learning Outcome -> Lesson Plan -> Timetable -> Lesson Delivered -> Homework/Assessment -> Gradebook -> Intervention -> Report Card |
| Monthly fee | Fee Structure -> Scheduled Billing Preview -> Invoice -> Parent Notification -> Payment -> Reconciliation -> Receipt -> GL Posting -> Aging/Defaulter Workflow |
| Teacher leave | Leave Request -> Approval -> Affected Timetable Detected -> Available Substitute Suggested -> Substitute Assigned -> Teacher Notified -> Workload Updated |
| Transport | Student Assignment -> Route/Stop -> Fee Charge -> Daily Boarding -> Parent Alert -> School Arrival -> Return Boarding -> Drop Notification |
| Student transfer | Transfer Request -> Clearance: Fees + Library + Hostel + Assets -> Approval -> Transfer Certificate -> Enrollment History Updated -> Portal/Access Changed |
| Procurement | Purchase Request -> Budget Check -> Approval -> Quotations -> PO -> Goods Receipt -> Inventory/Asset -> Supplier Invoice -> Accounts Payable -> Payment -> Reconciliation |

## Recommended implementation order for Codex

Do not ask Codex to attack the complete catalogue as independent tickets. Implement coherent vertical slices in a deliberate sequence so that foundational controls and shared services are built once and reused by later modules.

| Sequence | Implementation Wave | What I would complete |
| --- | --- | --- |
| Wave 0 | Stability & security | 500/503 diagnostics, tenant isolation, campus access, audit redaction, backup assurance, common errors/validation. |
| Wave 1 | Core configuration | Global campus/year context, School Settings, master data, grading, rooms, academic year lifecycle. |
| Wave 2 | Admissions -> Student -> Family | Admissions CRM, online application, household/guardian model, Student 360, documents, enrollment workflow. |
| Wave 3 | Parent/Student experience | Parent portal, student portal, forms, consents, notifications, PWA/mobile experience. |
| Wave 4 | Attendance & daily operations | Unmarked-state fix, period attendance, alerts, correction workflow, teacher My Day, substitute flow. |
| Wave 5 | Academics | Master timetable, curriculum/outcomes, gradebook, homework improvements, report cards/transcripts. |
| Wave 6 | Fees | Recurring billing, concessions, installments, payment/reconciliation, refund/credits, family statements, defaulter workflow. |
| Wave 7 | Communications & automation | WhatsApp/provider layer, notification center, workflow/rules engine, tasks and exception queues. |
| Wave 8 | Student life & safety | Health/clinic, behavior, counseling, clubs, sports, trips, visitor/pickup/gate controls. |
| Wave 9 | Operational modules | Transport live operations, hostel enhancements, library barcode/reservation, canteen if commercially justified. |
| Wave 10 | HR/Payroll/ERP | Employee workflows, payroll depth, procurement, assets, maintenance, AP and accounting integration. |
| Wave 11 | SaaS platform | Entitlements, white label, tenant onboarding, support impersonation, SSO/MFA, API/webhooks/integration framework. |
| Wave 12 | Intelligence | Command Center, report builder, analytics and only then AI/copilot capabilities. |

## Where the product stands now

The current application is best characterized as a broad functional ERP/SMS foundation with many modules already represented, but several workflows remain closer to administrative CRUD plus reports than fully connected operational processes. This is a favorable position: the product does not need to be restarted. The highest-value transformations are Student + Household 360, Admissions CRM, full Parent/Student portals, a recurring Fee + Payment/Reconciliation engine, Teacher My Day + Gradebook, Health/Behavior/Student Support, Master Scheduling, Workflow/Rules Automation, a School Command Center, and mature SaaS configuration/integrations.

If those areas are implemented well on top of the substantial modules already present, the result moves from a broad school-management application toward a genuinely integrated school operating platform. The design objective should be simple: data entered once should automatically drive every relevant downstream process.

## Source basis and sharing notes

SMS_Product_Review.md / SMS_Product_Review.docx - read-only product review dated 18 September 2026.

SMS_UI_Inventory.md / SMS_UI_Inventory.docx - read-only inventory of observed screens, controls, fields and tables dated 18 September 2026.

External product-direction references used in the original recommendation included publicly available PowerSchool/Blackbaud materials concerning SIS, family portals, scheduling, health/behavior, activities and integrations. These external references were used only to inform broader product-direction comparisons; the gap classifications in this document are grounded primarily in the supplied SMS review documents.



---

## 10. Instructions for Continuing in Another ChatGPT/Codex Account

For best continuity, upload these files to the new account/session:

1. `SMS_Product_Improvement_Conversation_Archive.md` — this document
2. `SMS_Codex_Project_Context_Master.md`
3. `SMS_UI_Inventory.md`
4. `SMS_Product_Review.md`
5. `SMS_Final_Recommendation_and_Codex_Roadmap.docx`
6. the actual source repository

Then use this prompt:

> Read `SMS_Codex_Project_Context_Master.md` and `SMS_Product_Improvement_Conversation_Archive.md` fully before proposing implementation. Treat the existing application as a broad production codebase, not a greenfield build. Inspect the repository/database and classify the requested work as FIX, ENHANCE, VERIFY, MISSING, or STRATEGIC before writing code. Do not duplicate an existing module just because the prior read-only UI review did not expose it. Preserve tenant/campus isolation, auditability, historical integrity, idempotency, correction/reversal workflows and the Wave 0–12 roadmap.
